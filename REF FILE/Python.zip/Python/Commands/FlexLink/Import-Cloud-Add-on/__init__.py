from vcApplication import * 
  
def OnAppInitialized(): 
  cmduri = getApplicationPath() + 'cmdPointImport.py'
  cmd = loadCommand('cmdPointImport', cmduri)
  iconuri = getCommandPath() + 'rPythonCommandRemoveHoles.svg'
  addMenuItem('FLLayoutTab/VcRibbonImport', 'Import cloud', -1, 'cmdPointImport',iconuri) 
  #addMenuItem('FLCoreDebugTab/PyhtonCommands', 'Import cloud', -1, 'cmdPointImport',iconuri) 
  #addMenuItem('FLBetaTab/FLBetaGroup', 'Import cloud', -1, 'cmdPointImport',iconuri)
