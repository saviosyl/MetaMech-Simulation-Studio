from vcCommand import *
from vcScript import * 
from vcHelpers.Application import * 
import os

cmd = getCommand()
app = cmd.Application
panel = app.PythonActionPanel 

#Define link
filepathProp = createProperty(VC_URI, 'File')
#Possible to add filter for URI in python?

#Define Scale
ScaleFactor = cmd.createProperty(VC_REAL, "Scale Factor")
ScaleFactor.Value = 1000

#Define Point size
PointSize =  cmd.createProperty(VC_REAL, "Point Size")
PointSize.Value = 3.0

#Define RGB Mode
ColorConfig = cmd.createProperty(VC_STRING, 'Color Configuration',VC_PROPERTY_STEP)
ColorConfig.StepValues = ['RGB','BGR']
ColorConfig.Value = ColorConfig.StepValues[0]

#Define Button
ImportButton =  cmd.createProperty(VC_BUTTON, "Import")

def OnStart():
  executeInActionPanel()  
  open_dialog = app.findCommand('dialogOpen')
  open_dialog.OnPostExecute = setURI
  open_dialog.Param_3 = 'ASCII Point Cloud (*.pts)|*.pts'
  open_dialog.execute()

def setURI(open_dialog):
  open_dialog.OnPostExecute = None
  if not open_dialog.Param_2:
    return
  filepathProp.Value = open_dialog.Param_1[8:]
  #print path.split()

def createFeaturePointSet(comp,name):
  feat = comp.RootFeature.createFeature(VC_GEOMETRY, name)
  point_set = feat.Geometry.createGeometrySet(VC_POINTSET)
  if ColorConfig.Value == ColorConfig.StepValues[0]:
    point_set.ColorConfiguration = VC_COLOR_CONFIGURATION_RGBA
  else:
    point_set.ColorConfiguration = VC_COLOR_CONFIGURATION_BGRA
  point_set.PointSize = PointSize.Value
  return point_set

def read_file(open_dialog):
  #pointsets are limited to maximum 16777215 points, therefore multiple features needs to be created

  #get filename use to name import
  filename =  os.path.basename(filepathProp.Value).split(".")[0]
  comp = app.findComponent(filename)
  if comp:
    app.deleteComponent(comp)
  
  with open(filepathProp.Value, 'r') as fp:
    num_lines = sum(1 for line in fp if line.rstrip())

  featureMaxPoints = 16777215
  featureCount = 0
  count = 0

  comp = app.createComponent()
  comp.Name = filename
  point_set = createFeaturePointSet(comp,'cloud_'+str(featureCount))
  with open(filepathProp.Value, 'r') as file:
    for line in file:
      if count >= featureMaxPoints:
        point_set.update()
        featureCount += 1
        point_set = createFeaturePointSet(comp,'cloud_'+str(featureCount))
        count = 0
      line = line.replace('\n','')
      args = line.split(' ')
      try:
        x = float(args[0]) * ScaleFactor.Value
        y = float(args[1]) * ScaleFactor.Value
        z = float(args[2]) * ScaleFactor.Value
        
        r = float(args[4]) / 255.0
        g = float(args[5]) / 255.0
        b = float(args[6]) / 255.0
        
        point_set.addPoint(x, y, z, r, g, b)
        count +=1
        UpdateProgress(count+featureCount*featureMaxPoints,num_lines)  
      except:
        continue

  progressStdMessage(num_lines,num_lines)  

  endMessage('Import Complete')  
  point_set.update()
  comp.rebuild()
  app.render()
  
def cleanFilePath(arg):
  if "file://" in filepathProp.Value:
    filepathProp.Value = filepathProp.Value[8:]

ImportButton.OnChanged = read_file
filepathProp.OnChanged = cleanFilePath

def UpdateProgress(count,Max):
  #Update every full percent
  percent = Max/100
  if count % percent == 0:
    progressStdMessage(count,Max)

def OnCloseMethodCalled():
  pass 
  #print "Python action panel closed!" 
  
panel.OnPanelClosed = OnCloseMethodCalled

addState(None)