from vcCommand import * 
from vcHelpers.Selection import *
import vcMatrix 

cmd = getCommand()
app = cmd.Application
comp = None
nbrX = cmd.createProperty(VC_INTEGER, "Number X")
dispX = cmd.createProperty(VC_REAL, "Displacement X")
dispX.Quantity = "Distance"
nbrY = cmd.createProperty(VC_INTEGER, "Number Y")
dispY = cmd.createProperty(VC_REAL, "Displacement Y")
nbrZ = cmd.createProperty(VC_INTEGER, "Number Z")
dispZ = cmd.createProperty(VC_REAL, "Displacement Z")
cloneButton = cmd.createProperty(VC_BUTTON, "Clone")

def first_state():
  nbrX.Value = 1
  nbrY.Value = 1
  nbrZ.Value = 1
  dispX.Value = 1000
  dispY.Value = 1000
  dispZ.Value = 1000
  executeInActionPanel()

def OnRespond(args):
  newComps = []
  compListOrg = app.SelectionManager.getSelection(VC_SELECTION_COMPONENT)
  first = True
  x = 1
  y = 1
  z = 1
  totalClones = 0
  compListNew = []
  while totalClones < (nbrX.Value*nbrY.Value*nbrZ.Value-1):
    x += 1
    if x > nbrX.Value:
      x = 1
      y += 1
      if y > nbrY.Value:
        y = 1
        z += 1
        if z > nbrZ.Value:
          continue
    for comp in compListOrg:
      if comp.Parent in compListOrg:
        continue
      newComp = comp.clone()
      compListNew.append(newComp)
      newComp.update()
      if first:
        copyDisPX = newComp.PositionMatrix.P.X - comp.PositionMatrix.P.X
        copyDisPY = newComp.PositionMatrix.P.Y - comp.PositionMatrix.P.Y
        copyDisPZ = newComp.PositionMatrix.P.Z - comp.PositionMatrix.P.Z
        first = False
      mtx = vcMatrix.new(newComp.PositionMatrix)
      mtx.translateAbs(-copyDisPX+dispX.Value*(x-1),-copyDisPY+dispY.Value*(y-1),-copyDisPZ+dispZ.Value*(z-1))
      newComp.PositionMatrix = mtx
      newComp.update()
    app.SelectionManager.clear()
    app.SelectionManager.setSelection(compListNew)
    com = app.findCommand('GroupSelectedFeatures')
    com.execute()
      
    totalClones += 1
addState(first_state)
cloneButton.OnChanged = OnRespond