from vcApplication import *

def OnStart():
  cmduri = getApplicationPath() + "LinearClone.py"
  deleteCommand("LinearClone")
  cmd = loadCommand("LinearClone",cmduri)
  app = cmd.Application
  #localize = findCommand("netCommand") 
  #localize.execute("SetLocalizationCommand", "English", "Python", "LinearClone", "Tooltip", "Linear clone of objects") 
  #localize.execute("SetLocalizationCommand", "German", "Python", "LinearClone", "Text", "Linear clone of objects") 
  #addMenuItem("VcTabHome/VcRibbonTools", "LinearClone", -1, "LinearClone")
  addMenuItem("FLCoreDebugTab/PyhtonCommands", "LinearClone", -1, "LinearClone")
 