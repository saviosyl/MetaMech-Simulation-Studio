from vcCommand import *
from vcHelpers.Selection import *
from vcHelpers.Application import *


app = getApplication()

localize = app.findCommand('netCommand')

#EndDrives and Idlers
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::IncludeMotor','Description', 'Option to include a configurable motor.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::Size', 'Description', 'Defines the size of the component.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::ProtectiveCover','Description', 'Option for a protective cover to avoid pinch points.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::CoverPlate','Description', 'Option for visualization of the cover plate.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::MotorPosition','Description', 'Defines the position of the motor.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::MotorRotation','Description', 'Defines the rotation of the motor.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::Suspended','Description', 'Option for suspended drive')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::Guided','Description', 'Option for guided drive.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::SlipClutch','Description', 'Option for slip clutch')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::SupportWheel','Description', 'Option for support wheel')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::InvertedInsert', 'Description', 'Flips the orientation of the interfaces. Only needed in specific cases.')

localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Process::Speed', 'Description', 'Defines the speed of the conveyor. If configured the speed is set to match the configuration.')

#Beams
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::Length', 'Description', 'Defines the length of the component.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::Type', 'Description', 'Defines the type of the component.')

#Bends
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::BendDirection', 'Description', 'Defines the direction of the bend.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::Angle', 'Description', 'Defines the angle of the bend.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::CustomAngle', 'Description', 'Defines the custom angle of the bend.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::CustomAngleOption', 'Description', 'Custom angle option.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::Radius', 'Description', 'Defines the radius of the bend.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::TYPBendOption', 'Description', 'Custom angle and radius options.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::BeamLengthIn', 'Description', 'Modify the straight section of the bend. Cutting will be required.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::BeamLengthOut', 'Description', 'Modify the straight section of the bend. Cutting will be required.')

#Supports
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::SupportConnector', 'Description', 'Defines the connector for the support.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::Foot Type', 'Description', 'Defines the foot type of the support.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::Foot', 'Description', 'Defines the foot type of the support.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::SupportBeamSize', 'Description', 'Defines the size of the support beam.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::FloorLevel', 'Description', 'Set an offset for the floor level. The length of the support will be recalculated to match the new heigth.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::FloorAttachementBracket', 'Description', 'Option for attachement bracket.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::AnchoringPoints', 'Description', 'Option for anchoring points.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::VibrationAbsorber', 'Description', 'Option for vibration absorber.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::IncludeExtraFasteners', 'Description', 'Include extra fasteners on additional lanes, assuming hook and screws.')

#GuideRails
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::RemoveLeftBracket', 'Description', 'Option to remove the left bracket. Note that both brackets cannot be removed.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::RemoveRightBracket', 'Description', 'Option to remove the left bracket. Note that both brackets cannot be removed.')

#Feeders
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Process::Feeding Interval', 'Description', 'Defines if feeding should be based on parts per minute, an even interval or a distribution.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Process::PartsPerMinute', 'Description', 'Defines the number of parts per minute to feed.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Process::Interval', 'Description', 'Defines the interval between products.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Process::Feeding Mode', 'Description', 'Defines if the feeding should be infinite or a certain number of products.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Process::MaxNumber', 'Description', 'Defines the number of products to feed.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Process::NumberOfPallets', 'Description', 'Defines the number of pallets to feed.')

localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Product::IncludeProduct', 'Description', 'Option to include product on top of pallet')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Product::Shape', 'Description', 'Seelct a shape of the product from a list of basic shapes.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Product::Material', 'Description', 'Define the material of the product.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Product::ProductLength', 'Description', 'Define the length of the product.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Product::ProductWidth', 'Description', 'Define the width of the product.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Product::ProductHeight', 'Description', 'Define the height of the product.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Product::FlexLinkLogo', 'Description', 'Option for a FlexLink logo on a product. Note only for products based on the basic shapes.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Product::PickPart', 'Description', 'Pick any geometry in the 3D world to use as product. Note that the zero position of the geometry needs to be in the bottom centre.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Product::ClearPart', 'Description', 'Remove the selected geometry for feeding.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Product::OffsetDirection', 'Description', 'Define the offset direction, to compensate zero point of a selcted geomtry.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Product::OffsetLength', 'Description', 'Define offset length, to compensate zero point of a selcted geomtry.')

#HU
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::PalletStop', 'Description', 'Defines the type of stop unit on the module.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::StopType', 'Description', 'Defines the type of stop unit on the module.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::StopUnit', 'Description', 'Defines the stop unit size on the module.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::QueueDamperUnits', 'Description', 'Defines the number of queue dampers for the module.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::ExtraQueueDamper', 'Description', 'Option for having an extra damper on each damper unit.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::SpeedBooster', 'Description', 'Option for speed booster.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::RFID', 'Description', 'Option for RFID.')

localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Options::Prestop', 'Description', 'Option to add a stop module upstream.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Options::Prestop Main', 'Description', 'Option to add a stop module on the main conveyor.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Options::Prestop Transfer', 'Description', 'Option to add a stop module on the transfer conveyor.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Options::Sensor', 'Description', 'Option to add a max queue sensor.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Options::Sensor Main', 'Description', 'Option to add a max queue sensor on the main conveyor.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Options::Sensor Transfer', 'Description', 'Option to add a max queue sensor on the transfer conveyor.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Options::SCDC', 'Description', 'Option to add and connect a SCDC to the module.')

#X45P
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'Process::DiscSpeed', 'Description', 'Unit is rpm.')

#Statistics
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::ShowTotalProduction', 'Description', 'Total number of parts passed.')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::ShowUnitProduction', 'Description', 'Number of parts passed during the last unit [min/hour/day].')
localize.execute('SetLocalizationCommand', 'English', 'ComponentWrapper', 'FlexLink::ShowAverageUnitProduction', 'Description', 'Average for the selected unit [min/hour/day] for the entire duration of the simulation.')