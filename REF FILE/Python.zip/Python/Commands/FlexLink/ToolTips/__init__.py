from vcApplication import *

def OnStart():
  # Commands:
  loadCommand("ToolTip", getApplicationPath() + 'tooltip.py')

