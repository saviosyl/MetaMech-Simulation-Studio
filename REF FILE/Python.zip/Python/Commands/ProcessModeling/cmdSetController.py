from vcCommand import *
import vcMatrix, vcVector
from vcHelpers.Output import *
cmd = getCommand()
app = cmd.Application
key = "ComboKey::Python.PMClearLinks.FlowGroup.SelectGroup"
localized_string = app.getLocalizedString(key)
if key == localized_string:
  localized_string = 'Select Group'
SELECT_GROUP = '<{}>'.format(localized_string)
key = "ComboKey::Python.PMClearLinks.ClearLinks.All"
localized_string = app.getLocalizedString(key)
if key == localized_string:
  localized_string = 'All'
ALL = '{}'.format(localized_string)
key = "ComboKey::Python.PMClearLinks.ClearLinks.Empty"
localized_string = app.getLocalizedString(key)
if key == localized_string:
  localized_string = 'Empty'
EMPTY = '{}'.format(localized_string)

def first_state(): 
  global button, selected_flow_group, process_controller, selected_implementer, new_implementer, transfer_props, work_stmts, transport_system
  sim = cmd.Simulation
  process_controller = sim.ProcessController
  transport_system = process_controller.TransportSystem 
  flow_group_manager = process_controller.FlowGroupManager 
 
  tcs = []
  for tc in transport_system.Controllers:
    if tc.IsSystem: 
      tcs.append(tc.Name)
    else: 
      tcs.append(tc.Component.Name)

  flow_groups = flow_group_manager.Groups

  pname = 'FlowGroup'
  selected_flow_group = createProperty(VC_STRING, pname, VC_PROPERTY_STEP)
  selected_flow_group.StepValues = [SELECT_GROUP, ALL] + [x.Name for x in flow_groups]
  selected_flow_group.Value = selected_flow_group.StepValues[0]
  selected_flow_group.OnChanged = updateselected

  pname = 'CurrentImplementer'
  selected_implementer = createProperty(VC_STRING, pname, VC_PROPERTY_STEP)
  selected_implementer.StepValues = []
  # Values = tcs[:]
  # Values.insert(0,EMPTY)
  # selected_implementer.StepValues = Values
  # selected_implementer.Value = Values[0]

  pname = 'NewImplementer'
  new_implementer = createProperty(VC_STRING, pname, VC_PROPERTY_STEP)
  new_implementer.StepValues = tcs
  new_implementer.Value = tcs[0]

  pname = 'CopyPropertyValues'
  transfer_props = createProperty(VC_BOOLEAN, pname)
  transfer_props.Value = True

  pname = 'IncludeWorkStatements'
  work_stmts = createProperty(VC_BOOLEAN, pname)
  work_stmts.Value = False

  pname = 'Change'
  button = createProperty(VC_BUTTON, pname)
  button.OnChanged = apply
  executeInActionPanel()


def updateselected(sel_group):
  global button, selected_flow_group, selected_implementer, new_implementer, transport_system
  
  if selected_flow_group.Value == SELECT_GROUP:
    links = []
  elif selected_flow_group.Value == ALL:
    links = transport_system.Links
  else:
    links = [l for l in transport_system.Links if l.SupportedGroup.Name == selected_flow_group.Value]

  # implementers = set((l.Implementer for l in links)) # vcTransportController unhashable 
  implementers = []
  for link in (l for l in links if l.Implementer not in implementers):
    implementers.append(link.Implementer)

  if None in implementers:
    idx = implementers.index(None)
    implementers[idx] = NoneImplementer()

  step_values = map(lambda i: i.Component.Name if i and i.Component else i.Name, implementers)
  step_values.sort()
  selected_implementer.StepValues = step_values

  if step_values and selected_implementer.Value not in step_values:
    selected_implementer.Value = step_values[0]


def apply(arg):  
  global button, selected_flow_group, process_controller, selected_implementer, new_implementer

  if selected_flow_group.Value == SELECT_GROUP: 
    error ('Please select a Flow Group')
    return

  transport_system = process_controller.TransportSystem 
  tcs = transport_system.Controllers

  if selected_implementer.Value != EMPTY:
    current_tc = [tc for tc in tcs if tc.Name == selected_implementer.Value or tc.Component and tc.Component.Name == selected_implementer.Value][0]
  else:
    current_tc = None
  
  new_tc = [tc for tc in tcs if tc.Name == new_implementer.Value or tc.Component and tc.Component.Name == new_implementer.Value][0]

  swap_links = [l for l in transport_system.Links if l.Implementer == current_tc]
  if selected_flow_group.Value != ALL:
    swap_links = [l for l in swap_links if l.SupportedGroup.Name == selected_flow_group.Value] # filter based on group

  builtin_props = ('Implementer', 'Source', 'Destination', 'SupportedGroup') # no need to store these properties

  for link in swap_links:
    if new_tc.Name == 'InterpolatingTransport':
      transport_system.createTransportLink(link.Source, link.Destination, new_tc, link.SupportedGroup)
      transport_system.deleteTransportLink(link)
      continue

    stored_link_props = dict([(p.Name, (p.Value, p.Type)) for p in link.Properties if p.Name not in builtin_props and p.WritableWhenConnected])
    link.Implementer = new_tc

    if not transfer_props.Value:
      continue

    # transfer property values
    for prop in link.Properties:
      stored_prop = stored_link_props.get(prop.Name, None)
      if not stored_prop:
        continue
      stored_prop_val, stored_prop_type = stored_prop
      if stored_prop_type == prop.Type:
        prop.Value = stored_prop_val

# Swapping all Work statement Controllers
  work_count = 0
  if work_stmts.Value:
    pgs = process_controller.ProcessManager.ProcessGroups
    routines = (r for group in pgs for r in group.Implementations)
    if selected_flow_group.Value != ALL:
      swap_link_comps = set()
      for l in swap_links:
        swap_link_comps.update((l.Source.Component, l.Destination.Component))
      routines = (r for r in routines if r.Program.Executor.Component in swap_link_comps)
    for routine in routines:
      for stmt in traverse_routine_statements(routine, VC_STATEMENT_WORK):
        if stmt.Controller == current_tc:
          stmt.Controller = new_tc
          work_count += 1

  info ('Controller changed to', len(swap_links), 'Transport Links and ', work_count, 'Work statements')

  updateselected(selected_flow_group)

def traverse_routine_statements(routine, stmt_type):
  stmts = []
  for statement in routine.Statements:
    stmts.extend(traverse_statements(statement, stmt_type))
  return stmts

def traverse_statements(statement, stmt_type):
  stmts = []
  if statement.Type == stmt_type:
    stmts.append(statement)
  elif statement.Scope:
    for sub_statement in statement.Scope.Statements:
      stmts.extend(traverse_statements(sub_statement, stmt_type))
  return stmts

class NoneImplementer(object):
  def __init__(self):
    self.Name = EMPTY
    self.Component = None

addState(first_state)

