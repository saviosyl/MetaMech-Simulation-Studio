from vcApplication import *

localize = findCommand('netCommand')

def OnStart():
  addUxSite('VcTabProcess/Transport Link Tools', 2)
  addUxSite('VcTabProcess/Helper Tools', 3)
  
  cmduri_clear_links = getApplicationPath() + 'cmdClearLinks.py'
  cmd_clear_links = loadCommand('PMClearLinks', cmduri_clear_links)
  addMenuItem('VcTabProcess/Transport Link Tools', 'Clear Links', -1, cmd_clear_links.Name)

  cmduri_autolink = getApplicationPath() + 'cmdAutoLink.py'
  cmd_autolink = loadCommand('PMAutoLink', cmduri_autolink )
  addMenuItem('VcTabProcess/Transport Link Tools', 'Autolink Process Steps', -1, cmd_autolink.Name)

  cmduri_setcontroller = getApplicationPath() + 'cmdSetController.py'
  cmd_setcontroller = loadCommand('PMSetController', cmduri_setcontroller)
  addMenuItem('VcTabProcess/Transport Link Tools', 'Set Link Controller', -1, cmd_setcontroller.Name)

  cmduri_createframe = getApplicationPath() + 'cmdCreateFrame.py'
  cmd_createframe = loadCommand('PMCreateFrame', cmduri_createframe)
  addMenuItem('VcTabProcess/Helper Tools', 'Create Frame', -1, cmd_createframe.Name)

  cmduri_create_signal = getApplicationPath() + 'cmdCreateSignal.py'
  cmd_create_signal = loadCommand('PMCreateSignal', cmduri_create_signal)
  addMenuItem('VcTabProcess/Helper Tools', 'Create Signal', -1, cmd_create_signal.Name)
  
  #For Create Property command
  cmduri_create_property = getApplicationPath() + 'cmdCreateProperty.py'
  cmd_create_property = loadCommand('PMCreateProperty', cmduri_create_property)
  addMenuItem('VcTabProcess/Helper Tools', 'Create Property', -1, cmd_create_property.Name)