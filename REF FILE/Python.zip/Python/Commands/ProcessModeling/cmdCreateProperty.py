from vcCommand import *
from vcHelpers.Selection import *
from vcHelpers.Output import *

SUPPORTED_PROPERTY_TYPES = {
'String'    : VC_STRING,
'Boolean'   : VC_BOOLEAN,
'Integer'   : VC_INTEGER,
'Real'      : VC_REAL
}

cmd = getCommand()
app = cmd.Application


def selection_changed():
  global current_selection
  current_selection = sel.getSelection(VC_SELECTION_COMPONENT)
  if len(current_selection)>0:
    cmd.Enabled = True
  else:
    cmd.Enabled = False

sel = app.SelectionManager
sel.OnSelectionChanged = selection_changed


def first_state(): 
  global button, prop1, prop2, current_selection

  pname = 'PropertyType'
  prop1 = createProperty(VC_STRING,pname,VC_PROPERTY_STEP)
  Values = [x for x in SUPPORTED_PROPERTY_TYPES] 
  prop1.StepValues = Values
  prop1.Value = Values[0]

  pname = 'PropertyName'
  prop2 = createProperty(VC_STRING,pname)

  pname = 'CreateProperty'
  button = createProperty(VC_BUTTON, pname)
  button.OnChanged = apply
  executeInActionPanel()


def apply(arg):  
  global button, prop1, prop2, current_selection
  
  if not current_selection:
    error ('No component(s) selected.')
    return

  property_name = prop2.Value
  if property_name == '':
    error ('Property name cannot be empty.')
    return
  elif ' ' in prop2.Value:
    error ('Property name contains spaces. Use "CamelCase" naming, for example "MyProperty_2", without quotation marks.')
    return
  elif not prop2.Value.replace('_','').isalnum():
    error ('Property name contains special characters.')
    return

  property_type = SUPPORTED_PROPERTY_TYPES[prop1.Value]
  for comp in current_selection:
    property_type = SUPPORTED_PROPERTY_TYPES[prop1.Value]
    existing_property = comp.getProperty(property_name)
    if existing_property:
      warning ('Property name "{}" exist already in "{}".'.format(property_name,comp.Name))
    else:
      comp.createProperty(property_type, property_name)
      info ('{} property "{}" created to the component "{}".'.format(prop1.Value,property_name,comp.Name))
      
addState( first_state )