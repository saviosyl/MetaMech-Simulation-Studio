from vcCommand import *
import vcMatrix, vcVector
from vcHelpers.Output import *
cmd = getCommand()
app = cmd.Application
key = "ComboKey::Python.PMClearLinks.FlowGroup.SelectGroup"
localized_string = app.getLocalizedString(key)
if key == localized_string:
  localized_string = 'Select Group'
SELECT_GROUP = '<{}>'.format(localized_string)

def first_state(): 
  global button, selected_flow_group,action, flow_group_manager, process_controller, copy_properties
  sim = cmd.Simulation
  process_controller = sim.ProcessController
  flow_table = process_controller.FlowTable2
  transport_system = process_controller.TransportSystem 
  flow_group_manager = process_controller.FlowGroupManager 
  product_type_manager = process_controller.ProductTypeManager 
  process_manager = process_controller.ProcessManager 
  process_data = process_controller.ProcessData  
  
  flow_groups = flow_group_manager.Groups

  pname = 'FlowGroup'
  selected_flow_group = createProperty(VC_STRING, pname , VC_PROPERTY_STEP)
  Values = [x.Name for x in flow_groups]
  Values.insert(0,SELECT_GROUP)
  selected_flow_group.StepValues = Values
  selected_flow_group.Value = Values[0]

  pname = 'CopyProperties'
  copy_properties = createProperty(VC_BOOLEAN, pname)
  copy_properties.Value = True

  pname = 'CreateLinks'
  button = createProperty(VC_BUTTON, pname)
  button.OnChanged = apply
  executeInActionPanel()

def update_properties(newlink, link_properties):
  global copy_properties
  if copy_properties.Value == True:
    for prop in link_properties:
      try:
        if newlink.getProperty(prop.Name): newlink.getProperty(prop.Name).Value = prop.Value
        else:
          new_prop = newlink.createProperty(prop.Type, prop.Name)
          new_prop.Value = prop.Value
      except: pass

def apply(arg):  
  global button, selected_flow_group, flow_group_manager, process_controller
  if selected_flow_group.Value == SELECT_GROUP: error ("Please select Flow Group")
  else:
    transport_system = process_controller.TransportSystem 
    links = transport_system.Links
    group = flow_group_manager.findGroup(selected_flow_group.Value)

    flow_table = process_controller.FlowTable2
    flow_sequence = flow_table.getSequence(group) #gets process flow group
    flow_implementation_groups = []
    flow_steps = flow_sequence.FlowSteps
    for i in range(flow_steps.size()):
      _step = flow_steps.get(i)
      _groups = _step.Groups
      for g in range(_groups.size()):
        if _groups.get(g) not in flow_implementation_groups:
          flow_implementation_groups.append(_groups.get(g))

    nodes = [] #all nodes and groups
    node_groups = []
    for grp in flow_implementation_groups:
      implementations = grp.Implementations
      for i in implementations:
        nodes.append(i.Program.Executor.TransportNode)
        node_groups.append(grp)

    link_data = [] #sources, destinations
    node_to_process = []
    process_to_node = []
    process_to_process = []
    counter = 0
    for link in links:
      if link.SupportedGroup.Name == selected_flow_group.Value:
        link_data.append([link.Source,link.Destination])
        if link.Source in nodes and link.Destination in nodes:
          process_to_process.append([node_groups[nodes.index(link.Source)],node_groups[nodes.index(link.Destination)],link])
        elif link.Source in nodes and link.Destination not in nodes:
          process_to_node.append([node_groups[nodes.index(link.Source)],link.Destination,link])
        elif link.Destination in nodes and link.Source not in nodes:
          node_to_process.append([link.Source, node_groups[nodes.index(link.Destination)],link])

    for node in nodes:
      for link in process_to_process:
        if node_groups[nodes.index(node)] == link[0]: #link[2].Source
          link_implementer = link[2].Implementer
          link_properties = link[2].Properties
          target_group_members = [x for x in nodes if node_groups[nodes.index(x)] == link[1]]

          for target in target_group_members:
            if [node,target] not in link_data:
              newlink = transport_system.createTransportLink(node, target,link_implementer , group)
              link_data.append([node,target])
              counter +=1
              update_properties(newlink, link_properties)

      for link in process_to_node:
        if node_groups[nodes.index(node)] == link[0]: 
          link_implementer = link[2].Implementer
          link_properties = link[2].Properties
          target = link[1]
          if [node,target] not in link_data:
            newlink = transport_system.createTransportLink(node, target,link_implementer , group)
            link_data.append([node,target])
            counter +=1
            update_properties(newlink, link_properties)

      for link in node_to_process:
        if node_groups[nodes.index(node)] == link[1]: #destination
          link_implementer = link[2].Implementer
          link_properties = link[2].Properties
          node_ = link[0]
          target_group_members = [x for x in nodes if node_groups[nodes.index(x)] == link[1]]
          for target in target_group_members:
            if [node_,target] not in link_data:
              newlink = transport_system.createTransportLink(node_, target,link_implementer , group)
              link_data.append([node_,target])
              counter +=1
              update_properties(newlink, link_properties)

    info (str(counter) + " new links created to Flow Group " + selected_flow_group.Value)

addState( first_state )
