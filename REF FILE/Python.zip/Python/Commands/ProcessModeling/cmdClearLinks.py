from vcCommand import *
import vcMatrix, vcVector
from vcHelpers.Output import *
cmd = getCommand()
app = cmd.Application
key = "ComboKey::Python.PMClearLinks.FlowGroup.SelectGroup"
localized_string = app.getLocalizedString(key)
if key == localized_string:
  localized_string = 'Select Group'
SELECT_GROUP = '<{}>'.format(localized_string)

def first_state(): 
  global button, selected_flow_group, clear_links, flow_group_manager, process_controller
  sim = cmd.Simulation
  process_controller = sim.ProcessController
  flow_table = process_controller.FlowTable2
  transport_system = process_controller.TransportSystem 
  flow_group_manager = process_controller.FlowGroupManager 
  product_type_manager = process_controller.ProductTypeManager 
  process_manager = process_controller.ProcessManager 
  process_data = process_controller.ProcessData  
  
  flow_groups = flow_group_manager.Groups

  pname = 'FlowGroup'
  selected_flow_group = createProperty(VC_STRING, pname, VC_PROPERTY_STEP)
  Values = [x.Name for x in flow_groups]
  Values.insert(0,SELECT_GROUP)
  selected_flow_group.StepValues = Values
  selected_flow_group.Value = Values[0]

  pname = 'ClearLinks'
  clear_links = createProperty(VC_STRING, pname, VC_PROPERTY_STEP)
  clear_links.StepValues = ['All', 'Unused', 'Empty']
  clear_links.Value = 'Unused'

  pname = 'Clear'
  button = createProperty(VC_BUTTON, pname)
  button.OnChanged = apply
  executeInActionPanel()

def apply(arg):  
  global button, selected_flow_group, clear_links, flow_group_manager, process_controller

  if selected_flow_group.Value == SELECT_GROUP: error("Please select Flow Group")
  else:
    transport_system = process_controller.TransportSystem 
    links = transport_system.Links
    counter = 0

    for link in links:
      if link.SupportedGroup.Name == selected_flow_group.Value:
        if clear_links.Value == 'All':
          transport_system.deleteTransportLink(link)
          counter +=1
        if clear_links.Value == 'Empty' and link.Implementer  == None: 
          transport_system.deleteTransportLink(link)
          counter +=1
        if clear_links.Value == 'Unused':
          group = link.SupportedGroup
          flow_table = process_controller.FlowTable2
          flow_sequence = flow_table.getSequence(group) #gets process flow group
          flow_implementation_groups = []
          flow_steps = flow_sequence.FlowSteps
          for i in range(flow_steps.size()):
            _step = flow_steps.get(i)
            _groups = _step.Groups
            for g in range(_groups.size()):
              if _groups.get(g) not in flow_implementation_groups:
                flow_implementation_groups.append(_groups.get(g))

          #flow_implementation_groups = flow_sequence.ProcessGroups #4.4
          nodes = []
          for grp in flow_implementation_groups:
            implementations = grp.Implementations
            for i in implementations:
              nodes.append(i.Program.Executor.TransportNode)
          
          all_links_in_solutions = transport_system.findAllLinksBetweenNodeSets(nodes,nodes,group)
          if link not in all_links_in_solutions:
            transport_system.deleteTransportLink(link)
            counter +=1
    info( str(counter) + " links cleared from Flow Group " + selected_flow_group.Value)

addState( first_state )