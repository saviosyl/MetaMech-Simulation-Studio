from vcCommand import *
import vcMatrix, vcVector
from vcHelpers.Selection import *
from vcHelpers.Output import *

cmd = getCommand()
app = cmd.Application
sel = app.SelectionManager
command_is_active = False
key = "ComboKey::Python.PMCreateFrame.CopyLocationFrom.NoComponentSelected"
localized_string = app.getLocalizedString(key)
if key == localized_string:
  localized_string = 'No components selected'
NO_COMP_SEL_MSG = '<{}>'.format(localized_string)
key = "ComboKey::Python.PMCreateFrame.CopyLocationFrom.SelectFrame"
localized_string = app.getLocalizedString(key)
if key == localized_string:
  localized_string = 'Select Frame'
SEL_FRAME_MSG = '<{}>'.format(localized_string)


def ContextChanged():
  global command_is_active
  command_is_active = False


def OnCloseMethodCalled():
  global command_is_active
  command_is_active = False
  cmd.Enabled = True


def selection_changed():
  global current_selection
  current_selection = sel.getSelection(VC_SELECTION_COMPONENT)
  if len(current_selection)>0:
    cmd.Enabled = True
  else:
    cmd.Enabled = False
  if command_is_active:
    get_all_frames()

sel.OnSelectionChanged = selection_changed
app.OnContextChanged = ContextChanged


def first_state(): 
  global button, prop1, prop2, prop3, prop4, current_selection, command_is_active
  command_is_active = True
  
  pname = 'NewFrameName'
  prop1 = createProperty(VC_STRING,pname)
  pname = 'FrameLocation'
  prop2 = createProperty(VC_MATRIX, pname)

  pname = 'CopyLocationFrom'
  prop3 = createProperty(VC_STRING, pname, VC_PROPERTY_STEP)
  prop3.OnChanged = get_frame_location
  
  pname = 'MakeUnique'
  prop4 = createProperty(VC_BOOLEAN, pname)
  prop4.Value = True

  pname = 'CreateFrame'
  button = createProperty(VC_BUTTON, pname)
  button.OnChanged = apply

  selection_changed()
  executeInActionPanel()


def get_all_frames():
  global first_comp, all_features, all_feature_nodes, current_selection, prop3
  all_frames = []
  all_nodes = []
  all_features = []
  all_feature_nodes = []

  if current_selection:
    first_comp = current_selection[0]
    nodes = [first_comp]
    while nodes:
      node = nodes.pop(0)
      all_nodes.append(node)
      nodes.extend(node.Children)
    for node in all_nodes:
      feats = [node.RootFeature]
      while feats:
        fea = feats.pop(0)
        feats.extend(fea.Children)
        if fea.Type == VC_FRAME:
          all_features.append(fea)
          all_feature_nodes.append(node)
    Values = [x.Name for x in all_features]
    Values.insert(0,SEL_FRAME_MSG)
    prop3.StepValues = Values
    prop3.Value = SEL_FRAME_MSG
  else:
    prop3.StepValues = [NO_COMP_SEL_MSG]
    prop3.Value = NO_COMP_SEL_MSG


def get_frame_location(args):
  global button, prop2, prop3, current_selection, first_comp, all_features, all_feature_nodes

  if not current_selection:
    return

  if prop3.Value != SEL_FRAME_MSG:
    ind = prop3.StepValues.index(prop3.Value)
    fea = all_features[ind-1]
    node = all_feature_nodes[ind-1]
    if fea:
      prop2.Value = fea.NodePositionMatrix * (node.WorldPositionMatrix * first_comp.InverseWorldPositionMatrix)


def apply(arg):  
  global button, prop1, prop2, prop4, current_selection

  if not current_selection:
    error ('No component(s) selected.')
    return

  frame_name = prop1.Value
  if frame_name == '':
    error ('New frame name cannot be empty.')
    return
  elif ' ' in frame_name:
    error ('New frame name contains spaces. Use "CamelCase" naming, for example "ApproachFrame_2", without quotation marks.')
    return
  elif not frame_name.replace('_','').isalnum():
    error ('New frame name contains special characters.')
    return

  for comp in current_selection:
    try:
      if prop4.Value == True: 
        comp.makeUnique()
      existing_frame = comp.findFeature(frame_name)
      if existing_frame:
        warning ('Feature name "{}" exist already in "{}".'.format(frame_name, comp.Name))
      else:
        mat = comp.createProperty(VC_MATRIX, frame_name)
        mat.Value = prop2.Value
        mat.ChangeOnRebuild = True
        transform = comp.RootFeature.createFeature(VC_TRANSFORM, frame_name + "_transform")
        transform.Expression = frame_name
        newframe = transform.createFeature(VC_FRAME, frame_name)
        info ('New frame "{}" created to the component "{}".'.format(frame_name,comp.Name))
        comp.update()
    except:
      print "Exeption while creating frame and properties."
  app.render()


addState( first_state )