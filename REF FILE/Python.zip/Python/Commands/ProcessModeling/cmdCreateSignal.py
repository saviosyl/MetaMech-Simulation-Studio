from vcCommand import *
from vcHelpers.Selection import *
from vcHelpers.Output import *

SUPPORTED_SIGNAL_TYPES = {
'Boolean'   : VC_BOOLEANSIGNAL,
'Integer'   : VC_INTEGERSIGNAL,
'Real'      : VC_REALSIGNAL,
'String'    : VC_STRINGSIGNAL,
'Component' : VC_COMPONENTSIGNAL
}

cmd = getCommand()
app = cmd.Application


def selection_changed():
  global current_selection
  current_selection = sel.getSelection(VC_SELECTION_COMPONENT)
  if len(current_selection)>0:
    cmd.Enabled = True
  else:
    cmd.Enabled = False

sel = app.SelectionManager
sel.OnSelectionChanged = selection_changed


def first_state(): 
  global button, prop1, prop2, current_selection

  pname = 'SignalType'
  prop1 = createProperty(VC_STRING,pname,VC_PROPERTY_STEP)
  Values = [x for x in SUPPORTED_SIGNAL_TYPES] 
  prop1.StepValues = Values
  prop1.Value = Values[0]

  pname = 'SignalName'
  prop2 = createProperty(VC_STRING,pname)

  pname = 'CreateSignal'
  button = createProperty(VC_BUTTON, pname)
  button.OnChanged = apply
  executeInActionPanel()


def apply(arg):  
  global button, prop1, prop2, current_selection
  
  if not current_selection:
    error ('No component(s) selected.')
    return

  signal_name = prop2.Value
  if signal_name == '':
    error ('Signal name cannot be empty.')
    return
  elif ' ' in prop2.Value:
    error ('Signal name contains spaces. Use "CamelCase" naming, for example "InputSignal_2", without quotation marks.')
    return
  elif not prop2.Value.replace('_','').isalnum():
    error ('Signal name contains special characters.')
    return

  signal_type = SUPPORTED_SIGNAL_TYPES[prop1.Value]
  for comp in current_selection:
    signal_type = SUPPORTED_SIGNAL_TYPES[prop1.Value]
    signal_beh = comp.findBehaviour(signal_name)
    if signal_beh:
      warning ('Signal name "{}" exist already in "{}".'.format(signal_name, comp.Name))
    else:
      signal_beh = comp.createBehaviour(signal_type, signal_name)
      info ('{} signal "{}" created to the component "{}".'.format(prop1.Value,signal_name,comp.Name))
      
addState( first_state )