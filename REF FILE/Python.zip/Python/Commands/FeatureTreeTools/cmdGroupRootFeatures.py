from vcCommand import *

app = getApplication()

def first_state():

  context = app.CurrentContext
  if context.Id != VC_CONTEXT_AUTHOR:
    'This command can be called from modeling context only'
    return
  node = context.ActiveNode
  comp = context.ActiveComponent
  if not node:
    return
  tr_name = gimmeUniqueName(comp, 'Transform')
  transform = node.RootFeature.createFeature(VC_TRANSFORM, tr_name)
  kids = node.RootFeature.Children
  kids.reverse()
  for i in kids:
    if i != transform:
      transform.attach(i, False)
  transform.rebuild()


addState( first_state )



def gimmeUniqueName(comp, nname):
  iii = 0
  while iii<10000:
    iii+=1
    tr_name = '%s_%i' % (nname, iii)
    if not comp.findFeature(tr_name):
      return tr_name
  return nname

