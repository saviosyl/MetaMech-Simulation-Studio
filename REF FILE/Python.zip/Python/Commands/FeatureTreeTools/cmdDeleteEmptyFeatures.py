from vcCommand import *
from vcHelpers.Selection import * 

app = getApplication()

def first_state():
  context = app.CurrentContext
  node = context.ActiveNode
  leaf_feas = [x for x in getGivenNodesFeatures(node) if not x.Children]
  for f in leaf_feas:
    while f:
      if isEmpty(f):
        del_this = f
        f = f.Parent
        del_this.delete()
        if f.Type == 'Root':
          f = None
      else:
        f = None



def  isEmpty(fea):
  '''
  emptiness tester
  returs tru if the given feature is empty
  '''
  if fea.Type in [VC_ANGULARCLONE, VC_EXTRUDE, VC_LINEARCLONE, VC_MIRROR, VC_REVOLVE, VC_SWITCH, VC_TRANSFORM]:
    if not fea.Children:
      # Operation features are empty if they have no children
      return True
    else:
      return False
  elif fea.Type == VC_GEOMETRY:
    if fea.Geometry.GeometrySetCount == 0 and not fea.Children:
      # geo feature is empty if it has no geometry sets in it (geo sets might be empty but this is not tested)
      return True
    else:
      return False

addState( first_state )





