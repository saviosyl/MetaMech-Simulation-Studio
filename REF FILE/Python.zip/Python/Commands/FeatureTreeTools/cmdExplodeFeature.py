from vcCommand import *
import vcMatrix
app = getApplication()
max_set_limit = 1000
decompose_explode_single_set_features = True

def first_state():
  messages = []
  s = app.SelectionManager
  feas = [x for x in s.getSelection(VC_SELECTION_FEATURE) if x.Type == VC_GEOMETRY]
  if not feas:
    return
  select_these = []
  for fea in feas[:]:
    feaname_cached = fea.Name
    if fea.Children:
      continue
    bothsets = [x for x in fea.Geometry.GeometrySets if x.Type in [VC_TRIANGLESET, VC_COMPACTLINESET]]
    if len(bothsets) == 0:
      continue
    if len(bothsets) == 1:
      if bothsets[0].Type == VC_TRIANGLESET:
        if decompose_explode_single_set_features:
          bothsets = bothsets[0].decompose(True)
          if len(bothsets) == 1:
            ret_yes_no = app.messageBox('Only one geometry set within feature (%s). \nExploding feature faces to new features.\nHit "Ok" to continue. ' % fea.Name,'Warning', VC_MESSAGE_TYPE_WARNING, VC_MESSAGE_BUTTONS_OKCANCEL)
            if ret_yes_no == VC_MESSAGE_RESULT_OK:
              pass # keep on going and exploding
            else:
              fea.rebuild()
              continue
            bothsets = bothsets[0].decompose(False)
            if len(bothsets) == 1:
              fea.rebuild()
              continue
        else:
          continue
      else:
        # single lineset should be exploded here.. not supported yet
        continue
    elif len(bothsets) > max_set_limit:
      #print 'Too many (%i) items to explode inside "%s". Maximum allowed is %i. Use Split command instead.' % (len(bothsets), fea.Name, max_set_limit)
      #this is asked from user multiple times (remember my selection option would be golden)
      ret_yes_no = app.messageBox('Large amount of geometry sets (%i) in feature "%s". \nOperation may take some time.\nHit "Ok" to continue. ' % (len(bothsets), fea.Name),'Warning', VC_MESSAGE_TYPE_WARNING, VC_MESSAGE_BUTTONS_OKCANCEL)
      if ret_yes_no == VC_MESSAGE_RESULT_OK:
        pass # keep on going and exploding
      else:
        continue
    tr = fea.Parent.createFeature(VC_TRANSFORM, fea.Name)
    tr.PositionMatrix = fea.PositionMatrix
    i = 0
    for i, g in enumerate(bothsets[:]):
      if g.Type ==VC_TRIANGLESET:
        newfea = tr.createFeature(VC_GEOMETRY,'%s__%i' % (fea.Name, i+1))
        newset = newfea.Geometry.createGeometrySet( VC_TRIANGLESET )
        if g.UseTextureCoordinates1:
          newset.TextureCoordinateTable = g.TextureCoordinateTable
        newset.PositionTable = g.PositionTable
        newset.PolygonTable = g.PolygonTable
        newset.Material = g.Material
        newset.update()
        newfea.ShowBackfaces = fea.ShowBackfaces
        fea.Geometry.deleteGeometrySet(g)
      elif g.Type ==VC_COMPACTLINESET:
        newfea = tr.createFeature(VC_GEOMETRY,'%s__L%i' % (fea.Name, i+1))
        newset = newfea.Geometry.createGeometrySet( VC_COMPACTLINESET )
        newset.Material = g.Material
        newset.LineWidth = g.LineWidth
        for line in g.Lines:
          newset.addLine( line )
        newset.update()
        fea.Geometry.deleteGeometrySet(g)
    if not fea.Geometry.GeometrySets:
      fea.delete()
    else:
      newmtx = vcMatrix.new()
      fea.PositionMatrix = newmtx
      tr.attach( fea )
      fea.Name += '__sets'
      fea.rebuild()
    tr.rebuild()
    select_these.append( tr )
    messages.append( '"%s" exploded to %i features' % (feaname_cached, len(tr.Children)) )
  if select_these:
    s.clear()
    for tr in select_these:
      s.setSelection(tr, True)
  app.render()
  if messages:
    for message in messages:
      print message
  else:
    print 'Explode done: Nothing exploded'


addState( first_state )

