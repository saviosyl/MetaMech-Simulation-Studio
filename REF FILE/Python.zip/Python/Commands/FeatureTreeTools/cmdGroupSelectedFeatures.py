from vcCommand import *

app = getApplication()

def first_state():
  context = app.CurrentContext
  if context.Id != VC_CONTEXT_AUTHOR:
    'This command can be called from modeling context only'
    return
  comp = context.ActiveComponent
  s = app.SelectionManager
  feas = s.getSelection(VC_SELECTION_FEATURE)
  if feas:
    if all(x.Parent == feas[0].Parent for x in feas):
      tr_name = gimmeUniqueName(comp, 'Transform')
      transform = feas[0].Parent.createFeature(VC_TRANSFORM,tr_name)
      feas.reverse()
      for i in feas:
        if i != transform:
          transform.attach(i, False)
      transform.rebuild()
      s.clear()
      s.setSelection( transform )
    else:
      print 'Command execution available only if selected features have the same parent.'
  app.render()


addState( first_state )


def gimmeUniqueName(comp, nname):
  iii = 0
  while iii<10000:
    iii+=1
    tr_name = '%s_%i' % (nname, iii)
    if not comp.findFeature(tr_name):
      return tr_name
  return nname

