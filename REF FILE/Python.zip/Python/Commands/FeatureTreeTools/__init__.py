from vcApplication import *
import os.path

mat_cmd_name = 'cmdSetFeatureMaterial'
mat_title = 'Set Material'
py_net_command = findCommand('netCommand')
py_net_command.execute('SetLocalizationCommand', 'English', 'Python', mat_cmd_name, 'Text', mat_title)

def OnStart():
  cmduri = getApplicationPath() + 'cmdExplodeFeature.py'
  cmd = loadCommand("ExplodeFeature",cmduri)
  addMenuItem('VcAuthorTreeViewFeaturesContextMenu', "Explode", -1, "ExplodeFeature")

  cmduri = getApplicationPath() + 'cmdRaiseFeature.py'
  cmd = loadCommand("RaiseFeature",cmduri)
  addMenuItem('VcAuthorTreeViewFeaturesContextMenu', "Raise", -1, "RaiseFeature")

  cmduri = getApplicationPath() + 'cmdGroupSelectedFeatures.py'
  cmd = loadCommand("GroupSelectedFeatures",cmduri)
  addMenuItem('VcAuthorTreeViewFeaturesContextMenu', "GroupSelectedFeatures", -1, "GroupSelectedFeatures")

  cmduri = getApplicationPath() + 'cmdGroupRootFeatures.py'
  cmd = loadCommand("GroupRootFeatures",cmduri)
  addMenuItem('VcAuthorTreeViewFeaturesContextMenu', "GroupRootLevelFeatures", -1, "GroupRootFeatures")

  cmduri = getApplicationPath() + 'cmdDeleteEmptyFeatures.py'
  cmd = loadCommand("DeleteEmptyFeatures",cmduri)
  addMenuItem('VcAuthorTreeViewFeaturesContextMenu', "DeleteEmptyFeatures", -1, "DeleteEmptyFeatures")

  cmduri = getApplicationPath() + 'SetFeatureMaterial.py'
  if os.path.isfile(cmduri.replace('file:///', '')):
    cmd = loadCommand('cmdSetFeatureMaterial', cmduri)
    mat_iconuri = 'Gallery/Tools/rMaterialAssign'
    addMenuItem('VcAuthorTreeViewFeaturesContextMenu', mat_title, -1, mat_cmd_name, mat_iconuri)
    addMenuItem('VcAuthor3DContextMenu', mat_title, -1, mat_cmd_name, mat_iconuri)
    #addMenuItem('VcAuthorTreeViewNodesContextMenu', mat_title, -1, mat_cmd_name, mat_iconuri)

  # 3d context menu items:
  addMenuItem('VcAuthor3DContextMenu/VcAuthor3DContextMenuTools', "Explode", -1, "ExplodeFeature")
  addMenuItem('VcAuthor3DContextMenu/VcAuthor3DContextMenuTools', "GroupSelectedFeatures", -1, "GroupSelectedFeatures")
  addMenuItem('VcAuthor3DContextMenu/VcAuthor3DContextMenuTools', "GroupRootLevelFeatures", -1, "GroupRootFeatures")
