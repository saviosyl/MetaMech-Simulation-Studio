from vcCommand import *

app = getApplication()

def first_state():
  s = app.SelectionManager
  feas = s.getSelection(VC_SELECTION_FEATURE)
  if feas:
    if all(x.Parent == feas[0].Parent for x in feas):
      feas.reverse()
      for fea in feas:
        if fea.Parent.Type != 'Root':
          grandparent = fea.Parent.Parent
          gpm_inv = grandparent.NodePositionMatrix
          gpm_inv.invert()
          fea.PositionMatrix = gpm_inv * fea.NodePositionMatrix
          grandparent.attach(fea)
          grandparent.rebuild()
          s.clear()
          s.setSelection( fea )
    else:
      print 'Command execution available only if selected features have the same parent.'
  app.render()


addState( first_state )

