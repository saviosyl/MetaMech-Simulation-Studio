# Material initialization OEM customization 2016/11/23
from vcApplication import *
import os.path

def OnStart(apppath, load_materials):
    # This is area where OEM specific file can add material customization
    load_materials(os.path.join(os.path.dirname(apppath[8:]),'FlexlinkMaterials.xml'),True)
