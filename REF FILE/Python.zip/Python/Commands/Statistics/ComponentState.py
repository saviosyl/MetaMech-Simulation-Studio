from vcCommand import *
from vcHelpers.Selection import *
import vcVector


REPORT_PROPERTY_LABEL = app.getLocalizedString("ComboKey::Python.__ComponentStateReport__.Text")
LAST_INTERVAL_NAME = app.getLocalizedString("ComboKey::Python.__ComponentStateReport__.DataFrom.Last Interval.Text")

app = getApplication()
cmd = getCommand()

system_states = [['WarmUp',1],
                 ['Idle',3],
                 ['Busy',4],
                 ['Setup',8],
                 ['Break',2],
                 ['Blocked',5],
                 ['Failed',6],
                 ['Repair',7]]

default_colors = {'Idle':app.findMaterial('yellow'),
                  'Busy':app.findMaterial('green'),
                  'Setup':app.findMaterial('cyan'),
                  'Break':app.findMaterial('blue'),
                  'Blocked':app.findMaterial('purple'),
                  'Failed':app.findMaterial('red'),
                  'Repair':app.findMaterial('orange')}


def close_panel():
  reset_cmd = app.findCommand('resetSimulation')
  reset_cmd.execute()
  save_state_cmd = app.findCommand('saveState')
  save_state_cmd.execute()  


def get_full_state_name(state_name):
  global type_prop, data_prop
  if type_prop.Value == type_prop.StepValues[0]: # System states
    if data_prop.Value == data_prop.StepValues[0]: # Interval
      return 'Interval{}Percentage'.format(state_name)
    else: # Overall
      return '{}Percentage'.format(state_name)
  else:
    if data_prop.Value == data_prop.StepValues[0]: # Interval
      return 'State{}IntervalPercentage'.format(state_name)
    else: # Overall
        return 'State{}Percentage'.format(state_name)


def get_data_series_colors(state_name,blend=1):
  global mat_props, mat_custom_props, props
  mat = None
  for prop in mat_props:
    if prop.Name == state_name:
      mat = prop.Value
      break
  if not mat:
    for prop in mat_custom_props:
      if prop.Name == state_name:
        mat = prop.Value
        break
  if not mat:
    #print 'Unknown material for', state_name
    return vcVector.new(1,1,1)
  vec = mat.Diffuse
  if blend < 1:
    vec.X *= blend
    vec.Y *= blend
    vec.Z *= blend
  return vec


def update_action_panel_UI():
  global comp, chart, statistics, type_prop, data_prop, color_prop, blended_prop, mat_props
  #print 'Updating UI'
  if color_prop.Value:
    if type_prop.Value == type_prop.StepValues[1]:
      blended_prop.IsVisible = True
    if type_prop.Value == type_prop.StepValues[0]: # System states
      blended_prop.IsVisible = False
      for prop in mat_custom_props:
        prop.IsVisible = False
      for prop in mat_props:
        prop.IsVisible = True
    elif blended_prop.Value == blended_prop.StepValues[0]: # Blended user defined state
      for prop in mat_custom_props:
        prop.IsVisible = False
      for prop in mat_props:
        prop.IsVisible = True
    else: # User defined states
      for prop in mat_props:
        prop.IsVisible = False
      new_props_created = False
      for state in statistics.States:
        if state[1] == 1:
          continue
        state_name = state[0]
        prop = cmd.getProperty(state_name)
        if prop:
          prop.IsVisible = True
        else:
          prop = cmd.createProperty('Ref<Material>',state_name)
          prop.OnChanged = update_chart_colors
          new_props_created = True
        for s in system_states:
          if s[1] == state[1]:
            system_state_name = s[0]
            break
        mat = default_colors[system_state_name]
        if mat:
          prop.Value = mat
        mat_custom_props.append(prop)
      if new_props_created:
        executeInActionPanel()
  else:
    blended_prop.IsVisible = False
    for prop in mat_props:
      prop.IsVisible = False
    for prop in mat_custom_props:
      prop.IsVisible = False


def update_chart_colors(arg = None):
  global comp, chart, statistics, typ
  if not chart.ChartType:
    close_panel()
    return
  if finalized and arg: 
    #print 'Updating Colors'
    for i in range(2):
      if color_prop.Value:
        if type_prop.Value == type_prop.StepValues[0]: # System states
          for data_series in chart.Series:
            vec = get_data_series_colors(data_series.Name)
            data_series.Colors = [vec]
        elif blended_prop.Value == blended_prop.StepValues[0]: # Blended user defined state
          blending_states = {}
          for data_series in chart.Series:
            for state in statistics.States:
              if data_series.Name == state[0]:
                for s in system_states:
                  if s[1] == state[1]:
                    system_state_name = s[0]
                    break
                break
            if system_state_name in blending_states:
              blending_states[system_state_name] *= 0.85
            else:
              blending_states[system_state_name] = 1
            blending = blending_states[system_state_name]
            vec = get_data_series_colors(system_state_name, blending)
            data_series.Colors = [vec]
        else: # User defined states
          for data_series in chart.Series:
            vec = get_data_series_colors(data_series.Name)
            data_series.Colors = [vec]
      else:
        update_chart()
    if arg and arg.Name == color_prop.Name or arg.Name == blended_prop.Name:
      update_action_panel_UI()



def update_chart(arg=None):
  global comp, chart, statistics, type_prop, data_prop, color_prop, blended_prop, mat_props, finalized  
  if not finalized:
    return
  if not chart.ChartType:# or len(chart.Series)<1:
    close_panel()
    return

  #print 'Clearing and creating chart'
  chart.clearSeries()
  if data_prop.Value == data_prop.StepValues[0]: # Last Interval
    chart.Name = "{} - {} ({})".format(comp.Name,REPORT_PROPERTY_LABEL,LAST_INTERVAL_NAME)
  else:
    chart.Name = "{} - {}".format(comp.Name,REPORT_PROPERTY_LABEL)
  if type_prop.Value == type_prop.StepValues[0]: # System states
    all_states = system_states
  else: # User defined states
    all_states = statistics.States
  for state in all_states:
    if state[1] == 1:
      continue
    state_name = state[0]
    data_series = chart.addSeries()
    data_series.SeriesName = state_name
    data_series.Name = state_name
    data_series.Components = [comp]
    full_name = get_full_state_name(state_name)
    data_series.Property = statistics.getProperty(full_name)
  if arg:
    if arg.Name == type_prop.Name or arg.Name == data_prop.Name:
      color_prop.Value = False
    update_action_panel_UI()
    update_chart_colors()


def configure_action_panel_UI():
  global color_prop, type_prop, data_prop, blended_prop, mat_props, mat_custom_props, finalized
  finalized = False
  for prop in cmd.Properties:
    cmd.deleteProperty(prop)  

  group = 0
  type_prop = cmd.createProperty(VC_STRING,'StateTypes', VC_PROPERTY_STEP)
  type_prop.StepValues = ['System States','User Defined States']
  type_prop.Value = type_prop.StepValues[1]
  type_prop.OnChanged = update_chart
  type_prop.Group += group

  data_prop = cmd.createProperty(VC_STRING,'DataFrom', VC_PROPERTY_STEP)
  data_prop.StepValues = ['Last Interval','Simulation Run']
  data_prop.Value = data_prop.StepValues[0]
  data_prop.OnChanged = update_chart
  data_prop.Group += group

  color_prop = cmd.createProperty(VC_BOOLEAN,'DefineColors')
  color_prop.OnChanged = update_chart_colors
  color_prop.Group += group

  blended_prop = cmd.createProperty(VC_STRING,'ColorMode',VC_PROPERTY_STEP)
  blended_prop.StepValues = ['Blended System State Colors','User Defined State Colors']
  blended_prop.Value = blended_prop.StepValues[0]
  blended_prop.IsVisible = False
  blended_prop.OnChanged = update_chart_colors
  blended_prop.Group += group

  mat_props = []
  mat_custom_props = []
  
  for state in system_states:
    state_name = state[0]
    if state_name != 'WarmUp': #skipping WarmUp
      prop = cmd.createProperty('Ref<Material>',state_name)
      prop.OnChanged = update_chart_colors
      prop.IsVisible = False
      prop.Group += group
      mat = default_colors[state_name]
      if mat:
        prop.Value = mat
      mat_props.append(prop)
  executeInActionPanel()
  finalized = True
  update_chart()


def first_state():
  global comp, chart, statistics
  selection = app.SelectionManager
  comps = selection.getSelection(VC_SELECTION_COMPONENT)
  if len(comps) == 0:
    title = app.getLocalizedString("ComboKey::Python.StatisticsMsgBoxTitle.Text")
    message = app.getLocalizedString("ComboKey::Python.StatisticsMsgBoxMessageNoComponents.Text")
    app.messageBox(message,title, 2, 1) 
    return
  comps = [x for x in comps if x.findBehavioursByType(VC_STATISTICS)]
  if len(comps) == 0:
    title = app.getLocalizedString("ComboKey::Python.StatisticsMsgBoxTitle.Text")
    message = app.getLocalizedString("ComboKey::Python.StatisticsMsgBoxMessageNoStatistics.Text")
    app.messageBox(message,title, 2, 1) 
    return
  comp = comps[0]
  dash = app.Dashboard
  # Detect what dashboard tab is selected and if no tabs ia available create one
  tab = dash.SelectedTab
  if tab == None:
    tab = dash.createTab('New', True)
  # Detect what chart location in the dashboard tab is selected for chart creation
  selChart = tab.SelectedChart
  if selChart == None:
    title = app.getLocalizedString("ComboKey::Python.StatisticsMsgBoxTitle.Text")
    message = app.getLocalizedString("ComboKey::Python.StatisticsMsgBoxMessageNoChartLocation.Text")
    app.messageBox(message,title, 2, 1) 
    return
  stats = comp.findBehavioursByType(VC_STATISTICS)
  statistics = stats[0]
  chart = tab.createChart(selChart, VC_CHARTTYPE_PIE, False)
  chart.TitleVisibility = True
  chart.LegendVisibility = True
  configure_action_panel_UI()
  update_chart()


addState(first_state)
