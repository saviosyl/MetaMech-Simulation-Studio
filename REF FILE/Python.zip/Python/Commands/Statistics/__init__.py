from vcApplication import *

def OnStart():
    if findCommand("__ComponentUtilizationReport__") == None:
        cmd = loadCommand("__ComponentUtilizationReport__", getApplicationPath() + "ComponentUtilizationReport.py")

    if findCommand("__ComponentStateReport__") == None:
        cmd = loadCommand("__ComponentStateReport__", getApplicationPath() + "ComponentState.py")

    if findCommand("__ComponentPartsProducedReport__") == None:
        cmd = loadCommand("__ComponentPartsProducedReport__", getApplicationPath() + "ComponentPartsProducedReport.py")

    if findCommand("__ComponentPartsAverageCountReport__") == None:
        cmd = loadCommand("__ComponentPartsAverageCountReport__", getApplicationPath() + "ComponentPartsAverageCountReport.py")

    if findCommand("__ComponentPartsAverageTimeReport__") == None:
        cmd = loadCommand("__ComponentPartsAverageTimeReport__", getApplicationPath() + "ComponentPartsAverageTimeReport.py")

    if findCommand("__ComponentJointsReport__") == None:
        cmd = loadCommand("__ComponentJointsReport__", getApplicationPath() + "ComponentJointsReport.py")

    if findCommand("__ComponentTravelDistance__") == None:
        cmd = loadCommand("__ComponentTravelDistance__", getApplicationPath() + "ComponentTravelDistance.py")

    if findCommand("__ComponentBatteryLevel__") == None:
        cmd = loadCommand("__ComponentBatteryLevel__", getApplicationPath() + "ComponentBatteryLevel.py")

    report_menu = VC_MENU_STATISTICS_TEMPLATE + '/Component Report templates'
    addMenuItem(report_menu, "Utilization", -1, "__ComponentUtilizationReport__")
    addMenuItem(report_menu, "State", -1, "__ComponentStateReport__")
    addMenuItem(report_menu, "Parts Produced", -1, "__ComponentPartsProducedReport__")
    addMenuItem(report_menu, "Parts Average Count", -1, "__ComponentPartsAverageCountReport__")
    addMenuItem(report_menu, "Parts Average Time", -1, "__ComponentPartsAverageTimeReport__")
    addMenuItem(report_menu, "Joint Values", -1, "__ComponentJointsReport__")
    addMenuItem(report_menu, "Travel Distance", -1, "__ComponentTravelDistance__")
    addMenuItem(report_menu, "Battery Level", -1, "__ComponentBatteryLevel__")
    