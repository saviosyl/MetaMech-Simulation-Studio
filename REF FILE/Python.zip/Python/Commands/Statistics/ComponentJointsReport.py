from vcCommand import *
from vcHelpers.Selection import *

REPORT_PROPERTY_LABEL = app.getLocalizedString("ComboKey::Python.__ComponentJointsReport__.Text")

app = getApplication()
cmd = getCommand()

def first_state():
  selection = app.SelectionManager
  comps = selection.getSelection(VC_SELECTION_COMPONENT)
  if len(comps) == 0:
    title = app.getLocalizedString("ComboKey::Python.StatisticsMsgBoxTitle.Text")
    message = app.getLocalizedString("ComboKey::Python.StatisticsMsgBoxMessageNoComponents.Text")
    app.messageBox(message,title, 2, 1)  
    return
  comps = [x for x in comps if (len(x.findBehavioursByType(VC_ROBOTCONTROLLER))+len(x.findBehavioursByType(VC_SERVOCONTROLLER))>0) ]
  if len(comps) == 0:
    title = app.getLocalizedString("ComboKey::Python.StatisticsMsgBoxTitle.Text")
    message = app.getLocalizedString("ComboKey::Python.StatisticsMsgBoxMessageNoControllers.Text")
    app.messageBox(message,title, 2, 1)  
    return
  dash = app.Dashboard
  # Detect what dashboard tab is selected and if no tabs ia available create one
  tab = dash.SelectedTab
  if tab == None:
    tab = dash.createTab('New', True)

  # Detect what chart location in the dashboard tab is selected for chart creation
  selChart = tab.SelectedChart
  if selChart == None:
    title = app.getLocalizedString("ComboKey::Python.StatisticsMsgBoxTitle.Text")
    message = app.getLocalizedString("ComboKey::Python.StatisticsMsgBoxMessageNoChartLocation.Text")
    app.messageBox(message,title, 2, 1) 
    return
  else:
    c = tab.createChart(selChart, VC_CHARTTYPE_LINE, False)
    if len(comps) > 1:
      c.Name = REPORT_PROPERTY_LABEL
    else:
      c.Name = "{} {}".format(comps[0].Name,REPORT_PROPERTY_LABEL)
  
  for comp in comps:
    controllers = comp.findBehavioursByType(VC_ROBOTCONTROLLER)+comp.findBehavioursByType(VC_SERVOCONTROLLER)  
    for ctrl in controllers:
      joints = ctrl.Joints
      c.TitleVisibility = True
      c.LegendVisibility = True
      c.SamplingInterval = 0.1
      for j in joints:
        s = c.addSeries()
        if len(comps) > 1:
          s.Name = "{}: {}".format(comp.Name,j.Name)
        s.Property = comp.getProperty(j.Name)

addState(first_state)
