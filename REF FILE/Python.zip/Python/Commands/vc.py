'''
    VC base module:

        Usage:

            import vc

            vc.makedirs()
            vc.removebom(file)
            vc.addbom(file)
            vc.normalize('asdf')
            vc.normalize('asdf', '932')
            unicode('\xf6\xe4', '1252')
            unicode('\xf6\xe4')                 # This will throw an exception, because fallback encoding after non-utf8 encoding is 'ascii'.
            vc.unicode('\xf6\xe4')              # This will use getsystemdefaultencoding() as a fallback, not ascii.
            str(unicode('asdf'))
            str(vc.unicode('asdf'))

            for lin in vc.open(file, 'r'):      # Read/write a TEXT file with encoding. Will automatically detect known encodings.
              print repr(lin)                   # Note: 'Unicode Warnings'-helper will still give warnings, because there's no bullet-proof way to read old encodings.

        Contents:
            getdefaultencoding()
            setdefaultencoding()
            getsystemdefaultencoding()
            setsystemdefaultencoding()

            unicode(string, [encoding])
            len(string)

            removebom(file)
            addbom(file)

            normalizeiter(list, [encoding])

            normalize(string, [encoding])

            url2path(string)
            
            path2url(string)

            open(file, mode, [encoding], [usebom])          - text file reading/writing

            class vcTextFileObject

        Note: normal 'str()' method can be used with __builtin__.str()
'''
import __builtin__
import sys
import locale
import vcUrlHelper
import os

'''
try:
  from vcCommand import *
except:
  try:
    from vcScript import *
  except:
    print "Error: vc.py was unable to import vcCommand and vcScript"
'''




# Always returns 'utf-8'.
# Note: previously was 'ascii'. See unicodeobject::_PyUnicode_Init().
#
def getdefaultencoding():
    return sys.getdefaultencoding()

def setdefaultencoding(encoding):
    return sys.setdefaultencoding(encoding)

# Returns system's ACP (default fallback encoding).
#
def getsystemdefaultencoding():
    return locale.getdefaultlocale()[1][2:]

def setsystemdefaultencoding(encoding):
    raise ValueError("Mehtod setsystemdefaultencoding() is not implemented! The only way to change system's ACP is from Regional settings in control panel!")


def makedirs(arg):
    unicode_path = unicode(__builtin__.str(arg))
    if os.path.exists(unicode_path) == False:
       os.makedirs(unicode_path)


def makedir(arg):
    makedirs(arg)

# Same as 'str()'.
# Not needed, as long as sys.getdefaultencoding() is utf-8
# Converts to utf8 encoded 'str' string
# Note: same as 'str(u"test")' or 'rString("test").toUtf8()'.
#
def str(arg):
    if isinstance(arg,__builtin__.unicode):
       return arg.encode('UTF-8')
    return __builtin__.str(arg)





# Similar to 'unicode(str[, encoding[, flags]])', but doesn't use 'ascii' as a fallback code page and can trim bom.
# This method uses getsystemdefaultencoding()/GetACP() as a fallback ansi encoding.
# Same as rString::fromUtf8().
# Converts to utf8 encoded 'unicode'
#
def unicode(arg, encoding = None, flags = None):

  if isinstance(arg, __builtin__.str) and __builtin__.len(arg) == 0:
    return arg
  if isinstance(arg, __builtin__.unicode) and __builtin__.len(arg) == 0:
    return arg

  # Note: 'flags' are unsued.

  # Auto trim bom (same as with std from_bytes converter)
  #
  if isinstance(arg, __builtin__.str) and arg.startswith('\xef\xbb\xbf'):
    arg = arg[3:]

  # Use specific encoding.
  #
  if encoding != None and encoding != 'system' and encoding != 'auto':
    return arg.decode(__builtin__.str(encoding), 'ignore')

  # Try utf-8.
  # Don't ignore errors!
  #
  try:
    return arg.decode('utf-8')
  except:
    pass

  # Try system's ACP
  #
  try:
    return arg.decode(getsystemdefaultencoding())
  except:
    pass

  # In theory we could detect that some characters don't belong to 1252.
  # See cp1252.py and items like "u'\ufffe'   #  0x90 -> UNDEFINED".
  # However it's better to use system's ACP, and 'ignore'. (Same as in rString::fromUtf8)
  #
  return arg.decode(getsystemdefaultencoding(), 'ignore')

def len(arg):
    return __builtin__.len(unicode(__builtin__.str(arg)))





# Reads 3 first bytes of UTF8 encoded files.
#
def removebom(arg):
    hasSignature = False
    if arg.read(3) == '\xef\xbb\xbf':
        hasSignature = True
    if hasSignature == False:
        arg.seek(0)




# Writes UTF8 signature
#
def addbom(arg):
    arg.write('\xef\xbb\xbf')






# Converts all file lines to utf8 encoded 'str' instances
#
def normalizeiter(arg, encoding = 'system'):
    return (unicode(line, encoding).encode('UTF-8') for line in arg)





# Converts to encoded ansi str to utf8 encoded ansi str.
# Basically same as vc.unicode(), but also includes conversion back to string:
#       str(vc.unicode(arg))
#
def normalize(arg, encoding = 'system'):
    if isinstance(arg, file):
        return normalizeiter(arg, encoding)
    elif isinstance(arg, vcTextFileObject):
        return normalizeiter(arg, encoding)
    elif isinstance(arg, __builtin__.str):
        return unicode(arg, encoding).encode('UTF-8')
    else:
        return unicode(str(arg), encoding).encode('UTF-8')

def url2path(arg):
    return vcUrlHelper.urlToLocalPath(arg)

def path2url(arg):
    return vcUrlHelper.localPathToUrl(arg)



# Opens a text file for reading or writing.
# Warning: MUST BE A TEXT FILE!
# 
def open(file, mode, encoding = 'auto', usebom = True):
    result = vcTextFileObject(file, mode, encoding, usebom)
    return result






# Text file reader/writer
##
class vcTextFileObject:

    __file = None
    __mode = ""
    __closed = False
    __usebom = True
    __usedbom = False
    __encoding = "auto"
    __onlyReading = False
    __isBinary = False
    __hasSignature = False
    __normalizeReading = True

    # Supported modes in 'mode': 'r', 'rt', 'rb', 'rb+', 'w', 'wb', 'wt', 'wt+', 'a', 'a+', etc.
    #
    def __init__(self, file, mode, encoding = 'auto', usebom = True, norm = True, autochecklines = 500):
        
        mode = mode.lower()
        if encoding == None:
          encoding = 'auto'
        encoding = __builtin__.str(encoding)
        encodingSimplified = encoding.replace('-', '').lower()
        
        self.__usebom = usebom
        self.__mode = mode
        self.__encoding = encoding
        self.__encodingSimplified = encodingSimplified
        self.__hasSignature = False
        self.__normalizeReading = norm
        
        # Open a text file (file cannot be binary, but 'mode' can be)
        #
        file_name_unicode = ""
        if isinstance(file, __builtin__.unicode):
            file_name_unicode = file
        else:
            file_name_unicode = unicode(__builtin__.str(file))
        self.__file = __builtin__.open(file_name_unicode, mode)

        self.__onlyReading = mode.find("w") == -1 and mode.find("a") == -1
        self.__isBinary = mode.find("b") != -1
        
        if self.__onlyReading:
            # see also: BOM_UTF8
            if self.__file.read(3) == '\xef\xbb\xbf':
                self.__hasSignature = True
            if self.__hasSignature == False:
                self.__file.seek(0)
        
        # Support auto detecting known encodings. 
        # We can do this because 'vc.open' is used only for reading text files.
        # However still, this is not bullet-proof, so user should use 'Unicode Warnings' helper, and convert all text files into utf8.
        #
        if self.__onlyReading and autochecklines > 0 and self.__encodingSimplified == 'auto' and self.__hasSignature == False:
          count = 0
          brokenLines = ""
          for lin in self.__file:
            count += 1
            try:
              lin.decode('utf-8')
            except:
              brokenLines += lin
            if __builtin__.len(brokenLines) > 10000 or count >= autochecklines:
              break
          
          if __builtin__.len(brokenLines) != 0:
            is_japanese = False
            try:
              brokenLines.decode('932')
              is_japanese = True
            except:
              is_japanese = False
            if is_japanese:
              self.__encoding = '932'
              self.__encodingSimplified = '932'
        
              
          self.__file.seek(0)

    @property
    def closed(self):
        return self.__closed

    @property
    def encoding(self):
        return self.__encoding

    @property
    def normalizing(self):
        return self.__normalizeReading

    @property
    def hasSignature(self):
        return self.__hasSignature


    def seek(self, pos, whence=0):
        self.__file.seek(pos, whence)

    def tell(self):
        return self.__file.tell()

    def truncate(self, pos=None):
        self.__file.truncate(pos)

    def flush(self):
        self.__file.flush()

    def close(self):
        if not self.__closed:
            self.flush()
            self.__file.close()
            self.__closed = True

    def __del__(self):
        try:
            self.close()
        except:
            pass

    def seekable(self):
        return self.__file.seekable()

    def readable(self):
        return self.__file.readable()

    def writable(self):
        return self.__file.writable()

    def _checkClosed(self, msg=None):
        if self.closed:
            raise ValueError("I/O operation on closed file."
                             if msg is None else msg)

    def __enter__(self):
        self._checkClosed()
        return self

    def __exit__(self, *args):
        self.close()

    def fileno(self):
        return self.__file.fileno()

    def isatty(self):
        self._checkClosed()
        return self.__file.isatty()


    # This is used in for-loops
    #
    def __iter__(self):
        self._checkClosed()
        return self

    def next(self):
        line = self.readline()
        if not line:
            raise StopIteration
        return line

    def readline(self, limit=-1):
        self._checkClosed()
        line = self.__file.readline(limit)
        if not line:
            return line
        
        if self.__normalizeReading:
            line = normalize(line, self.__encoding)
        return line

    def readlines(self, hint=None):
        lines = self.__file.readlines(hint)
        lines2 = []
        for lin in lines:
            if self.__normalizeReading:
                lines2.append(normalize(lin, self.__encoding))
            else:
                lines2.append(lin)
        lines = lines2
        return lines

    def write(self, data):
        self._checkClosed()
        if self.__usebom and self.__usedbom == False:
            self.__usedbom = True
            self.__file.write('\xef\xbb\xbf')
        self.__file.write(data)

    def writelines(self, lines):
        self._checkClosed()
        if self.__usebom and self.__usedbom == False:
            self.__usedbom = True
            self.__file.write('\xef\xbb\xbf')
        all_lines = ""
        for line in lines:
            if self.__isBinary:
                all_lines += line + '\r\n'
            else:
                all_lines += line + '\n'
        # Note: normal 'writelines' doesn't add '\r\n'
        self.__file.write(all_lines)

    def writeline(self, line):
        self.writelines([line])

        '''
file = open('test.csv', 'r')
for line in file:
    print repr(line), ", ", line

vc.url2path()
'''