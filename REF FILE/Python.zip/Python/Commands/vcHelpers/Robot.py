try:
  from vcCommand import *
except:
  try:
    from vcScript import *
  except:
    print "Error: vcHelpers.Robot was unable to import vcCommand and vcScript"

import vcMatrix
app = getApplication()
global idMTX
idMTX = vcMatrix.new()

__doc__ = '''
vcHelpers.Robot V1.0 Documentation 
_________________________________________________________________________________
  Methods:
  
    getRobot
      ( arg = None, SetActionMode = True )
        Returns a vcRobot - class
        arg:  Interface name in which the robot is connected (e.g. robot-class can be easily retrieved from pedestal), string
              or
              Robot component handle (e.g. robot-class can be easily retrieved anywhere where robot-component-object is available), vcComponent
              or
              arg can be left off if getRobot() is called from robot component itself  ( like getComponent )
              
              
    getSelectedRobotsData
      ()
        Returns: selected program,routine,controller,basename,toolname,basenames,toolnames,robotconfig,robotconfigs
        This method takes no arguments.
        
        
    printMatrix
      ( mtx )
        Prints a matrix content into message panel in nice readable format.
        mtx: Matrix to print, vcMatrix
'''


# vcRobot Class
class vcRobot:
  
  __doc__ = """
  Robot-class V1.0 Documentation:
  
  
  _________________________________________________________________________________
  Properties:
  
    Component: Robot component, vcComponent, R
    Controller: Robot controller in robot component, vcRobotController, R
    Executor: RSL program executor in robot component, vcRslProgramExecutor, R
    GraspContainer: Component container in robot's flange node, vcContainer, RW
    SignalMapOut: Out signal map in robot component, vcBooleanSignalMap, R
    SignalMapIn: Out signal map in robot component, vcBooleanSignalMap, R
    Tools: List of Tools in robot controller, list of vcBaseFrames, R
    Bases:  List of Bases in robot controller, list of vcBaseFrames, R
    Joints: List of Joints in robot controller, list of vcJoints, R
    Speed: Robot's CartesianSpeed for linear movements, RW
    AngularSpeed: Robot's AngularSpeed for linear movements, RW
    Acc: Robot's CartesianAccel for linear movements, RW
    AngularAcc: Robot's AngularAccel for linear movements, RW
    JointForce: Joint force for ptp/joint movement (0...100%), RW
    JointSpeed: Joint speed for ptp/joint movement (0...100%), RW
    ActiveTool: Tool point name or index, string or integer, RW
    Configuration: Define configuration before joint-movement. Set configuration to -1 to let system choose the closest configuration, string / int, RW, (Default -1)
    ConfigurationsList: List of configuration names, list of strings, R
    RecordRSL: Set this true in order to record all robot actions as RSL-statements in "RecordRoutine"     (FOR RSL AND POST-PROCESSING USE)
    RecordRoutine: Name of the routine where statements are recorded if "RecordRSL" is true, RW
    RecordRoutineObject: vcRslRoutine-object where statements are recorded if "RecordRSL" is true, R     (do not write this property)

  _________________________________________________________________________________
  Methods: 
  
    linearMoveToMtx
    
      Call a linear movement with matrix as a target. If called without arguments, drives robot to world origin.
      
      (ToMtx = ORIGIN, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, CS = 'world'):
        ToMtx: Target matrix in selected (world or robot) coordinate system (CS), vcMatrix [optional, default: identity matrix aka. origin]
        Tx: Translation offset in direction of X, real  [optional, default: 0]
        Ty: Translation offset in direction of y, real  [optional, default: 0]
        Tz: Translation offset in direction of z, real  [optional, default: 0]
        Rx: Rotation offset around x, real  [optional, default: 0]
        Ry: Rotation offset around y, real  [optional, default: 0]
        Rz: Rotation offset around z, real  [optional, default: 0]
        CS: Wheter the target is calculated using WORLD TARGET (argument value = 'world') or 
                        ROBOTROOT TARGET (argument value = 'robot')
                        , string, [optional, default: 'world']
    
    -------------------------------------------------------------------------------------------------------------------------
    jointMoveToMtx
    
      Call a joint movement with matrix as a target. If called without arguments, drives robot to world origin.
      
      (ToMtx = ORIGIN, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, CS = 'world'):
        ToMtx: Target matrix in selected (world or robot) coordinate system (CS), vcMatrix [optional, default: identity matrix aka. origin]
        Tx: Translation offset in direction of X, real  [optional, default: 0]
        Ty: Translation offset in direction of y, real  [optional, default: 0]
        Tz: Translation offset in direction of z, real  [optional, default: 0]
        Rx: Rotation offset around x, real  [optional, default: 0]
        Ry: Rotation offset around y, real  [optional, default: 0]
        Rz: Rotation offset around z, real  [optional, default: 0]
        CS: Wheter the target is calculated using WORLD TARGET (argument value = 'world') or 
                        ROBOTROOT TARGET (argument value = 'robot')
                        , string, [optional, default: 'world']

    -------------------------------------------------------------------------------------------------------------------------
    linearMoveToComponent
    
      Call a linear movement to component position. Give atleast ToComp as argument for this call.
      By default robot moves to component origin, but the position can be offset with Tx,Ty,Tz,Rx,Ry and Rz arguments.
      Target can also be specified with frame (frame name or feature object) or target position can be specified on 
      one of the component boundbox faces ('top','bottom','left','right','front','back').
      
      (ToComp, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, ToFrame = None, OnFace = None):
        ToComp: Target component, vcNode
        Tx: Translation offset in direction of X, real  [optional, default: 0]
        Ty: Translation offset in direction of y, real  [optional, default: 0]
        Tz: Translation offset in direction of z, real  [optional, default: 0]
        Rx: Rotation offset around x, real  [optional, default: 0]
        Ry: Rotation offset around y, real  [optional, default: 0]
        Rz: Rotation offset around z, real  [optional, default: 0]
        ToFrame: Target given as a frame-object (or its name) within the ToComp-component, vcFeature or string, [optional, default: None] *
        OnFace: Target face on component bound box, string ('top','bottom','left','right','front','back') [optional, default: None] *
        
        * Only one of these can be given (if both given ToFrame is prioritized)
      
    -------------------------------------------------------------------------------------------------------------------------
    jointMoveToComponent
    
      Call a joint movement to component position. Give atleast ToComp as argument for this call.
      By default robot moves to component origin, but the position can be offset with Tx,Ty,Tz,Rx,Ry and Rz arguments.
      Target can also be specified with frame (frame name or feature object) or target position can be specified on 
      one of the component boundbox faces ('top','bottom','left','right','front','back').
    
      (ToComp, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, ToFrame = None, OnFace = None):
        ToComp: Target component, vcNode
        Tx: Translation offset in direction of X, real  [optional, default: 0]
        Ty: Translation offset in direction of y, real  [optional, default: 0]
        Tz: Translation offset in direction of z, real  [optional, default: 0]
        Rx: Rotation offset around x, real  [optional, default: 0]
        Ry: Rotation offset around y, real  [optional, default: 0]
        Rz: Rotation offset around z, real  [optional, default: 0]
        ToFrame: Target given as a frame-object (or its name) within the ToComp-component, vcFeature or string, [optional, default: None] *
        OnFace: Target face on component bound box, string ('top','bottom','left','right','front','back') [optional, default: None] *
        
        * Only one of these can be given (if both given ToFrame is prioritized)
      
    -------------------------------------------------------------------------------------------------------------------------
    linearMoveToPosition
    
      Call linear movement to position given as X, Y, Z, Roll, Pitch and Yaw values.
      By default the values are all zero and the position is calculated from world origin. 
      Set CS to "robot" and the position is calculated from robot origin.
    
      (Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, CS = 'world'):
        Tx: X-target in world coordinate system (if WorldBase is True), real [optional, default: 0]
        Ty: Y-target in world coordinate system (if WorldBase is True), real [optional, default: 0]
        Tz: Z-target in world coordinate system (if WorldBase is True), real [optional, default: 0]
        Rx: A-target in world coordinate system (if WorldBase is True), real [optional, default: 0]
        Ry: B-target in world coordinate system (if WorldBase is True), real [optional, default: 0]
        Rz: C-target in world coordinate system (if WorldBase is True), real [optional, default: 0]
        CS: Wheter the target is calculated using WORLD TARGET (argument value = 'world') or 
                        ROBOTROOT TARGET (argument value = 'robot')
                        , string, [optional, default: 'world']
      
    -------------------------------------------------------------------------------------------------------------------------
    jointMoveToPosition
      
      Call joint movement to position given as X, Y, Z, Roll, Pitch and Yaw values.
      By default the values are all zero and the position is calculated from WorldBase. 
      Set CS to "robot" and the position is calculated from robot origin.
      
      (Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, CS = 'world'):
        Tx: X-target in world coordinate system (if WorldBase is True), real [optional, default: 0]
        Ty: Y-target in world coordinate system (if WorldBase is True), real [optional, default: 0]
        Tz: Z-target in world coordinate system (if WorldBase is True), real [optional, default: 0]
        Rx: A-target in world coordinate system (if WorldBase is True), real [optional, default: 0]
        Ry: B-target in world coordinate system (if WorldBase is True), real [optional, default: 0]
        Rz: C-target in world coordinate system (if WorldBase is True), real [optional, default: 0]
        CS: Wheter the target is calculated using WORLD TARGET (argument value = 'world') or 
                        ROBOTROOT TARGET (argument value = 'robot')
                        , string, [optional, default: 'world']
      
    -------------------------------------------------------------------------------------------------------------------------
    linearMoveToMtx_ExternalBase
    
      Call linear movement referenced to an external base. The target is given as matrix in Basenode's coordinate system. 
      Use this call for example when moving onto part on moving pallet. In this case, set pallet to be Basenode.
    
      (Basenode, ToMtx = ORIGIN, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0):
        Basenode: Movement base node, vcNode
      ToMtx: Target matrix in base node's coordinate system, vcMatrix [optional, default: identity matrix aka. origin]
      Tx: Translation offset in direction of X, real  [optional, default: 0]
        Ty: Translation offset in direction of y, real  [optional, default: 0]
        Tz: Translation offset in direction of z, real  [optional, default: 0]
        Rx: Rotation offset around x, real  [optional, default: 0]
        Ry: Rotation offset around y, real  [optional, default: 180]
        Rz: Rotation offset around z, real  [optional, default: 0]
      
    -------------------------------------------------------------------------------------------------------------------------
    followNode

      Robot keeps its position stationary to Basenode. Typically used when Basenode moves.

      (Basenode, FollowTime=1)
        Basenode: node to follow, vcNode
        FollowTime: delay time, real [optional, default: 1]
    -------------------------------------------------------------------------------------------------------------------------
    moveAway
    
      Call linear retraction movement from robot's current pose.
    
      (Tz = 200):
        Tz: Retraction distance z, real  [optional, default: 200]
        
    -------------------------------------------------------------------------------------------------------------------------
    linearMoveRel
    
      Call relative linear movement from robot's current pose.
    
      (Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0):
        Tx: Translation movement in direction of X, real  [optional, default: 0]
        Ty: Translation movement in direction of y, real  [optional, default: 0]
        Tz: Translation movement in direction of z, real  [optional, default: 0]
        Rx: Rotation offset around x, real  [optional, default: 0]
        Ry: Rotation offset around y, real  [optional, default: 0]
        Rz: Rotation offset around z, real  [optional, default: 0]

    -------------------------------------------------------------------------------------------------------------------------
    jointMoveRel
    
      Call relative joint movement from robot's current pose.
     
      (Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0):
        Tx: Translation movement in direction of X, real  [optional, default: 0]
        Ty: Translation movement in direction of y, real  [optional, default: 0]
        Tz: Translation movement in direction of z, real  [optional, default: 0]
        Rx: Rotation offset around x, real  [optional, default: 0]
        Ry: Rotation offset around y, real  [optional, default: 0]
        Rz: Rotation offset around z, real  [optional, default: 0]


    ------------------------------------------------------------------------------------------------------------------------
    driveJoints
    
      Drive robot joints with given joint target value. Drive multiple or single simultaneously.
    
      (J1 = 'current', J2 = 'current', J3 = 'current', J4 = 'current', J5 = 'current', J6 = 'current', MotionTime = 0, Relative = False)
        J1...J6: Joint 1...6 target values. If not given current value sustains, real [optional, default: 'current']
        MotionTime: Time to move to the target. With zero value motiontime is calculated according to acc, dec, speed values, real, [optional, default: 0]
        Relative: Set this True to give relative values instead of absolute, boolean, [optional, default: False (i.e. absolute)]

    ------------------------------------------------------------------------------------------------------------------------
    pick
      (Part, Approach = 200, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, OnFace = 'top', ApproachAxis = 'Z'):
      
        MACRO:
      Calls joint movement above the component
        +
        linear movement on component's top* face        (* OnFace default = 'top')
        +
        grasp component
        +
        move away from component.
    
        Part: Part to be picked, vcComponent
        Approach: Approach and retract distance, real, [optional,default: 200]
        Tx: Translation movement in direction of X, real  [optional, default: 0]
        Ty: Translation movement in direction of y, real  [optional, default: 0]
        Tz: Translation movement in direction of z, real  [optional, default: 0]
        Rx: Rotation offset around x, real  [optional, default: 0]
        Ry: Rotation offset around y, real  [optional, default: 0]
        Rz: Rotation offset around z, real  [optional, default: 0]
      ApproachAxis: Approach can be aligned with Part's 'X', '-X', 'Y', '-Y', 'Z' or '-Z' -axis, string, [optional, default: 'Z']

    -------------------------------------------------------------------------------------------------------------------------
    place
      (ToComp, Approach = 200, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, Part = None, ApproachAxis = 'Z'):
      
        MACRO:
      Calls joint movement above the ToComp
        +
        linear movement on component's top face
        +
        release component to ToComp
        +
        move away from component.
    
        ToComp: a Component on which a Part is to be released, vcComponent
        Approach: Approach and retract distance, real, [optional] default = 200
        Tx: Translation movement in direction of X, real  [optional, default: 0]
        Ty: Translation movement in direction of y, real  [optional, default: 0]
        Tz: Translation movement in direction of z, real  [optional, default: 0]
        Rx: Rotation offset around x, real  [optional, default: 0]
        Ry: Rotation offset around y, real  [optional, default: 0]
        Rz: Rotation offset around z, real  [optional, default: 0]
        Part: Component to be released. If no Part argument is given, the first Part in graspContainer is released, vcComponent [optional]
      ApproachAxis: Approach can be aligned with ToComp's 'X', '-X', 'Y', '-Y', 'Z' or '-Z' -axis, string, [optional, default: 'Z']
      
    ------------------------------------------------------------------------------------------------------------------------- 
    pickFromPallet
      (Pallet, Approach = 200, InversedOrder = False, Index = -1):
      
        MACRO:
      Finds a child components within the Pallet
        +
        Selects the child according to argument settings 
        +
        Calls joint movement above the component
        +
        linear movement on component's top face      
        +
        grasp component
        +
        move away from component.
    
        Pallet: Pallet from which to pick a Part, vcComponent
        Approach: Approach and retract distance, real, [optional, default: 200]
        InversedOrder: By default the last Part added on Pallet is picked. This can be inversed by setting InversedOrder = True, bool [optional, default: False]
        Index: Manually select the index of the picked part in pallet's children, integer, [optional, default: -1]

        returns picked part component object (vcComponent)
  
    -------------------------------------------------------------------------------------------------------------------------
    placeInPattern
      (ToComp, X_index, Y_index, Z_index, PatternSize_X = 0, PatternSize_Y = 0, PatternSize_Z = 0, Approach = 200, Part = None, StepSizeX = 0, StepSizeY = 0, StepSizeZ = 0, Rz = 0):
      
        Use this to create patterns with robot. Set indexes and the pattern sizes and the part position in pattern is calculated automatically.
        MACRO:
        Calls joint movement above the component
        +
        linear movement on target position
        +
        release component to ToComp
        +
        move away from component.
        
        ToComp: a Component on which a Part is to be released, vcComponent
        X_index: column Index in pattern, integer
        Y_index: row Index in pattern, integer
        Z_index: level Index in pattern, integer
        PatternSize_X: Total number of columns in pattern, integer [optional, default: 0]
        PatternSize_Y: Total number of rows in pattern, integer [optional, default: 0]
        PatternSize_Z: Total number of levels in pattern, integer [optional, default: 0]
        Approach: Approach and retract distance, real, [optional] default = 200
        Part: Component to be released. If no Part argument is given, the first Part in graspContainer is released, vcComponent [optional]
        StepSizeX: Pattern step size in X-direction. If no stepSize is given, a Part length is automatically taken to stepSizeX, real [optional, default: 0]
        StepSizeY: Pattern step size in Y-direction. If no stepSize is given, a Part width is automatically taken to stepSizeY, real [optional, default: 0]
        StepSizeZ: Pattern step size in Z-direction. If no stepSize is given, a Part height is automatically taken to stepSizeZ, real [optional, default: 0]
        Rz: Rotation offset in target position around z, real  [optional, default: 0]

    -------------------------------------------------------------------------------------------------------------------------
    pickMovingPart
      ( Part, Approach = 200, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0):
        
      Use this when picking moving components e.g. from running conveyor.
        MACRO:
        Calls joint movement above the component
        +
        linear movement on component's top* face        (* OnFace default = 'top')
        +
        grasp component
        +
        move away from component.
    
        Part: Part to be picked, vcComponent
        Approach: Approach and retract distance, real, [optional] default = 200
        Tx: Translation movement in direction of X, real  [optional, default: 0]
        Ty: Translation movement in direction of y, real  [optional, default: 0]
        Tz: Translation movement in direction of z, real  [optional, default: 0]
        Rx: Rotation offset around x, real  [optional, default: 0]
        Ry: Rotation offset around y, real  [optional, default: 0]
        Rz: Rotation offset around z, real  [optional, default: 0]
    
    -------------------------------------------------------------------------------------------------------------------------
    graspComponent
      (GraspThis):
      
        Grasp given component to robot's grasp container.
      
        GraspThis: Component to be picked, vcNode
        
    -------------------------------------------------------------------------------------------------------------------------
    graspComponents
      (GraspThese):
      
        Grasp multiple components to robot's grasp container.
      
        GraspThese: List of Components to be picked, list of vcNodes
      
    -------------------------------------------------------------------------------------------------------------------------
    releaseComponent
      (ToObject, ReleseThis = None):
      
        Release component from robot's container to target object. Target can be given as container, node or component -object.
      
        ToObject: Target container or component. If ToObject is component, 
                      a target container is tried to be found automatically,   vcNode or vcContainer
        ReleseThis: Component to be placed. If ReleseThis is not given, ReleseThis is tried to 
                       be found in graspContainer of robot,  vcNode
      
    -------------------------------------------------------------------------------------------------------------------------
    releaseAllComponents
      (ToObject):
      
        Release all components from robot's container to target object.
      
        ToObject: Target container or component. If ToObject is component, 
                      a target container is tried to be found automatically,   vcNode or vcContainer
        all components in the graspContainer are released to ToObject
        
    -------------------------------------------------------------------------------------------------------------------------
    traceOn
      (Index = 1):
      
        Plot robot's movement in the 3d world with trace.
      
        Index: Index of the Tool, int
    
    -------------------------------------------------------------------------------------------------------------------------
    traceOff
      (Index = 1):
        Index: Index of the Tool, int
    
    -------------------------------------------------------------------------------------------------------------------------
    mountTool
      (Tool):
        Tool: Tool to be mounted, vcComponent
    
    -------------------------------------------------------------------------------------------------------------------------
    unmountTool
      (Tool, ToObject):
        Tool: Tool to be unmounted, vcComponent
        ToObject: target for unmounting, vcComponent or vcContainer

    -------------------------------------------------------------------------------------------------------------------------
    callSubRoutine
      (rName):
      
        Call pre teached robot routine. Teach routines on Teach-tab.
      
        rName: Routine name, string
    
    -------------------------------------------------------------------------------------------------------------------------
    comment      (FOR RSL AND POST-PROCESSING USE)
      (Comment):
      
        Prints comment and adds comment statement in the RSL program if the execution is recorded. See RecordRSL - property.
      
        Comment: Comment text, string

    -------------------------------------------------------------------------------------------------------------------------
    delay      (FOR RSL AND POST-PROCESSING USE)
      (Delay):
      
        Creates delay and adds delay statement in the RSL program if the execution is recorded. See RecordRSL - property.
      
        Delay: Delay-time seconds, real

    -------------------------------------------------------------------------------------------------------------------------
    rsl_BinOut      (FOR RSL AND POST-PROCESSING USE)
      (Index, Value):
      
        Adds binOut statement in the RSL program if the execution is recorded. See RecordRSL - property.
      
        Index, Index of output signal in signal map, integer
        Value, Set True or False, boolean
  
    -------------------------------------------------------------------------------------------------------------------------
    rsl_BinIn      (FOR RSL AND POST-PROCESSING USE)
      (Index, Value):
      
        Adds binIn statement in the RSL program if the execution is recorded. See RecordRSL - property.
      
        Index, Index of output signal in signal map, integer
        Value, Set True or False, boolean
    
    -------------------------------------------------------------------------------------------------------------------------
"""
  
  def __setattr__(self, name, value):
    if name == 'Speed':
      self.Controller.MaxCartesianSpeed = value
    elif name == 'AngularSpeed':
      self.Controller.MaxAngularSpeed = value
    elif name == 'Acc':
      self.Controller.MaxCartesianAccel = value
    elif name == 'AngularAcc':
      self.Controller.MaxAngularAccel = value
    elif name == 'RecordRSL' and value == True:
      if self.RecordRoutine == 'MainRoutine':
        self.RecordRoutineObject = self.Executor.MainRoutine
      else:
        for r in self.Executor.SubRoutines:
          if r.Name == self.RecordRoutine:
            self.RecordRoutineObject = r
            break
        else:
          self.RecordRoutineObject = executor.createSubRoutine(self.RecordRoutine)
      self.RecordRoutineObject.beginBatch()
      for i in range(self.RecordRoutineObject.StatementCount):
        self.RecordRoutineObject.deleteStatement(0)
      self.RecordRoutineObject.endBatch()
    elif name == 'RecordRoutine':
      if value == 'MainRoutine':
        self.RecordRoutineObject = self.Executor.MainRoutine
      else:
        for r in self.Executor.SubRoutines:
          if r.Name == value:
            self.RecordRoutineObject = r
            break
        else:
          self.RecordRoutineObject = self.Executor.createSubRoutine(value)
    self.__dict__[name] = value
  
  
  def __init__(self, component, controller, executor, graspContainer, signalMapIn, signalMapOut):
    self.Component = component
    self.Controller = controller
    self.Executor = executor
    self.GraspContainer = graspContainer
    self.SignalMapOut = signalMapOut
    self.SignalMapIn = signalMapIn
    self.Tools = controller.Tools
    self.Bases = controller.Bases
    self.Joints = controller.Joints
    self.Speed = controller.MaxCartesianSpeed
    self.AngularSpeed = controller.MaxAngularSpeed
    self.Acc = controller.MaxCartesianAccel
    self.AngularAcc = controller.MaxAngularAccel
    self.JointForce = 100
    self.JointSpeed = 100
    self.ActiveTool = 1
    self.ActiveBase = 0
    self.RecordRSL = False
    self.Configuration = -1
    self.ConfigurationsList = getConfigNames(executor, controller)
    self.MotionTime = 0
    self.RecordRoutineObject = self.Executor.MainRoutine
    self.RecordRoutine = 'MainRoutine'



  def linearMoveToMtx(self, ToMtx = idMTX, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, CS = 'world'):
    targetMtx = vcMatrix.new(ToMtx)
    targetMtx.translateRel(Tx,Ty,Tz)
    targetMtx.rotateRelX(Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    robotMove = self.Controller.createTarget()
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
    if CS == 'world':
      robotMove.TargetMode = VC_MOTIONTARGET_TM_WORLDTARGET
    else:
      pass
      #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool

    # Call RSL
    doRSL(self, VC_STATEMENT_LINMOTION, robotMove)


  def jointMoveToMtx(self, ToMtx = idMTX, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, CS = 'world'):
    targetMtx = vcMatrix.new(ToMtx)
    targetMtx.translateRel(Tx,Ty,Tz)
    targetMtx.rotateRelX(Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    robotMove = self.Controller.createTarget()
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_JOINT
    if CS == 'world':
      robotMove.TargetMode = VC_MOTIONTARGET_TM_WORLDTARGET
    else:
      pass
      #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool

    # Call RSL
    doRSL(self, VC_STATEMENT_PTPMOTION, robotMove)
  

  def linearMoveToComponent(self, ToComp, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, ToFrame = None, OnFace = None):
    global app
    if type(ToComp) == type('DummyString'):
      ToComp = app.findComponent(ToComp)
    if ToComp:
      ToComp.update()
      ToMtx = ToComp.WorldPositionMatrix
      targetMtx = vcMatrix.new(ToMtx)
      if ToFrame:
        try:
          frameMtx = ToFrame.NodePositionMatrix
        except:
          try:
            ToFrame = ToComp.findFeature(ToFrame)
            frameMtx = ToFrame.NodePositionMatrix
          except:
            print 'Error: vcHelpers.Robot.linearMoveToComponent() was unable to get the ToFrame feature'
        try:
          targetMtx = targetMtx * frameMtx
        except:
          pass
        if not ToComp.getFeature(ToFrame.Name):
          print 'Error: vcHelpers.Robot.linearMoveToComponent(): ToFrame feature is not within ToComp - node'
          print '         - There might be error in matrix calculations due to this fact.'
          print '         - Please change ToFrame or ToComp - objects or move the ToFrame-feature under',ToComp.Name,'-node in node tree.'
      elif OnFace:
        onFace(ToComp,targetMtx,OnFace)
      targetMtx.translateRel(Tx,Ty,Tz)
      targetMtx.rotateRelX(180+Rx)
      targetMtx.rotateRelY(Ry)
      targetMtx.rotateRelZ(Rz)
      robotMove = self.Controller.createTarget()
      rc = robotMove.RobotConfig
      robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
      robotMove.TargetMode = VC_MOTIONTARGET_TM_WORLDTARGET
      robotMove.Target = targetMtx
      if self.ActiveTool:
        try:
          robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
        except:
          robotMove.ToolName = self.ActiveTool

      # Call RSL
      doRSL(self, VC_STATEMENT_LINMOTION, robotMove)
    else:
      print 'Error: vcHelpers.Robot.linearMoveToComponent() was unable to get the target component'


  def jointMoveToComponent(self, ToComp, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, ToFrame = None, OnFace = None):
    global app
    if type(ToComp) == type('DummyString'):
      ToComp = app.findComponent(ToComp)
    if ToComp:
      ToComp.update()
      ToMtx = ToComp.WorldPositionMatrix
      targetMtx = vcMatrix.new(ToMtx)
      if ToFrame:
        try:
          frameMtx = ToFrame.NodePositionMatrix
        except:
          try:
            ToFrame = ToComp.findFeature(ToFrame)
            frameMtx = ToFrame.NodePositionMatrix
          except:
            print 'Error: vcHelpers.Robot.jointMoveToComponent() was unable to get the ToFrame feature'
        try:
          targetMtx = targetMtx * frameMtx
        except:
          pass
        if not ToComp.getFeature(ToFrame.Name):
          print 'Error: vcHelpers.Robot.jointMoveToComponent(): ToFrame feature is not within ToComp - node'
          print '         - There might be error in matrix calculations due to this fact.'
          print '         - Please change ToFrame or ToComp - objects or move the ToFrame-feature under',ToComp.Name,'-node in node tree.'
      elif OnFace:
        onFace(ToComp,targetMtx,OnFace)
      targetMtx.translateRel(Tx,Ty,Tz)
      targetMtx.rotateRelX(180+Rx)
      targetMtx.rotateRelY(Ry)
      targetMtx.rotateRelZ(Rz)
      robotMove = self.Controller.createTarget()
      rc = robotMove.RobotConfig
      robotMove.MotionType = VC_MOTIONTARGET_MT_JOINT
      robotMove.TargetMode = VC_MOTIONTARGET_TM_WORLDTARGET
      robotMove.Target = targetMtx
      if self.ActiveTool:
        try:
          robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
        except:
          robotMove.ToolName = self.ActiveTool

      # Call RSL
      doRSL(self, VC_STATEMENT_PTPMOTION, robotMove)
    else:
      print 'Error: vcHelpers.Robot.jointMoveToComponent() was unable to get the target component'


  def linearMoveToPosition(self, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, CS = 'world'):
    targetMtx = vcMatrix.new()
    targetMtx.translateRel(Tx,Ty,Tz)
    targetMtx.rotateRelX(180+Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    robotMove = self.Controller.createTarget()
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
    if CS == 'world':
      robotMove.TargetMode = VC_MOTIONTARGET_TM_WORLDTARGET
    else:
      pass
      #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool

    # Call RSL
    doRSL(self, VC_STATEMENT_LINMOTION, robotMove)


  def jointMoveToPosition(self, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, CS = 'world'):
    targetMtx = vcMatrix.new()
    targetMtx.translateRel(Tx,Ty,Tz)
    targetMtx.rotateRelX(180+Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    robotMove = self.Controller.createTarget()
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_JOINT
    if CS == 'world':
      robotMove.TargetMode = VC_MOTIONTARGET_TM_WORLDTARGET
    else:
      pass
      #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool
    ####### TEST WITH 2011

    ######

    # Call RSL
    doRSL(self, VC_STATEMENT_PTPMOTION, robotMove)


  def linearMoveToMtx_ExternalBase(self, Basenode, ToMtx = idMTX, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0):
    targetMtx = vcMatrix.new(ToMtx)
    targetMtx.translateRel(Tx, Ty, Tz)
    targetMtx.rotateRelX(Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    base = self.Controller.Bases[self.ActiveBase]
    self.Controller.Bases[self.ActiveBase].Node = Basenode # <= 2011 bug fix
    if Basenode:
      Basenode.update()
      self.Component.update()
    base.PositionMatrix = vcMatrix.new()
    robotMove = self.Controller.createTarget()
    rc = robotMove.RobotConfig
    robotMove.BaseName = self.Controller.Bases[self.ActiveBase].Name
    robotMove.TargetMode = VC_MOTIONTARGET_TM_NORMAL
    robotMove.Target = targetMtx
    #printMatrix(targetMtx)
    robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool

    # Call RSL
    doRSL(self, VC_STATEMENT_LINMOTION, robotMove, Basenode)



  def jointMoveToMtx_ExternalBase(self, Basenode, ToMtx = idMTX, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0):
    targetMtx = vcMatrix.new(ToMtx)
    targetMtx.translateRel(Tx, Ty, Tz)
    targetMtx.rotateRelX(Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    base = self.Controller.Bases[self.ActiveBase]
    self.Controller.Bases[self.ActiveBase].Node = Basenode  # <= 2011 bug fix
    if Basenode:
      Basenode.update()
      self.Component.update()
    base.PositionMatrix = vcMatrix.new()
    robotMove = self.Controller.createTarget()
    rc = robotMove.RobotConfig
    robotMove.BaseName = self.Controller.Bases[self.ActiveBase].Name
    robotMove.TargetMode = VC_MOTIONTARGET_TM_NORMAL
    robotMove.Target = targetMtx
    robotMove.MotionType = VC_MOTIONTARGET_MT_JOINT
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool
    # Call RSL
    doRSL(self, VC_STATEMENT_PTPMOTION, robotMove, Basenode)


  def followNode(self, Basenode, FollowTime=1):
    base = self.Controller.Bases[self.ActiveBase]
    self.Controller.Bases[self.ActiveBase].Node = Basenode # <= 2011 bug fix
    if Basenode:
      Basenode.update()
      self.Component.update()
    base.PositionMatrix = vcMatrix.new()
    robotMove = self.Controller.createTarget()
    robotMove.BaseName = self.Controller.Bases[self.ActiveBase].Name
    robotMove.TargetMode = VC_MOTIONTARGET_TM_NORMAL
    robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
    self.Executor.deleteSubRoutine('vcHelperMove')
    subr = self.Executor.createSubRoutine('vcHelperMove')
    statement = subr.createStatement(VC_STATEMENT_LINMOTION)
    if Basenode:
      self.Controller.Bases[self.ActiveBase].Node = Basenode  
    statement.readFromTarget(robotMove)
    self.Executor.callRoutine('vcHelperMove')
    delay(FollowTime)
    self.Controller.Bases[self.ActiveBase].Node = None # self.ActiveBase


  def moveAway(self, Tz = 200):
    robotMove = self.Controller.createTarget()
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool
    targetMtx = vcMatrix.new(robotMove.Target)
    targetMtx.translateRel(0,0,-Tz)
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
    #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx

    # Call RSL
    doRSL(self, VC_STATEMENT_LINMOTION, robotMove)


  def linearMoveRel(self, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0):
    robotMove = self.Controller.createTarget()
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool
    targetMtx = vcMatrix.new(robotMove.Target)
    targetMtx.translateRel(Tx, Ty, Tz)
    targetMtx.rotateRelX(Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
    #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx

    # Call RSL
    doRSL(self, VC_STATEMENT_LINMOTION, robotMove)


  def jointMoveRel(self, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0):
    robotMove = self.Controller.createTarget()
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool
    targetMtx = vcMatrix.new(robotMove.Target)
    targetMtx.translateRel(Tx, Ty, Tz)
    targetMtx.rotateRelX(Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_JOINT
    #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx

    # Call RSL
    doRSL(self, VC_STATEMENT_PTPMOTION, robotMove)


  def driveJoints(self, J1 = 'current', J2 = 'current', J3 = 'current', J4 = 'current', J5 = 'current', J6 = 'current', MotionTime = 0, Relative = False, ExtraJoints = []):
    vals = []
    givenVals = [J1, J2, J3, J4, J5, J6]
    givenVals.extend( ExtraJoints )
    for i in range(len(self.Controller.Joints)):
      # get current values
      curVal = self.Controller.Joints[i].CurrentValue
      vals.append(curVal)
    for i in range( len(vals) - len(givenVals) ):
      givenVals.append('current')
    for i in range(len(vals)):
      if givenVals[i] != 'current':
        # update only given values, rest are left current
        if Relative:
          # relative
          vals[i] += givenVals[i]
        else:
          # absolute
          vals[i] = givenVals[i]
      # set joint targets
      val = vals[i]
      self.Controller.setJointTarget(i, val)
    if MotionTime:
      # override accs, decs and speeds if motiontime given != 0
      self.Controller.setMotionTime(MotionTime)
    motTime = self.Controller.calcMotionTime() # calc motiontime to return
    self.Controller.move()
    return motTime
      


  def pick(self, Part, Approach = 200, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0,OnFace = 'top', ApproachAxis = 'Z'):
    if Part:
      if ApproachAxis == 'Z':
        self.jointMoveToComponent(Part, Tx=Tx,Ty=Ty,Tz=Tz+Approach,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace)
      elif ApproachAxis == '-Z':
        self.jointMoveToComponent(Part, Tx=Tx,Ty=Ty,Tz=Tz-Approach,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace)
      elif ApproachAxis == 'Y':
        self.jointMoveToComponent(Part, Tx=Tx,Ty=Ty+Approach,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace)
      elif ApproachAxis == '-Y':
        self.jointMoveToComponent(Part, Tx=Tx,Ty=Ty-Approach,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace)
      elif ApproachAxis == 'X':
        self.jointMoveToComponent(Part, Tx=Tx+Approach,Ty=Ty,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace)
      elif ApproachAxis == '-X':
        self.jointMoveToComponent(Part, Tx=Tx-Approach,Ty=Ty,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace)
      self.linearMoveToComponent(Part, Tx,Ty,Tz,Rx,Ry,Rz,OnFace=OnFace)
      self.graspComponent(Part)
      if ApproachAxis == 'Z':
        self.linearMoveToComponent(Part, Tx=Tx,Ty=Ty,Tz=Tz+Approach,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace)
      elif ApproachAxis == 'Y':
        self.linearMoveToComponent(Part, Tx=Tx,Ty=Ty+Approach,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace)
      elif ApproachAxis == 'X':
        self.linearMoveToComponent(Part, Tx=Tx+Approach,Ty=Ty,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace)
      if ApproachAxis == '-Z':
        self.linearMoveToComponent(Part, Tx=Tx,Ty=Ty,Tz=Tz-Approach,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace)
      elif ApproachAxis == '-Y':
        self.linearMoveToComponent(Part, Tx=Tx,Ty=Ty-Approach,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace)
      elif ApproachAxis == '-X':
        self.linearMoveToComponent(Part, Tx=Tx-Approach,Ty=Ty,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace)


  def place(self, ToComp, Approach = 200, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, Part = None, ApproachAxis = 'Z'):
    if self.GraspContainer.Components or Part:
      if not Part:
        Part = self.GraspContainer.Components[0]
      PartHeight = Part.Geometry.BoundDiagonal.Z*2
      PartWidth = Part.Geometry.BoundDiagonal.Y*2
      PartLength = Part.Geometry.BoundDiagonal.X*2
      appr = Approach+PartHeight
      if ApproachAxis == 'Z':
        self.jointMoveToComponent(ToComp, Tx = Tx, Ty = Ty, Tz = Tz+appr+PartHeight, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')
      elif ApproachAxis == 'Y':
        self.jointMoveToComponent(ToComp, Tx = Tx, Ty = Ty+appr+PartWidth, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')
      elif ApproachAxis == 'X':
        self.jointMoveToComponent(ToComp, Tx = Tx+appr+PartLength, Ty = Ty, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')
      if ApproachAxis == '-Z':
        self.jointMoveToComponent(ToComp, Tx = Tx, Ty = Ty, Tz = Tz-appr-PartHeight, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')
      elif ApproachAxis == '-Y':
        self.jointMoveToComponent(ToComp, Tx = Tx, Ty = Ty-appr-PartWidth, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')
      elif ApproachAxis == '-X':
        self.jointMoveToComponent(ToComp, Tx = Tx-appr-PartLength, Ty = Ty, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')
      self.linearMoveToComponent(ToComp, Tx = Tx, Ty = Ty, Tz = Tz+PartHeight, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')
      self.releaseComponent(ToComp,Part)
      if ApproachAxis == 'Z':
        self.linearMoveToComponent(ToComp, Tx = Tx, Ty = Ty, Tz = Tz+appr+PartHeight, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')
      elif ApproachAxis == 'Y':
        self.linearMoveToComponent(ToComp, Tx = Tx, Ty = Ty+appr+PartWidth, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')
      elif ApproachAxis == 'X':
        self.linearMoveToComponent(ToComp, Tx = Tx+appr+PartLength, Ty = Ty, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')
      if ApproachAxis == '-Z':
        self.linearMoveToComponent(ToComp, Tx = Tx, Ty = Ty, Tz = Tz-appr-PartHeight, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')
      elif ApproachAxis == '-Y':
        self.linearMoveToComponent(ToComp, Tx = Tx, Ty = Ty-appr-PartWidth, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')
      elif ApproachAxis == '-X':
        self.linearMoveToComponent(ToComp, Tx = Tx-appr-PartLength, Ty = Ty, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top')


  def placeInPattern(self, ToComp, X_index, Y_index, Z_index, PatternSize_X = 0, PatternSize_Y = 0, PatternSize_Z = 0, Approach = 200, Part = None, StepSizeX = 0, StepSizeY = 0, StepSizeZ = 0, Rz = 0):
    if self.GraspContainer.Components or Part:
      if not Part:
        Part = self.GraspContainer.Components[0]
      if not StepSizeX:
        StepSizeX = Part.Geometry.BoundDiagonal.X*2
      if not StepSizeY:
        StepSizeY = Part.Geometry.BoundDiagonal.Y*2
      if not StepSizeZ:
        StepSizeZ = Part.Geometry.BoundDiagonal.Z*2
      appr = Approach+StepSizeZ
      xOffset = -(StepSizeX*(PatternSize_X-1))/2 + StepSizeX*X_index
      yOffset = -(StepSizeY*(PatternSize_Y-1))/2 + StepSizeY*Y_index
      zOffset = Z_index*StepSizeZ
      self.jointMoveToComponent(ToComp, Tx = xOffset, Ty = yOffset, Tz = zOffset+appr, Rz = Rz, OnFace = 'top')
      self.linearMoveToComponent(ToComp, Tx = xOffset, Ty = yOffset, Tz = zOffset+StepSizeZ, Rz = Rz, OnFace = 'top')
      self.releaseComponent(ToComp,Part)
      self.moveAway(Approach)


  def pickFromPallet(self, Pallet, Approach = 200, InversedOrder = False, Index = -1):
    if Pallet:
      Parts = []
      PalletConts = Pallet.findBehavioursByType(VC_CONTAINER)
      for cont in PalletConts:
        Parts.extend(cont.Components)
      if not Parts:
        Parts = Pallet.ChildComponents
      if Parts:
        if InversedOrder:
          Part = Parts[0]
        else:
          Part = Parts[-1]
        if Index != -1:
          if Index > len(Parts)-1:
            print 'Warning: vcHelpers.Robot: From component', self.Component.Name
            print '          Given "Index" argument is out of range. There are not that many parts on pallet.'
            return
          Part = Parts[Index]
        self.jointMoveToComponent(Part,Tz = Approach, OnFace = 'top')
        self.linearMoveToComponent(Part, OnFace = 'top')
        self.graspComponent(Part)
        self.linearMoveToComponent(Part,Tz = Approach, OnFace = 'top')
        return Part


  def pickMovingPart(self, Part, Approach = 200, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, ForceUpdatePos = True, rrx = -1, rry = -1, rrz = -1): # (debug args: ForceUpdatePos = True, rrx = -1, rry = -1, rrz = -1) (future arg#Advancement = 200)
    if Part:
      if self.RecordRSL:
        print 'Warning: vcHelpers.Robot: From component', self.Component.Name
        print '       - RSL-statement base configuration may need reconfiguration before post-processing.'
        print '       - External base node is overwritten on every statement creation.'
      ToMtx = vcMatrix.new()
      partHeight = Part.Geometry.BoundDiagonal.Z*2
      #self.jointMoveToMtx_ExternalBase(ToMtx, Part, Tx = Advancement, Tz = partHeight+Approach, Rx = 180)
      tx, ty, tz, rx, ry, rz = Tx, Ty, Tz, Rx, Ry, Rz
      self.linearMoveToMtx_ExternalBase(Part, ToMtx, Tx = Tx, Ty = Ty, Tz = partHeight + Tz, Rx = 180 + Rx, Ry = 0 + Ry, Rz = Rz)
      self.graspComponent(Part)
      # Force part on right position
      if ForceUpdatePos:
        # Get tool position
        if self.ActiveTool:
          if type(self.ActiveTool) == type('DummyString'):
            for i in self.Controller.Tools:
              if i.Name == self.ActiveTool:
                toolpos = i.PositionMatrix
          else:
            toolpos = self.Controller.Tools[self.ActiveTool-1].PositionMatrix
        else:
          toolpos = vcMatrix.new()
        toolpos.rotateRelZ(rz*rrz)
        toolpos.rotateRelY(ry*rry)
        toolpos.rotateRelX(rx*rrx)
        toolpos.translateRel(-tx,ty,tz+partHeight)
        partpos = vcMatrix.new(Part.PositionMatrix)
        v = partpos.P
        v.X = 0.0 + toolpos.P.X
        v.Y = 0.0 + toolpos.P.Y
        v.Z = 0.0 + toolpos.P.Z
        partpos.P = v
        Part.PositionMatrix = partpos
        Part.update()
      # Move away
      self.moveAway(Approach)


  def graspComponent(self, GraspThis):
    self.GraspContainer.grab(GraspThis)
    if self.RecordRSL:
      if self.ActiveTool:
        if type(self.ActiveTool) == type('DummyString'):
          run = 1
          for i in self.Controller.Tools:
            if i.Name == self.ActiveTool:
              tool = run
            run += 1
        else:
          tool = self.ActiveTool
      addRecStatement(self,VC_STATEMENT_SETBIN, tool, True)

  def graspComponents(self, GraspThese):
    for i in GraspThese:
      self.GraspContainer.grab(i)
    if self.RecordRSL:
      if self.ActiveTool:
        if type(self.ActiveTool) == type('DummyString'):
          run = 1
          for i in self.Controller.Tools:
            if i.Name == self.ActiveTool:
              tool = run
            run += 1
        else:
          tool = self.ActiveTool
      addRecStatement(self,VC_STATEMENT_SETBIN, tool, True)

  def releaseComponent(self, ToObject, ReleseThis = None):
    toContainer = None
    if not ReleseThis and  self.GraspContainer.Components:
      ReleseThis = self.GraspContainer.Components[0]
    elif not ReleseThis:
      print 'Error: vcHelpers.Robot: No component to release from graspContainer in robot', self.Component.Name
      return
    try:
      ToObject.Components
      toContainer = ToObject
    except:
      try:
        toContainer = ToObject.findBehavioursByType(VC_CONTAINER)[0]
      except:
        pass
    if not toContainer:
      try:
        ToObject.update()
        ReleseThis.update()
        newpos = ToObject.InverseWorldPositionMatrix*ReleseThis.WorldPositionMatrix
        ToObject.attach(ReleseThis)
        ReleseThis.PositionMatrix = newpos
      except:
        print 'Error: vcHelpers.Robot was unable to find detect targetContainer in ',ToObject.Name
    else:
      toContainer.grab(ReleseThis)
    if self.RecordRSL:
      if self.ActiveTool:
        if type(self.ActiveTool) == type('DummyString'):
          run = 1
          for i in self.Controller.Tools:
            if i.Name == self.ActiveTool:
              tool = run
            run += 1
        else:
          tool = self.ActiveTool
      addRecStatement(self,VC_STATEMENT_SETBIN, tool, False)

  def releaseAllComponents(self, ToObject):
    toContainer = None
    try:
      ToObject.Components
      toContainer = ToObject
    except:
      try:
        toContainer = ToObject.findBehavioursByType(VC_CONTAINER)[0]
      except:
        pass
    for iPart in self.GraspContainer.Components:
      if not toContainer:
        try:
          ToObject.update()
          iPart.update()
          newpos = ToObject.InverseWorldPositionMatrix*iPart.WorldPositionMatrix
          ToObject.attach(iPart)
          iPart.PositionMatrix = newpos
        except:
          print 'Error: vcHelpers.Robot was unable to find detect targetContainer in ',ToObject.Name
      else:
        toContainer.grab(iPart)
    if self.RecordRSL:
      if self.ActiveTool:
        if type(self.ActiveTool) == type('DummyString'):
          run = 1
          for i in self.Controller.Tools:
            if i.Name == self.ActiveTool:
              tool = run
            run += 1
        else:
          tool = self.ActiveTool
      addRecStatement(self,VC_STATEMENT_SETBIN, tool, False)

  def traceOn(self,Index = 1):
    self.SignalMapOut.output(Index+16,True)
    if self.RecordRSL:
      addRecStatement(self,VC_STATEMENT_SETBIN, Index+16, True)
    
  def traceOff(self,Index = 1):
    self.SignalMapOut.output(Index+16,False)
    if self.RecordRSL:
      addRecStatement(self,VC_STATEMENT_SETBIN, Index+16, False)

  def mountTool(self, Tool):
    try:
      iface = self.Controller.FlangeNode.getBehavioursByType(VC_ONETOONEINTERFACE)[0]
      if Tool:
        if iface:
          # check interfaces in the other component
          ifaces = Tool.findBehavioursByType(VC_ONETOONEINTERFACE )
          for other_iface in ifaces:
            if iface.canConnect(other_iface ):
              if iface.connect( other_iface, False ):
                iface.connect( other_iface, False )
                break
              else:
                print "Error: vcHelpers.Robot: Tool to mount has interface already connected"
          else:
            return "Error: vcHelpers.Robot: No matching interface detected to mount tool"
      else:
        print "Error: vcHelpers.Robot: No tool detected to mount"
    except:
      print 'Error: vcHelpers.Robot was unable to mount a Tool'
    if self.RecordRSL:
      if self.ActiveTool:
        if type(self.ActiveTool) == type('DummyString'):
          run = 1
          for i in self.Controller.Tools:
            if i.Name == self.ActiveTool:
              tool = run
            run += 1
        else:
          tool = self.ActiveTool
      addRecStatement(self,VC_STATEMENT_SETBIN, tool+32, True)
      
  
  def unmountTool(self, Tool, ToObject):
    toContainer = None
    iface = self.Controller.FlangeNode.getBehavioursByType(VC_ONETOONEINTERFACE)[0]
    if iface:
      iface.unConnect()
    if not Tool:
      print 'Error: vcHelpers.Robot: No such Tool to be unmounted in robot', self.Component.Name
      return
    try:
      ToObject.Components
      toContainer = ToObject
    except:
      try:
        toContainer = ToObject.findBehavioursByType(VC_CONTAINER)[0]
      except:
        pass
    if not toContainer:
      try:
        ToObject.update()
        Tool.update()
        newpos = ToObject.InverseWorldPositionMatrix*Tool.WorldPositionMatrix
        ToObject.attach(Tool)
        Tool.PositionMatrix = newpos
      except:
        print 'Error: vcHelpers.Robot was unable to find detect targetContainer for unmounting in ',ToObject.Name
    else:
      toContainer.grab(Tool)
    if self.RecordRSL:
      if self.ActiveTool:
        if type(self.ActiveTool) == type('DummyString'):
          run = 1
          for i in self.Controller.Tools:
            if i.Name == self.ActiveTool:
              tool = run
            run += 1
        else:
          tool = self.ActiveTool
      addRecStatement(self,VC_STATEMENT_SETBIN, self.ActiveTool+32, False)


  def callSubRoutine(self, rName):
    self.Executor.callRoutine(rName)
    if self.RecordRSL:
      addRecStatement(self,VC_STATEMENT_CALL, rName, None)


  def comment(self, Comment):
    print 'Comment From vcRobot -',self.Component.Name,':'
    print '    -',str(Comment)
    if self.RecordRSL:
      addRecStatement(self,VC_STATEMENT_COMMENT, Comment, None)


  def delay(self, Delay):
    if Delay < 0:
      Delay=0
    delay(Delay)
    if self.RecordRSL:
      addRecStatement(self,VC_STATEMENT_DELAY, Delay, None)


  def rsl_BinOut(self, Index, Value):
    addRecStatement(self,VC_STATEMENT_SETBIN, Index, Value)
  

  def rsl_BinIn(self, Index, Value):
    addRecStatement(self,VC_STATEMENT_WAITBIN, Index, Value)

  def setMotionTime(self, MotionTime):
    self.MotionTime = MotionTime


def getRobot(arg = None, SetActionMode = True):
  argType = None
  comp = getComponent
  # Test if the given argument is a robot component (vcComponent), interface name (string) or None
  
  # Component - arg
  try:
    arg.VCID
    argType = 'component'
  
  except:
    if not argType and type(arg) == type('dummystring'):
  # Iface name - arg
      argType = 'iface'
  # None - arg
  
  # Find robot component and save it to roboComp - variable
  if argType == None:
    roboComp = getComponent()
  elif argType == 'component':
    roboComp = arg
  elif argType == 'iface':
    iface = getComponent().findBehaviour(arg)
    if not iface or iface.Type != VC_ONETOONEINTERFACE:
      print 'Error: vcHelpers.Robot was unable to find interface called',arg,'in component "',getComponent().Name,'".'
      return None
    else:
      roboComp = iface.ConnectedComponent
      if not roboComp:
        print 'Error: vcHelpers.Robot was unable to find robot.'
        print '       - Connect robot to "',iface.Name,'"-interface.'
    
  # Find Controller, Executor, GraspContainer and signalMap
  controllers = roboComp.findBehavioursByType(VC_ROBOTCONTROLLER)
  executors = roboComp.findBehavioursByType(VC_RSLEXECUTOR)
  try:
    controller = controllers[0]    
  except:
    print 'Error: vcHelpers.Robot was unable to find controller in component "',roboComp.Name,'".'
    return
  
  try:
    executor = executors[0]
    executor.ActionMode = SetActionMode
    signalMapOut = executor.DigitalMapOut
    signalMapIn = executor.DigitalMapIn
  except:
    print 'Error: vcHelpers.Robot was unable to find executor in component "',roboComp.Name,'".'
    return
    
  graspContainers = roboComp.findBehavioursByType(VC_COMPONENTCONTAINER)
  if not graspContainers:
    print 'Error: vcHelpers.Robot was unable to find graspContainers in component "',roboComp.Name,'".'
    print '       - Robot model is being manipulated: GraspContainer added.'
    graspContainer = controller.FlangeNode.createBehaviour(VC_COMPONENTCONTAINER,'GraspContainer')
  else:
    graspContainer = graspContainers[-1]
    

  
  return vcRobot(roboComp, controller, executor, graspContainer, signalMapIn, signalMapOut)
    

  
def doRSL(robo, mtnType, robotMove, Basenode = None):
  robo.Executor.deleteSubRoutine('vcHelperMove')
  subr = robo.Executor.createSubRoutine('vcHelperMove')
  statement = subr.createStatement(mtnType)
  
  if robo.Configuration != -1 and mtnType == VC_STATEMENT_PTPMOTION:
    if type(robo.Configuration) == str:
      if robo.Configuration in robo.ConfigurationsList:
        conf = robo.ConfigurationsList.index(robo.Configuration)
        robotMove.RobotConfig = conf
      else:
        print 'Configuration name "%s" not found' % (robo.Configuration)
    else:
      robotMove.RobotConfig = robo.Configuration
  if Basenode:
    robo.Controller.Bases[robo.ActiveBase].Node = Basenode  
  
  statement.readFromTarget(robotMove)

  updSpeeds(robo, statement)
  if robo.MotionTime >= 0:
    statement.CycleTime = robo.MotionTime
  robo.Executor.callRoutine('vcHelperMove')
  robo.Controller.Bases[robo.ActiveBase].Node = None # self.ActiveBase
  if Basenode:
    Basenode.rebuild()
  if robo.RecordRSL:
    recRSL(robo, mtnType, robotMove, Basenode)
  mtx = vcMatrix.new()
  robotMove.Target = mtx
  robo.MotionTime = 0


def recRSL(robo, mtnType, robotMove, Basenode = None):
  subr = robo.RecordRoutineObject
  statement = subr.createStatement(mtnType)
  statement.readFromTarget(robotMove)
  if Basenode:
    robo.Controller.Bases[robo.ActiveBase].Node = Basenode
  updSpeeds(robo, statement)
  robo.Executor.callRoutine('vcHelperMove')
  robo.Controller.Bases[robo.ActiveBase].Node = None
  #mtx = vcMatrix.new()
  #robotMove.Target = mtx
  if Basenode:
    Basenode.rebuild()


def addRecStatement(robo,type, arg1 = 0, arg2 = 0):
  subr = robo.RecordRoutineObject
  statement = subr.createStatement(type)
  if type == VC_STATEMENT_SETBIN:
    statement.Output = arg1
    statement.Value = arg2
  elif type == VC_STATEMENT_CALL:
    statement.RoutineName = arg1
  elif type == VC_STATEMENT_COMMENT:
    statement.Comment = str(arg1)
  elif type == VC_STATEMENT_DELAY:
    statement.Delay = arg1
  elif type == VC_STATEMENT_WAITBIN:
    statement.Input = arg1
    statement.Value = arg2
    


def onFace(ToComp,targetMtx,OnFace):
  compBC = ToComp.Geometry.BoundCenter
  compBD = ToComp.Geometry.BoundDiagonal
  if OnFace == 'top':
    targetMtx.translateRel(compBC.X,compBC.Y,compBC.Z+compBD.Z)
  if OnFace == 'bottom':
    targetMtx.translateRel(compBC.X,compBC.Y,compBC.Z-compBD.Z)
    targetMtx.rotateRelY(180)
  if OnFace == 'right':
    targetMtx.translateRel(compBC.X,compBC.Y-compBD.Y,compBC.Z)
    targetMtx.rotateRelX(90)
  if OnFace == 'left':
    targetMtx.translateRel(compBC.X,compBC.Y+compBD.Y,compBC.Z)
    targetMtx.rotateRelX(-90)
  if OnFace == 'front':
    targetMtx.translateRel(compBC.X+compBD.X,compBC.Y,compBC.Z)
    targetMtx.rotateRelY(90)
  if OnFace == 'back':
    targetMtx.translateRel(compBC.X-compBD.X,compBC.Y,compBC.Z)
    targetMtx.rotateRelY(-90)
    

def updSpeeds(robo, statement):
  if statement.Type == VC_STATEMENT_PTPMOTION:
    statement.JointSpeed = robo.JointSpeed
    statement.JointForce = robo.JointForce
  else:
    statement.AngularAcceleration = robo.AngularAcc
    statement.AngularDeceleration = robo.AngularAcc
    statement.MaxAngularSpeed = robo.AngularSpeed
    statement.Acceleration = robo.Acc
    statement.Deceleration = robo.Acc
    statement.MaxSpeed = robo.Speed
  
  
  
def printMatrix(mat):
  """Usefull utiliTy function for printing matrix value"""
  print '----------------------------------------------------------------------'
  for Vec in [mat.N,mat.O,mat.A,mat.P]:
    s = ''
    x = round(Vec.X,3)
    y = round(Vec.Y,3)
    z = round(Vec.Z,3)
    w = round(Vec.W,3)
    s += str(x)
    while len(s) <15:
      s+=' '
    s += str(y)
    while len(s) <30:
      s+=' '
    s += str(z)
    while len(s) <45:
      s+=' '
    s += str(w)
    print s
  print '----------------------------------------------------------------------'
  
  
 
  
def getSelectedRobotsData():
  global app
  program = None
  routine = None
  controller = None
  basename = '*NULL*'
  toolname = '*NULL*'
  basenames = []
  toolnames = []
  robotconfig = -1
  robotconfigs = []
  sel = app.SelectionManager
  try:
    robocomp = app.CurrentContext.ActiveRobot
  except:
    try:
      robocomp = app.CurrentContext.ActiveComponent
    except:
      selected_components = sel.getSelection(VC_SELECTION_COMPONENT)
      if len(selected_components) == 1:
        robocomp = selected_components[0]
      else:
        robocomp = None
  if robocomp:
    executors = robocomp.findBehavioursByType( VC_RSLEXECUTOR )
    if len(executors) == 1:
      program = executors[0]
    if not program:
      print "Current selection is not valid - Select a Robot RSL Program" 
      return None
    routine = program.CurrentRoutine
    controller = program.Controller
    controller.clearTargets()
    motiontarget = controller.createTarget()
    basename = motiontarget.BaseName
    if basename == '':
      basename = '*NULL*'
    #endif
    toolname = motiontarget.ToolName
    if toolname == '':
      toolname = '*NULL*'
    #endif
    robotconfig = motiontarget.RobotConfig
    motiontarget.TargetMode = VC_MOTIONTARGET_TM_NORMAL
    basenames = [ '*NULL*' ]
    for b in controller.Bases:
      basenames.append( b.Name )
    #endfor
    toolnames = [ '*NULL*' ]
    for t in controller.Tools:
      toolnames.append( t.Name )
    #endfor
    dummyStatement = routine.createStatement(VC_STATEMENT_PTPMOTION)
    for prop in dummyStatement.Properties:
      if prop.Name == 'Configuration':
        break
      else:
        prop = None
      #endif
    #endfor
    if prop == None:
      robotconfigs = ['Config1', 'Config2', 'Config3', 'Config4', 'Config5', 'Config6', 'Config7', 'Config8']
    else:
      robotconfigs = []
      for config in prop.StepValues:
        robotconfigs.append( config )
      #endfor
    #endif
    routine.deleteStatement( dummyStatement.Index )
    return (program,routine,controller,basename,toolname,basenames,toolnames,robotconfig,robotconfigs)
  else:
    print "Current selection is not valid - Select a Robot RSL Program" 
    return None
  

def getConfigNames(executor, controller):
    robotconfigs = []
    routine = executor.MainRoutine
    controller.clearTargets()
    motiontarget = controller.createTarget()
    robotconfig = motiontarget.RobotConfig
    motiontarget.TargetMode = VC_MOTIONTARGET_TM_NORMAL
    dummyStatement = routine.createStatement(VC_STATEMENT_PTPMOTION)
    for prop in dummyStatement.Properties:
      if prop.Name == 'Configuration':
        break
      else:
        prop = None
    if prop == None:
      robotconfigs = ['Config1', 'Config2', 'Config3', 'Config4', 'Config5', 'Config6', 'Config7', 'Config8']
    else:
      for config in prop.StepValues:
        robotconfigs.append( config )
    controller.clearTargets()
    routine.beginBatch()
    #for i in range( routine.StatementCount ): # commented out in 2012SP2
    routine.deleteStatement(len(routine.Statements)-1)
    routine.endBatch()
    return robotconfigs   
 