try:
  from vcCommand import *
except:
  try:
    from vcScript import *
  except:
    print "Error: vcHelpers.Application was unable to import vcCommand and vcScript"

global previousmessage, propWin, app, cmd
previousmessage = ''
app = getApplication()
cmd = None
property_counter = 0

################################################
 # Command Helpers 
################################################

def findCommand(name):
  return app.findCommand(name)
   
################################################
 # Progress / Message Helpers 
################################################

def startMessage(message):
  print message
  app.ProgressStatus = message
  app.ProgressValue = 0.0

def progressMessage(message,fraction=-1.0):
  global previousmessage
  if message == previousmessage:
    return
  previousmessage = message
  print message
  app.ProgressStatus = message
  if fraction > 0.0:
    app.ProgressValue = fraction

def endMessage(message):
  print message
  app.ProgressStatus = message
  app.ProgressValue = 2.0
  
def progressStdMessage(completed,all):
  if all < 1:
    return
  fullfraction = (1.0*completed)/(1.0*all)
  if all > 1000:
    fraction = int(100*fullfraction)
  elif all > 100:
    fraction = 10*int(10*fullfraction)
  elif all > 25:
    fraction = 25*int(4*fullfraction)
  else:
    fraction = 50*int(2*fullfraction)
  progressMessage('  %.f percentage done...' % (fraction),fullfraction)
  
################################################
 # Property Helpers 
################################################
''' 
Supported proerty types:
VC_BOOLEAN 
VC_INTEGER
VC_REAL
VC_STRING 
VC_VECTOR
VC_MATRIX
VC_EXPRESSION
VC_URI
VC_BUTTON
VC_MATERIAL 
VC_OBJECT 
VC_OBJECTLIST 

Supported property kinds:
VC_PROPERTY_DEFAULT
VC_PROPERTY_LIMIT
VC_PROPERTY_STEP
'''
builtInProps = set(["Name","BackfaceMode","PDFExportLevel","Visible","Material","BOM","BOMname","BOMdescription","Category","SimulationLevel"])

def resetPropertyCounter():
  global property_counter
  property_counter = 0

def addProperty(owner,type,name,visible,rebuild,update,value,onchanged,units):
  global property_counter
  property = owner.getProperty( name )
  if property != None:
    if property.Name not in builtInProps:
      owner.deleteProperty( property )
    else: 
      return None
  property = owner.createProperty( type, name )
  property.IsVisible = visible
  property.ChangeOnRebuild = rebuild
  property.ChangeOnUpdate = update
  if units != '' and units != None:
    property.Quantity = units 
    property.Magnitude = 1.0 
  #endif 
  if type != VC_BUTTON:
    property.Value = value
  property.OnChanged = onchanged
  property.Group = property_counter
  property_counter += 1
  return property

def addLimitProperty(owner,type,name,visible,rebuild,update,value,onchanged,units,min,max):
  global property_counter
  property = owner.getProperty( name )
  if property != None:
    if property.Name not in builtInProps:
      owner.deleteProperty( property )
    else: 
      return None
  property = owner.createProperty( type, name, VC_PROPERTY_LIMIT )
  property.MinValue = min
  property.MaxValue = max
  property.IsVisible = visible
  property.ChangeOnRebuild = rebuild
  property.ChangeOnUpdate = update
  if units != '' and units != None:
    property.Quantity = units 
    property.Magnitude = 1.0 
  #endif
  property.Value = value
  property.OnChanged = onchanged
  property.Group = property_counter
  property_counter += 1
  return property

def addStepProperty(owner,type,name,visible,rebuild,update,value,onchanged,units,steps):
  global property_counter
  property = owner.getProperty( name )
  if property != None:
    if property.Name not in builtInProps:  
      owner.deleteProperty( property )
    else: 
      return None
    #endif
  #endif
  property = owner.createProperty( type, name, VC_PROPERTY_STEP )
  if property.Type == VC_INTEGER:
    property.StepValues = [int(stp) for stp in steps]
  elif property.Type != 'Ref<Node>' and property.Type != 'List<Ref<Node> >' :
    property.StepValues = steps
  #endif    
  property.IsVisible = visible
  property.ChangeOnRebuild = rebuild
  property.ChangeOnUpdate = update
  if units != '' and units != None:
    property.Quantity = units 
    property.Magnitude = 1.0 
  #endif
  property.Value = value
  property.OnChanged = onchanged
  property.Group = property_counter
  property_counter += 1
  return property
  
def copyProperties(op1, op2):
  for prop in op1.Properties:
    if prop.Name not in builtInProps:       
      quantity = ''
      if prop.Type == VC_REAL or prop.Type == VC_VECTOR or prop.Type == VC_MATRIX:
        if prop.Quantity != None:
          quantity = prop.Quantity
      OnChanged = None
      if prop.StepValues != None:
        newProp =  addStepProperty(op2,prop.Type,prop.Name,prop.IsVisible,prop.ChangeOnRebuild,prop.ChangeOnUpdate,prop.Value,OnChanged,quantity,prop.StepValues)
      elif prop.MinValue != None:
        newProp = addLimitProperty(op2,prop.Type,prop.Name,prop.IsVisible,prop.ChangeOnRebuild,prop.ChangeOnUpdate,prop.Value,OnChanged,quantity,prop.MinValue,prop.MaxValue)
      else:
        newProp = addProperty(op2,prop.Type,prop.Name,prop.IsVisible,prop.ChangeOnRebuild,prop.ChangeOnUpdate,prop.Value,OnChanged,quantity)
      #endif
      if prop.Group:
        newProp.Group = prop.Group
      #endif
    #endif
  #endfor

def displayPropertyDialog(commandname,title,firsttabname):
  '''
  # if firsttabname is '' then a propertydialog without tabs is displayed
  propertydialog = app.findCommand("genVarSpaceDialog")
  result = 0
  propertydialog.execute( commandname, title, firsttabname, result )
  result = propertydialog.Param_4
  return (result==1)
  '''
  mycmd = app.findCommand(commandname)
  if mycmd:
    mycmd.executeInActionPanel()
  


class DialogObject:
  '''
  Dialog helper documentation:

  Typical workflow:
    diag = getDialog( Caption = 'PropertyDialog')
    p1 = diag.addProperty(paramName, paramType)
    p2 = diag.addProperty(paramName2, paramType2)
    diag.show()


  getDialog( Caption = 'PropertyDialog')
    optional parameter Caption can be set to define dialog caption (i.e. title bar text)
    return DialogObject

  -------------------------------------------------------------------------------
  methods of DialogObject
    addProperty(paramName, paramType, paramEventFunc = None, paramConstraint = VC_PROPERTY_DEFAULT)
      - add new property into dialog

    getProperty(propName)
      - get existing property from dialog, None returned if not found

    show()
      - shows dialog

    hide()
      - hides dialog, but doesn't destroy it

    destroyWindow()
      - hides and destroys dialog


  '''
  def __init__(self, Caption):
    netCommand = app.findCommand('netCommand')
    netCommand.execute('SetLocalizationCommand', 'English', 'Python', 'dummy_placeholder_command', 'Text', Caption)
    dummy_cmd = app.findCommand('dummy_placeholder_command')
    self.LayoutItem = dummy_cmd
    self.Params = []
    self.ParamDict = {}
    self.PropWin = None
    self.Name = None
    self.GeneralTabCaption = None
    self.CurrentTab = None

  def __del__(self):
    for p in self.LayoutItem.Properties[:]:
      self.LayoutItem.deleteProperty(p)

  def show(self):
    self.LayoutItem.executeInActionPanel()

  def addProperty(self,paramName, paramType, paramEventFunc = None, paramConstraint = VC_PROPERTY_DEFAULT):
    param = None
    if self.LayoutItem:
      if paramName in self.ParamDict:
        self.LayoutItem.deleteProperty(paramName)
      for p in self.Params:
        if p.Name == paramName:
          self.Params.remove(p)
          break
      param = self.LayoutItem.createProperty(paramType, paramName, paramConstraint)
      self.Params.append(param)
      self.ParamDict[paramName] = param
      if paramEventFunc:
        self.Params[-1].OnChanged = paramEventFunc
    else:
      print 'Error,, re-init dialog!!'
    return param

  def showTabs(self, GeneralTabCaption = 'General'):
    pass

  def hide(self):
    pass

  def destroyWindow(self):
    self.__del__()

  def getProperty(self, propName):
    return self.ParamDict.get(propName, None)

def getDialog(Caption = 'PropertyDialog'):
  params = []
  dia = DialogObject(Caption)
  return dia