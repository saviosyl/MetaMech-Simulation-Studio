try:
  from vcCommand import *
except:
  try:
    from vcScript import *
  except:
    print "Error: vcHelpers.Dialog was unable to import vcCommand and vcScript"


global propWin, app, cmd
app = getApplication()
cmd = None


class DialogObject:
  def __init__(self):
    #layoutitem = app.findLayoutItem("LayoutPropertyList")
    #app.deleteLayoutItem(layoutitem)
    #if not layoutitem:
    print map(lambda x: x.Name+' '+str(x.Type), app.LayoutItems)
    layoutitem = app.createLayoutItem("LayoutPropertyList")
    print map(lambda x: x.Name+' '+str(x.Type), app.LayoutItems)
    self.LayoutItem = layoutitem
    self.Params = []
    self.ParamDict = {}
    self.PropWin = None

  def __del__(self):
    if self.PropWin:
      destroyCmd = app.findCommand('destroyPropertyWindow')
      destroyCmd.Param_1 = self.PropWin
      destroyCmd.execute()
      self.PropWin = None
      app.deleteLayoutItem(self.LayoutItem)
      self.LayoutItem = None

  def show(self):
    global app
    if not self.PropWin:
      cmd = app.findCommand("createPropertyWindow")
      cmd.Param_1 = self.LayoutItem
      cmd.Param_2 = False
      cmd.execute()
      self.PropWin = cmd.Param_3
    cmd2 = app.findCommand("showPropertyWindow")
    cmd2.Param_1 = self.PropWin
    cmd2.execute()


  def addProperty(self,paramName, paramType, paramEventFunc = None):
    if self.LayoutItem:
      if paramName in self.ParamDict:
        self.LayoutItem.deleteProperty(paramName)
      param = self.LayoutItem.createProperty(paramType, paramName)
      if paramEventFunc:
        self.Params.append(param)
        self.ParamDict[paramName] = param
        self.Params[-1].OnChanged = paramEventFunc
    else:
      print 'Error,, re set dialog!!'
    return param

  def hide(self):
    if self.PropWin:
      hideCmd = app.findCommand('hidePropertyWindow')
      hideCmd.Param_1 = self.PropWin
      hideCmd.execute()

  def destroyWindow(self):
    self.__del__()

  def getProperty(self, propName):
    try:
      prop = self.ParamDict[propName]
    except:
      prop = None
    return prop

def getDialog():
  params = []
  dia = DialogObject()
  return dia








