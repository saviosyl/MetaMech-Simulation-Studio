#Copyright Visual Components Oy 2010
#see license.txt for license details
__version__ = '2010-04-13'
__doc__=''

from vcApplication import *

def OnStart():
  cmduri = getApplicationPath() + 'dummy_placeholder_command.py'
  cmd = loadCommand("dummy_placeholder_command",cmduri)
