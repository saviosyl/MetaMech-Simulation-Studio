try:
  from vcCommand import *
except:
  try:
    from vcScript import *
  except:
    print "Error: vcHelpers.Geometry was unable to import vcCommand and vcScript"

import vcMatrix
import vcVector
import bisect

from vcHelpers.Selection import *

from math import *

def ComponentWeight( cmp ):
  if cmp is None:
    return 0.0
  #endif

  geosets = getGivenComponentsGeosets( cmp )
  originalTriangleSets = []
  for geoset in geosets:
    if geoset.Type == VC_TRIANGLESET:
      originalTriangleSets.append(geoset)
    else:
      print 'geoset is not triangle set'
    #endif
  #endfor

  #print len(originalTriangleSets)
  return calcTriangleSetsAreaMassVolumeCoiInertia(geosets,8.0)
  #return 1000.0

def calcPointListsNormalAreaCenterConvexity(pointvectors):
  # calculates normal, area and center of the list of given pointvectors (as vcVectors)
  # also returns convexity as that is calculated anyway
  normal = vcVector.new()
  area = 0.0
  center = vcVector.new()
  convex = True
  if len(pointvectors) > 2:
    N1 = (pointvectors[1]-pointvectors[0]) ^ (pointvectors[2]-pointvectors[0])   # reference normal
    for i in range(1,len(pointvectors)-1):
      N = (pointvectors[i]-pointvectors[0]) ^ (pointvectors[i+1]-pointvectors[0])
      dA = 0.5 * N.length()
      if N1*N < 0.0: # could be negative area
        dA *= -1.0
        convex = False
      #endif
      center += (pointvectors[i] + pointvectors[i+1] + pointvectors[0])*dA
      normal += N                          #  normal will be average of all normals
    #endfor
    area = 0.5 * normal.length()      # Sum of all normals
    if abs(area) > 0.0001: # avoid division by zero
      center *= (1.0/(3.0*area))
    normal.normalize()
  #endif
  return (normal,area,center,convex)

def IsLooping(curve):
  cl = len(curve)
  if curve[0].X <>curve[cl-1].X:
    return False
  if curve[0].Y <>curve[cl-1].Y:
    return False
  if curve[0].Z <>curve[cl-1].Z:
    return False
  return True

def calcShellMOI(pointvectors, cog):
  moi = vcVector.new()
  cpi = vcVector.new()
  if len(pointvectors) > 1:
    P0 = pointvectors[0] - cog;
    for i in range( 1, len(pointvectors) - 1 ):
      P1 = pointvectors[i] - cog
      P2 = pointvectors[i+1] - cog
      C = (P0 + P1 + P2)*(1.0/3.0)
      N = (P1 - P0 ) ^ (P2 - P0)
      A = 0.5*N.length()
      x1 = P0.X
      x2 = P1.X
      x3 = P2.X
      y1 = P0.Y
      y2 = P1.Y
      y3 = P2.Y
      z1 = P0.Z
      z2 = P1.Z
      z3 = P2.Z
      Ix = A/6.0*(x1*x1 + x2*x2 + x3*x3 + x1*x2 + x1*x3 + x2*x3)
      Iy = A/6.0*(y1*y1 + y2*y2 + y3*y3 + y1*y2 + y1*y3 + y2*y3)
      Iz = A/6.0*(z1*z1 + z2*z2 + z3*z3 + z1*z2 + z1*z3 + z2*z3)
      moi.X += Iy + Iz
      moi.Y += Ix + Iz
      moi.Z += Ix + Iy
      cpi.X += A/12.0*(2.*(x1*y1+x2*y2+x3*y3)+x1*y2+x2*y1+x1*y3+x3*y1+x2*y3+x3*y2) # Ixy
      cpi.Y += A/12.0*(2.*(z1*y1+z2*y2+z3*y3)+z1*y2+z2*y1+z1*y3+z3*y1+z2*y3+z3*y2) # Iyz
      cpi.Z += A/12.0*(2.*(x1*z1+x2*z2+x3*z3)+x1*z2+x2*z1+x1*z3+x3*z1+x2*z3+x3*z2) # Izx
    #endfor
  #endif
  return (moi, cpi)

def calcSolidMOI(pointvectors, cog):
  moi = vcVector.new()
  cpi = vcVector.new()
  if len(pointvectors) > 1:
    P0 = pointvectors[0] - cog;
    for i in range( 1, len(pointvectors) - 1 ):
      P1 = pointvectors[i] - cog
      P2 = pointvectors[i+1] - cog
      C = (P0 + P1 + P2)*(1.0/3.0)
      N = (P1 - P0 ) ^ (P2 - P0)
      #A = 0.5*N.length()
      #N.normalize()
      #V = N*C*A/3.0
      V = N*C/6.0
      x1 = P0.X
      x2 = P1.X
      x3 = P2.X
      y1 = P0.Y
      y2 = P1.Y
      y3 = P2.Y
      z1 = P0.Z
      z2 = P1.Z
      z3 = P2.Z
      Ix = V/10.0*(x1*x1 + x2*x2 + x3*x3 + x1*x2 + x1*x3 + x2*x3)
      Iy = V/10.0*(y1*y1 + y2*y2 + y3*y3 + y1*y2 + y1*y3 + y2*y3)
      Iz = V/10.0*(z1*z1 + z2*z2 + z3*z3 + z1*z2 + z1*z3 + z2*z3)
      moi.X += Iy + Iz
      moi.Y += Ix + Iz
      moi.Z += Ix + Iy
      cpi.X += V/20.0*(2.*(x1*y1+x2*y2+x3*y3)+x1*y2+x2*y1+x1*y3+x3*y1+x2*y3+x3*y2) # Ixy
      cpi.Y += V/20.0*(2.*(z1*y1+z2*y2+z3*y3)+z1*y2+z2*y1+z1*y3+z3*y1+z2*y3+z3*y2) # Iyz
      cpi.Z += V/20.0*(2.*(x1*z1+x2*z2+x3*z3)+x1*z2+x2*z1+x1*z3+x3*z1+x2*z3+x3*z2) # Izx
    #endfor
  #endif
  return (moi, cpi)


def calcTriangleSetsAreaMassVolumeCoiInertia(trianglesets,density=1.0,type='SOLID'):
  totalarea = 0.0
  totalvolume = 0.0
  shellcentroid = vcVector.new()
  solidcentroid = vcVector.new()
  boundarycount = 0

  for triangleset in trianglesets:
    #for edge in triangleset.Edges:
    #  boundarycount += (edge.Type==VC_EDGE_BOUNDARY)
    ##endfor
    for i in range(triangleset.TriangleCount):
      (normal,area,center) = CalcNormalAreaCenter(triangleset.getPointPositions([x for x in triangleset.getTriangle(i)]))
      totalarea += area
      dV = normal*center*area/3.0
      totalvolume += dV
      shellcentroid += area*center
      solidcentroid += (3.0/4.0)*center * dV
    #endfor
  #endfor
  shellcentroid *= (1.0/totalarea)
  solidcentroid *= (1.0/totalvolume)

  solidMOI = vcVector.new()
  solidCPI = vcVector.new()
  for triangleset in trianglesets:
    for i in range(triangleset.TriangleCount):
      dMOI, dCPI = calcSolidMOI( triangleset.getPointPositions([x for x in triangleset.getTriangle(i)]), solidcentroid )
      solidMOI += dMOI
      solidCPI += dCPI
    #endfor
  #endfor
  # Parallel Axis Theorem
  solidMOIorg = vcVector.new()
  solidMOIorg.X = solidMOI.X + totalvolume*(solidcentroid.Y*solidcentroid.Y + solidcentroid.Z*solidcentroid.Z)
  solidMOIorg.Y = solidMOI.Y + totalvolume*(solidcentroid.X*solidcentroid.X + solidcentroid.Z*solidcentroid.Z)
  solidMOIorg.Z = solidMOI.Z + totalvolume*(solidcentroid.X*solidcentroid.X + solidcentroid.Y*solidcentroid.Y)

  solidMOI *= (1.0/totalvolume)
  solidMOIorg *= (1.0/totalvolume)

  solidCPIorg = vcVector.new()
  solidCPIorg.X = solidCPI.X + totalvolume*(solidcentroid.X*solidcentroid.Y) # Ixy, Iyx
  solidCPIorg.Y = solidCPI.Y + totalvolume*(solidcentroid.Y*solidcentroid.Z) # Iyz, Izy
  solidCPIorg.Z = solidCPI.Z + totalvolume*(solidcentroid.Z*solidcentroid.X) # Izx, Ixz
  solidCPI *= (1.0/totalvolume)
  solidCPIorg *= (1.0/totalvolume)

  shellMOI = vcVector.new()
  shellCPI = vcVector.new()
  for triangleset in trianglesets:
    for i in range(triangleset.TriangleCount):
      dMOI, dCPI = calcShellMOI( triangleset.getPointPositions([x for x in triangleset.getTriangle(i)]), shellcentroid )
      shellMOI += dMOI
      shellCPI += dCPI
    #endfor
  #endfor
  # Parallel Axis Theorem
  shellMOIorg = vcVector.new()
  shellMOIorg.X = shellMOI.X + totalarea*(shellcentroid.Y*shellcentroid.Y + shellcentroid.Z*shellcentroid.Z)
  shellMOIorg.Y = shellMOI.Y + totalarea*(shellcentroid.X*shellcentroid.X + shellcentroid.Z*shellcentroid.Z)
  shellMOIorg.Z = shellMOI.Z + totalarea*(shellcentroid.X*shellcentroid.X + shellcentroid.Y*shellcentroid.Y)

  shellMOI *= (1.0/totalarea)
  shellMOIorg *= (1.0/totalarea)

  shellCPIorg = vcVector.new()
  shellCPIorg.X = shellCPI.X + totalarea*(shellcentroid.X*shellcentroid.Y) # Ixy, Iyx
  shellCPIorg.Y = shellCPI.Y + totalarea*(shellcentroid.Y*shellcentroid.Z) # Iyz, Izy
  shellCPIorg.Z = shellCPI.Z + totalarea*(shellcentroid.Z*shellcentroid.X) # Izx, Ixz
  shellCPI *= (1.0/totalarea)
  shellCPIorg *= (1.0/totalarea)

  app.ProgressStatus = "Done"
  app.ProgressValue = 2.0
  if boundarycount > 0:
    print "WARNING: GEOMETRY is NOT PROPERLY CLOSED: VOLUME, COG and MOI CANNOT be GARANTEED!"
  print "Density = 8000 kg/m^3 (steel)" #  1.0 g/cm^3 (water)"
  print "Mass = %.6f kg" % (totalvolume* density/1000000.) # mm^3 * g/(10*mm)^3*kg/(1000*g)
  print "Volume = %.6f cm^3" % (0.001*totalvolume)
  print "Area = %.2f square meters" % (0.000001*totalarea)
  print "Center of gravity (Shell) = %.2f, %.2f, %.2f {mm}" % (shellcentroid.X, shellcentroid.Y, shellcentroid.Z)
  print "Center of gravity (Solid) = %.2f, %.2f, %.2f {mm}" % (solidcentroid.X, solidcentroid.Y, solidcentroid.Z)
  print "Moment of Inertia (Solid cog) = %.2f, %.2f, %.2f {mm^2}" % (solidMOI.X, solidMOI.Y, solidMOI.Z)
  print "Moment of Inertia (Solid org) = %.2f, %.2f, %.2f {mm^2}" % (solidMOIorg.X, solidMOIorg.Y, solidMOIorg.Z)
  print "Cross Product of Inertia (Solid cog) = %.2f, %.2f, %.2f {mm^2}" % (solidCPI.X, solidCPI.Y, solidCPI.Z)
  print "Cross Product of Inertia (Solid org) = %.2f, %.2f, %.2f {mm^2}" % (solidCPIorg.X, solidCPIorg.Y, solidCPIorg.Z)
  print "Moment of Inertia (Shell cog) = %.2f, %.2f, %.2f {mm^2}" % (shellMOI.X, shellMOI.Y, shellMOI.Z)
  print "Moment of Inertia (Shell org) = %.2f, %.2f, %.2f {mm^2}" % (shellMOIorg.X, shellMOIorg.Y, shellMOIorg.Z)
  print "Cross Product of Inertia (Shell cog) = %.2f, %.2f, %.2f {mm^2}" % (shellCPI.X, shellCPI.Y, shellCPI.Z)
  print "Cross Product of Inertia (Shell org) = %.2f, %.2f, %.2f {mm^2}" % (shellCPIorg.X, shellCPIorg.Y, shellCPIorg.Z)

  return totalvolume* density/1000000.0

def calcTrianglesetsAxisAlignment(triangleset): #OK (does what it says)
  # aligns a coordinate systems x axis normal to the largest triangle
  # and y axis normal to the largest triangle perpendicular to the first

  # collect calculated data information to a table
  tdatas = []

  for i in range(triangleset.TriangleCount):
    triangle = triangleset.getTriangle(i)
    pointvectors = []
    for j in range(3):
      pointvectors.append( triangleset.getPoint( triangle[j] ) )
    tdatas.append( calcPointListsNormalAreaCenterConvexity(pointvectors) )

  # find the normal of the biggest triangle:
  biggestarea = 0.0
  firstnormal = vcVector.new(1,0,0)
  firstindex = 0
  for i in range(len(tdatas)):
    if tdatas[i][1] > biggestarea:
      biggestarea = tdatas[i][1]
      firstnormal = tdatas[i][0]
      firstindex = i

  #find perpendicular triangles and choose the largest
  secondnormal = vcVector.new(0,1,0)
  secondindex = 0
  biggestarea = 0.0
  for i in range(len(tdatas)):
    if i != firstindex and abs(tdatas[i][0]*firstnormal) < 0.1 and tdatas[i][1] > biggestarea:
      biggestarea = tdatas[i][1]
      secondnormal = tdatas[i][0]
      secondindex = i

  n = firstnormal
  o = secondnormal
  a = n^o
  a.normalize()

  m = vcMatrix.new()
  m.N = n
  m.O = o
  m.A = a
  wpr = m.WPR
  m.WPR = wpr
  return m

def calcTrianglesetsCornersInReference(triangleset,m): #OK
  # Transforms all positions to reference matrix m and chooses the smallest and biggest of each coordinate
  smallest = vcVector.new(1e39,1e39,1e39)
  biggest = vcVector.new(-1e39,-1e39,-1e39)
  for i in range(triangleset.PointCount):
    p = m * triangleset.getPoint(i)
    if p.X < smallest.X:
      smallest.X = p.X
    if p.X > biggest.X:
      biggest.X = p.X
    if p.Y < smallest.Y:
      smallest.Y = p.Y
    if p.Y > biggest.Y:
      biggest.Y = p.Y
    if p.Z < smallest.Z:
      smallest.Z = p.Z
    if p.Z > biggest.Z:
      biggest.Z = p.Z
  return (smallest,biggest)

def createBlockOnTriangleset(triangleset):
  blockset = triangleset.Container.createGeometrySet( VC_TRIANGLESET )
  blockset.Material = triangleset.Material

  m = calcTrianglesetsAxisAlignment(triangleset)
  im = vcMatrix.new(m)
  im.invert()

  s,b = calcTrianglesetsCornersInReference(triangleset,im)

  v = m*vcVector.new(s.X,s.Y,s.Z)
  pt0 = blockset.addPoint(v)
  v = m*vcVector.new(b.X,s.Y,s.Z)
  pt1 = blockset.addPoint(v)
  v = m*vcVector.new(b.X,b.Y,s.Z)
  pt2 = blockset.addPoint(v)
  v = m*vcVector.new(s.X,b.Y,s.Z)
  pt3 = blockset.addPoint(v)
  v = m*vcVector.new(s.X,s.Y,b.Z)
  pt4 = blockset.addPoint(v)
  v = m*vcVector.new(b.X,s.Y,b.Z)
  pt5 = blockset.addPoint(v)
  v = m*vcVector.new(b.X,b.Y,b.Z)
  pt6 = blockset.addPoint(v)
  v = m*vcVector.new(s.X,b.Y,b.Z)
  pt7 = blockset.addPoint(v)

  blockset.addTriangle( pt0, pt3, pt2 )
  blockset.addTriangle( pt0, pt2, pt1 )
  blockset.addTriangle( pt4, pt5, pt6 )
  blockset.addTriangle( pt4, pt6, pt7 )
  blockset.addTriangle( pt0, pt1, pt5 )
  blockset.addTriangle( pt0, pt5, pt4 )
  blockset.addTriangle( pt1, pt2, pt6 )
  blockset.addTriangle( pt1, pt6, pt5 )
  blockset.addTriangle( pt2, pt3, pt7 )
  blockset.addTriangle( pt2, pt7, pt6 )
  blockset.addTriangle( pt3, pt0, pt4 )
  blockset.addTriangle( pt3, pt4, pt7 )

  blockset.update()
  return blockset

def createCylinderOnTriangleset(triangleset):
  cylinderset = triangleset.Container.createGeometrySet( VC_TRIANGLESET )
  cylinderset.Material = triangleset.Material
  m = calcTrianglesetsAxisAlignment(triangleset)
  im = vcMatrix.new(m)
  im.invert()
  s,b = calcTrianglesetsCornersInReference(triangleset,im)
  d = 0.5*(b-s)
  c = s + d
  m.translateRel(c.X,c.Y,c.Z)
  dxy = abs(d.X-d.Y)
  dxz = abs(d.X-d.Z)
  dyz = abs(d.Y-d.Z)
  radius = sqrt(d.X*d.X+d.Y*d.Y)
  height = d.Z*2
  if dxz < dyz:
    if dxz < dxy:
      m.rotateRelX(-90)
      radius = sqrt(d.X*d.X+d.Z*d.Z)
      height = d.Y*2
    #endif
  else:
    if dyz < dxy:
      m.rotateRelY(90)
      radius = sqrt(d.Y*d.Y+d.Z*d.Z)
      height = d.X*2
    #endif
  #endif
  radius *= 0.70710678118654752440084436210485
  facets = int(radius/10)
  if facets < 11:
    facets = 11
  if facets > 119:
    facets = 119
  m.translateRel(0,0,-height/2)
  v = m*vcVector.new(0,0,0)
  pt0 = cylinderset.addPoint(v)
  v = m*vcVector.new(radius,0,0)
  pt1 = cylinderset.addPoint(v)
  v = m*vcVector.new(radius,0,height)
  pt2 = cylinderset.addPoint(v)
  v = m*vcVector.new(0,0,height)
  pt3 = cylinderset.addPoint(v)
  pt1o = pt1
  pt2o = pt2
  for i in range(facets-1):
    m.rotateRelZ(360.0/facets)
    v = m*vcVector.new(radius,0,0)
    pt4 = cylinderset.addPoint(v)
    v = m*vcVector.new(radius,0,height)
    pt5 = cylinderset.addPoint(v)
    cylinderset.addTriangle( pt0, pt4, pt1 )
    cylinderset.addTriangle( pt1, pt5, pt2 )
    cylinderset.addTriangle( pt4, pt5, pt1 )
    cylinderset.addTriangle( pt3, pt2, pt5 )
    pt1 = pt4
    pt2 = pt5
  #endfor
  pt4 = pt1o
  pt5 = pt2o
  cylinderset.addTriangle( pt0, pt4, pt1 )
  cylinderset.addTriangle( pt1, pt5, pt2 )
  cylinderset.addTriangle( pt4, pt5, pt1 )
  cylinderset.addTriangle( pt3, pt2, pt5 )
  cylinderset.update()
  return cylinderset

def mergeGeoSetsWithSameMaterial(geofeature):
  geosets = geofeature.Geometry.GeometrySets

  originalTriangleSets = []
  originalPolygonSets = []
  originalLineSets = []

  # Collect Geosets
  for geoset in geosets:
    if geoset.Type == VC_TRIANGLESET:
      originalTriangleSets.append(geoset)
    elif geoset.Type == VC_POLYGONSET:
      originalPolygonSets.append(geoset)
    elif geoset.Type == VC_COMPACTLINESET:
      originalLineSets.append(geoset)
    #endif
  #endfor

  materialCount = 0
  materialCount += mergeGeoSets(geofeature, originalTriangleSets, VC_TRIANGLESET)
  materialCount += mergeGeoSets(geofeature, originalPolygonSets, VC_POLYGONSET)
  materialCount += mergeGeoSets(geofeature, originalLineSets, VC_COMPACTLINESET)

  geoSetCount = len(originalTriangleSets) + len(originalPolygonSets) + len(originalLineSets)

  return geoSetCount, materialCount

def mergeGeoSets(geofeature, allgeosets, geoSetType):
  materialmap = {}

  # Collect materials
  for gset in allgeosets:
    material = 'None'
    if gset.Material != None:
      material = gset.Material.Name
    #endif
    if not materialmap.has_key(material):
      entry = ([], [])
      materialmap[material] = entry
    else:
      entry = materialmap[material]
    #endif

    if geoSetType == VC_TRIANGLESET:
      pc = gset.TriangleCount
    elif geoSetType == VC_POLYGONSET:
      pc = gset.PolygonCount
    elif geoSetType == VC_LINESET or geoSetType == VC_COMPACTLINESET:
      pc = gset.LineCount
    else:
      pc = 0

    ix = bisect.bisect_right(entry[1], pc)

    entry[0].insert(ix, gset)
    entry[1].insert(ix, pc)
  #endfor

  for material, gslist in materialmap.iteritems():
    geosets, sizes = gslist

    # Merge the two smallest geosets until there is only one left
    while len(geosets) > 1:
      # Pop the two smallest sets
      geoA, geoB = geosets[0:2]
      szA, szB = sizes[0:2]
      del geosets[0:2]
      del sizes[0:2]

      geoA.merge(geoB)

      # Reinsert the newly merged set
      szMerged = szA + szB
      geofeature.Geometry.deleteGeometrySet(geoB)

      ix = bisect.bisect_right(sizes, szMerged)
      sizes.insert(ix, szMerged)
      geosets.insert(ix, geoA)

  geofeature.Geometry.update()
  return (len(materialmap))

def getTriangleDataCount(trianglesets):
  trianglecount = 0
  pointcount = 0
  trianglesetcount = 0
  for triangleset in trianglesets:
    if triangleset.Type == VC_TRIANGLESET:
      trianglecount += triangleset.TriangleCount
      pointcount += triangleset.PointCount
      trianglesetcount += 1
  return (trianglesetcount,trianglecount,pointcount)

def getPolygonDataCount(geosets):
  polygonsetcount = 0
  polygoncount = 0
  pointcount = 0
  for polygonset in geosets:
    if polygonset.Type == VC_POLYGONSET:
      polygonsetcount += 1
      polygoncount += polygonset.PolygonCount
      pointcount += len(polygonset.Points)
  return polygonsetcount, polygoncount, pointcount

def getLineDataCount(linesets):
  linecount = 0
  pointcount = 0
  linesetcount = 0
  for lineset in linesets:
    if lineset.Type == VC_COMPACTLINESET:
      linesetcount += 1
      linecount += lineset.LineCount
      for line in lineset.Lines:
        pointcount += len(line)
  return (linesetcount,linecount,pointcount)



AIMED = True

def CalcNormalAreaCenter(points):
  #print points
  normal = vcVector.new()
  center = vcVector.new()
  if len(points) > 1:
    fpt = points[0];
    for i in range(len(points)):
      j = (i+1)%len(points)
      normal += (points[i] - fpt) ^ (points[j] - fpt)
      center += points[i]
  else:
    return 0.0, 0.0, 0.0
  area = 0.5 * normal.length()
  center = center* (1.0/(1.0*len(points)))
  normal.normalize()
  return (normal,area,center)

def getaimedmatrix(set):
  m = vcMatrix.new()
  firstpolygon = None
  firstnormal = vcVector.new(0.0,0.0,1.0)
  firstcenter = vcVector.new()
  # find biggest polygon
  biggestarea = 0.0
  for poly in set.Polygons:
    (normal,area,center) = CalcNormalAreaCenter(poly.Points)
    if biggestarea < area:
      biggestarea = area
      firstpolygon = poly
      firstnormal = normal
      firstcenter = center
  # find polygons whose normal is close to perpendicular
  smallestangle = 1e39
  biggestarea = 0.0
  secondbigpolygon = None
  secondbignormal = vcVector.new(0.0,0.0,1.0)
  secondbigcenter = vcVector.new()
  secondpolygon = None
  secondnormal = vcVector.new(0.0,0.0,1.0)
  secondcenter = vcVector.new()
  for poly in set.Polygons:
    if poly != firstpolygon:
      (normal,area,center) = CalcNormalAreaCenter(poly.Points)
      angle = normal*firstnormal
      if abs(angle) < smallestangle:
        smallestangle = abs(angle)
        secondnormal = normal
        secondcenter = center
        secondpolygon = poly
      if abs(angle) < 0.1 and biggestarea < area:
        biggestarea = area
        secondbignormal = normal
        secondbigcenter = center
        secondbigpolygon = poly
  n = firstnormal
  o = secondbignormal
  a = n^o
  a.normalize()
  m.N = n
  m.O = o
  m.A = a
  wpr = m.WPR
  m.WPR = wpr
  return m

def getcorners(set,m):
  # Transform all positions to matrix m
  smallest = vcVector.new(1e39,1e39,1e39)
  biggest = vcVector.new(-1e39,-1e39,-1e39)
  found = False
  for poly in set.Polygons:
    for point in poly.Points:
      found = True
      p = m * point.Position
      if p.X < smallest.X:
        smallest.X = p.X
      if p.X > biggest.X:
        biggest.X = p.X
      if p.Y < smallest.Y:
        smallest.Y = p.Y
      if p.Y > biggest.Y:
        biggest.Y = p.Y
      if p.Z < smallest.Z:
        smallest.Z = p.Z
      if p.Z > biggest.Z:
        biggest.Z = p.Z
  if not found:
    smallest = vcVector.new()
    biggest = vcVector.new()
  return (smallest,biggest,found)


def blockifyPolygonSet(geometry, orig_set):
  global center, diagonal

  # Store polygon set information
  s_center = orig_set.BoundCenter
  s_diagonal = orig_set.BoundDiagonal
  s_material = orig_set.Material

  # Delete geometry sets original geometry
  set = geometry.createGeometrySet( VC_POLYGONSET )
  if s_material != None:
    set.Material = s_material

  if AIMED:
    m = getaimedmatrix(orig_set)
    im = vcMatrix.new(m)
    im.invert()
    (s,b,found) = getcorners(orig_set,im)
    if not found:
      return None
    v = m*vcVector.new(s.X,s.Y,s.Z)
    #print "v = %.2f %.2f %.2f" % (v.X,v.Y,v.Z)
    pt0 = set.createPoint(v)
    v = m*vcVector.new(b.X,s.Y,s.Z)
    pt1 = set.createPoint(v)
    v = m*vcVector.new(b.X,b.Y,s.Z)
    pt2 = set.createPoint(v)
    v = m*vcVector.new(s.X,b.Y,s.Z)
    pt3 = set.createPoint(v)
    v = m*vcVector.new(s.X,s.Y,b.Z)
    pt4 = set.createPoint(v)
    v = m*vcVector.new(b.X,s.Y,b.Z)
    pt5 = set.createPoint(v)
    v = m*vcVector.new(b.X,b.Y,b.Z)
    pt6 = set.createPoint(v)
    v = m*vcVector.new(s.X,b.Y,b.Z)
    pt7 = set.createPoint(v)
  else:
    xmin = s_center.X - s_diagonal.X
    xmax = s_center.X + s_diagonal.X
    ymin = s_center.Y - s_diagonal.Y
    ymax = s_center.Y + s_diagonal.Y
    zmin = s_center.Z - s_diagonal.Z
    zmax = s_center.Z + s_diagonal.Z
    pt0 = set.createPoint( xmin, ymin, zmin )
    pt1 = set.createPoint( xmax, ymin, zmin )
    pt2 = set.createPoint( xmax, ymax, zmin )
    pt3 = set.createPoint( xmin, ymax, zmin )
    pt4 = set.createPoint( xmin, ymin, zmax )
    pt5 = set.createPoint( xmax, ymin, zmax )
    pt6 = set.createPoint( xmax, ymax, zmax )
    pt7 = set.createPoint( xmin, ymax, zmax )

  poly = set.createPolygon()
  poly.addPoint( pt0 )
  poly.addPoint( pt3 )
  poly.addPoint( pt2 )
  poly.addPoint( pt1 )
  poly.update()

  poly = set.createPolygon()
  poly.addPoint( pt4 )
  poly.addPoint( pt5 )
  poly.addPoint( pt6 )
  poly.addPoint( pt7 )
  poly.update()

  poly = set.createPolygon()
  poly.addPoint( pt0 )
  poly.addPoint( pt1 )
  poly.addPoint( pt5 )
  poly.addPoint( pt4 )
  poly.update()

  poly = set.createPolygon()
  poly.addPoint( pt1 )
  poly.addPoint( pt2 )
  poly.addPoint( pt6 )
  poly.addPoint( pt5 )
  poly.update()

  poly = set.createPolygon()
  poly.addPoint( pt2 )
  poly.addPoint( pt3 )
  poly.addPoint( pt7 )
  poly.addPoint( pt6 )
  poly.update()

  poly = set.createPolygon()
  poly.addPoint( pt3 )
  poly.addPoint( pt0 )
  poly.addPoint( pt4 )
  poly.addPoint( pt7 )
  poly.update()

  set.update()
  return set

def cylindrifyPolygonSet(geometry, orig_set):
  global center, diagonal

  # Store polygon set information
  s_center = orig_set.BoundCenter
  s_diagonal = orig_set.BoundDiagonal
  s_material = orig_set.Material

  # Create geometry
  set = geometry.createGeometrySet( VC_POLYGONSET )
  if s_material != None:
    set.Material = s_material

  # Figure out the direction for cylinder based on smallest area
  # and even sides
  area_xy = 4*s_diagonal.X*s_diagonal.Y
  area_zy = 4*s_diagonal.Y*s_diagonal.Z
  area_xz = 4*s_diagonal.X*s_diagonal.Z

  if abs(s_diagonal.X - s_diagonal.Y) < 1.0:
    even_xy = True
  else:
    even_xy = False
  if abs(s_diagonal.Y - s_diagonal.Z) < 1.0:
    even_zy = True
  else:
    even_zy = False
  if abs(s_diagonal.X - s_diagonal.Z) < 1.0:
    even_xz = True
  else:
    even_xz = False

  smallest = area_xy
  plane = "xy"
  if area_zy<smallest:
    smallest = area_zy
    plane = "zy"
  if area_xz<smallest:
    smallest = area_xz
    plane = "xz"

  # Choose a plane that has equal sidea and smallest area
  # If not found choose the one with even sides
  # If not found choose the one with smalles area
  if even_xy != True and even_zy != True and even_xz != True:
    plane = plane
  elif even_xy == True and plane == "xy":
    plane = "xy"
  elif even_zy == True and plane == "zy":
    plane = "zy"
  elif even_xz == True and plane == "xz":
    plane = "xz"
  elif even_xy == True:
    plane = "xy"
  elif even_zy == True:
    plane = "zy"
  else:
    plane = "xz"

  # Calculate center, axis, and radius
  DEG_TO_RAD = 0.0174532925199432957692369076848
  radius = 1.0
  center_bottom = vcVector.new(1.0,0,0)
  center_top = vcVector.new(1.0,0,0)
  sections = 11
  section_angle = 360.0 / sections
  reversed = False

  if plane == "xy":
    # radius
    if s_diagonal.X < s_diagonal.Y:
      radius = s_diagonal.Y
    else:
      radius = s_diagonal.X
    # center bottom
    center_bottom.X = s_center.X
    center_bottom.Y = s_center.Y
    center_bottom.Z = s_center.Z-s_diagonal.Z
    # center top
    center_top.X = s_center.X
    center_top.Y = s_center.Y
    center_top.Z = s_center.Z+s_diagonal.Z

    # Create lower points
    bottom_pts = []
    angle = 0
    for i in range(sections):
      pt = vcVector.new()
      pt.X = center_bottom.X + cos(angle*DEG_TO_RAD)*radius
      pt.Y = center_bottom.Y + sin(angle*DEG_TO_RAD)*radius
      pt.Z = center_bottom.Z
      bottom_pts.append(set.createPoint(pt))
      angle = angle + section_angle

    # Create upper points
    top_pts = []
    for point in bottom_pts:
      pt = vcVector.new()
      pt.X = point.Position.X
      pt.Y = point.Position.Y
      pt.Z = point.Position.Z+2.0*s_diagonal.Z
      top_pts.append(set.createPoint(pt))


  elif plane == "zy":
    # radius
    if s_diagonal.Y < s_diagonal.Z:
      radius = s_diagonal.Z
    else:
      radius = s_diagonal.Y
    # center bottom
    center_bottom.X = s_center.X-s_diagonal.X
    center_bottom.Y = s_center.Y
    center_bottom.Z = s_center.Z
    # center top
    center_top.X = s_center.X+s_diagonal.X
    center_top.Y = s_center.Y
    center_top.Z = s_center.Z

    # Create lower points
    bottom_pts = []
    angle = 0
    for i in range(sections):
      pt = vcVector.new()
      pt.X = center_bottom.X
      pt.Y = center_bottom.Y + cos(angle*DEG_TO_RAD)*radius
      pt.Z = center_bottom.Z + sin(angle*DEG_TO_RAD)*radius
      bottom_pts.append(set.createPoint(pt))
      angle = angle + section_angle

    # Create upper points
    top_pts = []
    for point in bottom_pts:
      pt = vcVector.new()
      pt.X = point.Position.X+2*s_diagonal.X
      pt.Y = point.Position.Y
      pt.Z = point.Position.Z
      top_pts.append(set.createPoint(pt))


  else:
    reversed = True
    # radius
    if s_diagonal.X < s_diagonal.Z:
      radius = s_diagonal.Z
    else:
      radius = s_diagonal.X
    # center bottom
    center_bottom.X = s_center.X
    center_bottom.Y = s_center.Y-s_diagonal.Y
    center_bottom.Z = s_center.Z
    # center top
    center_top.X = s_center.X
    center_top.Y = s_center.Y+s_diagonal.Y
    center_top.Z = s_center.Z

    # Create lower points
    bottom_pts = []
    angle = 0
    for i in range(sections):
      pt = vcVector.new()
      pt.X = center_bottom.X + cos(angle*DEG_TO_RAD)*radius
      pt.Y = center_bottom.Y
      pt.Z = center_bottom.Z + sin(angle*DEG_TO_RAD)*radius
      bottom_pts.append(set.createPoint(pt))
      angle = angle + section_angle

    # Create upper points
    top_pts = []
    for point in bottom_pts:
      pt = vcVector.new()
      pt.X = point.Position.X
      pt.Y = point.Position.Y+2*s_diagonal.Y
      pt.Z = point.Position.Z
      top_pts.append(set.createPoint(pt))


  # Create cone shell polygons
  for i in range(sections):
    if i == sections-1:
      pt1 = bottom_pts[i]
      pt2 = bottom_pts[0]
      pt3 = top_pts[0]
      pt4 = top_pts[i]
    else:
      pt1 = bottom_pts[i]
      pt2 = bottom_pts[i+1]
      pt3 = top_pts[i+1]
      pt4 = top_pts[i]

    poly = set.createPolygon()
    if reversed == True:
      poly.addPoint( pt4 )
      poly.addPoint( pt3 )
      poly.addPoint( pt2 )
      poly.addPoint( pt1 )
    else:
      poly.addPoint( pt1 )
      poly.addPoint( pt2 )
      poly.addPoint( pt3 )
      poly.addPoint( pt4 )
    poly.update()

  # Create lower caps
  center_pt = set.createPoint(center_bottom.X, center_bottom.Y, center_bottom.Z)

  for i in range(sections):
    if i == sections-1:
      pt1 = bottom_pts[i]
      pt2 = center_pt
      pt3 = bottom_pts[0]
    else:
      pt1 = bottom_pts[i]
      pt2 = center_pt
      pt3 = bottom_pts[i+1]

    poly = set.createPolygon()
    if reversed == True:
      poly.addPoint( pt3 )
      poly.addPoint( pt2 )
      poly.addPoint( pt1 )
    else:
      poly.addPoint( pt1 )
      poly.addPoint( pt2 )
      poly.addPoint( pt3 )
    poly.update()

  # Create top caps
  center_pt = set.createPoint(center_top.X, center_top.Y, center_top.Z)

  for i in range(sections):
    if i == sections-1:
      pt1 = top_pts[0]
      pt2 = center_pt
      pt3 = top_pts[i]
    else:
      pt1 = top_pts[i+1]
      pt2 = center_pt
      pt3 = top_pts[i]

    poly = set.createPolygon()
    if reversed == True:
      poly.addPoint( pt3 )
      poly.addPoint( pt2 )
      poly.addPoint( pt1 )
    else:
      poly.addPoint( pt1 )
      poly.addPoint( pt2 )
      poly.addPoint( pt3 )
    poly.update()

  set.update()

  return set
