try:
  from vcCommand import *
except:
  try:
    from vcScript import *
  except:
    print "Error: vcHelpers.Math was unable to import vcCommand and vcScript"

from math import *
import vcMatrix
import vcVector

################################################
 # General conversion variables and helpers 
################################################

ZERO = 0.0001
RAD_TO_DEG = 57.295779513082320876798154814105
DEG_TO_RAD = 0.01745329251994329576923690768489
PI = 3.1415926535897932384626433832795

'''
For trigonometric- and quadrilateral -solvers see pictures in:
Help: "Reference Guide" => "Expression Reference" => "Functions"

## Triangular -solvers
def sasa( side1, angle3, side2 ):
  return angle between side2 and side3
def sass( side1, angle3, side2 ):
  return side opposite angle3
def sssa( side1, side2, side3 ):
  return angle between side2 and side3

## Quadrilateral -solvers
def sasasa(s1,a1,s2,a2,s3): 
  return angle between s3 and s4 (angles in radians)
def sasass(s1,a1,s2,a2,s3): 
  return s4 (angles in radians)
def sasssa1(s1,a1,s2,s3,s4): 
  return angle between s2 and s3 (angles in radians)
def sasssa2(s1,a1,s2,s3,s4): 
  return angle between s3 and s4 (angles in radians)
## Degree version of same
def sasasad(s1,a1,s2,a2,s3): 
  return angle between s3 and s4 (angles in degrees)
def sasassd(s1,a1,s2,a2,s3): 
  'return s4 (angles in degrees)
def sasssa1d(s1,a1,s2,s3,s4): 
  'return angle between s2 and s3 (angles in degrees)
def sasssa2d(s1,a1,s2,s3,s4):
  return angle between s3 and s4 (angles in degrees)

## matrix to expression conversion
def matrixExpr( M, tolerance=ZERO ):
  convert vcMatrix to expression-string. return "Tx(?).Ty(?).Tz(?).Rz(?).Ry(?).Rz(?)"
'''


##
## Triangular -solvers
##
def sasa( side1, angle3, side2 ):
  '''return angle between side2 and side3'''
  s1 = float(side1)
  a3 = float(angle3)
  s2 = float(side2)
  if s1 <= 0.0:
    return 0.0
  if s2 <= 0.0:
    return atan2(sin(a3),-cos(a3))
  s1_2 = s1*s1
  s2_2 = s2*s2
  s3_2 = s1_2 + s2_2 - 2*s1*s2*cos(a3)
  if s3_2 <= 0.0:
    return PI
  s3 = sqrt( s3_2 )
  cos_a1 = (s2_2 + s3_2 - s1_2)/(2*s2*s3)
  return atan2( s1*sin(a3)/s3, cos_a1 )

def sass( side1, angle3, side2 ):
  '''return side opposite angle3'''
  s1 = float(side1)
  a3 = float(angle3)
  s2 = float(side2)
  if s1 <= 0.0:
    if s2 < 0.0:
      return 0.0
    else:
      return s2
  if s2 <= 0.0:
    return s1
  s3 = s1*s1 + s2*s2 - 2*s1*s2*cos(a3)
  if s3 <= 0.0: 
    return 0.0
  return sqrt( s3 )

def sssa( side1, side2, side3 ):
  '''return angle between side2 and side3'''
  s1 = float(side1)
  s2 = float(side2)
  s3 = float(side3)
  if s1 <= 0.0 or s3 <= 0.0: 
    return 0.0
  if s2 <= 0.0:
    return PI/2.
  cos_a1 = (s2*s2 + s3*s3 - s1*s1)/(2*s2*s3)
  if cos_a1 > 1.0:
    cos_a1 = 1.0
  elif cos_a1 < -1.0:
    cos_a1 = -1.0
  return abs(acos( cos_a1 ))

##
## Quadrilateral -solvers
##
def sasasa(s1,a1,s2,a2,s3): 
  ''''return angle between s3 and s4 (angles in radians)'''
  a1 = float(a1)
  a2 = float(a2)
  s1 = float(s1)
  s2 = float(s2)
  s3 = float(s3)
  return sasa( sass(s1,a1,s2), a2-sasa(s1,a1,s2), s3)
def sasass(s1,a1,s2,a2,s3): 
  '''return s4 (angles in radians)'''
  a1 = float(a1)
  a2 = float(a2)
  s1 = float(s1)
  s2 = float(s2)
  s3 = float(s3)
  return sass( sass(s1,a1,s2), a2-sasa(s1,a1,s2), s3)
def sasssa1(s1,a1,s2,s3,s4): 
  '''return angle between s2 and s3 (angles in radians)'''
  a1 = float(a1)
  s1 = float(s1)
  s2 = float(s2)
  s3 = float(s3)
  s4 = float(s4)
  s5 = sass(s1,a1,s2)
  return sssa(s1,s2,s5) + sssa(s4,s3,s5)
def sasssa2(s1,a1,s2,s3,s4): 
  '''return angle between s3 and s4 (angles in radians)'''
  a1 = float(a1)
  s1 = float(s1)
  s2 = float(s2)
  s3 = float(s3)
  s4 = float(s4)
  return sssa( sass(s1,a1,s2), s3, s4 )


# Degree version of same
def sasasad(s1,a1,s2,a2,s3): 
  ''''return angle between s3 and s4 (angles in degrees)'''
  a1 = float(a1)
  a2 = float(a2)
  s1 = float(s1)
  s2 = float(s2)
  s3 = float(s3)
  return sasasa(s1,a1*DEG_TO_RAD,s2,a2*DEG_TO_RAD,s3)*RAD_TO_DEG
def sasassd(s1,a1,s2,a2,s3): 
  '''return s4 (angles in degrees)'''
  a1 = float(a1)
  a2 = float(a2)
  s1 = float(s1)
  s2 = float(s2)
  s3 = float(s3)
  return sasass(s1,a1*DEG_TO_RAD,s2,a2*DEG_TO_RAD,s3) 
def sasssa1d(s1,a1,s2,s3,s4): 
  '''return angle between s2 and s3 (angles in degrees)'''
  a1 = float(a1)
  s1 = float(s1)
  s2 = float(s2)
  s3 = float(s3)
  s4 = float(s4)
  return sasssa1(s1,a1*DEG_TO_RAD,s2,s3,s4)*RAD_TO_DEG
def sasssa2d(s1,a1,s2,s3,s4):
  '''return angle between s3 and s4 (angles in degrees)'''
  a1 = float(a1)
  s1 = float(s1)
  s2 = float(s2)
  s3 = float(s3)
  s4 = float(s4)
  return sasssa2(s1,a1*DEG_TO_RAD,s2,s3,s4)*RAD_TO_DEG



def matrixExpr( M, tolerance=ZERO ):
  '''convert vcMatrix to expression-string. return "Tx(?).Ty(?).Tz(?).Rz(?).Ry(?).Rz(?)"'''
  expr = ""
  if abs( M.P.X ) > tolerance:
    expr += "Tx(%g)." % M.P.X
  if abs( M.P.Y ) > tolerance:
    expr += "Ty(%g)." % M.P.Y
  if abs( M.P.Z ) > tolerance:
    expr += "Tz(%g)." % M.P.Z
  if abs( M.WPR.Z ) > tolerance:
    expr += "Rz(%g)." % M.WPR.Z
  if abs( M.WPR.Y ) > tolerance:
    expr += "Ry(%g)." % M.WPR.Y
  if abs( M.WPR.X ) > tolerance:
    expr += "Rx(%g)." % M.WPR.X
  if len(expr):
    return expr[0:len(expr)-1]
  return None

def trapezoid(a, b, x, c, d):
  '''return a value between 0-1 based on the x location on trapezoid defined by a,b,c,d'''
  if x <= a or d <= x:
    return 0.0
  if x < b:
    return (a - x) / (a - b) # note : a - b = 0 will never happen
  if x <= c:
    return 1.0
  return (x - d) / (c - d) # when x < d, and c - d will never happen

def trapesine(a, b, x, c, d):
  '''return a value between 0-1 based on the x location on trapezoid defined by a,b,c,d with sinusoidal ramps'''
  if x <= a or d <= x:
    return 0.0
  if x < b:
    return 0.5 - 0.5*cos(PI*(a - x) / (a - b)) # note : a - b = 0 will never happen
  if x <= c:
    return 1.0
  return 0.5 - 0.5*cos(PI*(x - d) / (c - d))