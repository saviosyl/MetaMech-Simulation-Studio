from zipfile import *
import re, tempfile, os
import xml.etree.ElementTree as xml

try:
  from vcCommand import *
except:
  try:
    from vcScript import *
  except:
    print "Error: vcHelpers.VcmFile was unable to import vcCommand and vcScript"


NS = {
  "": "http://schemas.visualcomponents.com/2017/01/component/componentxml",
  "xsd": "http://www.w3.org/2001/XMLSchema",
  "xsi": "http://www.w3.org/2001/XMLSchema-instance"
}


def getXmlValue(root,name, valtype=str):
  tag = '{{{}}}{}'.format(NS[""], name)
  for child in root:
    if child.tag == tag:
      try:
        value = valtype(child.text)
      except:
        value = child.text
      return value
  return ''

def getXmlPropertyValue(root, name, valtype=str):
  for property in root.findall('{{{}}}Property'.format(NS[""])):
    if property.get('name') == name:
      try:
        if valtype == bool:
          value = eval(property.text)
        else:
          value = valtype(property.text)
      except:
        value = property.text

      return value
  return ''

def updateXmlPropertyIfChanged(properties, name, value, origproperties):
  if str(value) != str(getXmlPropertyValue(origproperties,name)):
    setXmlPropertyValue(properties, name, value)

def setXmlPropertyValue(root,name,value):
  for property in root.findall('{{{}}}Property'.format(NS[""])):
    if property.get('name') == name:
      break
  else:
    # Create property
    property = xml.SubElement(root, '{{{}}}Property'.format(NS[""]), {'name':name})
  property.text = str(value)

def setXmlValue(root,name,value):
  tag = '{{{}}}{}'.format(NS[""], name)
  for child in root:
    if child.tag == tag:
      child.text = str(value)
      return

def getSimpleStringValue(str,key):
  keystr = key + ' *\"(?P<value>.*)\"'
  re_keystr = re.compile(keystr,re.M+re.I)
  valuesearch = re_keystr.search(str)
  if valuesearch == None:
    return ''
  else:
    return unescapeStr(valuesearch.group('value'))

def getSimpleNumValue(str,key):
  keystr = key+' *(?P<value>-?\d+)'
  re_keystr = re.compile(keystr,re.M+re.I)
  valuesearch = re_keystr.search(str)
  if valuesearch == None:
    return 0
  else:
    return eval(valuesearch.group('value'))

def getKeyStringValue(str,key):
  keystr = 'Key \"' + key + '\"*\r?\n *Value \"(?P<value>.*)\"'
  re_keystr = re.compile(keystr,re.M+re.I)
  valuesearch = re_keystr.search(str)
  if valuesearch == None:
    return ''
  else:
    return unescapeStr(valuesearch.group('value'))


def escapeStr(value):
  return repr(value)[1:-1].replace('"', '\\"').replace("\\'", "'")

ESCAPED_CHARS = {'\\\\':'\\', '\\"':'"', '\\n':'\n', '\\r':'\r'}
def unescapeStr(value):
  for key, val in ESCAPED_CHARS.iteritems():
    value = value.replace(key, val)
  return value

def wrapText(text, wraplim=76):
  wrapped = ""
  for line in text.splitlines(True):
    caret = 0
    while caret + wraplim < len(line):
      caret += wraplim
      line = line[:caret] + '\\\n' + line[caret:]
      caret += 2
    wrapped += line
  return wrapped

def prettyXML(xmlstr):
  xmlstr = re.sub(">\s*<", ">\n<", xmlstr)
  prettystr = ""
  level = 0
  for line in xmlstr.splitlines(True):
    prevlevel = level
    # opening tag
    if re.search("(<\w+)[>\s]", line):
      level += 1
    # closing tag
    if re.search("(</\w+)>", line):
      level -= 1

    indent = ""
    if line.startswith("<"):
      indent = "  "*prevlevel if prevlevel < level else "  "*level
    prettystr += indent + line

  return prettystr

def getComponentData(filename):
  return ComponentData(filename)


class ComponentData(object):

  __slots__= (
    'Website',
    'Manufacturer',
    'Name',
    'IsDeprecated',
    'Revision',
    'Type',
    'Tags',
    'Reach',
    'Uri',
    'Description',
    'DetailedRevision',
    'Author',
    'MaxPayLoad',
    'Logo',
    'FileName',
    'PreviewIcon',
    'Email',
    'VcId',
    'Icon',
    '_XmlModel',
    '_XmlOriginalModel',
    '_FileNameUnicode'
  )

  def __init__(self,filename):
    self.FileName = filename
    if isinstance(filename, unicode):
      self._FileNameUnicode = filename
    else:
      self._FileNameUnicode = filename.decode()

    # Test component zip validity
    if not is_zipfile(self._FileNameUnicode):
      print "ComponentData initialization error: %s is not a valid vcm file" % self.FileName
      return
    zip = ZipFile(self._FileNameUnicode, "r")
    try:
      self.read_component_dat(zip.read("component.dat"))
    except:
      pass
    try:
      self.read_model_xml(zip.read("model.xml"))
    except:
      pass
    zip.close()

  def read_component_dat(self,contents):
    self.Name = getSimpleStringValue(contents,'Name')
    self.Icon = getSimpleStringValue(contents,'Icon')
    self.PreviewIcon = getSimpleStringValue(contents,'PreviewIcon')
    self.Logo = getSimpleStringValue(contents,'Logo')
    self.Description = getSimpleStringValue(contents,'Description')
    self.Uri = getSimpleStringValue(contents,'Uri')
    self.VcId = getSimpleStringValue(contents,'VcId')
    self.Revision = getSimpleNumValue(contents,'Revision')
    self.DetailedRevision = getSimpleStringValue(contents,'DetailedRevision')
    self.Manufacturer = getKeyStringValue(contents,'Manufacturer')
    self.Email = getKeyStringValue(contents,'Email')
    self.Website = getKeyStringValue(contents,'Website')
    self.IsDeprecated = getKeyStringValue(contents,'IsDeprecated')
    self.Tags = []
    tagstring = getSimpleStringValue(contents,'Tags')
    if tagstring != '':
      self.Tags = tagstring.split(';')
    self.Author = getKeyStringValue(contents,'Author')
    if self.Author == '':
      self.Author = getKeyStringValue(contents,'Author Company')
    self.MaxPayLoad = getKeyStringValue(contents,'Max Payload')
    if self.MaxPayLoad == '':
      self.MaxPayLoad = getKeyStringValue(contents,'MaxPayLoad')
    if self.MaxPayLoad == '':
      self.MaxPayLoad = getKeyStringValue(contents,'Max_Payload')
    self.Type = getKeyStringValue(contents,'Type')
    self.Reach = getKeyStringValue(contents, 'Reach')

  def read_model_xml(self,contents):
    #xml.register_namespace('', ns)
    self._XmlModel = xml.fromstring(contents)
    self._XmlOriginalModel = xml.fromstring(contents) # for comparison

    # set default namespaces
    try:
      for prefix, url in NS.items():
        xml.register_namespace(prefix, url)
        if prefix:
          self._XmlModel.set("xmlns:"+prefix, url)
    except Exception as e:
      print e

    # These are the contents in the standard model.xml according to the current namespace
    self.Icon = getXmlValue(self._XmlModel,'ThumbnailImageUrl')
    self.PreviewIcon = getXmlValue(self._XmlModel,'PreviewImageUrl')
    self.Uri = getXmlValue(self._XmlModel,'ModelUrl')
    self.Logo = getXmlValue(self._XmlModel,'LogoImageUrl')
    xmlproperties = self._XmlModel.find('{{{0}}}Properties'.format(NS[""]))
    if xmlproperties is not None:
      self.Name = getXmlPropertyValue(xmlproperties,'Name')
      self.Description = getXmlPropertyValue(xmlproperties,'Description')
      self.VcId = getXmlPropertyValue(xmlproperties,'VCID')
      self.Revision = getXmlPropertyValue(xmlproperties,'Revision', int)
      self.DetailedRevision = getXmlPropertyValue(xmlproperties,'DetailedRevision')
      self.Manufacturer = getXmlPropertyValue(xmlproperties,'Manufacturer')
      self.Email = getXmlPropertyValue(xmlproperties,'Email')
      self.Website = getXmlPropertyValue(xmlproperties,'Website')
      self.IsDeprecated = getXmlPropertyValue(xmlproperties,'IsDeprecated', bool)
      tagstring = getXmlPropertyValue(xmlproperties,'Tags')
      self.Tags = []
      if tagstring != '':
        self.Tags = tagstring.split(';')
      self.Author = getXmlPropertyValue(xmlproperties,'Author')
      self.MaxPayLoad = getXmlPropertyValue(xmlproperties,'MaxPayload', int)
      self.Type = getXmlPropertyValue(xmlproperties,'Type')
      self.Reach = getXmlPropertyValue(xmlproperties,'Reach', int)

  def __str__(self):
    text = ""
    for key in self.__slots__:
      if key.startswith("_"):
        continue
      val = getattr(self, key)
      val = ("\n" + str(val)).replace("\n", "\n\t")
      text += "{}: {}\n".format(key, val)
    return text

  def __repr__(self):
    text = 'VcId \"' + self.VcId + '\"\n'
    text += 'Revision %i\n' % self.Revision
    if self.DetailedRevision != '':
      text += 'DetailedRevision \"' + self.DetailedRevision + '\"\n'

    if len(self.Tags) > 0:
      text += 'Tags \"'
      text += ';'.join(self.Tags)
      text += '\"\n'

    text += 'KeywordMap\n{\n'
    if self.Author != '':
      text += '  Keyword\n  {\n    Key \"Author\"\n    Value \"' + escapeStr(self.Author) + '\"\n  }\n'
    if self.Email != '':
      text += '  Keyword\n  {\n    Key \"Email\"\n    Value \"' + escapeStr(self.Email) + '\"\n  }\n'
    if self.Manufacturer != '':
      text += '  Keyword\n  {\n    Key \"Manufacturer\"\n    Value \"' + escapeStr(self.Manufacturer) + '\"\n  }\n'
    if self.MaxPayLoad != '':
      text += '  Keyword\n  {\n    Key \"Max Payload\"\n    Value \"' + str(self.MaxPayLoad) + '\"\n  }\n'
    if self.Reach != '':
      text += '  Keyword\n  {\n    Key \"Reach\"\n    Value \"' + str(self.Reach) + '\"\n  }\n'
    if self.Type != '':
      text += '  Keyword\n  {\n    Key \"Type\"\n    Value \"' + escapeStr(self.Type) + '\"\n  }\n'
    if self.Website != '':
      text += '  Keyword\n  {\n    Key \"Website\"\n    Value \"' + escapeStr(self.Website) + '\"\n  }\n'
    if self.IsDeprecated != '':
      text += '  Keyword\n  {\n    Key \"IsDeprecated\"\n    Value \"'+ str(self.IsDeprecated) +'\"\n  }\n'

    text += '}\n'
    text += 'Items\n{\n  Item\n  {\n'
    text += '    Name \"' + escapeStr(self.Name) + '\"\n'
    text += '    Icon \"' + self.Icon + '\"\n'
    text += '    PreviewIcon \"' + self.PreviewIcon + '\"\n'
    text += '    Description \"' + escapeStr(self.Description) + '\"\n'
    text += '    Logo \"' + self.Logo + '\"\n'
    text += '    Uri \"' + self.Uri + '\"\n'
    text += '  }\n}\n'

    return text

  def ensureTag(self,tag):
    for t in self.Tags:
      if t.lower() == tag.lower():
        return
    self.Tags.append(tag)

  def removeTag(self,tag):
    for t in self.Tags:
      if t.lower() == tag.lower():
        self.tags.remove(t)
        return

  def updatexml(self):
    setXmlValue(self._XmlModel,'ThumbnailImageUrl',self.Icon)
    setXmlValue(self._XmlModel,'PreviewImageUrl',self.PreviewIcon)
    setXmlValue(self._XmlModel,'ModelUrl',self.Uri)
    setXmlValue(self._XmlModel,'LogoImageUrl',self.Logo)
    xmlorigproperties = self._XmlOriginalModel.find('{{{0}}}Properties'.format(NS[""]))
    xmlproperties = self._XmlModel.find('{{{0}}}Properties'.format(NS[""]))
    if xmlproperties is not None:
      updateXmlPropertyIfChanged(xmlproperties,'Name',self.Name, xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'Description',self.Description, xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'VCID',self.VcId, xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'Revision',self.Revision, xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'DetailedRevision',self.DetailedRevision, xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'Manufacturer',self.Manufacturer, xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'Email',self.Email, xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'Website',self.Website, xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'IsDeprecated',self.IsDeprecated, xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'Tags', ';'.join(self.Tags), xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'Author',self.Author, xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'MaxPayload',self.MaxPayLoad, xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'Reach',self.Reach, xmlorigproperties)
      updateXmlPropertyIfChanged(xmlproperties,'Type',self.Type, xmlorigproperties)

  def write(self):
    # Test component zip validity
    if not is_zipfile(self._FileNameUnicode):
      print "ComponentData write error: %s is not a valid vcm file" % self.FileName
      return
    # Open original zip file to read it's content into memory
    zip = ZipFile(self._FileNameUnicode,"r")
    names = []
    files = []
    try:
      names = zip.namelist( )
      for name in names:
        files.append(zip.read(name))
    except Exception as e:
      print e
      zip.close()
      return
    zip.close()
    #now write the new contents to a tempfile first
    tempfilename = ''
    try:
      handle, tempfilename = tempfile.mkstemp()
      os.close(handle)
      zip = ZipFile(tempfilename, "w",compression=ZIP_DEFLATED)
    except Exception as e:
      print e
      zip.close()
      return
    i = 0
    for name in names:
      data = files[i]
      if name == "component.dat":
        try:
          zip.writestr(name, repr(self))
        except Exception as e:
          print e
          zip.close()
          os.remove(tempfilename)
          return
      elif name == "model.xml":
        try:
          self.updatexml()
          xmlstr = xml.tostring(self._XmlModel,encoding='UTF-8',method='xml')
          zip.writestr(name, prettyXML(xmlstr))
        except Exception as e:
          print e
          zip.close()
          os.remove(tempfilename)
          return
      else:
        try:
          zip.writestr(name, data)
        except Exception as e:
          print e
          zip.close()
          os.remove(tempfilename)
          return
      i += 1
    zip.close()
    # replace the original with temp file if got this far
    try:
      os.remove(self._FileNameUnicode)
      os.rename(tempfilename,self._FileNameUnicode)
    except Exception as e:
      print e
