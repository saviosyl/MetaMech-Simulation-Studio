VC_ADD_STATEMENT = 'add_as_statement'
VC_EXECUTE_STATEMENT = 'execute_as_statement'
#VC_EXECUTE_MOTIONTARGET = 'execute_as_motiontarget'

try:
  from vcCommand import *
except:
  try:
    from vcScript import *
  except:
    print "Error: vcHelpers.Robot was unable to import vcCommand and vcScript"

import vcMatrix
app = getApplication()
global idMTX
idMTX = vcMatrix.new()


def clearRoutine(routine):
  #self.RecordRoutineObject.beginBatch()
  for statm in routine.Statements[:]:
    routine.deleteStatement(statm)
  #self.RecordRoutineObject.endBatch()



# vcRobot Class
class vcRobot2(object):

  def __setattr__(self, name, value):
    if name == 'Speed':
      self.Controller.MaxCartesianSpeed = value
    elif name == 'AngularSpeed':
      self.Controller.MaxAngularSpeed = value
    elif name == 'Acc':
      self.Controller.MaxCartesianAccel = value
    elif name == 'AngularAcc':
      self.Controller.MaxAngularAccel = value
    elif name == 'RecordRSL' and value == True:
      if self.RecordRoutine == 'MainRoutine':
        self.RecordRoutineObject = self.Program.MainRoutine
      else:
        for r in self.Program.Routines:
          if r.Name == self.RecordRoutine:
            self.RecordRoutineObject = r
            break
        else:
          self.RecordRoutineObject = self.Program.addRoutine(self.RecordRoutine)
      #clearRoutine(self.RecordRoutineObject)
    elif name == 'RecordRoutine':
      if value == 'MainRoutine':
        self.RecordRoutineObject = self.Program.MainRoutine
      else:
        for r in self.Program.Routines:
          if r.Name == value:
            self.RecordRoutineObject = r
            break
        else:
          self.RecordRoutineObject = self.Program.addRoutine(value)
    #if name not in self.__dict__ and '__locked__' in self.__dict__:
    if not hasattr(self, name) and '__locked__' in self.__dict__:
      raise NameError("Attribute or method '%s' not found." % name)
    else:
      self.__dict__[name] = value
    

  
  def __init__(self, component, controller, executor, graspContainer, signalMapIn, signalMapOut):
    self.Component = component
    self.Controller = controller
    self.MotionTarget = self.Controller.createTarget()
    self.Executor = executor
    self.Program = executor.Program
    self.GraspContainer = graspContainer
    self.SignalMapOut = signalMapOut
    self.SignalMapIn = signalMapIn
    self.Tools = controller.Tools
    self.Bases = controller.Bases
    self.ToolDict = dict( (x.Name,x) for x in self.Tools )
    self.BaseDict = dict( (x.Name,x) for x in self.Bases )
    self.Joints = controller.Joints
    self.Speed = controller.MaxCartesianSpeed
    self.AngularSpeed = controller.MaxAngularSpeed
    self.Acc = controller.MaxCartesianAccel
    self.AngularAcc = controller.MaxAngularAccel
    self.JointForce = 1.0 # 100%
    self.JointSpeed = 1.0 # 100%
    self.ActiveTool = 1
    self.ActiveBase = 0
    self.Controller.Bases[self.ActiveBase].Node = None
    self.Configuration = -1
    self.ConfigurationsList = getConfigNames(executor, controller)
    self.MotionTime = 0
    self.RecordRSL = False
    self.RecordRoutineObject = self.Program.MainRoutine
    self.RecordRoutine = 'MainRoutine'
    self.Execution = VC_EXECUTE_STATEMENT
    self.ForceReset = False
    self.ConfigWarningsEvent = None
    self.ConfigWarnings = []
    
    self._jointRoutine = self.Program.findRoutine( 'vcHelperJointMove' )
    if self._jointRoutine:
      clearRoutine(self._jointRoutine)
    self._jointStatement = None

    self._linearRoutine = self.Program.findRoutine( 'vcHelperLinearMove' )
    if self._linearRoutine:
      clearRoutine(self._linearRoutine)
    self._linearStatement = None

    self.Warnings = True
    self.__locked__ = True #keep this last in init
  
  
  @property
  def Tools(self):
    return self.Controller.Tools
  @property
  def ToolDict(self):
    return dict( (x.Name,x) for x in self.Controller.Tools )
  @property
  def Bases(self):
    return self.Controller.Bases
  @property
  def BaseDict(self):
    return dict( (x.Name,x) for x in self.Controller.Bases )
  @property
  def Joints(self):
    return self.Controller.Joints
  @property
  def JointRoutine(self):
    if self._jointRoutine == None:
      self._jointRoutine = self.Program.findRoutine( 'vcHelperJointMove' )
      if not self._jointRoutine:
        self._jointRoutine = self.Program.addRoutine( 'vcHelperJointMove' )
    return self._jointRoutine
  @property
  def LinearRoutine(self):
    if self._linearRoutine == None:
      self._linearRoutine = self.Program.findRoutine( 'vcHelperLinearMove' )
      if not self._linearRoutine:
        self._linearRoutine = self.Program.addRoutine( 'vcHelperLinearMove' )
    return self._linearRoutine
  @property  
  def JointStatement(self):
    if self._jointStatement == None:
      if self.JointRoutine.Statements:
        self._jointStatement = self.JointRoutine.Statements[0]
      else:
        self._jointStatement = self.JointRoutine.addStatement(VC_STATEMENT_PTPMOTION)
    return self._jointStatement
  @property  
  def LinearStatement(self):
    if self._linearStatement == None: 
      if self.LinearRoutine.Statements:
        self._linearStatement = self.LinearRoutine.Statements[0]
      else:
        self._linearStatement = self.LinearRoutine.addStatement(VC_STATEMENT_LINMOTION)
    return self._linearStatement  

  def linearMoveToMtx(self, ToMtx = idMTX, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, CS = 'world'):
    targetMtx = vcMatrix.new(ToMtx)
    targetMtx.translateRel(Tx,Ty,Tz)
    targetMtx.rotateRelX(Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    robotMove = self.MotionTarget
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
    if CS == 'world':
      robotMove.TargetMode = VC_MOTIONTARGET_TM_WORLDTARGET
    else:
      pass
      #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool

    # Call RSL
    statement = doRSL(self, VC_STATEMENT_LINMOTION, robotMove)
    return statement


  def jointMoveToMtx(self, ToMtx = idMTX, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, CS = 'world'):
    targetMtx = vcMatrix.new(ToMtx)
    targetMtx.translateRel(Tx,Ty,Tz)
    targetMtx.rotateRelX(Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    robotMove = self.MotionTarget
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_JOINT
    if CS == 'world':
      robotMove.TargetMode = VC_MOTIONTARGET_TM_WORLDTARGET
    else:
      pass
      #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool

    # Call RSL
    statement = doRSL(self, VC_STATEMENT_PTPMOTION, robotMove)
    return statement
  

  def linearMoveToComponent(self, ToComp, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, ToFrame = None, OnFace = None):
    global app
    if type(ToComp) == type('DummyString'):
      ToComp = app.findComponent(ToComp)
    if ToComp:
      ToComp.update()
      ToMtx = ToComp.WorldPositionMatrix
      targetMtx = vcMatrix.new(ToMtx)
      if ToFrame:
        try:
          frameMtx = ToFrame.NodePositionMatrix
        except:
          try:
            ToFrame = ToComp.findFeature(ToFrame)
            frameMtx = ToFrame.NodePositionMatrix
          except:
            print 'Error: vcHelpers.Robot.linearMoveToComponent() was unable to get the ToFrame feature'
        try:
          targetMtx = targetMtx * frameMtx
        except:
          pass
        if not ToComp.getFeature(ToFrame.Name):
          print 'Error: vcHelpers.Robot.linearMoveToComponent(): ToFrame feature is not within ToComp - node'
          print '         - There might be error in matrix calculations due to this fact.'
          print '         - Please change ToFrame or ToComp - objects or move the ToFrame-feature under',ToComp.Name,'-node in node tree.'
      elif OnFace:
        onFace(ToComp,targetMtx,OnFace)
      targetMtx.translateRel(Tx,Ty,Tz)
      targetMtx.rotateRelX(180+Rx)
      targetMtx.rotateRelY(Ry)
      targetMtx.rotateRelZ(Rz)
      robotMove = self.MotionTarget
      rc = robotMove.RobotConfig
      robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
      robotMove.TargetMode = VC_MOTIONTARGET_TM_WORLDTARGET
      robotMove.Target = targetMtx
      if self.ActiveTool:
        try:
          robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
        except:
          robotMove.ToolName = self.ActiveTool

      # Call RSL
      statement = doRSL(self, VC_STATEMENT_LINMOTION, robotMove)
      return statement
    else:
      print 'Error: vcHelpers.Robot.linearMoveToComponent() was unable to get the target component'


  def jointMoveToComponent(self, ToComp, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, ToFrame = None, OnFace = None):
    global app
    if type(ToComp) == type('DummyString'):
      ToComp = app.findComponent(ToComp)
    if ToComp:
      ToComp.update()
      ToMtx = ToComp.WorldPositionMatrix
      targetMtx = vcMatrix.new(ToMtx)
      if ToFrame:
        try:
          frameMtx = ToFrame.NodePositionMatrix
        except:
          try:
            ToFrame = ToComp.findFeature(ToFrame)
            frameMtx = ToFrame.NodePositionMatrix
          except:
            print 'Error: vcHelpers.Robot.jointMoveToComponent() was unable to get the ToFrame feature'
        try:
          targetMtx = targetMtx * frameMtx
        except:
          pass
        if not ToComp.getFeature(ToFrame.Name):
          print 'Error: vcHelpers.Robot.jointMoveToComponent(): ToFrame feature is not within ToComp - node'
          print '         - There might be error in matrix calculations due to this fact.'
          print '         - Please change ToFrame or ToComp - objects or move the ToFrame-feature under',ToComp.Name,'-node in node tree.'
      elif OnFace:
        onFace(ToComp,targetMtx,OnFace)
      targetMtx.translateRel(Tx,Ty,Tz)
      targetMtx.rotateRelX(180+Rx)
      targetMtx.rotateRelY(Ry)
      targetMtx.rotateRelZ(Rz)
      robotMove = self.MotionTarget
      rc = robotMove.RobotConfig
      robotMove.MotionType = VC_MOTIONTARGET_MT_JOINT
      robotMove.TargetMode = VC_MOTIONTARGET_TM_WORLDTARGET
      robotMove.Target = targetMtx
      if self.ActiveTool:
        try:
          robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
        except:
          robotMove.ToolName = self.ActiveTool

      # Call RSL
      statement = doRSL(self, VC_STATEMENT_PTPMOTION, robotMove)
      return statement
    else:
      print 'Error: vcHelpers.Robot.jointMoveToComponent() was unable to get the target component'


  def linearMoveToPosition(self, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, CS = 'world'):
    targetMtx = vcMatrix.new()
    targetMtx.translateRel(Tx,Ty,Tz)
    targetMtx.rotateRelX(180+Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    robotMove = self.MotionTarget
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
    if CS == 'world':
      robotMove.TargetMode = VC_MOTIONTARGET_TM_WORLDTARGET
    else:
      pass
      #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool

    # Call RSL
    statement = doRSL(self, VC_STATEMENT_LINMOTION, robotMove)
    return statement


  def jointMoveToPosition(self, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, CS = 'world'):
    targetMtx = vcMatrix.new()
    targetMtx.translateRel(Tx,Ty,Tz)
    targetMtx.rotateRelX(180+Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    robotMove = self.MotionTarget
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_JOINT
    if CS == 'world':
      robotMove.TargetMode = VC_MOTIONTARGET_TM_WORLDTARGET
    else:
      pass
      #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool
    ####### TEST WITH 2011

    ######

    # Call RSL
    statement = doRSL(self, VC_STATEMENT_PTPMOTION, robotMove)
    return statement


  def linearMoveToMtx_ExternalBase(self, Basenode, ToMtx = idMTX, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0):
    targetMtx = vcMatrix.new(ToMtx)
    targetMtx.translateRel(Tx, Ty, Tz)
    targetMtx.rotateRelX(Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    base = self.Controller.Bases[self.ActiveBase]
    self.Controller.Bases[self.ActiveBase].Node = Basenode # <= 2011 bug fix
    if Basenode:
      Basenode.update()
      self.Component.update()
    base.PositionMatrix = vcMatrix.new()
    robotMove = self.MotionTarget
    rc = robotMove.RobotConfig
    robotMove.BaseName = self.Controller.Bases[self.ActiveBase].Name
    robotMove.TargetMode = VC_MOTIONTARGET_TM_NORMAL
    robotMove.Target = targetMtx
    robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool
    # Call RSL
    statement = doRSL(self, VC_STATEMENT_LINMOTION, robotMove, Basenode)
    return statement



  def jointMoveToMtx_ExternalBase(self, Basenode, ToMtx = idMTX, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0):
    targetMtx = vcMatrix.new(ToMtx)
    targetMtx.translateRel(Tx, Ty, Tz)
    targetMtx.rotateRelX(Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    base = self.Controller.Bases[self.ActiveBase]
    self.Controller.Bases[self.ActiveBase].Node = Basenode  # <= 2011 bug fix
    if Basenode:
      Basenode.update()
      self.Component.update()
    base.PositionMatrix = vcMatrix.new()
    robotMove = self.MotionTarget
    rc = robotMove.RobotConfig
    robotMove.BaseName = self.Controller.Bases[self.ActiveBase].Name
    robotMove.TargetMode = VC_MOTIONTARGET_TM_NORMAL
    robotMove.Target = targetMtx
    robotMove.MotionType = VC_MOTIONTARGET_MT_JOINT
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool
    # Call RSL
    statement = doRSL(self, VC_STATEMENT_PTPMOTION, robotMove, Basenode)
    return statement


  def followNode(self, Basenode, FollowTime=1):
    print 'not implemented'
    return
    base = self.Controller.Bases[self.ActiveBase]
    self.Controller.Bases[self.ActiveBase].Node = Basenode # <= 2011 bug fix
    if Basenode:
      Basenode.update()
      self.Component.update()
    base.PositionMatrix = vcMatrix.new()
    robotMove = self.MotionTarget
    robotMove.BaseName = self.Controller.Bases[self.ActiveBase].Name
    robotMove.TargetMode = VC_MOTIONTARGET_TM_NORMAL
    robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
    self.Executor.deleteSubRoutine('vcHelperMove')
    subr = self.Executor.createSubRoutine('vcHelperMove')
    statement = subr.createStatement(VC_STATEMENT_LINMOTION)
    if Basenode:
      self.Controller.Bases[self.ActiveBase].Node = Basenode  
    statement.readFromTarget(robotMove)
    self.Executor.callRoutine('vcHelperMove')
    delay(FollowTime)
    self.Controller.Bases[self.ActiveBase].Node = None # self.ActiveBase


  def moveAway(self, Tz = 200):
    robotMove = self.Controller.createTarget()
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool
    targetMtx = vcMatrix.new(robotMove.Target)
    targetMtx.translateRel(0,0,-Tz)
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
    #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx

    # Call RSL
    statement = doRSL(self, VC_STATEMENT_LINMOTION, robotMove)
    return statement


  def linearMoveRel(self, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0):
    robotMove = self.Controller.createTarget()
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool
    targetMtx = vcMatrix.new(robotMove.Target)
    targetMtx.translateRel(Tx, Ty, Tz)
    targetMtx.rotateRelX(Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_LINEAR
    #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx

    # Call RSL
    statement = doRSL(self, VC_STATEMENT_LINMOTION, robotMove)
    return statement


  def jointMoveRel(self, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0):
    robotMove = self.Controller.createTarget()
    if self.ActiveTool:
      try:
        robotMove.ToolName = self.Controller.Tools[self.ActiveTool-1].Name
      except:
        robotMove.ToolName = self.ActiveTool
    targetMtx = vcMatrix.new(robotMove.Target)
    targetMtx.translateRel(Tx, Ty, Tz)
    targetMtx.rotateRelX(Rx)
    targetMtx.rotateRelY(Ry)
    targetMtx.rotateRelZ(Rz)
    rc = robotMove.RobotConfig
    robotMove.MotionType = VC_MOTIONTARGET_MT_JOINT
    #robotMove.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
    robotMove.Target = targetMtx

    # Call RSL
    statement = doRSL(self, VC_STATEMENT_PTPMOTION, robotMove)
    return statement


  def driveJoints(self, J1 = 'current', J2 = 'current', J3 = 'current', J4 = 'current', J5 = 'current', J6 = 'current', MotionTime = 0, Relative = False, ExtraJoints = []):
    vals = []
    givenVals = [J1, J2, J3, J4, J5, J6]
    givenVals.extend( ExtraJoints )
    for i in range(len(self.Controller.Joints)):
      # get current values
      curVal = self.Controller.Joints[i].CurrentValue
      vals.append(curVal)
    for i in range( len(vals) - len(givenVals) ):
      givenVals.append('current')
    for i in range(len(vals)):
      if givenVals[i] != 'current':
        # update only given values, rest are left current
        if Relative:
          # relative
          vals[i] += givenVals[i]
        else:
          # absolute
          vals[i] = givenVals[i]
      # set joint targets
      val = vals[i]
      self.Controller.setJointTarget(i, val)
    if MotionTime:
      # override accs, decs and speeds if motiontime given != 0
      self.Controller.setMotionTime(MotionTime)
    motTime = self.Controller.calcMotionTime() # calc motiontime to return
    self.Controller.move()
    return motTime
      


  def pick(self, Part, Approach = 200, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0,OnFace = 'top', ApproachAxis = 'Z'):
    statements = []
    if Part:
      if ApproachAxis == 'Z':
        statements.append(self.jointMoveToComponent(Part, Tx=Tx,Ty=Ty,Tz=Tz+Approach,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace))
      elif ApproachAxis == '-Z':
        statements.append(self.jointMoveToComponent(Part, Tx=Tx,Ty=Ty,Tz=Tz-Approach,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace))
      elif ApproachAxis == 'Y':
        statements.append(self.jointMoveToComponent(Part, Tx=Tx,Ty=Ty+Approach,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace))
      elif ApproachAxis == '-Y':
        statements.append(self.jointMoveToComponent(Part, Tx=Tx,Ty=Ty-Approach,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace))
      elif ApproachAxis == 'X':
        statements.append(self.jointMoveToComponent(Part, Tx=Tx+Approach,Ty=Ty,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace))
      elif ApproachAxis == '-X':
        statements.append(self.jointMoveToComponent(Part, Tx=Tx-Approach,Ty=Ty,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace))
      statements.append(self.linearMoveToComponent(Part, Tx,Ty,Tz,Rx,Ry,Rz,OnFace=OnFace))
      self.graspComponent(Part)
      if ApproachAxis == 'Z':
        statements.append(self.linearMoveToComponent(Part, Tx=Tx,Ty=Ty,Tz=Tz+Approach,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace))
      elif ApproachAxis == 'Y':
        statements.append(self.linearMoveToComponent(Part, Tx=Tx,Ty=Ty+Approach,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace))
      elif ApproachAxis == 'X':
        statements.append(self.linearMoveToComponent(Part, Tx=Tx+Approach,Ty=Ty,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace))
      if ApproachAxis == '-Z':
        statements.append(self.linearMoveToComponent(Part, Tx=Tx,Ty=Ty,Tz=Tz-Approach,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace))
      elif ApproachAxis == '-Y':
        statements.append(self.linearMoveToComponent(Part, Tx=Tx,Ty=Ty-Approach,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace))
      elif ApproachAxis == '-X':
        statements.append(self.linearMoveToComponent(Part, Tx=Tx-Approach,Ty=Ty,Tz=Tz,Rx=Rx,Ry=Ry,Rz=Rz, OnFace=OnFace))
    return statements


  def place(self, ToComp, Approach = 200, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, Part = None, ApproachAxis = 'Z'):
    statements = []
    if self.GraspContainer.Components or Part:
      if not Part:
        Part = self.GraspContainer.Components[0]
      PartHeight = Part.Geometry.BoundDiagonal.Z*2
      PartWidth = Part.Geometry.BoundDiagonal.Y*2
      PartLength = Part.Geometry.BoundDiagonal.X*2
      appr = Approach
      if ApproachAxis == 'Z':
        statements.append(self.jointMoveToComponent(ToComp, Tx = Tx, Ty = Ty, Tz = Tz+appr+PartHeight, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
      elif ApproachAxis == 'Y':
        statements.append(self.jointMoveToComponent(ToComp, Tx = Tx, Ty = Ty+appr+PartWidth, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
      elif ApproachAxis == 'X':
        statements.append(self.jointMoveToComponent(ToComp, Tx = Tx+appr+PartLength, Ty = Ty, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
      if ApproachAxis == '-Z':
        statements.append(self.jointMoveToComponent(ToComp, Tx = Tx, Ty = Ty, Tz = Tz-appr-PartHeight, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
      elif ApproachAxis == '-Y':
        statements.append(self.jointMoveToComponent(ToComp, Tx = Tx, Ty = Ty-appr-PartWidth, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
      elif ApproachAxis == '-X':
        statements.append(self.jointMoveToComponent(ToComp, Tx = Tx-appr-PartLength, Ty = Ty, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
      statements.append(self.linearMoveToComponent(ToComp, Tx = Tx, Ty = Ty, Tz = Tz+PartHeight, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
      self.releaseComponent(ToComp,Part)
      if ApproachAxis == 'Z':
        statements.append(self.linearMoveToComponent(ToComp, Tx = Tx, Ty = Ty, Tz = Tz+appr+PartHeight, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
      elif ApproachAxis == 'Y':
        statements.append(self.linearMoveToComponent(ToComp, Tx = Tx, Ty = Ty+appr+PartWidth, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
      elif ApproachAxis == 'X':
        statements.append(self.linearMoveToComponent(ToComp, Tx = Tx+appr+PartLength, Ty = Ty, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
      if ApproachAxis == '-Z':
        statements.append(self.linearMoveToComponent(ToComp, Tx = Tx, Ty = Ty, Tz = Tz-appr-PartHeight, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
      elif ApproachAxis == '-Y':
        statements.append(self.linearMoveToComponent(ToComp, Tx = Tx, Ty = Ty-appr-PartWidth, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
      elif ApproachAxis == '-X':
        statements.append(self.linearMoveToComponent(ToComp, Tx = Tx-appr-PartLength, Ty = Ty, Tz = Tz, Rx = Rx, Ry = Ry, Rz = Rz, OnFace = 'top'))
    return statements


  def placeInPattern(self, ToComp, X_index, Y_index, Z_index, PatternSize_X = 0, PatternSize_Y = 0, PatternSize_Z = 0, Approach = 200, Part = None, StepSizeX = 0, StepSizeY = 0, StepSizeZ = 0, Rz = 0):
    statements = []
    if self.GraspContainer.Components or Part:
      if not Part:
        Part = self.GraspContainer.Components[0]
      if not StepSizeX:
        StepSizeX = Part.Geometry.BoundDiagonal.X*2
      if not StepSizeY:
        StepSizeY = Part.Geometry.BoundDiagonal.Y*2
      if not StepSizeZ:
        StepSizeZ = Part.Geometry.BoundDiagonal.Z*2
      appr = Approach+StepSizeZ
      xOffset = -(StepSizeX*(PatternSize_X-1))/2 + StepSizeX*X_index
      yOffset = -(StepSizeY*(PatternSize_Y-1))/2 + StepSizeY*Y_index
      zOffset = Z_index*StepSizeZ
      statements.append(self.jointMoveToComponent(ToComp, Tx = xOffset, Ty = yOffset, Tz = zOffset+appr, Rz = Rz, OnFace = 'top'))
      statements.append(self.linearMoveToComponent(ToComp, Tx = xOffset, Ty = yOffset, Tz = zOffset+StepSizeZ, Rz = Rz, OnFace = 'top'))
      statements.append(self.releaseComponent(ToComp,Part))
      statements.append(self.moveAway(Approach))
    return statements


  def pickFromPallet(self, Pallet, Approach = 200, InversedOrder = False, Index = -1):
    if Pallet:
      Parts = []
      PalletConts = Pallet.findBehavioursByType(VC_CONTAINER)
      for cont in PalletConts:
        Parts.extend(cont.Components)
      if not Parts:
        Parts = Pallet.ChildComponents
      if Parts:
        if InversedOrder:
          Part = Parts[0]
        else:
          Part = Parts[-1]
        if Index != -1:
          if Index > len(Parts)-1:
            if self.Warnings:
              print 'Warning: vcHelpers.Robot: From component', self.Component.Name
              print '          Given "Index" argument is out of range. There are not that many parts on pallet.'
            return
          Part = Parts[Index]
        self.jointMoveToComponent(Part,Tz = Approach, OnFace = 'top')
        self.linearMoveToComponent(Part, OnFace = 'top')
        self.graspComponent(Part)
        self.linearMoveToComponent(Part,Tz = Approach, OnFace = 'top')
        return Part


  def pickMovingPart(self, Part, Approach = 200, Tx = 0,Ty = 0,Tz = 0,Rx = 0,Ry = 0,Rz = 0, ForceUpdatePos = True, rrx = -1, rry = -1, rrz = -1): # (debug args: ForceUpdatePos = True, rrx = -1, rry = -1, rrz = -1) (future arg#Advancement = 200)
    statements = []
    if Part:
      if self.RecordRSL and self.Warnings:
        print 'Warning: vcHelpers.Robot: From component', self.Component.Name
        print '       - RSL-statement base configuration may need reconfiguration before post-processing.'
        print '       - External base node is overwritten on every statement creation.'
      ToMtx = vcMatrix.new()
      partHeight = Part.Geometry.BoundDiagonal.Z*2
      #self.jointMoveToMtx_ExternalBase(ToMtx, Part, Tx = Advancement, Tz = partHeight+Approach, Rx = 180)
      tx, ty, tz, rx, ry, rz = Tx, Ty, Tz, Rx, Ry, Rz
      statements.append(self.linearMoveToMtx_ExternalBase(Part, ToMtx, Tx = Tx, Ty = Ty, Tz = partHeight + Tz, Rx = 180 + Rx, Ry = 0 + Ry, Rz = Rz))
      self.graspComponent(Part)
      # Force part on right position
      if ForceUpdatePos:
        # Get tool position
        if self.ActiveTool:
          if type(self.ActiveTool) == type('DummyString'):
            for i in self.Controller.Tools:
              if i.Name == self.ActiveTool:
                toolpos = i.PositionMatrix
          else:
            toolpos = self.Controller.Tools[self.ActiveTool-1].PositionMatrix
        else:
          toolpos = vcMatrix.new()
        toolpos.rotateRelZ(rz*rrz)
        toolpos.rotateRelY(ry*rry)
        toolpos.rotateRelX(rx*rrx)
        toolpos.translateRel(-tx,ty,tz+partHeight)
        partpos = vcMatrix.new(Part.PositionMatrix)
        v = partpos.P
        v.X = 0.0 + toolpos.P.X
        v.Y = 0.0 + toolpos.P.Y
        v.Z = 0.0 + toolpos.P.Z
        partpos.P = v
        Part.PositionMatrix = partpos
        Part.update()
      # Move away
      statements.append(self.moveAway(Approach))
    return statements

  def graspComponent(self, GraspThis):
    self.GraspContainer.grab(GraspThis)
    if self.RecordRSL:
      if self.ActiveTool:
        if type(self.ActiveTool) == type('DummyString'):
          run = 1
          for i in self.Controller.Tools:
            if i.Name == self.ActiveTool:
              tool = run
            run += 1
        else:
          tool = self.ActiveTool
      addRecStatement(self,VC_STATEMENT_SETBIN, tool, True)

  def graspComponents(self, GraspThese):
    for i in GraspThese:
      self.GraspContainer.grab(i)
    if self.RecordRSL:
      if self.ActiveTool:
        if type(self.ActiveTool) == type('DummyString'):
          run = 1
          for i in self.Controller.Tools:
            if i.Name == self.ActiveTool:
              tool = run
            run += 1
        else:
          tool = self.ActiveTool
      addRecStatement(self,VC_STATEMENT_SETBIN, tool, True)

  def releaseComponent(self, ToObject, ReleseThis = None):
    toContainer = None
    if not ReleseThis and  self.GraspContainer.Components:
      ReleseThis = self.GraspContainer.Components[0]
    elif not ReleseThis:
      print 'Error: vcHelpers.Robot: No component to release from graspContainer in robot', self.Component.Name
      return
    try:
      ToObject.Components
      toContainer = ToObject
    except:
      try:
        toContainer = ToObject.findBehavioursByType(VC_CONTAINER)[0]
      except:
        pass
    if not toContainer:
      try:
        ToObject.update()
        ReleseThis.update()
        newpos = ToObject.InverseWorldPositionMatrix*ReleseThis.WorldPositionMatrix
        ToObject.attach(ReleseThis)
        ReleseThis.PositionMatrix = newpos
      except:
        print 'Error: vcHelpers.Robot was unable to find detect targetContainer in ',ToObject.Name
    else:
      toContainer.grab(ReleseThis)
    if self.RecordRSL:
      if self.ActiveTool:
        if type(self.ActiveTool) == type('DummyString'):
          run = 1
          for i in self.Controller.Tools:
            if i.Name == self.ActiveTool:
              tool = run
            run += 1
        else:
          tool = self.ActiveTool
      addRecStatement(self,VC_STATEMENT_SETBIN, tool, False)

  def releaseAllComponents(self, ToObject):
    toContainer = None
    try:
      ToObject.Components
      toContainer = ToObject
    except:
      try:
        toContainer = ToObject.findBehavioursByType(VC_CONTAINER)[0]
      except:
        pass
    for iPart in self.GraspContainer.Components:
      if not toContainer:
        try:
          ToObject.update()
          iPart.update()
          newpos = ToObject.InverseWorldPositionMatrix*iPart.WorldPositionMatrix
          ToObject.attach(iPart)
          iPart.PositionMatrix = newpos
        except:
          print 'Error: vcHelpers.Robot was unable to find detect targetContainer in ',ToObject.Name
      else:
        toContainer.grab(iPart)
    if self.RecordRSL:
      if self.ActiveTool:
        if type(self.ActiveTool) == type('DummyString'):
          run = 1
          for i in self.Controller.Tools:
            if i.Name == self.ActiveTool:
              tool = run
            run += 1
        else:
          tool = self.ActiveTool
      addRecStatement(self,VC_STATEMENT_SETBIN, tool, False)

  def traceOn(self,Index = 1):
    self.SignalMapOut.output(Index+16,True)
    if self.RecordRSL:
      addRecStatement(self,VC_STATEMENT_SETBIN, Index+16, True)
    
  def traceOff(self,Index = 1):
    self.SignalMapOut.output(Index+16,False)
    if self.RecordRSL:
      addRecStatement(self,VC_STATEMENT_SETBIN, Index+16, False)

  def mountTool(self, Tool):
    try:
      iface = self.Controller.FlangeNode.getBehavioursByType(VC_ONETOONEINTERFACE)[0]
      if Tool:
        if iface:
          # check interfaces in the other component
          ifaces = Tool.findBehavioursByType(VC_ONETOONEINTERFACE )
          for other_iface in ifaces:
            if iface.canConnect(other_iface ):
              if iface.connect( other_iface, False ):
                iface.connect( other_iface, False )
                break
              else:
                print "Error: vcHelpers.Robot: Tool to mount has interface already connected"
          else:
            return "Error: vcHelpers.Robot: No matching interface detected to mount tool"
      else:
        print "Error: vcHelpers.Robot: No tool detected to mount"
    except:
      print 'Error: vcHelpers.Robot was unable to mount a Tool'
    if self.RecordRSL:
      if self.ActiveTool:
        if type(self.ActiveTool) == type('DummyString'):
          run = 1
          for i in self.Controller.Tools:
            if i.Name == self.ActiveTool:
              tool = run
            run += 1
        else:
          tool = self.ActiveTool
      addRecStatement(self,VC_STATEMENT_SETBIN, tool+32, True)
      
  
  def unmountTool(self, Tool, ToObject):
    toContainer = None
    iface = self.Controller.FlangeNode.getBehavioursByType(VC_ONETOONEINTERFACE)[0]
    if iface:
      iface.unConnect()
    if not Tool:
      print 'Error: vcHelpers.Robot: No such Tool to be unmounted in robot', self.Component.Name
      return
    try:
      ToObject.Components
      toContainer = ToObject
    except:
      try:
        toContainer = ToObject.findBehavioursByType(VC_CONTAINER)[0]
      except:
        pass
    if not toContainer:
      try:
        ToObject.update()
        Tool.update()
        newpos = ToObject.InverseWorldPositionMatrix*Tool.WorldPositionMatrix
        ToObject.attach(Tool)
        Tool.PositionMatrix = newpos
      except:
        print 'Error: vcHelpers.Robot was unable to find detect targetContainer for unmounting in ',ToObject.Name
    else:
      toContainer.grab(Tool)
    if self.RecordRSL:
      if self.ActiveTool:
        if type(self.ActiveTool) == type('DummyString'):
          run = 1
          for i in self.Controller.Tools:
            if i.Name == self.ActiveTool:
              tool = run
            run += 1
        else:
          tool = self.ActiveTool
      addRecStatement(self,VC_STATEMENT_SETBIN, self.ActiveTool+32, False)


  def callSubRoutine(self, rName):
    self.Executor.callRoutine(self.Program.findRoutine(rName))
    if self.RecordRSL:
      addRecStatement(self,VC_STATEMENT_CALL, rName, None)
  def callRoutine(self, rName):
    self.callSubRoutine(rName)

  def comment(self, Comment):
    print 'Comment From vcRobot -',self.Component.Name,':'
    print '    -',str(Comment)
    if self.RecordRSL:
      addRecStatement(self,VC_STATEMENT_COMMENT, Comment, None)


  def delay(self, Delay):
    if Delay < 0:
      Delay=0
    delay(Delay)
    if self.RecordRSL:
      addRecStatement(self,VC_STATEMENT_DELAY, Delay, None)


  def rsl_BinOut(self, Index, Value):
    addRecStatement(self,VC_STATEMENT_SETBIN, Index, Value)
  

  def rsl_BinIn(self, Index, Value):
    addRecStatement(self,VC_STATEMENT_WAITBIN, Index, Value)

  def setMotionTime(self, MotionTime):
    self.MotionTime = MotionTime


def getRobot(arg = None, SetActionMode = True):
  argType = None
  # Test if the given argument is a robot component (vcComponent), interface name (string) or None
  
  # Component - arg
  try:
    arg.VCID
    argType = 'component'
  
  except:
    if not argType and type(arg) == type('dummystring'):
  # Iface name - arg
      argType = 'iface'
  # None - arg
  
  # Find robot component and save it to roboComp - variable
  if argType == None:
    roboComp = getComponent()
  elif argType == 'component':
    roboComp = arg
  elif argType == 'iface':
    iface = getComponent().findBehaviour(arg)
    if not iface or iface.Type != VC_ONETOONEINTERFACE:
      print 'Error: vcHelpers.Robot was unable to find interface called',arg,'in component "',getComponent().Name,'".'
      return None
    else:
      roboComp = iface.ConnectedComponent
      if not roboComp:
        print 'Error: vcHelpers.Robot was unable to find robot.'
        print '       - Connect robot to "',iface.Name,'"-interface.'
        return None
    
  # Find Controller, Executor, GraspContainer and signalMap
  executors = roboComp.findBehavioursByType(VC_ROBOTEXECUTOR)
  old_executors = roboComp.findBehavioursByType(VC_RSLEXECUTOR)
  if not executors and old_executors:
    print 'Error vcHelpers.Robot2: Old robot "%s". Visit program-tab to convert robot to new executor' % roboComp.Name
    return
  
  try:
    executor = executors[0]
    executor.IsEnabled = not SetActionMode
    signalMapOut = executor.DigitalOutputSignals
    signalMapIn = executor.DigitalInputSignals 
  except:
    print 'Error: vcHelpers.Robot was unable to find executor in component "',roboComp.Name,'".'
    return

  controller = executor.Controller
  if not controller:
    print 'Error: vcHelpers.Robot was unable to find controller associated with the robot executor in "',roboComp.Name,'".'
    return
    
  graspContainers = controller.FlangeNode.getBehavioursByType(VC_COMPONENTCONTAINER)
  if not graspContainers:
    print 'Error: vcHelpers.Robot was unable to find graspContainers in component "',roboComp.Name,'".'
    print '       - Robot model is being manipulated: GraspContainer added.'
    graspContainer = controller.FlangeNode.createBehaviour(VC_COMPONENTCONTAINER,'GraspContainer')
  else:
    graspContainer = graspContainers[-1]
  return vcRobot2(roboComp, controller, executor, graspContainer, signalMapIn, signalMapOut)
    
'''
VC_ADD_STATEMENT = 'add_as_statement'
VC_EXECUTE_STATEMENT = 'execute_as_statement'
'''

def doRSL(robo, mtnType, robotMove, Basenode = None):
  if Basenode:
    robo.Controller.Bases[robo.ActiveBase].Node = Basenode
  else:
    robo.Controller.Bases[robo.ActiveBase].Node = None
  if mtnType == VC_STATEMENT_PTPMOTION:
    if robo.Configuration != -1:
      if type(robo.Configuration) == str:
        if robo.Configuration in robo.ConfigurationsList:
          conf = robo.ConfigurationsList.index(robo.Configuration)
          robotMove.RobotConfig = conf
        else:
          print 'Configuration name "%s" not found' % (robo.Configuration)
      else:
        robotMove.RobotConfig = robo.Configuration
    else:
      robotMove.RobotConfig = -1
  if robo.Execution == VC_EXECUTE_STATEMENT:
    if mtnType == VC_STATEMENT_PTPMOTION:
      statement = robo.JointStatement
      routine = robo.JointRoutine
    else:
      statement = robo.LinearStatement
      routine = robo.LinearRoutine
    readFromTarget(robo, robotMove, statement)
    #statement.readFromTarget(robotMove)
    robo.Executor.callRoutine(routine)
    if Basenode:
      Basenode.rebuild()
  if robo.RecordRSL or robo.Execution == VC_ADD_STATEMENT:
    statement = recRSL(robo, mtnType, robotMove, Basenode)
  robo.Controller.Bases[robo.ActiveBase].Node = None # self.ActiveBase

  if robo.ForceReset:
    resetTarget(robo, robotMove)

  mtx = vcMatrix.new()
  robotMove.Target = mtx
  robo.MotionTime = 0
  return statement

def resetTarget(robo, robotMove):
  robotMove = robo.Controller.createTarget()
  mtx = robotMove.Target
  mtx.translateRel(0,0,0.0001) # A LITTLE MOTION IS REQUIRED IN ORDER TO FORCE BASE CHANGE
  robotMove.Target = mtx
  robotMove.BaseName = '*NULL*'
  #t.TargetMode = VC_MOTIONTARGET_TM_ROBOTROOT
  robo.Controller.addTarget(robotMove)
  robo.Controller.move()

def readFromTarget(robo, motiontarget, statement):
  position = statement.Positions[0]
  # Ext axis
  vals = [robo.Controller.Joints[i].CurrentValue for i, x in enumerate(robo.Controller.Joints) if x.ExternalController]
  position.setExternalJoints( vals )
  # Base
  if type(robo.ActiveBase) == str:
    statement.Base = robo.BaseDict[robo.ActiveBase]
  else:
    statement.Base = robo.Bases[robo.ActiveBase]
  # TCP
  if type(robo.ActiveTool) == str:
    statement.Tool = robo.ToolDict[robo.ActiveTool]
  else:
    statement.Tool = robo.Tools[robo.ActiveTool-1]
  # Position
  if motiontarget.TargetMode == VC_MOTIONTARGET_TM_WORLDTARGET:
    position.PositionInWorld = motiontarget.Target
  else:
    position.PositionInReference = motiontarget.Target
  # Configuration
  if robo.ConfigurationsList:
    position.Configuration = robo.ConfigurationsList[motiontarget.RobotConfig]
  # config warnings
  if robo.ConfigWarningsEvent:
    conf_warnings = [motiontarget.getConfigWarning(x) for x in range(motiontarget.ConfigCount)]
    robo.ConfigWarningsEvent( conf_warnings )
  # Speeds and Accelerations
  updSpeeds(robo, statement)
  # fixed motion time (MISSING IN NG)
  if robo.MotionTime >= 0:
    statement.CycleTime = robo.MotionTime


def recRSL(robo, mtnType, robotMove, Basenode = None):
  subr = robo.RecordRoutineObject
  statement = subr.addStatement(mtnType)
  readFromTarget(robo, robotMove, statement)
  if Basenode:
    robo.Controller.Bases[robo.ActiveBase].Node = Basenode
  updSpeeds(robo, statement)
  robo.Controller.Bases[robo.ActiveBase].Node = None
  return statement



def addRecStatement(robo,type, arg1 = 0, arg2 = 0):
  subr = robo.RecordRoutineObject
  statement = subr.addStatement(type)
  #rint type,[(x.Name, x.Type, x.Value) for x in statement.Properties], statement.Type
  if type == VC_STATEMENT_SETBIN:
    statement.OutputPort = arg1
    statement.OutputValue = arg2
  elif type == VC_STATEMENT_WAITBIN:
    statement.Input = arg1
    statement.Value = arg2
  elif type == VC_STATEMENT_CALL:
    pass
    #statement.Routine = robo.Program.findRoutine(arg1)
  elif type == VC_STATEMENT_COMMENT:
    statement.Comment = str(arg1)
  elif type == VC_STATEMENT_DELAY:
    statement.Delay = arg1


def onFace(ToComp,targetMtx,OnFace):
  compBC = ToComp.Geometry.BoundCenter
  compBD = ToComp.Geometry.BoundDiagonal
  if OnFace == 'top':
    targetMtx.translateRel(compBC.X,compBC.Y,compBC.Z+compBD.Z)
  if OnFace == 'bottom':
    targetMtx.translateRel(compBC.X,compBC.Y,compBC.Z-compBD.Z)
    targetMtx.rotateRelY(180)
  if OnFace == 'right':
    targetMtx.translateRel(compBC.X,compBC.Y-compBD.Y,compBC.Z)
    targetMtx.rotateRelX(90)
  if OnFace == 'left':
    targetMtx.translateRel(compBC.X,compBC.Y+compBD.Y,compBC.Z)
    targetMtx.rotateRelX(-90)
  if OnFace == 'front':
    targetMtx.translateRel(compBC.X+compBD.X,compBC.Y,compBC.Z)
    targetMtx.rotateRelY(90)
  if OnFace == 'back':
    targetMtx.translateRel(compBC.X-compBD.X,compBC.Y,compBC.Z)
    targetMtx.rotateRelY(-90)
    

def updSpeeds(robo, statement):
  if statement.Type == VC_STATEMENT_PTPMOTION:
    statement.JointSpeed = robo.JointSpeed
    statement.JointForce = robo.JointForce
  else:
    statement.AngularAcceleration = robo.AngularAcc
    statement.AngularDeceleration = robo.AngularAcc
    statement.MaxAngularSpeed = robo.AngularSpeed
    statement.Acceleration = robo.Acc
    statement.Deceleration = robo.Acc
    statement.MaxSpeed = robo.Speed

'''
def updSpeeds(robotMove, statement):
  if robotMove.MotionType == VC_MOTIONTARGET_MT_JOINT:
    robotMove.JointSpeedFactor = robo.JointSpeed
    robotMove.JointForce = robo.JointForce
  else:
    robotMove.AngularAcceleration = robo.AngularAcc
    robotMove.AngularDeceleration = robo.AngularAcc
    robotMove.MaxAngularSpeed = robo.AngularSpeed
    robotMove.Acceleration = robo.Acc
    robotMove.Deceleration = robo.Acc
    robotMove.MaxSpeed = robo.Speed'''
  
  
  
def printMatrix(mat):
  """Usefull utiliTy function for printing matrix value"""
  print '----------------------------------------------------------------------'
  for Vec in [mat.N,mat.O,mat.A,mat.P]:
    s = ''
    x = round(Vec.X,3)
    y = round(Vec.Y,3)
    z = round(Vec.Z,3)
    w = round(Vec.W,3)
    s += str(x)
    while len(s) <15:
      s+=' '
    s += str(y)
    while len(s) <30:
      s+=' '
    s += str(z)
    while len(s) <45:
      s+=' '
    s += str(w)
    print s
  print '----------------------------------------------------------------------'
  
  
 
  
def getSelectedRobotsData(robocomp = None):
  global app
  executor = None
  routine = None
  controller = None
  basename = '*NULL*'
  toolname = '*NULL*'
  basenames = []
  toolnames = []
  robotconfig = -1
  robotconfigs = []
  sel = app.SelectionManager
  try:
    robocomp = app.CurrentContext.ActiveRobot
  except:
    try:
      robocomp = app.CurrentContext.ActiveComponent
    except:
      selected_components = sel.getSelection(VC_SELECTION_COMPONENT)
      if len(selected_components) == 1:
        robocomp = selected_components[0]
      else:
        robocomp = None
  if robocomp:
    executors = robocomp.findBehavioursByType( VC_ROBOTEXECUTOR )
    if executors:
      executor = executors[0]
  if executor and executor.Controller != None and executor.Controller.Type == VC_ROBOTCONTROLLER:
    try:
      routine = app.CurrentContext.ActiveScope # not yet implemented ! ! ! ! 
    except:
      routine = executor.Program.MainRoutine
    controller = executor.Controller
    controller.clearTargets()
    motiontarget = controller.createTarget()
    basename = motiontarget.BaseName
    if basename == '':
      basename = '*NULL*'
    toolname = motiontarget.ToolName
    if toolname == '':
      toolname = '*NULL*'
    robotconfig = motiontarget.RobotConfig
    motiontarget.TargetMode = VC_MOTIONTARGET_TM_NORMAL
    basenames = [ '*NULL*' ]
    for b in controller.Bases:
      basenames.append( b.Name )
    toolnames = [ '*NULL*' ]
    for t in controller.Tools:
      toolnames.append( t.Name )
    dummyStatement = routine.addStatement(VC_STATEMENT_PTPMOTION)
    robotconfigs = ['Config1', 'Config2', 'Config3', 'Config4', 'Config5', 'Config6', 'Config7', 'Config8']
    for prop in dummyStatement.Positions[0].Properties:
      if prop.Name == 'Configuration':
        robotconfigs = prop.StepValues
        break
    routine.deleteStatement( dummyStatement )
    return (executor,routine,controller,basename,toolname,basenames,toolnames,robotconfig,robotconfigs)
  else:
    print "Current selection is not valid - Select a Robot Component (or pass it as an argument)" 
    return None
    

def getConfigNames(executor, controller):
    robotconfigs = []
    routine = executor.Program.MainRoutine
    controller.clearTargets()
    motiontarget = controller.createTarget()
    robotconfig = motiontarget.RobotConfig
    motiontarget.TargetMode = VC_MOTIONTARGET_TM_NORMAL
    dummyStatement = routine.addStatement(VC_STATEMENT_PTPMOTION)
    for prop in dummyStatement.Positions[0].Properties:
      if prop.Name == 'Configuration':
        break
      else:
        prop = None
    if prop == None:
      robotconfigs = ['Config1', 'Config2', 'Config3', 'Config4', 'Config5', 'Config6', 'Config7', 'Config8']
    else:
      for config in prop.StepValues:
        robotconfigs.append( config )
    controller.clearTargets()
    routine.deleteStatement( dummyStatement )
    return robotconfigs
