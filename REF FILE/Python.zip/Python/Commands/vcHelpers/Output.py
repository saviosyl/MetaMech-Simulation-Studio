###########################################################
## Print output helpers
## version 1.0
###########################################################
## USAGE:
#  import to a vcPythonScript, vcProcessHandler, or vcCommand script with: from vcHelpers.Output import *
#  Instead of print, use info, warning, error or debug function calls. Positional arguments are supported like with print call.
#  To print simulation time (as a prefix), set 'simtime' key argument to true e.g. warning('my warning message', simtime=True)
#  To toggle message type on/off, call setInfo, setWarnings, setErrors, setDebug functions with bool argument.
#  All message types are enabled by default.
#  To bind a property as a toggle, call bindInfoProperty, bindErrorProperty, bindWarningProperty, bindDebugProperty with the name of the property or the property instance as the argument.
#  OnChanged event handler for the given property is not overridden. It can be used for other purposes normally.
#  Only one binding per message type is allowed at a time. New binding will override any existing binding.
###########################################################

_INFO = 0
_WARNING = 1
_DEBUG = 2
_ERROR = 3

INFO_ON = True
WARNINGS_ON = True
DEBUG_ON = True
ERRORS_ON = True

_bound_props = {}

try:
  from vcCommand import *
  _context_type = 'command'
except:
  try:
    from vcScript import *
    _context_type = 'component'
  except:
    try:
      from vcPythonProcessHandler import *
      _context_type = 'process'
    except:
      print "Error: vcHelpers.Output failed to import dependencies"

_sim = getSimulation()
if _context_type == 'command':
  _context = getCommand()
else:
  _context = getComponent()

def info(*args, **kwargs):
  if not INFO_ON:
    return
  args = ('INFO]:',) + args
  _msg(*args, **kwargs)

def warning(*args, **kwargs):
  if not WARNINGS_ON:
    return
  args = ('WARNING]:',) + args
  _msg(*args, **kwargs)

def error(*args, **kwargs):
  if not ERRORS_ON:
    return
  args = ('ERROR]:',) + args
  _msg(*args, **kwargs)

def debug(*args, **kwargs):
  if not DEBUG_ON:
    return
  args = ('DEBUG]:',) + args
  _msg(*args, **kwargs)

def _msg(*args, **kwargs):
  simtime = kwargs.get('simtime')
  if simtime:
    prefix = '({}) [{} -'.format(_sim.SimTime, _context.Name)
  else:
    prefix = '[{} -'.format(_context.Name)
  print prefix, ' '.join((str(x) for x in args))

def setInfo(val):
  # type: (bool) -> None
  global INFO_ON
  INFO_ON = val

def setWarnings(val):
  # type: (bool) -> None
  global WARNINGS_ON
  WARNINGS_ON = val

def setErrors(val):
  # type: (bool) -> None
  global ERRORS_ON
  ERRORS_ON = val

def setDebug(val):
  # type: (bool) -> None
  global DEBUG_ON
  DEBUG_ON = val

def bindInfoProperty(prop_or_name):
  # type: (vcProperty or str) -> bool
  return _bind_property(prop_or_name, _INFO)

def bindErrorProperty(prop_or_name):
  # type: (vcProperty or str) -> bool
  return _bind_property(prop_or_name, _ERROR)

def bindWarningProperty(prop_or_name):
  # type: (vcProperty or str) -> bool
  return _bind_property(prop_or_name, _WARNING)
  
def bindDebugProperty(prop_or_name):
  # type: (vcProperty or str) -> bool
  return _bind_property(prop_or_name, _DEBUG)

def _bind_property(prop_or_name, output_type):
  # type: (..., int) -> bool
  # overrides existing binding
  global _bound_props
  prop = _validate_property(prop_or_name)
  if not prop:
    return False
  _bound_props[output_type] = prop
  handler = _bind_event_handler(output_type)
  handler(prop) # set initial value
  prop.OnChanged = handler
  return True

def _validate_property(prop_or_name):
  # type: (...) -> vcProperty
  # (vcProperty or str) -> Optional[vcProperty]
  if type(prop_or_name) is str:
    prop = _context.getProperty(prop_or_name)
    if not prop:
      print '[vcHelpers.Output - ERROR]: Could not find property "{}" in "{}"'.format(prop_or_name, _context.Name)
      return None
  elif type(prop_or_name).__name__ == 'vcProperty':
    prop = _context.getProperty(prop_or_name.Name) # get a new copy
  else:
    print '[vcHelpers.Output - ERROR]: Binding error - Invalid argument for property'
    return None
  return prop

def _bind_event_handler(output_type):
  # type: (int) -> function
  def on_changed(prop):
    val = bool(prop.Value)
    if output_type == _INFO:
      setInfo(val)
    elif output_type == _WARNING:
      setWarnings(val)
    elif output_type == _ERROR:
      setErrors(val)
    elif output_type == _DEBUG:
      setDebug(val)
  return on_changed


