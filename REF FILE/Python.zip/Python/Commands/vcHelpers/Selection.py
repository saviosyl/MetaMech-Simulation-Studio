try:
  from vcCommand import *
except:
  try:
    from vcScript import *
  except:
    print "Error: vcHelpers.Selection was unable to import vcCommand and vcScript"

app = getApplication()
sim = getSimulation()

################################################
# functions returning list of Components
################################################

def getAllComponents(): #OK
  return app.Components

def getSelectedComponents(): #OK
  return app.SelectionManager.getSelection(VC_SELECTION_COMPONENT)

 ################################################
# functions returning list of Nodes
################################################

def getAllComponentsNodes(): #OK
  nodes = []
  for component in (c for c in app.Components if c.Parent == sim.World):
    nodes.extend(getGivenComponentsNodes(component))
  return nodes

def getSelectedComponentsNodes():  #OK
  nodes = []
  for component in getSelectedComponents():
    nodes.extend(traverseNodeChildren(component))
  return nodes

def getGivenComponentsNodes(component, includeChildComponents=True): #OK
  return traverseNodeChildren(component, None if includeChildComponents else component)

def getSelectedNodes(): #OK
  return app.SelectionManager.getSelection(VC_SELECTION_NODE)

################################################
# functions returning list of Features
################################################

def getAllComponentsFeatures(): #OK
  features = []
  for node in getAllComponentsNodes():
    features.extend(getGivenNodesFeatures(node))
  return features

def getSelectedComponentsFeatures(): #OK
  features = []
  for node in getSelectedComponentsNodes():
    features.extend(getGivenNodesFeatures(node))
  return features

def getGivenComponentsFeatures(component, limit=False): #OK
  features = []
  for node in getGivenComponentsNodes(component):
    if limit and component != node.Component:
      continue
    features.extend(getGivenNodesFeatures(node))
  return features

def getSelectedNodesFeatures(): #OK
  features = []
  for node in getSelectedNodes():
    features.extend(getGivenNodesFeatures(node))
  return features

def getGivenNodesFeatures(node): #OK
  return traverseFeatureChildren(node.RootFeature)

def getSelectedFeatures(): #OK
  return app.SelectionManager.getSelection(VC_SELECTION_FEATURE)

################################################
# functions returning list of Geometry sets
################################################

def getAllComponentsGeosets(fromFeatureTree=False): #OK
  geosets =[]
  for component in getAllComponents():
    geosets.extend(getGivenComponentsGeosets(component, fromFeatureTree))
  return geosets

def getSelectedComponentsGeosets(fromFeatureTree=False): #OK
  geosets =[]
  for component in getSelectedComponents():
    geosets.extend(getGivenComponentsGeosets(component, fromFeatureTree))
  return geosets

def getGivenComponentsGeosets(component, fromFeatureTree=False): #OK
  geosets =[]
  for node in getGivenComponentsNodes(component):
    geosets.extend(getGivenNodesGeosets(node, fromFeatureTree))
  return geosets

def getSelectedNodesGeosets(fromFeatureTree=False): #OK
  geosets =[]
  for node in getSelectedNodes():
    geosets.extend(getGivenNodesGeosets(node, fromFeatureTree))
  return geosets

def getGivenNodesGeosets(node, fromFeatureTree=False): #OK
  if fromFeatureTree:
    sets = []
    gfeats = filterFeatures(getGivenNodesFeatures(node), VC_GEOMETRY)
    for gfeat in gfeats:
      sets.extend(gfeat.Geometry.GeometrySets)
    return sets
  else:
    return node.Geometry.GeometrySets

def getSelectedFeaturesGeosets(): #OK
  geosets = []
  for feature in getSelectedFeatures():
    geosets.extend(getGivenFeaturesGeosets(feature))
  return geosets

def getGivenFeaturesGeosets(feature): #OK
  geosets = []
  if feature and feature.Type == VC_GEOMETRY:
    geosets.extend(feature.Geometry.GeometrySets)
  return geosets

def getSelectedGeosets(): #OK
  print 'getSelectedGeosets is not available anymore'
  return []
  #return app.getSelection(VC_SELECTION_GEOMETRYSET).Objects

################################################
# functions returning list of Behaviours
################################################

def getAllComponentsBehaviours(): #OK
  behaviours = []
  for node in getAllComponentsNodes():
    behaviours.extend(getGivenNodesBehaviours(node))
  return behaviours

def getSelectedComponentsBehaviours(): #OK
  behaviours = []
  for node in getSelectedComponentsNodes():
    behaviours.extend(getGivenNodesBehaviours(node))
  return behaviours

def getGivenComponentsBehaviours(component):  #OK
  behaviours = []
  for node in getGivenComponentsNodes(component):
    behaviours.extend(getGivenNodesBehaviours(node))
  return behaviours

def getSelectedNodesBehaviours():  #OK
  behaviours = []
  for node in getSelectedNodes():
    behaviours.extend(getGivenNodesBehaviours(node))
  return behaviours

def getGivenNodesBehaviours(node):  #OK
  return node.Behaviours

################################################
# functions to filter lists
################################################

def filterFeatures(features,filter): #OK
  objects = []
  for feature in features:
    if feature.Type == filter:
      objects.append(feature)
  return objects

def filterBehaviours(behaviours,filter): #OK
  objects = []
  for behaviour in behaviours:
    if behaviour.Type == filter:
      objects.append(behaviour)
  return objects

def filterGeosets(geosets,filter): #OK
  objects = []
  for gs in geosets:
    if gs and gs.Type == filter:
      objects.append(gs)
  return objects

############################################
# functions returning flat lists of Trees
############################################

def traverseNodeChildren(node, component=None): #OK
  nodes = []
  nodes.append(node)
  for child in (n for n in node.Children if not component or component and n.Component == component):
    nodes.extend(traverseNodeChildren(child, component))
  return nodes

def traverseFeatureChildren(feature):
  features = []
  features.append(feature)
  for child in feature.Children:
    features.extend(traverseFeatureChildren(child))
  return features

############################################
# other selection related helpers
############################################

def getCurrentSelectionType():
  #return app.CurrentSelection.Type
  ## loop fix for missing current selection in NG
  for sel_type in [VC_SELECTION_COMPONENT, VC_SELECTION_NODE, VC_SELECTION_FEATURE, VC_SELECTION_GEOMETRYSET]:
    if app.SelectionManager.getSelection(sel_type):
      return sel_type

def setCurrentSelectionType(type):
  pass
  #app.CurrentSelection = app.getSelection(type)

def getSelectedNodeGeosetMap():
  # collects all geosets and their nodes into a map
  # also collects geosets into a list
  # this is useful with commands, that manipulate geoset selection
  currentselectiontype = getCurrentSelectionType()
  nodemap = {}
  geosetmap = {}
  allgeosets = []
  if currentselectiontype == VC_SELECTION_COMPONENT:
    nodes = getSelectedComponentsNodes()
    for node in nodes:
      nodename = node.Component.Name+'::'+node.Name
      nodemap[nodename] = node
      sets = getGivenNodesGeosets(node)
      geosetmap[nodename] = sets
      allgeosets.extend(sets)
  elif currentselectiontype == VC_SELECTION_NODE:
    nodes = getSelectedNodes()
    for node in nodes:
      nodename = node.Component.Name+'::'+node.Name
      nodemap[nodename] = node
      sets = getGivenNodesGeosets(node)
      geosetmap[nodename] = sets
      allgeosets.extend(sets)
  elif currentselectiontype == VC_SELECTION_FEATURE:
    nodes = [getSelectedNodes()[0]]
    for node in nodes:
      nodename = node.Component.Name+'::'+node.Name
      nodemap[nodename] = node
      sets = getSelectedFeaturesGeosets()
      geosetmap[nodename] = sets
      allgeosets.extend(sets)
  elif currentselectiontype == VC_SELECTION_GEOMETRYSET:
    nodes = [getSelectedNodes()[0]]
    for node in nodes:
      nodename = node.Component.Name+'::'+node.Name
      nodemap[nodename] = node
      sets = getSelectedGeosets()
      geosetmap[nodename] = sets
      allgeosets.extend(sets)
  #endif
  return(nodemap,geosetmap,allgeosets)

def rebuildSelectedGeosetNodes():
  currentselectiontype = getCurrentSelectionType()
  if currentselectiontype == VC_SELECTION_COMPONENT:
    for component in getSelectedComponents():
      component.rebuild()
  elif currentselectiontype == VC_SELECTION_NODE:
    for node in getSelectedNodes():
      node.rebuild()
  elif currentselectiontype == VC_SELECTION_FEATURE:
    feas = app.SelectionManager.getSelection(VC_SELECTION_FEATURE)
    for fea in feas:
      fea.rebuild()



############################################
# NAMING CONVENTION USED
############################################
'''
from vcScript import *

returntypes = ['Component','Node','Feature','Geoset','Behaviour']
types = ['Component','Node','Feature','Geoset']
scopes = ['All','Selected','Given']

for r in returntypes:
  for t in types:
    for s in scopes:
      print 'get%s%ss%ss' % (s,t,r)
'''

############################################
# NEW PROGRAM ROUTINE AND STATEMENT RELATED HELPERS
############################################

def filterTypes(items,itypes):
  return [x for x in items if x.Type in itypes]

def getGivenComponentsPrograms(component):
  return [x.Program for x in component.findBehavioursByType(VC_ROBOTEXECUTOR)]

def getAllComponentsPrograms():
  programs = []
  for component in getAllComponents():
    programs.extend(getGivenComponentsPrograms(component))
  return programs

def getSelectedComponentsPrograms():
  programs = []
  for component in getSelectedComponents():
    programs.extend(getGivenComponentsPrograms(component))
  return programs

def getGivenProgramsRoutines(program):
  if not program:
    return []
  routines = [program.MainRoutine]
  routines.extend(program.Routines)
  return routines

def getSelectedStatements():
  return app.SelectionManager.getSelection(VC_SELECTION_STATEMENT)

def getSelectedRoutine():
  return app.TeachContext.ActiveRoutine

def getSelectedProgram():
  if app.TeachContext.ActiveRoutine:
    return app.TeachContext.ActiveRoutine.Program
  else:
    return None

def getSelectedProgramsRoutines():
  return getGivenProgramsRoutines(getSelectedProgram())

def extendStatements(statement,statements):
  statements.append(statement)
  if statement.Type == VC_STATEMENT_WHILE:
    for s in statement.Scope.Statements:
      statements = extendStatements(s,statements)
  elif statement.Type == VC_STATEMENT_IF:
    for s in statement.ThenScope.Statements:
      statements = extendStatements(s,statements)
    for s in statement.ElseScope.Statements:
      statements = extendStatements(s,statements)
  elif statement.Type == VC_STATEMENT_SWITCHCASE:
    for scope in statement.Cases:
      for s in scope.Statements:
        statements = extendStatements(s,statements)
  return statements

def getGivenRoutinesStatements(routine):
  statements = []
  if not routine:
    return statements
  for statement in routine.Statements:
    statements = extendStatements(statement,statements)
  return statements

def getSelectedRoutinesStatements():
  return getGivenRoutinesStatements(getSelectedRoutine())

def getGivenProgramsStatements(program):
  statements = []
  if not program:
    return statements
  for routine in getGivenProgramsRoutines(program):
    statements.extend(getGivenRoutinesStatements(routine))
  return statements

def getSelectedProgramsStatements():
  return getGivenProgramsStatements(getSelectedProgram())

def getGivenComponentsStatements(component):
  statements = []
  for program in getGivenComponentsPrograms(component):
    statements.extend(getGivenProgramsStatements(program))
  return statements

def getSelectedComponentsStatements():
  statements = []
  for component in getSelectedComponents():
    statements.extend(getGivenComponentsStatements(component))
  return statements

def getAllProgramsStatements():
  statements = []
  for program in getAllComponentsPrograms():
    statements.extend(getGivenProgramsStatements(program))
  return statements

def getAllComponentsStatements():
  return getAllProgramsStatements()



