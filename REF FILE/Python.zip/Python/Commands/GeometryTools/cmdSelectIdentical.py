from vcApplication import *
from vcCommand import *
from vcHelpers.Selection import *
from vcHelpers.Application import *
import vcMatrix 

app = getApplication()
cmd = getCommand()

# Variables
selectionLevel = addStepProperty( cmd, VC_STRING, 'SelectionLevel', True, False, False, 'Feature', None, '',  ["Feature", "GeoSet"])
findIdentical = createProperty(VC_BUTTON, 'Find')

# Note: typically executed from ribbon in Modeling tab
def OnExecute():
  cmd.SelectionLevel = 'Feature'
  onSelectionTypeChanged(None)
  executeInActionPanel()

def onSelectionTypeChanged( prop ):
  if cmd.SelectionLevel == 'GeoSet':
    if not app.SelectionManager.getSelection(VC_SELECTION_GEOMETRYSET):
      app.SelectionManager.clear()
    app.SelectionManager.setGeometrySelectEnabled(1)
  else:
    if not app.SelectionManager.getSelection(VC_SELECTION_FEATURE):
      app.SelectionManager.clear()
    app.SelectionManager.setGeometrySelectEnabled(0)

def onFind(args):
  geometries = app.SelectionManager.getSelection(VC_SELECTION_GEOMETRYSET)
  nodes = app.SelectionManager.getSelection(VC_SELECTION_NODE)
  parentnodes = app.SelectionManager.getSelection(VC_SELECTION_PARENTNODE)
  features = app.SelectionManager.getSelection(VC_SELECTION_FEATURE)
  
  if features and parentnodes:
    finalFeatures = findIdenticalFeatures(features, parentnodes)
    
    print "Found {0} identical features".format(len(finalFeatures))
    
    if finalFeatures:
      app.SelectionManager.clear()
      app.SelectionManager.setSelection(finalFeatures)

  elif geometries and parentnodes:
    finalGeometries = findIdenticalGeosets(geometries)
    
    print "Found {0} identical geometries".format(len(finalGeometries))
    
    if finalGeometries:
      app.SelectionManager.clear()
      app.SelectionManager.setSelection(finalGeometries)

  else:
    print "Please select feature or geometry."

# note: duplicate function in cmdSelectIdenticalOneShot.py
def findIdenticalFeatures(features, parentnodes):  
    selectedNodeAllFeatures = getGivenNodesFeatures(parentnodes[0])
    finalFeatures = []
    for feature1 in features:
      if feature1.Type != VC_GEOMETRY:
        print "Skipped {0} {1} feature because it is not a {2} feature"\
            .format(feature1.Name, feature1.Type, VC_GEOMETRY)
        continue
      finalFeatures.append(feature1)
      for feature2 in selectedNodeAllFeatures:
        if feature2 in features:
          continue
        else:
          if feature2 in finalFeatures : continue
          if feature2.Type != VC_GEOMETRY: continue
          if feature2.Geometry.GeometrySetCount != feature1.Geometry.GeometrySetCount: continue
        
          allok = True
          for i in range(feature1.Geometry.GeometrySetCount):
              geoset1 = feature1.Geometry.GeometrySets[i]
              geoset2 = feature2.Geometry.GeometrySets[i]
          
              if geoset1.Type == VC_TRIANGLESET: 
                  if geoset1.Type != geoset2.Type: allok = False; break
                  if geoset1.Material != geoset2.Material: allok = False; break
                  if geoset1.PointCount != geoset2.PointCount: allok = False; break
                  if geoset1.TriangleCount != geoset2.TriangleCount: allok = False; break
                  if geoset1.TriangleTable != geoset2.TriangleTable: allok = False; break
                  # Todo: this doesnt work
                  #if geoset1.PositionTable != geoset2.PositionTable: allok = False; break

          if allok:
              finalFeatures.append(feature2)   
    
    return finalFeatures
  


def findIdenticalGeosets( setsToCheck ):
  
  finalGeometries = [] 
  for gs in setsToCheck:
  
    if gs.Type != VC_TRIANGLESET: continue

    finalGeometries.append(gs)
    
    i1,i2,i3 = gs.getTriangle(0)
    p1 = gs.getPoint(i1)
    p2 = gs.getPoint(i2)
    p3 = gs.getPoint(i3)
    xx = p2-p1
    yy = p3-p2
    xx.normalize()
    yy.normalize()
    zz = xx ^ yy
    zz.normalize()
    yy = zz ^ xx
    yy.normalize()
    invM1 = vcMatrix.new()
    invM1.N = xx
    invM1.O = yy
    invM1.A = zz
    invM1.P = p1
    invM1.invert()
    
    for testgs in gs.Container.GeometrySets:
      if testgs in finalGeometries: continue
      if testgs.Type != VC_TRIANGLESET: continue
      #if gs.Material != testgs.Material: continue 
      if gs.PointCount != testgs.PointCount: continue
      if gs.TriangleCount != testgs.TriangleCount: continue
      if gs.TriangleTable != testgs.TriangleTable: continue
      
      i1,i2,i3 = testgs.getTriangle(0)
      p1 = testgs.getPoint(i1)
      p2 = testgs.getPoint(i2)
      p3 = testgs.getPoint(i3)
      xx = p2-p1
      yy = p3-p2
      xx.normalize()
      yy.normalize()
      zz = xx ^ yy
      zz.normalize()
      yy = zz ^ xx
      yy.normalize()
      invM2 = vcMatrix.new()
      invM2.N = xx
      invM2.O = yy
      invM2.A = zz
      invM2.P = p1
      invM2.invert()
      for i in range(gs.PointCount):
        p1 = invM1*gs.getPoint(i)
        p2 = invM2*testgs.getPoint(i)
        if (p2-p1).length() > 0.001:
          break
        #endif
      else:
        finalGeometries.append(testgs)
      #endfor
    #endfor 
  #endfor

  return finalGeometries

selectionLevel.OnChanged = onSelectionTypeChanged
findIdentical.OnChanged = onFind
addState(OnExecute)
