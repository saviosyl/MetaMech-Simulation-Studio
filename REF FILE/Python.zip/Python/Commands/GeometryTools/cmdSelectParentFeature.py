from vcCommand import *

def OnStart():
  app = getApplication()
  sm = app.SelectionManager
  feas = sm.getSelection(VC_SELECTION_FEATURE)
  if not feas:
    return
  common_anch = None
  all_chains = []
  for f in feas:
    p = f.Parent
    if not p:
      return
    parent_chain = [p]
    while p.Type != 'Root':
      p = p.Parent
      parent_chain.append(p)
    all_chains.append(parent_chain)
  all_chains.sort(key = lambda x: len(x))
  if not all_chains:
    # bad selection
    return
  elif len(all_chains) == 1:
    # single feature selection => get closest parent
    common_anch = all_chains[0][0]
  else:
    # multi feature selection => find closest common anchestor
    for p in all_chains.pop(0):
      if all([p in x for x in all_chains]):
        common_anch = p
        break
  if common_anch:
    sm.setSelection(common_anch)


addState(None)






