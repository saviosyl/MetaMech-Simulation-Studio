from vcCommand import *
from vcHelpers.Selection import *
from vcHelpers.Application import *
import math
import bisect
import time

# Note: reading settings from another command, that might have been executed before or not.
cmd = app.findCommand('cmdRemoveHoles')
app = getApplication()
components = []
features = []
parentnode = []
nodes = []
geometries = []

# Note: typically executed from r-click menu in features tree
def OnExecute( ):

  nodes = app.SelectionManager.getSelection(VC_SELECTION_NODE)
  parentnode = app.SelectionManager.getSelection(VC_SELECTION_PARENTNODE)
  components = app.SelectionManager.getSelection(VC_SELECTION_COMPONENT)
  features = app.SelectionManager.getSelection(VC_SELECTION_FEATURE)
  geometries = app.SelectionManager.getSelection(VC_SELECTION_GEOMETRYSET)
  
  if components:
    for c in components:
      removeHoles( c, getGivenComponentsFeatures( c ) )
  elif features and parentnode:
    removeHoles( parentnode[0], features )
  elif nodes:
    for n in nodes:
      removeHoles( n, getGivenNodesFeatures( n ) )
  elif geometries and parentnode:
    removeHoles( parentnode[0], getGivenComponentsFeatures( parentnode[0] ), geometries )
  else:
    print "Please select components, features, or geometries."

  app.render();

# Todo: remove duplicate function in cmdRemoveHolesExecute.py
def removeHoles( node, featureList, geosetList = [] ):

  totalTriangles = 0
  totalNewTriangles = 0
  totalHolesRemoved = 0

  planarityTolerance = cmd.PlanarityTolerance
  mergePointsTolerance = cmd.MergePointsTolerance
  colinearTolerance = math.cos(math.radians(cmd.ColinearTolerance))
  minCircumference = math.pi*cmd.MinHoleDiameter
  minPerimeter = cmd.MinHolePerimeter
  minRadius = cmd.MinHoleDiameter/2.0
  minPointCount = cmd.MinHolePointCount
  removeCircularHolesOnly = cmd.RemoveCircularHolesOnly

  geosetListCopy = geosetList[:]
  if components or nodes:
    startMessage( 'Removing holes from %s' % node.Name )
  else:
    startMessage( 'Removing holes' )
  #endif

  progress = 0
  progressTriangles = 0
  for f in featureList: # this loop is only to get a pre-estimate of triangle count for progess message
    if f.Type == VC_GEOMETRY and f.ShowContent:
      for gs in f.Geometry.GeometrySets:
        if gs.Type != VC_TRIANGLESET: continue
        if geometries and gs not in geosetListCopy: continue
        progressTriangles += gs.TriangleCount
      #endfor
    #endif
  #endfor

  for f in featureList:
    progressStdMessage( float(totalTriangles), float(progressTriangles) )

    if f.Type == VC_GEOMETRY and f.ShowContent:
      
      if cmd.DebugMessages: print 'Remove Holes:%s::%s: Processing...' % (node.Name, f.Name)

      if len(geometries) == 0 and cmd.MergeByMaterial:
        if cmd.DebugMessages: print 'Remove Holes: Merging GeoSets by Material and decomposing .' 
        mergeTriSetsWithSameMaterial(f)
        if cmd.DebugMessages: print 'Remove Holes: GeoSet Material Merge complete, Decomposing...' 
        for gs in f.Geometry.GeometrySets:
          if gs.Type == VC_TRIANGLESET: gs.decompose()
        if cmd.DebugMessages: print 'Remove Holes: GeoSet Decomposition complete...' 
      #endif

      newFeature = f.Parent.createFeature( VC_GEOMETRY, f.Name )
      
      holesRemoved = 0
      originalTriangleCount = 0
      newTriangleCount = 0
      for gs in f.Geometry.GeometrySets:

        if gs.Type != VC_TRIANGLESET: continue
        if geometries and gs not in geosetListCopy: continue
        if gs in geosetListCopy: geosetListCopy.remove( gs )

        originalTriangleCount += gs.TriangleCount
        
        if cmd.DebugMessages: print 'Remove Holes: Merging Points...' 

        gs.mergePoints( mergePointsTolerance )
        gs.update()
        if not gs.PointCount or not gs.TriangleCount:
          f.Geometry.deleteGeometrySet(gs)
          continue
        #endif

        progress += gs.TriangleCount/10
        progressStdMessage( float(progress), float(progressTriangles) )
        
        if cmd.DebugMessages: print 'Remove Holes: Creating Topology...' 

        t0 = time.clock()

        points = []
        edges = []
        edgeTriangles = []
        pointTriangles = []
        triangles = []
        for t in range(gs.TriangleCount):
          i1, i2, i3 = gs.getTriangle(t)
          n = gs.getTriangleNormal(t)
          #n.W = -(n*gs.getPoint(i1))
          indices = [i1,i2,i3]
          vertices = []
          for i in indices:
            p = gs.getPoint(i)
            try:
              v = points.index(p)
              ##pt = pointTriangles[v]
              ##pt.append(t)
              ##pointTriangles[v] = pt
              pointTriangles[v].append(t)
            except:
              points.append(p)
              v = len(points)-1
              pointTriangles.append([t])
            vertices.append(v)
          #endfor i
          triangles.append( (vertices, n) )

          v1 = vertices[0]
          for i in range(3):
            v2 = vertices[(i+1)%3]
            try:
              e = edges.index( (v2,v1) )
              t1, t2 = edgeTriangles[e]
              tv1, n1 = triangles[t1]
              if n1*n > colinearTolerance:
                edgeTriangles[e] = (t1, t)
              else:
                edges.append( (v1,v2) )
                edgeTriangles.append((t,-1))
            except:
              edges.append( (v1,v2) )
              edgeTriangles.append((t,-1))
            #endtry
            v1 = v2
          #endfor i
        #endfor t

        progress += 3*gs.TriangleCount/10 # 2/5
        progressStdMessage( float(progress), float(progressTriangles) )
        if cmd.DebugMessages: 
          t1 = time.clock()
          print 'Copy Triangles %g sec' % (t1-t0)
          t0 = t1
        #endif

        faces = []
        tlist = range( len(triangles) )
        while tlist:
          t = tlist.pop()
          seeds = [t]
          face = [t]
          for t1 in seeds:
            v1, n1 = triangles[t1]
            for v in v1:
              for t2 in pointTriangles[v] :
                if t1 == t2: continue
                if t2 in face: continue
                v2, n2 = triangles[t2]
                if n1*n2 > colinearTolerance:
                  seeds.append(t2)
                  tlist.remove(t2)
                  face.append(t2)
                #endif
              #endfor t2
            #endfor v
          #endfor t1
          faces.append(face)
        #endfor t

        progress += gs.TriangleCount/5 # 3/5
        progressStdMessage( float(progress), float(progressTriangles) )
        if cmd.DebugMessages: 
          t1 = time.clock()
          print 'Build faces %g sec' % (t1-t0)
          t0 = t1
        #endif

        faceCurves = []
        faceCurveLengths = []
        for face in faces:
          boundary = []
          for i, et in enumerate(edgeTriangles):
            t1, t2 = et
            if t2 == -1 and t1 in face:
              boundary.append(edges[i])
            #endif
          #endfor

          curves = []
          while boundary:
            v1, v2 = boundary.pop()
            c = [v1]
            i = 0
            while i < len(boundary):
              p1, p2 = boundary[i]
              if v2 == p1:
                c.append(p1)
                v2 = p2
                boundary.pop(i)
                i = 0
              elif v1 == p2:
                c.insert(0,p1)
                v1 = p1
                boundary.pop(i)
                i = 0
              else:
                i += 1
              #endif
            #endwhile
            curves.append(c)
          #endwhile

          curveLengths = []
          if len(curves) > 1:
            maxClen = 0.0
            for c in curves:
              npts = len(c)
              clen = 0.0
              for i in range(npts):
                v = points[c[(i+1)%npts]] - points[c[i]]
                clen += v.length()
              #endfor
              curveLengths.append(clen)
              if clen > maxClen:
                maxClen = clen
                maxC = c
              #endif
            #endfor c
            i = curves.index(maxC)
            if i > 0:
              curves.pop(i)
              curves.insert(0,maxC)
              curveLengths.pop(i)
              curveLengths.insert(0,maxClen)
            #endif
          #endif
          faceCurves.append(curves)
          faceCurveLengths.append(curveLengths)
        #endfor face

        progress += gs.TriangleCount/5 #4/5
        progressStdMessage( float(progress), float(progressTriangles) )
        if cmd.DebugMessages: 
          t1 = time.clock()
          print 'Build faces curves %g sec' % (t1-t0)
          t0 = t1
        #endif

        if cmd.DebugMessages: print 'Remove Holes: Processing Faces...' 

        polygon = []
        newGS = newFeature.Geometry.createGeometrySet( VC_TRIANGLESET )
        newGS.Material = gs.Material
        for iface in range(len(faces)):
          
          vertices = []
          outerCurve = faceCurves[iface][0]
          for p in outerCurve: vertices.append(points[p]) 
          vertexCount = len(vertices)

          if vertexCount < 3: continue

          for innerCurve in range(1,len(faceCurves[iface])):
            if faceCurveLengths[iface][innerCurve] > minPerimeter:
              saveFace = True
              break
            #endif 
            if removeCircularHolesOnly:
              if faceCurveLengths[iface][innerCurve] > minCircumference:
                saveFace = True
                break
              #endif 
              circle = []
              for p in faceCurves[iface][innerCurve]: circle.append(points[p]) 
              if not calcCircle( circle, minPointCount, minRadius ):
                saveFace = True
                break
              #endif 
            #endif 
          else:
            saveFace = False

            p0 = vertices[-2]
            p1 = vertices[-1]
            v1 = p1 - p0
            v1.normalize()
            polyline = []
            for p2 in vertices:
              v2 = p2 - p1
              v2.normalize()
              dot = v1*v2
              if v2.length() > 0.0001 and dot < colinearTolerance: polyline.append(p1)
              v1 = v2
              p1 = p2
            #endfor p2
          #endfor

          if saveFace or (len(faceCurves[iface]) == 1 and vertexCount == len(polyline)):
            for t in faces[iface]:
              v, n = triangles[t]
              polygon.append(3)
              for i in v:
                polygon.append(newGS.addPoint(points[i]))
            #endfor t

          elif len(polyline) == 4:
            polygon.append(3)
            p1 = newGS.addPoint( polyline[0] )
            p2 = newGS.addPoint( polyline[1] )
            p3 = newGS.addPoint( polyline[2] )
            p4 = newGS.addPoint( polyline[3] )
            polygon.append(p1)
            polygon.append(p2)
            polygon.append(p3)
            polygon.append(3)
            polygon.append(p3)
            polygon.append(p4)
            polygon.append(p1)

          elif len(polyline) > 2:
            polygon.append(len(polyline))
            for p in polyline:
              polygon.append(newGS.addPoint( p ))
            #endfor p
          #endif
        #endfor iface
        newGS.PolygonTable = polygon
        newGS.update()
        newGS.mergePoints( mergePointsTolerance )
        newGS.update()

        if not newGS.PointCount or not newGS.TriangleCount:
          newFeature.Geometry.deleteGeometrySet(newGS)
        else:
          newGS.decompose()
        #endif

        progress += gs.TriangleCount/5 # 5/5

        f.Geometry.deleteGeometrySet(gs)

        progressStdMessage( float(progress), float(progressTriangles) )
      #endfor gs
      
      for gs in newFeature.Geometry.GeometrySets:
        planarity = 0
        points = []
        edges = []
        for t in xrange(gs.TriangleCount): 
          i1,i2,i3 = gs.getTriangle(t)
          n = gs.getTriangleNormal(t)
          nd = -(n*gs.getPoint(i1))
          for p in range(gs.PointCount):
            residue = n * gs.getPoint(p) + nd
            if residue < -planarityTolerance: # convex
              planarity = -1
              break
            elif residue > planarityTolerance: # concave
              planarity = 1
            #endif
          #endfor
          if planarity < 0: break
          
          triPointIndices = [i1,i2,i3]
          for e in xrange(3): # check if open volume (look for unconnected edges)
            if gs.getTriangleEdgeType( t, e ) == 5:
              p1 = gs.getPoint(triPointIndices[e])
              p2 = gs.getPoint(triPointIndices[(e+1)%3])
              if p1 not in points: points.append(p1)
              if p2 not in points: points.append(p2)
              ev1 = points.index(p1)
              ev2 = points.index(p2) 
              edge = (ev2, ev1)
              if edge in edges: edges.remove(edge)
              else: edges.append( (ev1, ev2) )
            #endif
          #endif
        #endif

        if planarity > 0 and edges and gs.TriangleCount >= 2*minPointCount:
          # okay, if disjoint (unconnected edges) and curves in, then likely a hole, remove it.
          # need another test here to see if one face, with two contours -> cylinder
          if 2*gs.BoundDiagonal.X < 10*minRadius and 2*gs.BoundDiagonal.Y < 10*minRadius and 2*gs.BoundDiagonal.Z < 10*minRadius:
            newFeature.Geometry.deleteGeometrySet(gs)
            holesRemoved += 1
          #endif
        else:
          newTriangleCount += gs.TriangleCount
        #endif
      #endfor
      
      newFeature.Geometry.moveGeometrySets( f.Geometry )
      newFeature.delete()
      f.rebuild()
      
      print '%s::%s: %i holes removed, reduced %d to %d triangles' % (node.Name, f.Name, holesRemoved, originalTriangleCount, newTriangleCount)
      totalTriangles += originalTriangleCount
      totalNewTriangles += newTriangleCount
      totalHolesRemoved += holesRemoved
    #endif
  #endfor

  endMessage( 'Removing holes completed' )
  if components or nodes:
    print '- %s Total %i holes removed, reduced %d to %d triangles' % (node.Name, totalHolesRemoved, totalTriangles, totalNewTriangles)
    print '- %s %g%% data reduction' %(node.Name, (100*(totalTriangles-totalNewTriangles))/max(1,totalTriangles))
  else:
    print '- Total %i holes removed, reduced %d to %d triangles' % (totalHolesRemoved, totalTriangles, totalNewTriangles)
    print '- %g%% data reduction' %( (100*(totalTriangles-totalNewTriangles))/max(1,totalTriangles))
  #endif

def mergeTriSetsWithSameMaterial(geofeature):
  materialmap = {}
  
  # Collect materials 
  for gset in geofeature.Geometry.GeometrySets:
    if gset.Type != VC_TRIANGLESET: continue

    material = 'None'
    if gset.Material != None:
      material = gset.Material.Name
    #endif
    if not materialmap.has_key(material):
      entry = ([], [])
      materialmap[material] = entry
    else:
      entry = materialmap[material]
    #endif
    
    pc = gset.TriangleCount
    
    ix = bisect.bisect_right(entry[1], pc)
    
    entry[0].insert(ix, gset)    
    entry[1].insert(ix, pc)
  #endfor
  
  for material, gslist in materialmap.iteritems():
    geosets, sizes = gslist
    
    # Merge the two smallest geosets until there is only one left
    while len(geosets) > 1:
      # Pop the two smallest sets
      geoA, geoB = geosets[0:2]
      szA, szB = sizes[0:2]
      del geosets[0:2]
      del sizes[0:2]
      
      geoA.merge(geoB)

      # Reinsert the newly merged set
      szMerged = szA + szB
      geofeature.Geometry.deleteGeometrySet(geoB)
      
      ix = bisect.bisect_right(sizes, szMerged)
      sizes.insert(ix, szMerged)
      geosets.insert(ix, geoA)
      
  geofeature.Geometry.update()  

def calcCircle( points, pointCount, testRadius ):

  if len(points) < pointCount: return False

  p1 = points[0]
  p2 = points[1]
  p3 = points[2]

  V1 = p1 - p2
  V2 = p2 - p3
  V3 = p3 - p1

  N = V1 ^ V2
  if N.length() < 0.0001: return False

  radius = V1.length()*V2.length()*V3.length()/(2.0*N.length())

  if radius > testRadius: return False

  alpha = -1.0*(V2*V2)*(V1*V3)
  beta = -1.0*(V3*V3)*(V2*V1)
  gamma = -1.0*(V1*V1)*(V3*V2)

  cP = (alpha*p1 + beta*p2 + gamma*p3)*(1.0/(2.0*N*N))

  #okay test that points are on circle:
  for p in points[3:]:
    if abs((p-cP).length()-radius) > 0.5: return False
  #endfor

  return True



addState(OnExecute)