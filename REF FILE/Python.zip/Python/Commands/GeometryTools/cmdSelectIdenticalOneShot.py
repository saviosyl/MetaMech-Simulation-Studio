from vcApplication import *
from vcCommand import *
from vcHelpers.Selection import *
import vcMatrix 

app = getApplication()

# Note: typically executed from r-click menu in features tree.
def OnExecute():
  nodes = app.SelectionManager.getSelection(VC_SELECTION_NODE)
  parentnodes = app.SelectionManager.getSelection(VC_SELECTION_PARENTNODE)
  features = app.SelectionManager.getSelection(VC_SELECTION_FEATURE)

  if features and parentnodes:
    finalFeatures = findIdenticalFeatures(features, parentnodes)
    print "Found {0} identical features".format(len(finalFeatures))
    if finalFeatures:
      app.SelectionManager.clear()
      app.SelectionManager.setSelection(finalFeatures)
  else:
    print "Please select feature or geometry."

# Todo: remove duplicate function in cmdSelectIdentical.py
def findIdenticalFeatures(features, parentnodes):  
    selectedNodeAllFeatures = getGivenNodesFeatures(parentnodes[0])
    finalFeatures = []
    for feature1 in features:
      if feature1.Type != VC_GEOMETRY:
        print "Skipped {0} {1} feature because it is not a {2} feature"\
            .format(feature1.Name, feature1.Type, VC_GEOMETRY)
        continue
      finalFeatures.append(feature1)
      feature1SetCount = feature1.Geometry.GeometrySetCount
      for feature2 in selectedNodeAllFeatures:
        if feature2 in features:
          continue
        else:
          if feature2 in finalFeatures : continue
          if feature2.Type != VC_GEOMETRY: continue
          if feature2.Geometry.GeometrySetCount != feature1SetCount: continue
        
          allok = True
          for i in range(feature1SetCount):
              geoset1 = feature1.Geometry.GeometrySets[i]
              geoset2 = feature2.Geometry.GeometrySets[i]
              
              if geoset1.Type == VC_TRIANGLESET: 
                  if geoset1.Type != geoset2.Type: allok = False; break
                  if geoset1.Material != geoset2.Material: allok = False; break
                  if geoset1.PointCount != geoset2.PointCount: allok = False; break
                  if geoset1.TriangleCount != geoset2.TriangleCount: allok = False; break
                  if geoset1.TriangleTable != geoset2.TriangleTable: allok = False; break
                  # Todo: this doesnt work
                  #if geoset1.PositionTable != geoset2.PositionTable: allok = False; break

          if allok:
              finalFeatures.append(feature2)   
    
    return finalFeatures
  

addState(OnExecute)
