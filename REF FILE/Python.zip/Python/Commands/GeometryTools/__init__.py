from vcApplication import *

def OnStart():
  # Commands:
  loadCommand("cmdSelectIdentical", getApplicationPath() + 'cmdSelectIdentical.py')
  loadCommand("cmdSelectIdenticalOneShot", getApplicationPath() + 'cmdSelectIdenticalOneShot.py')
  loadCommand("cmdSelectParentFeature", getApplicationPath() + 'cmdSelectParentFeature.py')
  loadCommand("cmdRemoveHoles", getApplicationPath() + 'cmdRemoveHoles.py')
  loadCommand("cmdRemoveHolesExecute", getApplicationPath() + 'cmdRemoveHolesExecute.py')
  loadCommand("cmdRemoveHolesOneShot", getApplicationPath() + 'cmdRemoveHolesOneShot.py')
  loadCommand("cmdCreateConvexHull", getApplicationPath() + 'cmdCreateConvexHull.py')
  loadCommand("cmdCountTriangles", getApplicationPath() + 'cmdCountTriangles.py')

  
  # Modeling tab buttons:
  # Note: button's title can be overridden by localization, which is based on command's id (last argument).
  addMenuItem(VC_MENU_MODELING_TOOLGALLERY_FEATURE, "Select Identical", -1, 'cmdSelectIdentical')
  addMenuItem(VC_MENU_MODELING_TOOLGALLERY_FEATURE, "Remove Holes", -1, 'cmdRemoveHoles')
  # Modeling tab Geometry/Tools/Simplify
  addMenuItem('VcTabAuthor/VcRibbonGeometry/ToolGalleryItems/SimplifyTools', "Convert To ConvexHull", -1, 'cmdCreateConvexHull')
  addMenuItem('VcTabAuthor/VcRibbonGeometry/ToolGalleryItems/SimplifyTools' , "Count Triangles", -1, 'cmdCountTriangles')

  # Feature context menu items:
  addMenuItem(VC_MENU_FEATURE, "Select Identical", -1, 'cmdSelectIdenticalOneShot')
  addMenuItem(VC_MENU_FEATURE, "Select Parent", -1, 'cmdSelectParentFeature')
  addMenuItem(VC_MENU_FEATURE, "Remove Holes", -1, 'cmdRemoveHolesOneShot')
  addMenuItem(VC_MENU_FEATURE, "Convert To ConvexHull", 13, 'cmdCreateConvexHull')
  
  # 3d context menu items:
  addMenuItem('VcAuthor3DContextMenu/VcAuthor3DContextMenuTools', 'Remove Holes', -1, 'cmdRemoveHoles')
  addMenuItem('VcAuthor3DContextMenu/VcAuthor3DContextMenuTools', 'Select Identical', -1, 'cmdSelectIdentical')
  addMenuItem('VcAuthor3DContextMenu/VcAuthor3DContextMenuTools', 'Select Parent', -1, 'cmdSelectParentFeature')
  addMenuItem('VcAuthor3DContextMenu/VcAuthor3DContextMenuTools', "Convert To ConvexHull", 10, 'cmdCreateConvexHull')
  addMenuItem('VcAuthor3DContextMenu/VcAuthor3DContextMenuTools', "Count Triangles", -3, 'cmdCountTriangles')

