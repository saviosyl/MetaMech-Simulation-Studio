from vcCommand import *
from vcHelpers.Application import *


def convert_convex(tset):
  '''
  Creaating convexhull for the triangle sets
  '''
  tset.convexHull(False)

def filterTriangleSet(geoset, filter):
  '''
  Filter VC_TRIANGLESET object
  '''
  objects = []
  if geoset.Type == filter:
    objects.append(geoset)
  return objects 

def filterFeatures(features, filter, loop = False):
  '''
  Filter VC_GEOMETRY feature from component and node
  If loop is false, collect the geometry sets from the selected geometry feature
  '''
  objects = []
  if loop:
    for feature in features:
      if feature.Type == filter:
        objects.append(feature)
  else:
    if features.Type == filter:
      objects.extend(features.Geometry.GeometrySets)
  return objects

def traverseFeatureChildren(feature):
  '''
  Add feature and child features
  '''
  features = []
  features.append(feature)
  for child in feature.Children:
    features.extend(traverseFeatureChildren(child))
  return features

def getGivenNodesFeatures(node):
  '''
  Get component/node root feature
  '''
  return traverseFeatureChildren(node.RootFeature)

def getGivenNodesGeosets(node, fromFeatureTree=False):
  '''
  Filter geometry features and collect geometry sets from the geometry feature
  '''
  if fromFeatureTree:
    sets = []
    gfeats = filterFeatures(getGivenNodesFeatures(node), VC_GEOMETRY, loop = True)
    for gfeat in gfeats:
      sets.extend(gfeat.Geometry.GeometrySets)
    return sets

def traverseNodeChildren(node): 
  '''
  Get selected node and it's children
  '''
  nodes = []
  nodes.append(node)
  for child in node.Children:
    nodes.extend(traverseNodeChildren(child))
  return nodes

def getTriangleSets(nodes):
  '''
  Get component/node triangle sets
  '''
  geosets = []
  tsets = []
  for node in nodes:
    geosets.extend(getGivenNodesGeosets(node, fromFeatureTree=True))
  for geoset in geosets:
    tsets.extend(filterTriangleSet(geoset, VC_TRIANGLESET)) 
  return tsets

def first_state(): 
  '''
  Executuion starts here
  '''
  app = getApplication()
  selected_components = app.SelectionManager.getSelection(VC_SELECTION_COMPONENT)
  selected_node = app.SelectionManager.getSelection(VC_SELECTION_NODE)
  selected_features = app.SelectionManager.getSelection(VC_SELECTION_FEATURE)

  nodes = []
  all_features = []
  exclude_geometry = ['Root', 'Frame']

  '''
  If component(s) is selected
  '''
  if selected_components:
    print "Converting selected component features to convexhull"
    for component in selected_components:
      nodes.extend(traverseNodeChildren(component))
    tsets = getTriangleSets(nodes)
    for tset in tsets:
      convert_convex(tset)
  
  '''
  If a node is selected
  '''
  if selected_node:
    print "Converting selected node and its clild nodes to convexhull"
    for child_node in selected_node:
      nodes.extend(traverseNodeChildren(child_node))
    tsets = getTriangleSets(nodes)
    for tset in tsets:
      convert_convex(tset)
  
  '''
  If feature(s) is selected. 
  Exit the command execution if root or frame feature is selected
  '''
  if selected_features:
    geosets = []
    tsets = []
    for selected_feature in selected_features:
      all_features.extend(traverseFeatureChildren(selected_feature))
    for feature in all_features:
      if feature.Type in exclude_geometry:
        print 'Warning: {} feature cannot be converted to ConvexHull.'.format(feature.Type)
        return
      else:
        geosets.extend(filterFeatures(feature, VC_GEOMETRY, loop=False))
    print "Converting geometry features to convexhull"
    for geoset in geosets:
      tsets.extend(filterTriangleSet(geoset, VC_TRIANGLESET)) 
    for tset in tsets:
      convert_convex(tset)
    for f in selected_features:
      f.rebuild()
  app.render()

addState( first_state )