from vcCommand import *
from vcHelpers.Selection import *


app = getApplication()

# feature types that may include triangles
triangled_features = [VC_BLOCK,
                      VC_CONE,
                      VC_CYLINDER,
                      VC_GEOMETRY,
                      VC_SPHERE,
                      VC_WEDGE]

def give_geo_count(c):
  nodes = [c]
  data_count = 0
  while nodes:
    node = nodes.pop(0)
    own_kids = [x for x in node.Children if x.Component == c]
    nodes.extend( own_kids )
    data_count += sum(x.PolygonCount for x in node.Geometry.GeometrySets if x.Type == VC_TRIANGLESET)
  return data_count


def get_geo_count(f):
  if f.Type == VC_GEOMETRY:
    return sum(x.PolygonCount for x in f.Geometry.GeometrySets if x.Type == VC_TRIANGLESET)
  elif f.Type == VC_BLOCK:
    return 12
  elif f.Type in [VC_CYLINDER, VC_CONE]:
    count = 0
    if f.Caps:
      count += int(evl(f,'Sections'))*2
    count += int(evl(f,'Sections'))*2
    return count
  elif f.Type == VC_SPHERE:
    count = 0
    if evl(f,'EndSweep') - evl(f,'StartSweep') < 360 and f.Caps:
      count = evl(f,'Spans')*2
    count += (int(evl(f,'Spans'))*2-2)*int(evl(f,'Sections'))
    return count
  elif f.Type == VC_WEDGE:
    if f.MirrorBack and f.MirrorDown:
      count = 28
    elif f.MirrorBack or f.MirrorDown:
      count = 20
    else:
      count = 16
    return count


def evl(feature,prop_name):
  return feature.getProperty(prop_name).CalculatedValue


def count_clones( f, comp ):
  '''
  Counts how many times the given geometry is cloned in the feature tree.
  Also checks if the geometry is extruded, revolved and mirrored as that increases the total amount of triangles.
  '''
  clone_count = 1
  safety_runner = 0
  extruded, revolved, mirrored = False, False, False
  if f.Type == 'Root':
    clone_count = -1
  while f.Parent.Type != 'Root' or safety_runner>400:
    safety_runner += 1
    f = f.Parent
    if f.Type in [VC_LINEARCLONE, VC_ANGULARCLONE]:
      try:
        clone_count *= evl(f,'Count')
      except:
        clone_count = -1
    elif f.Type == VC_EXTRUDE:
      extruded = True
    elif f.Type == VC_MIRROR:
      mirrored = True
    elif f.Type == VC_REVOLVE:
      revolved = True
  return [clone_count, extruded, revolved, mirrored]

def triangle_count_layout(*args):
  comps_and_datas = [ (x.Name, give_geo_count(x) ) for x in app.Components ]
  comps_and_datas.sort( key = lambda x: x[1], reverse = True )
  total = sum( x[1] for x in comps_and_datas )
  print '-'*99
  print 'Layout triangle count:'
  for i, (name, data_count) in enumerate(comps_and_datas):
    percentage = float(data_count)/total
    print "  %i. %s: %i  (%.1f%s)" % ( i+1, name, data_count, percentage*100, "%" )
    #print i+1,".", name, ", PolygonCount:", data_count, "  %.2f %" % cumulative
  if total > 99999:
    print 'Total triangle count in this layout: {} ({}M)'.format(total, total/1000000.0)
  else:
    print 'Total triangle count in this layout: {}'.format(total)


def triangle_count_component(arg):
  global props_dict

  if arg.Name == 'SelectedFeature':
    active_features = getSelectedFeatures()
    IsFeature = True
    if not active_features:
      IsFeature = False
      print 'Error: Set a feature active by selecting atleast one component feature'
      return

  else: #Active Component
    comp = app.CurrentContext.ActiveComponent
    IsFeature = False
    if not comp:
      print 'Error: Set a component active by selecting it or one of its features.'
      return

  print '-'*99
  if not IsFeature:
    poly_count = 0 
    nodes = [x for x in getGivenComponentsNodes(comp) if x.Component == comp]
    props_dict = dict( (x.Name, x.Value) for x in comp.Properties )
    print 'Triangle Count: "%s"' % comp.Name
    for node in nodes:
      for geoset in node.Geometry.GeometrySets:
        if geoset.Type in [VC_TRIANGLESET]:
          poly_count += geoset.PolygonCount
    features = [x for n in nodes for x in getGivenNodesFeatures(n)]
    features = [x for x in features if x.Type in triangled_features]
    feas_and_datas = [ (x.Name, get_geo_count(x), count_clones( x, comp ) ) for x in features ]
  else:
    print 'Triangle Count Feature:'
    features = [x for x in active_features if x.Type in triangled_features]
    feas_and_datas = [ (x.Name, get_geo_count(x), count_clones( x, active_features ) ) for x in features]
  feas_and_datas.sort( key = lambda x: x[1], reverse = True )
  total_data_count = 0
  for i, (name, data_count, clones) in enumerate(feas_and_datas):
    # data count per feature (index; feature name; triangle count)
    line_string = '  %4i. %s: %i ' % (i+1, name, data_count)
    total_data_count += data_count 
    clone_count, extruded, revolved, mirrored = clones
    # Additional data per line if the geometry is cloned, extruded, revolved or mirrored. 
    # The triangle count per feature excludes the additional triangles that these operations adds
    additional_data = ''
    if clone_count == -1:
      additional_data += '(Clones x N/A) '
    elif clone_count > 1:
      additional_data += '(Clones x %i) ' % clone_count
    if extruded:
      additional_data += '(Extruded)'
    if revolved:
      additional_data += '(Revolved)'
    if mirrored:
      additional_data += '(Mirrored)'
    print line_string + additional_data 
  
  if IsFeature:
    feature_name = [x.Name for x in features]
    #for feature in active_features:
    if total_data_count > 99999:
      print 'Total triangle count in selected feature(s) {}: {}'.format(''.join(x for x in str(feature_name)), total_data_count/1000000.0) #large numbers add the info in Millions for easy reading
    else:
      print 'Total triangle count in selected feature(s) {}: {}'.format(''.join(x for x in str(feature_name)), total_data_count)
  else:
    if poly_count > 99999:
      print 'Total triangle count ("{}"): {} ({}M)'.format(comp.Name, poly_count, poly_count/1000000.0) #large numbers add the info in Millions for easy reading
    else:
      print 'Total triangle count ("{}"): {} '.format(comp.Name, poly_count)
  
  
def OnStart():
  global active_feature, active_component, layout

  active_feature = createProperty(VC_BUTTON, 'SelectedFeature')
  active_feature.OnChanged = triangle_count_component

  active_component = createProperty(VC_BUTTON, 'ActiveComponent')
  active_component.OnChanged = triangle_count_component

  layout = createProperty(VC_BUTTON, 'Layout')
  layout.OnChanged = triangle_count_layout
  executeInActionPanel()

addState(None)
