from vcCommand import *
from vcHelpers.Selection import *
from vcHelpers.Application import *
import math
import bisect
import time

app = getApplication()
cmd = getCommand()
 
# Visible variables
selectionLevel = addStepProperty( cmd, VC_STRING, 'SelectionLevel', True, False, False, 'Feature', None, '',  ["Feature", "GeoSet"])
addProperty( cmd, VC_BOOLEAN, 'RemoveCircularHolesOnly', True, False, False, False, None, '' )
addLimitProperty( cmd, VC_INTEGER, 'MinHolePointCount', True, False, False, 4, None, '', 3, 12)
minHoleDiameter = addLimitProperty( cmd, VC_REAL, 'MinHoleDiameter', True, False, False, 10., None, 'Distance', 0., 100000.)
minHolePerimeter = addLimitProperty( cmd, VC_REAL, 'MinHolePerimeter', True, False, False, 150., None, 'Distance', 0., 314159.)

# Hidden variables
addLimitProperty( cmd, VC_REAL, 'MergePointsTolerance', False, False, False, 0.001, None, 'Distance', 0., 1. )
addLimitProperty( cmd, VC_REAL, 'ColinearTolerance', False, False, False, 0.25, None, 'Angle', 0., 5. )
addLimitProperty( cmd, VC_REAL, 'PlanarityTolerance', False, False, False, 0.1, None, 'Distance', 0., 5. )
addProperty( cmd, VC_BOOLEAN, 'MergeByMaterial', False, False, False, False, None, '' )
addProperty( cmd, VC_BOOLEAN, 'DebugMessages', False, False, False, False, None, '' )
addProperty( cmd, VC_STRING, 'TargetCommand', False, False, False, 'cmdRemoveHolesExecute', None, '' )

# Note: typically executed from ribbon in Modeling tab
def OnExecute():
  cmd.SelectionLevel = 'Feature'
  onSelectionTypeChanged(None)
  executeInActionPanel()

def onSelectionTypeChanged( prop ):
  if cmd.SelectionLevel == 'GeoSet':
    if not app.SelectionManager.getSelection(VC_SELECTION_GEOMETRYSET):
      app.SelectionManager.clear()
    app.SelectionManager.setGeometrySelectEnabled(1)
  else:
    if not app.SelectionManager.getSelection(VC_SELECTION_FEATURE):
      app.SelectionManager.clear()
    app.SelectionManager.setGeometrySelectEnabled(0)

def onMinHolePerimiterChanged( prop ):
  cmd.MinHoleDiameter = min( cmd.MinHoleDiameter, cmd.MinHolePerimeter/math.pi )

def onMinHoleDiameterChanged( prop ):
  cmd.MinHolePerimeter = max( cmd.MinHoleDiameter*math.pi, cmd.MinHolePerimeter )

selectionLevel.OnChanged = onSelectionTypeChanged
minHoleDiameter.OnChanged = onMinHoleDiameterChanged
minHolePerimeter.OnChanged = onMinHolePerimiterChanged
addState(OnExecute)
