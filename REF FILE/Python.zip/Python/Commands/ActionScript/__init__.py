from vcApplication import *



def OnStart():
  cmduri = getApplicationPath() + 'create_action_script.py'
  cmd = loadCommand("simCreateActionScript",cmduri)
  prop = cmd.createProperty(VC_STRING, "ScriptText")
  script_path = cmd.getCommandPath()
  script_path = script_path[8:len(script_path)]
  script_path = script_path[0:len(script_path)-23] 
  script_path = script_path+"action_script.py"
  file = open(unicode(script_path, "utf-8"),"r")
  prop.Value = ""
  try:
    prop.Value = file.read()
  except:
    print "Error parsing action template"
  file.close()


  addMenuItem(VC_MENU_MODELING_WIZARDS + '/Component Wizards', "Action Script", -1, "simCreateActionScript")

