#  Action Script v. 2021-08-16 (yyyy-mm-dd)
#
#  Generic Action (grasp,release,mount,unmount,traceon,traceoff, sweptvolumeon, sweptvolumeoff) execution
#  by triggering a specific robot output with a specific value
#    Default Signal mapping:
#      signals 01...16: grasp/release
#      signals 17...32: trace_on/trace_off
#      signals 33...48: mount_tool/unmount_tool
#      signals 49...80: trace_extTCP_on/trace_extTCP_off
#      signal  81:      swept_volume_on/swept_volume_off
#
from vcScript import *
import vcVector
import vcMatrix

global grasp_association
from collections import defaultdict
comp = getComponent()
app = getApplication()
sim = getSimulation()
normal_vec = vcVector.new(0,0,1)
default_detection_volume = vcVector.new(50,50,50)
EPSILON = 10e-5

controller_flange_node = None
flange_node_tool_interface = None
detection_volume_tool = None
detection_volume_tools_list = []

ignore_as_release_target_filter_props = ['ExcludeRobotReleasingTo']
ignore_as_grasp_object_filter_props = ['ExcludeRobotGrasping']

def DetectionVolumeChange(prop):
  current_tool_property = DetectionVolumeTool
  current_tool = GetCurrentTool(current_tool_property)
  GenerateDetectionGeometrySet(current_tool,DetectionVolumeGeometry)

def GenerateDetectionGeometrySet(tool_frame,volume_geometry):

  current_detection_volume = DetectionVolume
  box = current_detection_volume.Value * 0.5 

  if tool_frame:
    tool_node = tool_frame.Node
    tool_matrix = tool_frame.PositionMatrix
  else:
    tool_node = controller.FlangeNode
    tool_matrix = vcMatrix.new()
  tool_frame_matrix = comp.InverseWorldPositionMatrix * tool_node.WorldPositionMatrix * tool_matrix

  geo = comp.UserGeometry
  geo.clear()

  p1 = tool_frame_matrix * vcVector.new(box.X, box.Y, box.Z)
  p2 = tool_frame_matrix * vcVector.new(box.X, -box.Y, box.Z)
  p3 = tool_frame_matrix * vcVector.new(-box.X, box.Y, box.Z)
  p4 = tool_frame_matrix * vcVector.new(-box.X, -box.Y, box.Z)
  p5 = tool_frame_matrix * vcVector.new(box.X, box.Y, -box.Z)
  p6 = tool_frame_matrix * vcVector.new(box.X, -box.Y, -box.Z)
  p7 = tool_frame_matrix * vcVector.new(-box.X, box.Y, -box.Z)
  p8 = tool_frame_matrix * vcVector.new(-box.X, -box.Y, -box.Z)

  
  if volume_geometry.Value == "Line":
    color = app.findMaterial('red')
    lineset = geo.createGeometrySet(VC_COMPACTLINESET) 
    lineset.Material = color
    lineset.addLine([p1, p2, p4, p3, p1])
    lineset.addLine([p5, p6, p8, p7, p5])
    lineset.addLine([p1, p5])
    lineset.addLine([p2, p6])
    lineset.addLine([p3, p7])
    lineset.addLine([p4, p8])

    lineset.LineWidth = 7.0 
    lineset.update()
  
  if volume_geometry.Value == "Box":
    color = app.findMaterial('transp_red')
    tset = geo.createGeometrySet(VC_TRIANGLESET) 
    tset.UseBackface = True
    tset.Material = color

    tp1 = tset.addPoint(p1)
    tp2 = tset.addPoint(p2)
    tp3 = tset.addPoint(p3)
    tp4 = tset.addPoint(p4)
    tp5 = tset.addPoint(p5)
    tp6 = tset.addPoint(p6)
    tp7 = tset.addPoint(p7)
    tp8 = tset.addPoint(p8)

    tset.addTriangle(tp1,tp2,tp4)    #tri_Right1
    tset.addTriangle(tp4,tp3,tp1) #tri_Right2
    tset.addTriangle(tp1,tp3,tp7) #tri_Top1
    tset.addTriangle(tp7,tp5,tp1) #tri_Top2
    tset.addTriangle(tp6,tp8,tp7)   #tri_Left1
    tset.addTriangle(tp7,tp5,tp6)   #tri_Left2 
    tset.addTriangle(tp6,tp2,tp4) #tri_Bottom1
    tset.addTriangle(tp4,tp8,tp6) #tri_Bottom2
    tset.addTriangle(tp8,tp4,tp3)   #tri_Back1
    tset.addTriangle(tp3,tp7,tp8)   #tri_Back2 
    tset.addTriangle(tp6,tp2,tp1)  #tri_Front1 
    tset.addTriangle(tp1,tp5,tp6)  #tri_Front2 
    tset.update()

  app.render()

def UpdateToolOnConnect(other_sim_interface, retain_offset):
  global controller

  if controller:
    controller_tools = controller.Tools
    if controller_tools:
      for tool in controller_tools:
        detection_volume_tools_list.append(tool.Name) if tool.Name not in detection_volume_tools_list else detection_volume_tools_list
      DetectionVolumeTool.StepValues = detection_volume_tools_list
      detection_volume_tool = detection_volume_tools_list[-1]
      DetectionVolumeTool.Value = detection_volume_tool

def UpdateToolOnDisConnect(other_sim_interface):
  global controller, detection_volume_tool, detection_volume_tools_list

  detection_volume_tools_list = []
  if controller:
    controller_tools = controller.Tools
    if controller_tools:
      for tool in controller_tools:
        if tool.Name not in detection_volume_tools_list: 
          detection_volume_tools_list.append(tool.Name)
      DetectionVolumeTool.StepValues = detection_volume_tools_list
      DetectionVolumeTool.Value = detection_volume_tools_list[0]

def ChangeDetectionVisiblity(prop):
  global controller, detection_volume_tool, flange_node_tool_interface
  
  if flange_node_tool_interface == None:
    controller_flange_node = controller.FlangeNode
    flange_node_tool_interface = controller_flange_node.getBehavioursByType(VC_ONETOONEINTERFACE)[0]
    flange_node_tool_interface.OnConnect = UpdateToolOnConnect
    flange_node_tool_interface.OnDisconnect = UpdateToolOnDisConnect

  if controller:
    controller_tools = controller.Tools
  if controller_tools:
    if detection_volume_tool == None:
      detection_volume_tool = controller_tools[0].Name
    for tool in controller_tools:
      detection_volume_tools_list.append(tool.Name) if tool.Name not in detection_volume_tools_list else detection_volume_tools_list
      DetectionVolumeTool.StepValues = detection_volume_tools_list
      if detection_volume_tool in detection_volume_tools_list:
        DetectionVolumeTool.Value = detection_volume_tool
  if prop.Value:
    DetectionVolumeGeometry.IsVisible = True
    DetectionVolumeTool.IsVisible = True
    DetectionVolume.IsVisible = True
    tool = GetCurrentTool(DetectionVolumeTool)
    GenerateDetectionGeometrySet(tool, DetectionVolumeGeometry)  
  else:
    detection_volume_tool = DetectionVolumeTool.Value
    comp.UserGeometry.clear()
    DetectionVolumeGeometry.IsVisible = False
    DetectionVolumeTool.IsVisible = False
    DetectionVolume.IsVisible = False  

def GetCurrentTool(prop):
  global controller, detection_volume_tool, detection_volume_tools_list

  for tool in controller.Tools:
    if prop.Value == tool.Name:
      current_tool = tool
      detection_volume_tool = current_tool
      return detection_volume_tool
  else:
    print '{} not found.'.format(prop.Value)
    if prop.Value in detection_volume_tools_list:
      detection_volume_tools_list.remove(prop.Value)
    DetectionVolumeTool.StepValues = detection_volume_tools_list
    detection_volume_tool_property_value = detection_volume_tools_list[0]
    print 'DetectionVolumeTool is {}.'.format(detection_volume_tool_property_value)
    DetectionVolumeTool.Value = detection_volume_tool_property_value
    GetCurrentTool(DetectionVolumeTool)

def CurrentDetectionVolumeTool(prop):
  current_tool = GetCurrentTool(prop)
  if DetectionVolumeVisiblity.Value: 
    GenerateDetectionGeometrySet(current_tool,DetectionVolumeGeometry)  

def ChangeDetectionVolumeGeometry(prop):
  global detection_volume_tool
  GenerateDetectionGeometrySet(detection_volume_tool,prop)
  
def confirmProperty(name,defaultvalue,type=VC_REAL,constraints=VC_PROPERTY_DEFAULT):
     global comp
     prop = comp.getProperty(name)
     if type == VC_VECTOR:
        if prop == None:
          prop = comp.createProperty(type,name,constraints)
          prop.Value = default_detection_volume
     else:
        if prop == None:
         prop = comp.createProperty(type,name,constraints)
         prop.Value = defaultvalue
     return prop


Verbose = confirmProperty("SignalActions::DisplayMessages",False,VC_BOOLEAN)
ReleaseToWorld = confirmProperty("SignalActions::ReleaseToWorld",False,VC_BOOLEAN)
ReleaseToPhysics = confirmProperty("SignalActions::ReleaseToPhysics",'Never',VC_STRING, VC_PROPERTY_STEP)
ReleaseToPhysics.StepValues = ['Never', 'If Target not Detected', 'Always']
MultiGrasp = confirmProperty("SignalActions::MultiGrasp",False,VC_BOOLEAN)
TraceWidth = confirmProperty("SignalActions::TraceWidth",1,VC_INTEGER)
TraceWidth.IsVisible = True
TraceZOffset = confirmProperty("SignalActions::TraceZOffset",0.,VC_REAL)
UpdateWorldIOnRelease = confirmProperty("SignalActions::UpdateWorldIOnRelease",False,VC_BOOLEAN)
DetectLockedComponents = confirmProperty("SignalActions::DetectLockedComponents",False,VC_BOOLEAN)
DetectHiddenComponents = confirmProperty("SignalActions::DetectHiddenComponents",False,VC_BOOLEAN)
ExcludeReleasingToComponents = confirmProperty("SignalActions::ExcludeReleasingTo",[],"List<Ref<Component> >")
ExcludeReleasingToComponents.IsVisible = True
ExcludeGraspingComponents = confirmProperty("SignalActions::ExcludeGrasping",[],"List<Ref<Component> >")
ExcludeGraspingComponents.IsVisible = True

BundleReleasedComponents = confirmProperty("SignalActions::BundleReleasedComponents",False,VC_BOOLEAN)

'''
Detection volume visualization
'''
DetectionVolumeVisiblity = confirmProperty("SignalActions::ShowDetectionVolume",False,VC_BOOLEAN)
DetectionVolumeVisiblity.ChangeOnRebuild = True
DetectionVolumeVisiblity.Value = False
DetectionVolumeVisiblity.OnChanged = ChangeDetectionVisiblity


DetectionVolumeGeometry = confirmProperty("SignalActions::DetectionVolumeGeometry",'Box',VC_STRING, VC_PROPERTY_STEP)
DetectionVolumeGeometry.StepValues = ['Box', 'Line']
DetectionVolumeGeometry.IsVisible = False
DetectionVolumeGeometry.OnChanged = ChangeDetectionVolumeGeometry

DetectionVolumeTool = confirmProperty("SignalActions::DetectionVolumeTool",'',VC_STRING, VC_PROPERTY_STEP)
DetectionVolumeTool.IsVisible = False
DetectionVolumeTool.OnChanged = CurrentDetectionVolumeTool

DetectionVolume = confirmProperty("SignalActions::DetectionVolume",default_detection_volume,VC_VECTOR)
DetectionVolume.Quantity =  "Distance"
DetectionVolume.IsVisible = False
DetectionVolume.OnChanged = DetectionVolumeChange

'''
Assembly behaviour
'''
GraspIncludeEmptyAssemblies = confirmProperty("SignalActions::GraspIncludeEmptyAssemblies",'No -Delete',VC_STRING, VC_PROPERTY_STEP)
GraspIncludeEmptyAssemblies.StepValues = ['No -Delete', 'No -Leave', 'Yes']

group_index = 0
Verbose.Group = group_index = group_index+10
ReleaseToWorld.Group = group_index = group_index+10
ReleaseToPhysics.Group = group_index = group_index+10
MultiGrasp.Group = group_index = group_index+10
TraceWidth.Group = group_index = group_index+10
TraceZOffset.Group = group_index = group_index+10
sweptVolumeItems = defaultdict(list)
red_material = app.findMaterial('red')
CONFIGURE_DIALOG_CMD = "showGraspRelease"
ASSOCIATE_GRASPING_TO_OUTPUT = True
ACTIONS_NAME1 = "Actions"
MOUNTPLATE_NAME = "mountplate"
GRASP_CONTAINER = "GraspContainer"
ACTION_BUTTON1 = "SignalActions::Configure"
TRACE_LAYER = "RobotTrace"
TRACE_COLORS = [ "red", "blue", "green", "white", "black", "grey", "yellow", "brown", "cyan", "purple", "ingido", "orange", "pink", "beige", "cream", "khaki" ]
trace_lines = []
sweptVolumeItems = {}


class Trace:
  def __init__(self):
    self.Tool = None
    self.ToolName = None
    self.Base = None
    self.BaseName = None
    self.Node = None
    self.Material = None
    self.LineSet = None
    self.Point = None
    self.Port = -1
    self.Robot = None
    self.Light = None
    self.Particles = None

# Create new action with its properties
def AddAction(actor, name, props):
  action = actor.createAction(name)
  for prop in props:
    if len(prop) > 3:
      p = action.createProperty(prop[0],prop[1],prop[3])
      p.StepValues = prop[2]
      p.Value = prop[2][prop[4]]
    else:
      p = action.createProperty(prop[0],prop[1])
      p.Value = prop[2]
      if p.Name == "GravityDirection":
        p.Quantity = 'Distance'
    p.IsVisible = True


def ToolName(index):
  return "TOOL_DATA[%i]" % index


def BaseName(index):
  return "BASE_DATA[%i]" % index


def Tool(toolname):
  for tool in controller.Tools:
    if tool.Name == toolname:
      return tool
  return None


def Base(basename):
  for base in controller.Bases:
    if base.Name == basename:
      return base
  return None


# Configure component if required
def AutoConfigure(bForceReset = False):
  global comp, controller
  exec_list = comp.findBehavioursByType(VC_ROBOTEXECUTOR)
  executor = None
  outputmap = None
  #controller = None
  if len(exec_list):
    executor = exec_list[0]
  if executor:
    outputmap = executor.DigitalOutputSignals
    controller = executor.Controller
  if outputmap:
    if outputmap.PortCount < 49:
      outputmap.PortCount = 49
  # find default flange interface
  iface_name = ""
  ifaces = comp.findBehavioursByType(VC_ONETOONEINTERFACE)
  if len(ifaces):
    iface_name = ifaces[len(ifaces)-1].Name
  # Add action container and all default actions if not available yet
  actor = comp.findBehaviour(ACTIONS_NAME1)
  if not actor:
    actor = comp.createBehaviour(VC_ACTIONCONTAINER,ACTIONS_NAME1)
    bForceReset = True
  if bForceReset:
    actor.clear()
    # Add default actions
    toolnames = []
    basenames = []
    if controller:
      for tool in controller.Tools:
        toolnames.append(tool.Name)
      if len(toolnames) < 16:
        for i in range(len(toolnames),17):
          toolnames.append("*NULL*")
      for base in controller.Bases:
         basenames.append(base.Name)
      if len(basenames) < 32:
        for i in range(len(toolnames),33):
          basenames.append("*NULL*")
    else:
      for i in range(1,17):
        toolnames.append(ToolName(i))
      for i in range(1,33):
        basenames.append(BaseName(i))
    for i in range(1,17):
      if toolnames[i-1] != "*NULL*":
        AddAction(actor, "Grasp", [ (VC_INTEGER, "Port", i), (VC_BOOLEAN, "Value", True), (VC_STRING,"UsingTool",toolnames[i-1]), (VC_VECTOR,"DetectionVolumeSize",vcVector.new(50,50,50) )])
    for i in range(1,17):
      if toolnames[i-1] != "*NULL*":
        AddAction(actor, "Release", [ (VC_INTEGER, "Port", i), (VC_BOOLEAN, "Value", False), (VC_REAL,"GravityDirection",25.0)])
    for i in range(17,33):
      if toolnames[i-17] != "*NULL*":
        AddAction(actor, "TraceOn", [
            (VC_INTEGER, "Port", i),
            (VC_BOOLEAN, "Value", True),
            (VC_STRING,"UsingTool",toolnames[i-17]),
            (VC_STRING,"Attached","%s::%s" % (comp.Name, comp.Name)),
            ('Ref<Material>', "Material", app.findMaterial(TRACE_COLORS[(i-1) % 16]))
            ]
        )
    for i in range(17,33):
      if toolnames[i-17] != "*NULL*":
        AddAction(actor, "TraceOff", [ (VC_INTEGER, "Port", i), (VC_BOOLEAN, "Value", False), (VC_STRING,"UsingTool",toolnames[i-17])])
    for i in range(33,49):
      if toolnames[i-33] != "*NULL*":
        AddAction(actor, "MountTool", [ (VC_INTEGER, "Port", i), (VC_BOOLEAN, "Value", True), (VC_STRING,"UsingTool",toolnames[i-33]), (VC_VECTOR,"DetectionVolumeSize",vcVector.new(50,50,50) ),(VC_STRING,"Interface",iface_name)])
    for i in range(33,49):
      if toolnames[i-33] != "*NULL*":
        AddAction(actor, "UnmountTool", [ (VC_INTEGER, "Port", i), (VC_BOOLEAN, "Value", False), (VC_REAL,"GravityDirection",25.0),(VC_STRING,"Interface",iface_name)])
    for i in range(49,81):
      if basenames[i-49] != "*NULL*":
        AddAction(actor, "TraceOn", [
            (VC_INTEGER, "Port", i),
            (VC_BOOLEAN, "Value", True),
            (VC_STRING,"UsingTool",basenames[i-49]),
            (VC_STRING,"Attached","%s::%s" % (comp.Name, controller.FlangeNode.Name)),
            ('Ref<Material>', "Material", app.findMaterial(TRACE_COLORS[(i-1) % 16])),
            ]
        )
    for i in range(49,81):
      if basenames[i-49] != "*NULL*":
        AddAction(actor, "TraceOff", [ (VC_INTEGER, "Port", i), (VC_BOOLEAN, "Value", False), (VC_STRING,"UsingTool",basenames[i-49])])
    AddAction(actor, "SweptVolumeOn", [
    (VC_INTEGER, "Port", 81),
    (VC_BOOLEAN, "Value", True),
    (VC_STRING, "SweptMethod", ['HullFromHulls','HullFromSilhouettes','Lofting'], VC_PROPERTY_STEP, 0),
    ('List<Ref<Node>>', "SweptGeometry", [comp]),
    ('Ref<Material>', "Material", red_material),
    (VC_STRING, "AttachTo", ['Node','Closest','NewComponent'], VC_PROPERTY_STEP, 2),
    ('Ref<Node>', "TargetNode", comp),
    (VC_STRING,"UsingTool",toolnames[0]),
    (VC_VECTOR,"DetectionVolumeSize",vcVector.new(50,50,50) )])
    AddAction(actor, "SweptVolumeOff", [ (VC_INTEGER, "Port", 81), (VC_BOOLEAN, "Value", False), (VC_BOOLEAN, "StoreGeometry", False)])
  else:
    # Old models will pass through this conversion.
    for act in actor.Actions:
        if act.Name == "TraceOn":
            if act.getProperty("Material") == None:
                # print "Converting port '" + str(act.Port) + "' from color to material"
                p = act.createProperty("Ref<Material>", "Material")
                p.Value = app.findMaterial(act.Color)
                p.IsVisible = True
                act.deleteProperty("Color")

  # Add configuration editor button
  if not comp.getProperty(ACTION_BUTTON1):
    prop = comp.createProperty(VC_BUTTON, ACTION_BUTTON1)
  # Add graspcontainer to flangenode if not created yet
  container = comp.findBehaviour(GRASP_CONTAINER)
  if not container:
    flange = comp.findNode(MOUNTPLATE_NAME)
    if flange:
      container = flange.createBehaviour(VC_COMPONENTCONTAINER,GRASP_CONTAINER)
    else:
      print "Configuration error: no flange node (%s) found in order to create a container for it (%s)" % (MOUNTPLATE_NAME,GRASP_CONTAINER)


# Display Grasp & Release configuration GUI
def GraspReleaseConfiguration(args):
  cmd = app.findCommand(CONFIGURE_DIALOG_CMD)
  cmd.execute("All:Actions")


def OutputTriggered( map, port, value ):
  global comp, executor, outputmap, all_actions
  # rint "Output %i set to value %i" % (port,value)
  # Find if there is an action for this signal
  for actions in all_actions:
    action = None
    for act in actions.Actions:
      # rint act.Name, act.Port, act.Value
      if act.Port == port and act.Value == value:
        action = act
        break
    if not action:
      return
    ret = ""
    if action.Name == "Grasp":
      ret = Grasp( port, action.UsingTool, action.DetectionVolumeSize )
    elif action.Name == "Release":
      ret = Release( port, action.GravityDirection )
    elif action.Name == "MountTool":
      ret = MountTool( port, action.UsingTool, action.DetectionVolumeSize, action.Interface )
    elif action.Name == "UnmountTool":
      ret = UnmountTool( port, action.GravityDirection, action.Interface )
    elif action.Name == "TraceOn":
      ret = TraceOn( port, action.UsingTool, action.Attached, action.Material.Name )
    elif action.Name == "TraceOff":
      ret = TraceOff( action.UsingTool )
    elif action.Name == "SweptVolumeOn":
      ret = SweptVolumeOn( port, action )
    elif action.Name == "SweptVolumeOff":
      ret = SweptVolumeOff( port, action.StoreGeometry )
    if Verbose.Value:
      print "%s: Action \'%s\' executed (%s) " % (comp.Name, action.Name, ret)


# Initialize Grasp & release action implementation
def OnStart():
  global robot, executor, outputmap, all_actions, grasp_container
  global grasp_association, traces, trace_lines, grasped_components, sweptVolumeItems
  # Initialize signal map entries wit the attached action entry
  grasped_components = []
  grasp_association = {}
  sweptVolumeItems = defaultdict(list)
  traces = []
  trace_lines = []
  grasp_container = comp.findBehaviour(GRASP_CONTAINER)
  exec_list = comp.findBehavioursByType(VC_ROBOTEXECUTOR)
  executor = None
  outputmap = None
  if len(exec_list):
    executor = exec_list[0]
  if not executor:
    return
  robot = executor.Controller
  outputmap = executor.DigitalOutputSignals
  if not outputmap:
    return
  outputmap.OnSignalTrigger = OutputTriggered
  all_actions = comp.findBehavioursByType(VC_ACTIONCONTAINER)


def DetectionHelper( tool_name, bound ):

  global robot, grasp_container
  # Define bound corner points when original bound vector is thought as bound box diagonal vector
  v1 = bound*(-0.5)
  v2 = bound*0.5

  # Following code sets a specific tool and extracts tool matrix in world coordinate system
  # This transformation is then applied to the bound box defining volume.
  sim.update()
  tool = Tool(tool_name)
  if tool:
    tnode = tool.Node
    tmatrix = tool.PositionMatrix
  else:
    tnode = robot.FlangeNode
    tmatrix = vcMatrix.new()
  m = tnode.WorldPositionMatrix * tmatrix
  v = m.P
  # a) Create volume bbox detector and test if geometry bbox is fully inside the detection volume
  vol_detector = sim.newVolumeDetector()
  vol_detector.TestMethod = VC_INSIDE
  vol_detector.Corner1 = v1
  vol_detector.Corner2 = v2
  vol_detector.Transformation = m
  node_list = get_grasp_candidates()
  vol_detector.NodeList = node_list
  part = None
  hit = vol_detector.testOneCollision()
  if hit:
    part = vol_detector.getHitNode(0).Component
  # b) If no geometry bbox was fully inside the detection volume, create new colision detector
  # using volume as detection geometry
  if not part:
    coll_detector = sim.newCollisionDetector()
    coll_detector.DisplayCollisions = 0
    node_list = get_grasp_candidates()
    coll_detector.NodeListA = node_list
    hit = coll_detector.testOneBBoxCollision(v1,v2,m)
    if hit:
      part = coll_detector.getHitNodeA(0).Component
  return part


def get_grasp_candidates():
  grasp_candidates = [ (sim.World, VC_NODELIST_INCLUDE, VC_NODELIST_TREE ) , (comp, VC_NODELIST_EXCLUDE, VC_NODELIST_TREE )]
  grasp_candidates.extend([(x, VC_NODELIST_EXCLUDE, VC_NODELIST_COMPONENT ) for x in app.Components if exclude_grasp_object_test(x)])
  return grasp_candidates


def exclude_grasp_object_test(icomponent):
  if icomponent in ExcludeGraspingComponents.Value:
    return True
  if not DetectHiddenComponents.Value and not icomponent.Visible:
    return True
  if not DetectLockedComponents.Value and icomponent.Locked:
    return True
  for ignore_prop_name in ignore_as_grasp_object_filter_props:
    ignore_prop = icomponent.getProperty(ignore_prop_name)
    if ignore_prop and ignore_prop.Value:
      return True


def Grasp( output, tool_name, bound ):

  global robot, grasp_container, grasp_association, grasped_components
  grasp_cont = grasp_container
  tool = Tool(tool_name)
  if tool:
    tnode = tool.Node
    if tnode:
      container = tnode.getBehaviour( GRASP_CONTAINER )
      if not container:
        contname = '%s_%s_%s' % (GRASP_CONTAINER, tnode.Component.Name, tnode.Name )
        contname = contname.replace(' ', '')
        container = tnode.findBehaviour( contname )
        if not container:
          container = tnode.createBehaviour( VC_COMPONENTCONTAINER, contname )
    if container:
      grasp_cont = container
  if MultiGrasp.Value:
    count = 0
    multi_grasp_list = []
    while True:
      part = DetectionHelper( tool_name, bound )
      if not part:
        break
      multi_grasp_list.append(part)
      root_phys_entities = part.getBehavioursByType('rPhysicsEntity')
      for root_phys_entity in root_phys_entities:
        physicsType = root_phys_entity.getProperty('Physics Type')
        if physicsType.Value == 0:
          physicsType.Value = 2 # switch to kinematic
      # assembly handling
      if GraspIncludeEmptyAssemblies.Value == "No -Delete": 
        grasp_cont.grab(part, assemblymode=VC_GRAB_ASSEMBLY_DELETE_IF_EMPTY)
      elif GraspIncludeEmptyAssemblies.Value == "Yes": 
        grasp_cont.grab(part, assemblymode=VC_GRAB_ASSEMBLY_GRAB)
      else: grasp_cont.grab(part, assemblymode=VC_GRAB_ASSEMBLY_KEEP)
      
      grasped_components.append( part )
      count += 1
    grasp_association[output] = multi_grasp_list
    if count > 0:
      #grasped_components_name = grasped_components[-1].Name
      grasped_components_name = [x.Name for x in grasped_components]
      return 'Ok. {} component(s): "{}", Grasped.'.format(count,''.join(c for c in str(grasped_components_name) if c not in '[]' and c))
    else:
      return "No component detected to grasp"
  else:
    part = DetectionHelper( tool_name, bound )
    if part:
      grasp_association[output] = part
      root_phys_entities = part.getBehavioursByType('rPhysicsEntity')
      for root_phys_entity in root_phys_entities:
        physicsType = root_phys_entity.getProperty('Physics Type')
        if physicsType.Value == 0:
          physicsType.Value = 2 # switch to kinematic

      # assembly handling
      if GraspIncludeEmptyAssemblies.Value == "No -Delete": 
        grasp_cont.grab(part, assemblymode=VC_GRAB_ASSEMBLY_DELETE_IF_EMPTY)
      elif GraspIncludeEmptyAssemblies.Value == "Yes": 
        grasp_cont.grab(part, assemblymode=VC_GRAB_ASSEMBLY_GRAB)
      else: grasp_cont.grab(part, assemblymode=VC_GRAB_ASSEMBLY_KEEP)
      
      grasped_components.append( part )
      #grasped_components_name = [x.Name for x in grasped_components]
      grasped_components_name = grasped_components[-1].Name
      return 'Ok. Grasped component: "{}"'.format(''.join(c for c in str(grasped_components_name) if c not in '[]'))
    else:
      return "No component detected to grasp"


def MountTool( output, tool_name, bound, iface_name ):
  global robot, grasp_container, grasp_association
  part = DetectionHelper( tool_name, bound )
  if part:
    iface = comp.findBehaviour(iface_name)
    if iface:
      # check interfaces in the other component
      ifaces = part.findBehavioursByType(VC_ONETOONEINTERFACE )
      for other_iface in ifaces:
        if iface.canConnect(other_iface ):
          if iface.connect( other_iface, True ):
            return 'Ok, Mounted using ToolFrame: "{}". Mounted Component: "{}"'.format (tool_name, part.Name)
          else:
            return "Tool to mount has interface already connected"
      return "No matching interface detected to mount tool"
  else:
    return "No tool detected to mount"


def ReleaseHelper( part, detection_tolerance ):
  global robot
  part.update()
  # Detect where to release using offset at "gravity" direction
  # Basically just translate detected component in the world z axis direction downwards with tolerance value
  gravity = vcVector.new(0,0,-detection_tolerance)
  # Calculate gravity at node parent coordinate system ( reset translate component and use just rotation)
  invert_coord = part.Parent.InverseWorldPositionMatrix
  invert_coord.P = vcVector.new()
  node_gravity = invert_coord * gravity
  # Translate node using gravity
  # rint "Node gravity X=%f Y=%f Z=%f" % (node_gravity.X,node_gravity.Y,node_gravity.Z)
  orig_m = part.PositionMatrix
  pos_m = part.PositionMatrix
  pos = pos_m.P
  pos += node_gravity
  pos_m.P = pos
  part.PositionMatrix = pos_m
  if UpdateWorldIOnRelease.Value:
    sim.update()
  else:
    part.update()
  release_node = None
  detector = sim.newCollisionDetector()
  detector.DisplayCollisions = 0
  detector.NodeListA = [ (part, VC_NODELIST_INCLUDE, VC_NODELIST_COMPONENT ) ]
  detector.NodeListB = get_target_candidates()
  hit = detector.testOneCollision()
  # Restore location (minus gravity offset)
  part.PositionMatrix = orig_m
  part.update()
  if hit:
    return detector.getHitNodeB(0)
  else:
    return None


def get_target_candidates():
  target_candidates = [ (sim.World, VC_NODELIST_INCLUDE, VC_NODELIST_TREE ) , (comp, VC_NODELIST_EXCLUDE, VC_NODELIST_TREE )]
  target_candidates.extend([(x, VC_NODELIST_EXCLUDE, VC_NODELIST_COMPONENT ) for x in app.Components if exclude_release_target_test(x)]) #VC_NODELIST_COMPONENT
  return target_candidates


def exclude_release_target_test(icomponent):
  if icomponent in ExcludeReleasingToComponents.Value:
    return True
  if not DetectHiddenComponents.Value and not icomponent.Visible:
    return True
  for ignore_prop_name in ignore_as_release_target_filter_props:
    ignore_prop = icomponent.getProperty(ignore_prop_name)
    if ignore_prop and ignore_prop.Value:
      return True


def CheckNodeParentVisiblity(node): 
  if node.Parent.Name != "ROOT":
    if node.Visible == False:
      return node
    else:
      node = node.Parent 
      return CheckNodeParentVisiblity(node)



def Release( output, detection_tolerance ):
  global robot, grasp_container, grasp_association, grasped_components
  # Find first the part to be released
  physicsType = None
  set_phys = False
  part = None
  if len(grasped_components) == 0:
    return "No component to release"
  release_list = []
  if ASSOCIATE_GRASPING_TO_OUTPUT:
    try:
      if MultiGrasp.Value:
        multi_release_list = grasp_association[output] 
        if multi_release_list:
          release_list = multi_release_list
      else:
        part = grasp_association[output]
        release_list.append(part)
    except:
      pass
    if len(release_list)==0:
      return "No component associated to release with output %i" % output
  else:
    if MultiGrasp.Value:
      release_list = grasped_components
    else:
      release_list.append(grasped_components[0])
  grasp_association[output] = None
  count_to_physics = 0
  count_to_node = 0
  count_to_world = 0
  count_to_container = 0
  count_to_world_container = 0
  first_part = None
  release_list_name = [x.Name for x in release_list]
  for part in release_list:
    grasped_components.remove( part )
    if ReleaseToPhysics.Value == 'Always':
      set_phys = True
      release_node = sim.World
    elif first_part and BundleReleasedComponents.Value:
      release_node = first_part
    elif ReleaseToWorld.Value:
      release_node = sim.World
      if ReleaseToPhysics.Value != 'Never':
        set_phys = True
    else:
      release_node = ReleaseHelper( part, detection_tolerance )
      if not release_node:
        if ReleaseToPhysics.Value != 'Never':
          set_phys = True
        release_node = sim.World
    # Calculate position in relative to the detected component (NOTE: component origin)
    pos_m = release_node.InverseWorldPositionMatrix * part.WorldPositionMatrix
    pos = pos_m.P
    # Extract all containers what this node owns (containers where to release)
    if release_node != sim.World:
      ContainerList = release_node.getBehavioursByType(VC_CONTAINER)
    else:
      ContainerList = []
    if first_part and BundleReleasedComponents.Value:
      # Do not use container for bundled components
      ContainerList = []
    # Search closest container in the detected component
    BestContainer = None
    BestProximity = 1e10
    for cont in ContainerList:
      dist = cont.getContainerProximity( pos )
      if dist < 0.0: # Container with no physical limits return -1.0 value
        dist = 1e5
      if dist < BestProximity:
        BestContainer = cont
        BestProximity = dist
    # Release component to the closest container
    if BestContainer:
      # rint "Container \'%s\' found at proximity = %f" % (BestContainer.Name, BestProximity)
      
      # assembly handling
      if GraspIncludeEmptyAssemblies.Value == "No -Delete": BestContainer.grab(part, assemblymode=VC_GRAB_ASSEMBLY_DELETE_IF_EMPTY)
      elif GraspIncludeEmptyAssemblies.Value == "Yes": BestContainer.grab(part, assemblymode=VC_GRAB_ASSEMBLY_GRAB)
      else: BestContainer.grab(part, assemblymode=VC_GRAB_ASSEMBLY_KEEP)

      message = ""
      if release_node.Parent:
        count_to_container += 1
        message = "Ok, Released component {} to Node: {} container".format(''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Parent.Name)
      else:
        count_to_world_container += 1
        message = "Ok, Released component {} to world container".format(''.join(c for c in str(release_list_name) if c not in '[]'))
      if not MultiGrasp.Value:
        if set_phys:
          message = "Ok, Released component {} to physics".format(''.join(c for c in str(release_list_name) if c not in '[]'))
          setPhysics(part)
    else:
      # rint "No container found to release component, just connect it hierarchically"
      pos_m = release_node.InverseWorldPositionMatrix * part.WorldPositionMatrix
      part.PositionMatrix = pos_m
      release_node.attach(part, False)
      message = "Ok, "
      if release_node.Parent:
        count_to_node += 1
        if release_node.Parent.Name == 'ROOT':
          message += 'Attached component {} directly to Node: ROOT in Component: "{}".'\
                    .format(''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Component.Name)
        elif release_node.Component.Visible == False:
          message += 'Attached component {0} directly to Node: "{1}" in Component: "{2}".Attached COMPONENT: "{2}" is IN-VISIBLE'\
                     .format(''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Name, release_node.Component.Name)
        elif release_node.Visible == False:
          message += 'Attached component {0} directly to Node: "{1}" in Component: "{2}".Attached NODE: "{1}" is IN-VISIBLE'\
                       .format(''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Name, release_node.Component.Name)
        else:
          invisible_node = CheckNodeParentVisiblity(release_node)
          if not invisible_node:
            message += 'Attached component {} directly to Node: "{}" in Component: "{}".'\
                       .format(''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Name, release_node.Component.Name)
          else:
            message += 'Attached component {} directly to Node: "{}" in Component: "{}".Attached NODE: "{}" is IN-VISIBLE'\
                       .format(''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Name, release_node.Component.Name, invisible_node.Name)
      else:
        count_to_world += 1
        message = "Ok, Attached directly to world"
      if not MultiGrasp.Value:
        if set_phys:
          message = "Ok, Released to physics"
          setPhysics(part)
        return message
    if set_phys:
      count_to_physics += 1
      setPhysics(part)
    if not first_part and BundleReleasedComponents.Value:
      first_part = part
      first_part.update()
  #endfor
  message = "Ok, "
  if count_to_physics:
    message += "Released %i to physics. " % count_to_physics
  else:
    if count_to_node == 1:
      message += "Attached directly to node, "
    elif count_to_node > 1:
      if release_node.Parent.Name == 'ROOT':
        message += '{} component(s): {}, Attached directly to Node: ROOT in Component: "{}".'\
                    .format(count_to_node, ''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Component.Name)
      elif release_node.Component.Visible == False:
        message += '{0} component(s): {1},  Attached directly to Node: "{2}" in Component: "{3}".Attached COMPONENT: "{3}" is IN-VISIBLE'\
                  .format(count_to_node,''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Name, release_node.Component.Name)
      elif release_node.Visible == False:
        message += '{0} component(s): {1}, Attached directly to Node: "{2}" in Component: "{3}".Attached NODE: "{2}" is IN-VISIBLE'\
                    .format(count_to_node, ''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Name, release_node.Component.Name)
      else:
        invisible_node = CheckNodeParentVisiblity(release_node)
        if not invisible_node:
          message += '{} component(s): {}, Attached directly to Node: "{}" in Component: "{}".'\
                    .format(count_to_node, ''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Name, release_node.Component.Name)
        else:
          message += '{} component(s): {}, Attached directly to Node: "{}" in Component: "{}".Attached NODE: "{}" is IN-VISIBLE'\
                    .format(count_to_node, ''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Name, release_node.Component.Name, invisible_node.Name)

    if count_to_world == 1:
      message += "Attached component: {} directly to world.".format(''.join(c for c in str(release_list_name) if c not in '[]'))
    elif count_to_world > 1:
          message += " {} component(s): {}, Attached directly to world".format(count_to_world, ''.join(c for c in str(release_list_name) if c not in '[]'))
    if count_to_container == 1:
      message += 'Released component: {} to Node container in Component: {}'.format(''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Name)
    elif count_to_container > 1:
          message += '{} component(s): {}, Released to Node in Component: "{}".'\
                    .format(count_to_container, ''.join(c for c in str(release_list_name) if c not in '[]'), release_node.Name)
    if count_to_world_container == 1:
      message += "Released component: {} to world container"\
                  .format(''.join(c for c in str(release_list_name) if c not in '[]'))
    elif count_to_world_container > 1:
          message += "{} component(s): {}, Released to world container."\
                      .format(count_to_world_container, ''.join(c for c in str(release_list_name) if c not in '[]'))
  return message


def setPhysics(part):
  root_phys_entities = part.getBehavioursByType('rPhysicsEntity')
  if root_phys_entities:
    root_phys_entity = root_phys_entities[0]
  else:
    root_phys_entity = part.createBehaviour('rPhysicsEntity', 'PhysicsEntity')
  physicsType = root_phys_entity.getProperty('Physics Type')
  physicsType.Value = 0


def UnmountTool( output, detection_tolerance, iface_name ):
  global robot, grasp_container
  # Look first the gripper to be released
  iface = comp.findBehaviour(iface_name)
  if not iface:
    return
  gripper = iface.ConnectedComponent
  if not gripper:
    return "No tool to UnMount"
  # Unconnect interface
  if UpdateWorldIOnRelease.Value:
    sim.update()
  else:
    gripper.update()
  world_pos = gripper.WorldPositionMatrix
  other_iface = iface.ConnectedSection.ConnectedToSection.Interface
  # look if gripper can be released to some other component pallet etc.
  release_node = ReleaseHelper( gripper, detection_tolerance )
  if not release_node:
    if not ReleaseToWorld.Value:
      iface.unConnect(other_iface)
      return "No component detected to UnMount tool to"
    release_node = sim.World
  # Calculate position in relative to the detected component (NOTE: component origin)
  pos_m = release_node.InverseWorldPositionMatrix * gripper.WorldPositionMatrix
  pos = pos_m.P
  iface.unConnect(other_iface)
  # Extract all containers what this node owns (containers where to release)
  ContainerList = release_node.getBehavioursByType(VC_CONTAINER)
  # Search closest container in the detected component
  BestContainer = None
  BestProximity = 1e10
  for cont in ContainerList:
    dist = cont.getContainerProximity( pos )
    if dist < 0.0: # Container with no physical limits return -1.0 value
      dist = 1e5
    if dist < BestProximity:
      BestContainer = cont
      BestProximity = dist
  # Release component to the closest container
  if BestContainer:
    # rint "Container \'%s\' found at proximity = %f" % (BestContainer.Name, BestProximity)
    BestContainer.grab( gripper )
    if release_node.Parent:
      return 'Ok, UnMounted Component: "{}" directly to Container: "{}" in Component: "{}"'.format(gripper.Name, release_node.Name, release_node.Component.Name)
    else:
      return 'Ok, UnMounted Component: "{}" to World container'.format(gripper.Name)
  else:
    # rint "No container found to release component"
    gripper.update()
    pos_m = release_node.InverseWorldPositionMatrix * world_pos
    gripper.PositionMatrix = pos_m
    release_node.attach(gripper, False)
    if release_node.Parent:
      return 'Ok, UnMounted Component: "{}" directly to Node: "{}" in Component: "{}"'.format(gripper.Name, release_node.Name, release_node.Component.Name)
    else:
      return 'Ok, UnMounted Component: "{}" directly to World'.format(gripper.Name)


def TraceOn( port, tool_name, node_name, color ):
  global robot, grasp_container, traces, trace_lines, world
  # Find out if trace is already active
  for trace in traces:
    if trace.Port == port:
      return
  # Following code sets a specific tool and extracts tool matrix in world coordinate system
  # This transformation is then applied to the bound box defining volume.
  mat = app.findMaterial(color)
  layer = app.findLayer(TRACE_LAYER)
  world = sim.World
  container = None
  cnode = None
  if node_name != "":
    parts = node_name.split("::",2)
    if len(parts) == 1:
      ctrcmp = comp
      nname = parts[0]
    else:
      ctrcmp = app.findComponent(parts[0])
      nname = parts[1]
    if ctrcmp != None:
      cnode = ctrcmp.findNode(nname)
    else:
      cnode = None
    if cnode != None:
      container = cnode.UserGeometry
  if container == None:
    container = world.UserGeometry
  if cnode == None:
    cnode = world
  # Create trace object, which is used at updating
  trace = Trace()
  trace.Tool = Tool(tool_name)
  trace.Port = port
  trace.ToolName = tool_name
  trace.Base = Base(tool_name)
  trace.BaseName = tool_name
  trace.Node = cnode
  trace.Material = color
  trace.LineSet = container.createGeometrySet(VC_COMPACTLINESET)
  trace_lines.append(trace.LineSet)
  trace.LineSet.Name = "TRACE"
  trace.LineSet.Material = mat
  trace.LineSet.Layer = layer
  trace.LineSet.LineWidth = TraceWidth.Value
  trace.Robot = robot

  m = CalcTracePosition( trace )
  trace.Point = m.P
  traces.append(trace)
  resumeRun()
  return "Ok"


def TraceOff( tool_name ):
  global robot, grasp_container, traces
  trace = None
  for t in traces:
    if t.ToolName == tool_name:
      trace = t
      break
    if t.BaseName == tool_name:
      trace = t
      break
  if trace:
    '''
    # light effects
    if trace.Light:
      trace.Light.Enabled = False'''
    m = CalcTracePosition( trace )
    trace.Node.update()
    trace.LineSet.addLine([trace.Point, m.P])
    trace.LineSet.update()
    traces.remove(trace)
  CheckIfSuspendRun()
  return "Ok"


class SweptVol:
  def __init__(self, sv_item):
    self.SV = sv_item
    self.IsEnabled = False


def SweptVolumeOn( port, action):
  global sweptVolumeItems
  if not app.OnComponentRemoved:
    app.OnComponentRemoved = ComponentRemoved
  ready = False
  # create new sv with unique name
  for sv_index in range(10000):
    svName = "%s_SweptVolume_%i_%i" % (comp.Name, port, sv_index)
    sv_item = app.findLayoutItem(svName)
    if not sv_item:
      break
  sv_item = app.createLayoutItem(VC_LAYOUTITEM_IT_SWEPTVOLUME)
  sv_item.Name = svName

  # SET SWEPT VOLUME PROPERTIES
  sv_item.Material = action.Material
  sv_item.Decomposition = VC_CONVEXHULL  # # VC_DECOMPOSITION | VC_CONVEXHULL | VC_CONVEXHULL_TRIMESH
  if action.SweptMethod == "HullFromHulls":
    sv_item.method = VC_SWEPT_HULL_FROM_HULLS
  elif action.SweptMethod == "HullFromSilhouettes":
    sv_item.method = VC_SWEPT_HULL_FROM_SILHOUETTES
  else:
    sv_item.method = VC_SWEPT_LOFTING
  if not action.SweptGeometry:
    return "Please include node for Geometry"
  swept_nodes_list = action.SweptGeometry
  if swept_nodes_list == [comp]:
    # add the whole kinematic chain of the robot (including eoat) if only the robot root node is configured
    kids = comp.Children
    while kids:
      nnode = kids.pop(0)
      kids.extend(nnode.Children)
      swept_nodes_list.append(nnode)
  sv_item.InputNodeList = [(x,VC_NODELIST_INCLUDE,VC_NODELIST_NODE) for x in swept_nodes_list]
  # DEFINE node where to attach the wsept volume
  if action.AttachTo == "Node":
    sv_item.TargetNode = action.TargetNode
  elif action.AttachTo == "Closest":
    tool_name = action.UsingTool
    bound = action.DetectionVolumeSize
    target_node = DetectionHelper( tool_name, bound )
    if not target_node:
      return 'Target node for attaching the swept volume not detected.'
    else:
      sv_item.TargetNode = target_node
  else:
    #create new component
    c = app.findComponent(svName + "_result")
    if not c: # new component is created only if existing component is not found
      c = app.createComponent()
      c.Name = svName + "_result"
    sv_item.TargetNode = c
  #print 'start', sv_item.TargetNode
  sv_item.begin()
  resumeRun()
  sweptVolumeItems[port].append([sv_item,True])
  return "Ok."


def SweptVolumeOff(port, store):
  global sweptVolumeItems
  sv_list = sweptVolumeItems.get(port, [])
  if sv_list:
    sweptVolumeItems[port][-1][1] = False #set enabled flag to false
    sweptVolumeItems[port][-1][0].end()
    if store:
      sweptVolumeItems[port][-1][0].store()
    CheckIfSuspendRun()


def CalcTracePosition( trace ):
  if trace.Node != world:
    trace.Node.update()
  # If trace is drawn by the tool
  if trace.Tool:
    tnode = trace.Tool.Node
    tnode.update()
    m = trace.Tool.PositionMatrix
    m = tnode.WorldPositionMatrix * m
  #if trace is drawn by the base
  elif trace.Base:
    tnode = trace.Base.Node
    if tnode:
      tnode.update()
      tnode_mtx = tnode.WorldPositionMatrix
    else:
      comp.update()
      tnode_mtx = comp.WorldPositionMatrix * controller.WorldTransformMatrix
    m = trace.Base.PositionMatrix
    m = tnode_mtx * m
  else:
    tnode = robot.FlangeNode
    tnode.update()
    m = vcMatrix.new()
    m = tnode.WorldPositionMatrix * m
  '''
  # light effects
  light = trace.Light
  if light and light.Enabled:
    light.Position = m.P
    light.Direction = m.A
    particles = trace.Particles
    if particles:
      ppm = particles.PositionMatrix
      ppm.P = m.P
      particles.PositionMatrix = ppm'''
  if TraceZOffset.Value:
    m.translateRel( 0., 0., -TraceZOffset.Value )
  return trace.Node.InverseWorldPositionMatrix * m


def CheckIfSuspendRun():
  global traces, sweptVolumeItems
  if len(traces) == 0 and not isActiveSwepts():
    suspendRun()


def isActiveSwepts():
  for port, sv_list in sweptVolumeItems.iteritems():
    for sv in sv_list:
      sv_item = sv[0]
      enabled = sv[1]
      if enabled:
        return True
  else:
    return False


def ComponentRemoved(component):
  for port,sv_list in sweptVolumeItems.iteritems():
    for sv, enabled in sv_list:
      if sv.TargetNode and sv.TargetNode.Component == component:
        #Clean up target node on swept volume and its action
        sweptVolumeItems[port] = []
        for actions in all_actions:
          for act in actions.Actions:
            if act.Port == port and act.Value and act.Name:
              act.AttachTo = 'NewComponent'


def OnRun():
  global robot, grasp_container, traces
  CheckIfSuspendRun()
  # Adaptive trace step size quality factor
  factor = 0.25 # 0.1=smallest error - 1.0=largest error
  min_factor = 0.01*factor

  while True:
    max_dist = 0.0
    min_time = 0.05
    for trace in traces:
      m = CalcTracePosition( trace )
      dist = (trace.Point-m.P).length()
      if dist > EPSILON:
        trace.LineSet.addLine([trace.Point, m.P])
        trace.Point = m.P
        trace.LineSet.update()
        if dist > max_dist:
            max_dist = dist
    # Calculate traces step size based on fastest moving trace
    if max_dist > 0.0:
      min_time = factor/max_dist
      if min_time > 0.05:
          min_time = 0.05
      if min_time < min_factor:
          min_time = min_factor
      # print "max_dist = ", max_dist, " min_time =", min_time
    delay(min(min_time,sim.SimSpeed))
    for port,sv_list in sweptVolumeItems.iteritems():
      for sv, enabled in sv_list:
        if enabled:
          sv.next()


def OnReset():
  global robot, grasp_container, trace, trace_lines, sweptVolumeItems
  '''
  # light effects
  light = app.findLight( "Torch"+comp.Name )
  if light:
    light.Enabled = False'''
  if app.OnComponentRemoved:
    app.OnComponentRemoved = None
  if sim:
    for line in trace_lines:
      ctr = line.Container
      ctr.deleteGeometrySet(line)
    trace_lines = []
  for port, sv_list in sweptVolumeItems.iteritems():
    for sv in sv_list:
      sv_item = sv[0]
      sv_item.end()
      sv_item.clear()
      app.deleteLayoutItem(sv_item)
  sweptVolumeItems = {}


def OnFinalize():
  global controller, flange_node_tool_interface
  #Hide some default behavior props to make property panel cleaner
  comp = getComponent()
  isVisible = False
  bs = comp.findBehavioursByType(VC_ROBOTEXECUTOR)
  if bs:
    exe = bs[0]
    controller = exe.Controller
    controller_flange_node = controller.FlangeNode
    flange_node_tool_interface = controller_flange_node.getBehavioursByType(VC_ONETOONEINTERFACE)[0]
    flange_node_tool_interface.OnConnect = UpdateToolOnConnect
    flange_node_tool_interface.OnDisconnect = UpdateToolOnDisConnect
    exe.getProperty('StatementHandler').IsVisible = isVisible
    if exe.DigitalInputSignals:
      exe.DigitalInputSignals.getProperty('Ports').IsVisible = isVisible
    if exe.DigitalOutputSignals:
      exe.DigitalOutputSignals.getProperty('Ports').IsVisible = isVisible
    if exe.Controller:
      kin = exe.Controller.Kinematics
      if kin and kin.Type == VC_ARTICULATEDKINEMATICS2:
        kin.getProperty('PalletizingMode').IsVisible = isVisible
        kin.getProperty('PalletizingNormal').IsVisible = isVisible
  cont = comp.findBehaviour('GraspContainer')
  if cont:
    cont.getProperty('Capacity').IsVisible = isVisible
  

# Configure actions and their visibility
AutoConfigure()
if app.findCommand(CONFIGURE_DIALOG_CMD):
  prop1 = comp.getProperty(ACTION_BUTTON1)
  prop1.OnChanged = GraspReleaseConfiguration
  prop1.IsVisible = True
else:
  prop1 = comp.getProperty(ACTION_BUTTON1)
  prop1.IsVisible = False


def DetectionVolumeOnRender(simulation):
  global detection_volume_tool

  if simulation.IsRunning and DetectionVolumeVisiblity.Value:
    DetectionVolumeVisiblity.Value = False
  else:
    if DetectionVolumeVisiblity.Value == True:
      GenerateDetectionGeometrySet(detection_volume_tool,DetectionVolumeGeometry)


app.OnRender = DetectionVolumeOnRender
