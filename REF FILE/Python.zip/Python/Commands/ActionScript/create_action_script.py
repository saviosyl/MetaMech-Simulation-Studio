from vcCommand import *

MOUNTPLATE_NAME = "mountplate"
GRASP_CONTAINER = "GraspContainer"

# Script template is now read already at application start to command property
# what robot execution conversion can also access


def first_state():
  script_text = getProperty("ScriptText")
  app = getApplication()
  context = app.CurrentContext
  if context.Id != VC_CONTEXT_AUTHOR:
    return 
  
  node = context.ActiveNode
  if node == None:
    node = context.ActiveComponent

  if node:
    beh = node.findBehaviour("ActionScript")
    if beh:
      print 'This node already has an existing ActionScript, please delete or rename it before creating a new one.'
      return
    sanitizeComponent(node.Component)
    beh = node.createBehaviour(VC_SCRIPT, "ActionScript")
    beh.Script = script_text.Value

def sanitizeComponent(comp):
  # flange
  flange = comp.findNode(MOUNTPLATE_NAME)
  if not flange:
    flange = autoCreateFlangeNode(comp)
  # container
  container = comp.findBehaviour(GRASP_CONTAINER)
  if not container:
    container = flange.createBehaviour(VC_COMPONENTCONTAINER,GRASP_CONTAINER)
  else:
    if container.Parent != flange:
      container.delete()
      container = flange.createBehaviour(VC_COMPONENTCONTAINER,GRASP_CONTAINER)
  # statistics
  stats = comp.findBehavioursByType(VC_STATISTICS)
  if stats:
    stats = stats[0]
  else:
    stats = comp.createBehaviour(VC_STATISTICS, 'Statistics')
  if not container.Statistics:
    container.Statistics = stats
  if not stats.States:
    states =  [('Warmup', 1), ('Break', 2), ('Setup', 1), ('Idle', 3), ('Busy', 4), ('Blocked', 5), ('Broken', 6), ('Repair', 7)]
    stats.States = states
  # executor
  executors = comp.findBehavioursByType(VC_ROBOTEXECUTOR )
  if executors:
    executor = executors[0]
  else:
    executor = comp.createBehaviour(VC_ROBOTEXECUTOR, 'Executor')
  #if not executor.Statistics: 
  ### COMMENTED OUT BECAUSE NEW ROBOT EXECUTOR DOESN'T SUPPORT STATES YET
  #  executor.Statistics = stats 
  # signal map IN
  if not executor.DigitalInputSignals:
    inmap = comp.findBehaviour('Inputs')
    if not inmap:
      inmap = comp.createBehaviour(VC_BOOLEANSIGNALMAP, 'Inputs')
      inmap.PortCount = 200
      inmap.Listeners = [executor]
    executor.DigitalInputSignals = inmap
  # signal map OUT
  if not executor.DigitalOutputSignals:
    outmap = comp.findBehaviour('Outputs')
    if not outmap:
      outmap = comp.createBehaviour(VC_BOOLEANSIGNALMAP, 'Outputs')
      outmap.PortCount = 200
      outmap.Listeners = [executor]
    executor.DigitalOutputSignals = outmap
  # controller
  if not executor.Controller:
    controllers = comp.findBehavioursByType(VC_ROBOTCONTROLLER )
    if controllers:
      controller = controllers[0]
    else:
      controller = comp.createBehaviour(VC_ROBOTCONTROLLER, 'Controller')
    for i in range(len(controller.Bases),16):
      base = controller.addBase()
      base.Name = 'BASE_%i' % (i+1)
    for i in range(len(controller.Joints),16):
      tool = controller.addTool()
      tool.Name = 'TOOL_%i' % (i+1)
      tool.Node = flange
    executor.Controller = controller
  else:
    controller = executor.Controller
  # kinematics
  if not controller.Kinematics:
    for kinem_type in [VC_ARTICULATEDKINEMATICS,
                        VC_ARTICULATEDKINEMATICS2,
                        VC_CARTESIANKINEMATICS,
                        VC_DELTAKINEMATICS,
                        VC_PARALLELLOGRAMKINEMATICS,
                        VC_SCARAKINEMATICS,
                        VC_PYTHONKINEMATICS]:
      kinems = comp.findBehavioursByType( kinem_type )
      if kinems:
        kinems = kinems[0]
        break
    if not kinems:
      kinems = comp.createBehaviour(VC_CARTESIANKINEMATICS, 'Kinematics')
      print 'Action script warning: Default kinematics type "cartesian" associated with the controller.'
    controller.Kinematics = kinems



def autoCreateFlangeNode(comp):
  nodes = [comp]
  while nodes:
    lastnode = nodes.pop(0)
    nodes.extend( [x for x in lastnode.Children if x.Type == VC_NODE])
  flange = lastnode.createNode(VC_NODE, MOUNTPLATE_NAME)
  return flange


# Register state
addState( first_state )