
#---------------------#
#                     #
# AUTO I/O FUNCTIONS  #
#                     #
#---------------------#

ROBOT_INTERFACE_NAME = "EOAT_MountInterface"
CONTROL_OPTIONS = ["IO","ExternalAxis"]

# IF AutoIOs IS ENABLED, CREATES INPUT AND OUTPUT DICTIONARIES FOR EACH SIGNAL WHICH PORT TO CONNECT
def EvaluateConnections():
  inDict, outDict = {}, {}
  if not autoIOs_prop:
    return
  elif autoIOs_prop.Value:
    for prop in comp.Properties:
      if prop.Name[0:len(TABNAME)] == TABNAME and prop.Name[-5:] == "_Port":
        signal_name = prop.Name[len(TABNAME):-5]
        if signal_name[0:len(IN_PREFIX)] == IN_PREFIX:
          inDict[signal_name] = prop.Value
        elif signal_name[0:len(OUT_PREFIX)] == OUT_PREFIX:
          outDict[signal_name] = prop.Value
  return inDict, outDict

def ConnectSignals(map, dict):
  for signal_name in dict:
    signal = comp.findBehaviour(signal_name)
    if signal:
      to_signal = dict[signal_name]
      print '{}: Connecting signals to robot'.format(comp.Name)
      #print '{}: Connecting signal "{}" to port {}'.format(comp.Name,signal.Name,to_signal)
      map.connect(to_signal, signal)
    else:
      print '{}: Signal "{}" not found.'.format(comp.Name,signal_name)

# CONNECT SIGNALS WHEN GRIPPER IS CONNECTED
def onConnectEvent(otherIface, offset):
  global inDict, outDict, inMap, outMap, control_prop
  if autoIOs_prop:
    if not autoIOs_prop.Value:
      return
  if control_prop:
    if control_prop.Value != CONTROL_OPTIONS[0]:
      return
  if comp.NodeInitialized:
    robotComp = otherIface.Component
    if robotComp.NodeInitialized:
      exes = robotComp.findBehavioursByType(VC_ROBOTEXECUTOR)
      if exes:
        exe = exes[0]
        outMap = exe.DigitalOutputSignals
        inMap = exe.DigitalInputSignals
        inDict, outDict = EvaluateConnections()
        ConnectSignals(inMap,outDict)
        ConnectSignals(outMap,inDict)

# DISCONNECT SIGNALS WHEN GRIPPER IS DISCONNECTED
def onDisConnectEvent(otherIface):
  global inMap, outMap
  try:
    if comp.NodeInitialized:
      robotComp = otherIface.Component
      if robotComp.NodeInitialized:
        exes = robotComp.findBehavioursByType(VC_ROBOTEXECUTOR)
        if exes:
          exe = exes[0]
          outMap = exe.DigitalOutputSignals
          inMap = exe.DigitalInputSignals
          for i in range(inMap.PortCount):
            signals = inMap.getConnectedExternalSignals(i)
            for signal in signals:
              if signal.Name in OUTPUT_SIGNAL_NAMES:
                inMap.disconnect(i)
                print '{}: Disconnecting signals'.format(comp.Name)
          for i in range(outMap.PortCount):
            signals = outMap.getConnectedExternalSignals(i)
            for signal in signals:
              if signal.Name in INPUT_SIGNAL_NAMES:
                outMap.disconnect(i)
                print '{}: Disconnecting signals'.format(comp.Name)
  except:
    pass

def AutoConnectChanged(arg):
  for p in comp.Properties:
    if TABNAME and "_Port" in p.Name:
      if arg.Value:
        p.WritableWhenDisconnected = True
      else:
        p.WritableWhenDisconnected = False

iface = comp.findBehaviour(ROBOT_INTERFACE_NAME)
iface.OnConnect = onConnectEvent
iface.OnDisconnect = onDisConnectEvent

def OnStart():
  iface.OnConnect = None
  iface.OnDisconnect = None

def OnReset():
  iface.OnConnect = onConnectEvent
  iface.OnDisconnect = onDisConnectEvent

control_prop = comp.getProperty(TABNAME+"ControlMode")
autoIOs_prop = comp.getProperty(TABNAME+"AutoConnectIOs")
if autoIOs_prop:
  autoIOs_prop.OnChanged = AutoConnectChanged

inDict, outDict = EvaluateConnections()

