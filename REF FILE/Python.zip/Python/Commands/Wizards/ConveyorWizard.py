from vcCommand import *
import vcMatrix, vcVector
from vcHelpers.Selection import *
app = getApplication()
creator_template_part = '87ac5548-5c66-4e9f-8bc6-1157da1d1509'


def first_state():
  global comp, node, mode_prop, frames_prop, direction_prop, apply_prop, processorIface_prop, creator_prop
  global them_frames, void_prop, inputs, outputs, inconnection_prop, outconnection_prop, interpolation_prop
  cmd = getCommand()
  for p in cmd.Properties:
    deleteProperty(p)

  context = app.CurrentContext
  if context.Id != VC_CONTEXT_AUTHOR:
    'This command can be called from modeling context only'
    return
  comp = context.ActiveComponent
  node = context.ActiveNode
  #print comp, node
  if not comp:
    warning('Please select 1 Node and 1 Node only.')
    return
  group = 0
  if not node:
    node = comp
  # property for choosing automatic frames or choose from list
  mode_prop = createProperty(VC_STRING, 'Frame Mode', VC_PROPERTY_STEP)
  mode_prop.StepValues = ['Auto create on top face', 'Choose Manually']
  mode_prop.Value = 'Auto create on top face'
  mode_prop.IsVisible = True
  mode_prop.Group = group = group + 10
  mode_prop.OnChanged = frameModeChange

  # create boolean prop for each frame
  all_them_feas = getGivenNodesFeatures(node)
  all_them_frames = [x for x in all_them_feas if x.Type == VC_FRAME]
  them_frames = []
  all_them_frames.sort(key = lambda x: x.Name)
  for frame in all_them_frames:
    frame_prop = createProperty(VC_BOOLEAN, frame.Name)
    frame_prop.IsVisible = False
    frame_prop.Group = group = group + 10
    them_frames.append([frame.Name, frame_prop, frame])

  # create void property list space holder
  #           (shown if user wants to choose frames and no frames present)
  void_prop = createProperty(VC_BUTTON, 'No pre-created frames found')
  void_prop.IsVisible = False
  void_prop.Group = group = group + 10

  # direction of the conveyor (shown in auto mode only)
  direction_prop = createProperty(VC_STRING, 'Conveyor Direction', VC_PROPERTY_STEP)
  direction_prop.StepValues = ['X', '-X', 'Y', '-Y']
  direction_prop.Value = 'X'
  direction_prop.IsVisible = True
  direction_prop.Group = group = group + 10

  # where to connect the input of the path
  inconnection_prop = createProperty(VC_STRING, 'Input Connection', VC_PROPERTY_STEP)
  outputs = findConnectors(VC_CONNECTOR_OUTPUT)
  keys = outputs.keys()
  keys.sort()
  prop_vals = ['None','Auto create in interface']
  for output_name in keys:
    prop_vals.append( output_name )
  inconnection_prop.StepValues = prop_vals
  inconnection_prop.Value = 'Auto create in interface'
  inconnection_prop.IsVisible = True
  inconnection_prop.Group = group = group + 10

  # where to connect the output of the path
  outconnection_prop = createProperty(VC_STRING, 'Output Connection', VC_PROPERTY_STEP)
  inputs = findConnectors(VC_CONNECTOR_INPUT)
  keys = inputs.keys()
  keys.sort()
  prop_vals = ['None','Auto create out interface']
  for input_name in keys:
    prop_vals.append( input_name )
  outconnection_prop.StepValues = prop_vals
  outconnection_prop.Value = 'Auto create out interface'
  outconnection_prop.IsVisible = True
  outconnection_prop.Group = group = group + 10

  # this property is hidden and always true to make it simpler for user
  processorIface_prop = createProperty(VC_BOOLEAN, 'Add Processor Interface')
  processorIface_prop.Value = True
  processorIface_prop.IsVisible = False
  processorIface_prop.Group = group = group + 10

  # option to add component creator
  creator_prop = createProperty(VC_BOOLEAN, 'Add Creator At Path Begin')
  creator_prop.Group = group = group + 10

  # choose the interpolation mode
  interpolation_prop = createProperty(VC_STRING, 'Path Interpolation', VC_PROPERTY_STEP)
  interpolation_prop.StepValues = ['Step', 'Linear', 'Cubic']
  interpolation_prop.Value = 'Linear'
  interpolation_prop.IsVisible = True
  interpolation_prop.Group = group = group + 10

  # button to execute the command
  apply_prop = createProperty(VC_BUTTON, 'Create Conveyor Behaviours')
  apply_prop.Group = group = group + 10
  apply_prop.OnChanged = createConveyorBehaviours
  executeInActionPanel()


def findConnectors(connector_type):
  '''
  finds all connector matching the given (input or output) -type
    (adds the bidirectional connectors too)
  '''
  connectors = {}
  behs = comp.findBehavioursByType(VC_CONTAINER)
  for b in behs:
    for c in b.Connectors:
      if c.Type in [connector_type, VC_CONNECTOR_INPUT_OUTPUT ]:
        connectors[b.Name+'::'+c.Name] = c
  return connectors


def frameModeChange(arg):
  '''
  show and hide frame related boolean properties
  '''
  if arg.Value == 'Auto create on top face':
    for val in them_frames:
      val[1].IsVisible = False
    direction_prop.IsVisible = True
    void_prop.IsVisible = False
  else:
    for val in them_frames:
      val[1].IsVisible = True
    direction_prop.IsVisible = False
    if not them_frames:
      void_prop.IsVisible = True
    else:
      pass
      #void_prop.IsVisible = False


def getNewFrameNames():
  i = 0
  while i<10000:
    i+=1
    fname1 = 'PathFrame_%i' % (i)
    fname2 = 'PathFrame_%i' % (i+1)
    fname3 = 'PathFrame_%i' % (i+2)
    if not any([comp.findFeature( fname1 ), comp.findFeature( fname2 ), comp.findFeature( fname3 )]):
      return fname1, fname2, fname3
  return 'ff__1', 'ff__2', 'ff__3'



def createConveyorBehaviours(arg):
  '''
  master function
  '''
  frames = []
  if mode_prop.Value == 'Auto create on top face':
    # Extract component dimensions
    L = node.BoundDiagonal.X*2
    W = node.BoundDiagonal.Y*2
    top_elevation = node.BoundDiagonal.Z + node.BoundCenter.Z

    # Create transform for frames
    iii = 0
    while iii<10000:
      iii+=1
      tr_name = 'PathFrames_%i' % iii
      if not comp.findFeature(tr_name):
        transf = node.RootFeature.createFeature(VC_TRANSFORM, tr_name)
        break
    m = vcMatrix.new()
    vec = vcVector.new(node.BoundCenter.X, node.BoundCenter.Y, top_elevation)
    m.P = vec
    rotations = {'X':0, '-X':180, 'Y':90, '-Y':-90}
    m.rotateRelZ( rotations[direction_prop.Value] )
    transf.PositionMatrix = m
    # Create three frames forming path
    them_all_frames = getGivenNodesFeatures(comp)
    them_all_frames = [x for x in them_all_frames if x.Type == VC_FRAME]
    framename1, framename2, framename3 = getNewFrameNames()
    frame1 = transf.createFeature(VC_FRAME, framename1)
    frame2 = transf.createFeature(VC_FRAME, framename2)
    frame3 = transf.createFeature(VC_FRAME, framename3)
    if 'X' in direction_prop.Value:
      D = L
    elif 'Y' in direction_prop.Value:
      D = W
    m = vcMatrix.new()
    m.translateRel(-D/2,0,0)
    frame1.PositionMatrix = m
    m = vcMatrix.new()
    m.translateRel(0,0,0)
    frame2.PositionMatrix = m
    m = vcMatrix.new()
    m.translateRel(D/2,0,0)
    frame3.PositionMatrix = m
    frames = [frame1, frame2, frame3]
  else:
    frames = []
    for val in them_frames:
      if val[1].Value:
        frames.append( val[2] )
    if not frames:
      warning('No frame features added to the Frames-list\nAdd frames or change the "Frame Mode"')
      return
  # statistics
  stats = node.createBehaviour(VC_STATISTICS, 'Statistics')

  # Create path
  path = node.createBehaviour(VC_ONEWAYPATH, 'Path')
  path.Path = frames
  interpolation_options = dict( zip(['Step', 'Linear', 'Cubic'],  [VC_PATH_STEP, VC_PATH_LINEAR, VC_PATH_CUBIC]) )
  path.Interpolation = interpolation_options[interpolation_prop.Value]
  if hasattr(path, 'Statistics'):
    path.Statistics = stats
  
  # create signal and connect to path
  signal = node.createBehaviour(VC_BOOLEANSIGNAL, 'PowerOnSignal')
  signal.Connections = [path]

  # Add Creator
  if creator_prop.Value:
    creator = node.createBehaviour(VC_COMPONENTCREATOR, 'ComponentCreator')
    creator.Location = frames[0]
    creator.Interval = 5
    creator.Limit = 99999
    creator.Part = 'vcid:' + creator_template_part
    creator.getConnector('Output').connect( path.getConnector('Input') )
    if hasattr(creator, 'Statistics'):
        creator.Statistics = stats
    input_connector = creator.getConnector('Input')
    input_beh = creator
  else:
    input_connector = path.getConnector('Input')
    input_beh = path


  # Input
  if inconnection_prop.Value == None:
    pass
  elif inconnection_prop.Value == 'Auto create in interface':
    # Create Interface
    iface = node.createBehaviour(VC_ONETOONEINTERFACE, 'InInterface')
    isection = iface.createSection('Section')
    isection.Frame = frames[0]
    flow = isection.createField(VC_FLOWFIELD,'FlowIn')
    flow.Container = input_beh
    for i, connector in enumerate(input_beh.Connectors):
      if connector == input_connector:
        flow.Port = i
  elif inconnection_prop.Value in outputs.keys():
    # connect to an existing connector
    outputs[inconnection_prop.Value].connect( input_connector )

  # Output
  if outconnection_prop.Value == None:
    pass
  elif outconnection_prop.Value == 'Auto create out interface':
    # Create Interface
    iface = node.createBehaviour(VC_ONETOONEINTERFACE, 'OutInterface')
    isection = iface.createSection('Section')
    isection.Frame = frames[-1]
    flow = isection.createField(VC_FLOWFIELD,'FlowOut')
    flow.Container = path
    flow.Port = 1
  elif outconnection_prop.Value in inputs.keys():
    # connect to an existing connector
    inputs[outconnection_prop.Value].connect( path.getConnector('Output') )


  # processor interface
  if processorIface_prop.Value:
    # add processor Iface for connecting sensors etc.
    iface = node.createBehaviour(VC_ONETOMANYINTERFACE, 'SensorInterface')
    #isection = iface.createSection('Section')
    isection = iface.Sections[0] #This for one to many
    field = isection.createField(VC_PROCESSORFIELD ,'PROCESSORFIELD')
    field.Parent = True
    field.Path = path


  comp.rebuild()
  getApplication().render()

def warning(s):
  print 'Wizard error: %s' % s

addState( first_state )