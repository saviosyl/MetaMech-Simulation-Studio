from __future__ import with_statement
from vcCommand import *
import os.path, vcMatrix, vcVector

app = getApplication()

def first_state():
  global add_prop, del_prop, comp, appl, servo
  cmd = getCommand()
  context = app.CurrentContext
  if context.Id != VC_CONTEXT_AUTHOR:
    'This command can be called from modeling context only'
    return
  comp = context.ActiveComponent
  if not comp:
    warning('Please select 1 Component and 1 Component only.')
    return
  for p in cmd.Properties:
    deleteProperty(p)
  group = 0
  servos = comp.findBehavioursByType(VC_SERVOCONTROLLER)
  if not servos:
    warning('No servo controller found. Please configure a servo controller first.')
    return
  servo = servos[0]
  #
  controls_prop = createProperty(VC_STRING, 'Positioner Type', VC_PROPERTY_STEP)
  controls_prop.StepValues = ['Workpiece Positioner', 'Robot Positioner']
  controls_prop.Value = 'Workpiece Positioner'
  controls_prop.Group = group = group + 10
  #
  #snap_mount_prop = createProperty(VC_BUTTON, 'SnapMount')
  #snap_mount_prop.OnChanged = snapMount
  #snap_mount_prop.Group = group = group + 10
  #
  controls_prop = createProperty(VC_STRING, 'Flange Node', VC_PROPERTY_STEP)
  controls_prop.StepValues = [x.Name for x in findAllNodes()]
  controls_prop.Value = controls_prop.StepValues[-1]
  controls_prop.Group = group = group + 10
  #executeInActionPanel()
  # register apply and cancel button
  createProperty(VC_BUTTON, 'ApplyButton')
  appl = getProperty('ApplyButton')
  appl.OnChanged = doSomeApply
  appl.Group = group = group + 10
  #createProperty(VC_BUTTON, 'CancelButton')
  #cancl = getProperty('CancelButton')
  #cancl.OnChanged = doSomeCancel
  #cancl.Group = group = group + 10
  executeInActionPanel()

def findAllNodes():
  loop_nodes = [comp]
  nodes = []
  while loop_nodes:
    node = loop_nodes.pop(0)
    nodes.append(node)
    #print 'kids', [x.Type for x in node.Children], 's', node.Children # LOTS OF LINECHANGES PRINTED
    loop_nodes.extend( [x for x in node.Children if x.Type == 32768] ) #VC_NODE not working
  return nodes

def snapMount(arg):
  pass

def doSomeApply(arg):
  createBehaviours()


def createBehaviours():
    servo.FlangeNode = comp.findNode( getProperty('Flange Node').Value )
    if getProperty('Positioner Type').Value == 'Workpiece Positioner':
        iface = comp.createBehaviour( VC_ONETOONEINTERFACE, 'RobotInterface' )
        iface.IsAbstract = True
        section = iface.createSection('Section')
        field = section.createField(VC_JOINTEXPORTFIELD , 'ExportJoint')
        field.Controller = servo
        field.Export = True
        print 'Workpiece Positioner behaviors created. You may close the wizard now.'
    elif getProperty('Positioner Type').Value == 'Robot Positioner':
        frame = servo.FlangeNode.RootFeature.createFeature(VC_FRAME, 'RobotFrame')
        geo = servo.FlangeNode.Geometry
        topFaceCenter = geo.BoundCenter
        topFaceCenter.Z = topFaceCenter.Z + geo.BoundDiagonal.Z
        mtx = vcMatrix.new()
        mtx.P = topFaceCenter
        frame.PositionMatrix = mtx
        frame.rebuild()
        iface = servo.FlangeNode.createBehaviour( VC_ONETOONEINTERFACE, 'MountInterface' )
        section = iface.createSection('Section')
        field = section.createField(VC_HIERARCHYFIELD , 'Pnp')
        section.Frame = frame
        field.Parent = True
        field.Node = servo.FlangeNode
        field.Frame = frame
        field = section.createField(VC_JOINTEXPORTFIELD , 'ExportJoint')
        field.Controller = servo
        field.Export = True
        #Connect to Robot Transport Controller
        iface_2 = comp.createBehaviour( VC_ONETOONEINTERFACE, 'ManagerInterface' )
        section_2 = iface_2.createSection('ConnectToManager')
        field_2 = section_2.createField(VC_HIERARCHYFIELD , 'Child')
        frame_2 = comp.RootFeature.createFeature(VC_FRAME, 'RootFrame')
        section_2.Frame = frame_2
        field_2.Parent = False
        field_2.Node = comp
        field_2.Frame = frame_2
        print 'Robot Positioner behaviors created. You may close the wizard now.'


def warning(s):
  print 'Wizard error: %s' % s

def getPropertyInObj(obj, name):
  for p in obj.Properties:
    if p.Name == name:
      return p

addState( first_state )
