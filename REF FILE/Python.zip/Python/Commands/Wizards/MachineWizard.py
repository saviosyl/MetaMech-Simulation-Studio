from vcCommand import *
import os.path

app = getApplication()
process_node_name = 'ProcessNode'
process_frame_name = 'ProductLocation'
resource_frame_name = 'ResourceLocation'

def OnStart():
  global setup_prop, door_controller_prop, comp, container_prop, state_prop, door_conf_prop, tool_conf_prop, controllers, finalized
  global create_works_prop, create_basics_prop, create_connectivity_prop, create_process_prop, node_prop, create_mtending_prop
  
  finalized = False
  comp = app.CurrentContext.ActiveComponent
  if not comp:
    print 'Select a component to use this wizard.'
    

  #TODO Check that servo, door joint and door state props work ok in every case
  #print 'You can use this wizard to add basic machine functions to your component.'
  #print 'These include frames, container, statistics, Works and Machine Tending library support, Connectivity and Process Modeling.'
  
  #Add servo controller selection property
  controllers = comp.findBehavioursByType(VC_SERVOCONTROLLER)
  servo_names = []
  for s in controllers:
    servo_names.append(s.Name)
  servo_names.append('No Servo')

  door_controller_prop = createProperty(VC_STRING, 'Servo Controller', VC_PROPERTY_STEP)
  door_controller_prop.StepValues = servo_names
  door_controller_prop.Value = door_controller_prop.StepValues[0]
  door_controller_prop.OnChanged = prop_changed

  
  #Add door joint selection prop
  door_conf_prop = createProperty(VC_STRING, 'Door Joint', VC_PROPERTY_STEP)
  stepVals = []

  
  for s in controllers:
    for j in s.Joints:
      stepVals.append(j.Name)
  stepVals.append('No Door Joint')
  
  if stepVals:
    door_conf_prop.StepValues = stepVals
    door_conf_prop.Value = door_conf_prop.StepValues[0]
  else:
    print 'Machine Wizard Error. No servo controlled joints found in the component.'
    return
  door_conf_prop.IsVisible = True
  if door_controller_prop.Value == 'No Servo':
    door_conf_prop.IsVisible = False
  door_conf_prop.OnChanged = prop_changed

  '''
  #Add spinning tool joint selection prop
  tool_conf_prop = createProperty(VC_STRING, 'Spinning Tool Joint', VC_PROPERTY_STEP)
  stepVals = []
  for s in controllers:
    stepVals = [x.Name for x in s.Joints]
  stepVals.append('No Spinning Tool Joint')
  tool_conf_prop.StepValues = stepVals
  tool_conf_prop.Value = tool_conf_prop.StepValues[-1]
  '''

  #Add state selection property
  
  state_prop = createProperty(VC_STRING, 'Current State', VC_PROPERTY_STEP)
  stepVals = ['Door is Open', 'Door is Closed'] #, 'No Door'
  state_prop.StepValues = stepVals
  state_prop.Value = state_prop.StepValues[0]
  state_prop.IsVisible = True
  if door_conf_prop.Value == 'No Door Joint':
    state_prop.IsVisible = False

  #Add process node slection property
  nodes = findAllNodes()
  node_prop = createProperty(VC_STRING, 'Process Location', VC_PROPERTY_STEP)
  stepVals = [x.Name for x in nodes]
  stepVals.append('Create New Node')
  node_prop.StepValues = stepVals
  if node_prop.StepValues:
    node_prop.Value = node_prop.StepValues[-1]
  else:
    print 'Could not select process node.'
  
  #Add container selection property
  conts = comp.findBehavioursByType(VC_COMPONENTCONTAINER)
  container_prop = createProperty(VC_STRING, 'Container', VC_PROPERTY_STEP)
  stepVals = [x.Name for x in conts]
  stepVals.append('Create New Container')
  container_prop.StepValues = stepVals
  if container_prop.StepValues:
    container_prop.Value = container_prop.StepValues[0]
  else:
    print 'Could not select container.'

  #create_basics_prop = createProperty(VC_BOOLEAN, 'Frames and container')
  #create_basics_prop.Value = True
  create_process_prop = createProperty(VC_BOOLEAN, 'Process Model')
  create_process_prop.Value = True
  create_works_prop = createProperty(VC_BOOLEAN, 'Works Library')
  create_works_prop.Value = False
  create_mtending_prop = createProperty(VC_BOOLEAN, 'Machine Tending Library')
  create_mtending_prop.Value = False
  create_mtending_prop.IsVisible = False
  create_connectivity_prop = createProperty(VC_BOOLEAN, 'PLC Connectivity')
  create_connectivity_prop.Value = False

  setup_prop = createProperty(VC_BUTTON, 'Apply')
  setup_prop.OnChanged = setupMachine

  executeInActionPanel()
  finalized = True

def setupMachine(arg):
  #print '-' * 20
  addStatistics()
  addBasics(node_prop.Value, container_prop.Value)
  #addFailureModes()
  if create_works_prop.Value or create_connectivity_prop.Value or create_mtending_prop.Value:
    addScript('MachineScript.py')
  if create_works_prop.Value:
    addWorks()
  if create_connectivity_prop.Value:
    addConnectivity()
  if create_process_prop.Value:
    addProcessModel()
  if create_mtending_prop.Value:
    addMachineTending()
  if create_works_prop.Value or create_connectivity_prop.Value or create_mtending_prop.Value:
    addScriptContent('MachineScript.py')

  
def addBasics(node, container):
  global cont, process_node, p_frame, via_frame, r_frame
  # Create / find the process node
  if node == 'Create New Node':
    process_node = comp.findNode(process_node_name)
    if process_node:
      print ('Node "%s" already exists' % (process_node.Name))
    else:
      process_node = comp.createNode(VC_NODE, process_node_name)
      compHeight = comp.BoundDiagonal.Z*2
      process_node.Offset = 'Tz(%s)' % ( compHeight * 0.5 )
  else:
    process_node = comp.findNode(node)
  # Create / find the required frames
  p_frame = process_node.getFeature(process_frame_name)
  if not p_frame:
    p_frame = comp.findFeature('WorkPartFrame')
    if not p_frame:
      p_frame = process_node.RootFeature.createFeature(VC_FRAME, process_frame_name)
      print 'Move %s Frame to the position where your process will take place.' % process_frame_name
  via_frame = comp.findFeature(p_frame.Name + 'Approach')
  if not via_frame:
    via_frame = comp.findFeature('ApproachFrame')
    if via_frame:
        via_frame.Name = p_frame.Name + 'Approach'
    else:
      via_frame = comp.findFeature('ApprouchFrame')
      if via_frame:
        via_frame.Name = p_frame.Name + 'Approach'
      else:
        via_frame = comp.RootFeature.createFeature(VC_FRAME, p_frame.Name + 'Approach')
        m = via_frame.PositionMatrix
        m.translateRel(0, -comp.BoundDiagonal.Y, comp.BoundDiagonal.Z)
        via_frame.PositionMatrix = m
        print 'Move %sApproach Frame to suitable location above resource frame.' % p_frame.Name
  r_frame = comp.findFeature(resource_frame_name)
  if not r_frame:
    r_frame = comp.findFeature('ResourceLocation')
    if not r_frame:
      r_frame = comp.RootFeature.createFeature(VC_FRAME, resource_frame_name)
      m = r_frame.PositionMatrix
      m.translateRel(0, -comp.BoundDiagonal.Y, 0)
      r_frame.PositionMatrix = m
      print 'Move %s Frame to the location that the resource will use when loading/unloading the machine.' % resource_frame_name
  comp.rebuild()
  # Create / find Container
  if container == 'Create New Container':
    cont = process_node.createBehaviour(VC_COMPONENTCONTAINER, 'ProcessContainer__HIDE__')
    st = comp.findBehaviour("Statistics")
    cont.Statistics = st.Name
    cont.Location = p_frame
  else:
    cont = comp.findBehaviour(container)


# Add works functionality
def addWorks():
  script = comp.findBehaviour('PythonScript')
  if not script:
    print 'Error: No PythonScript found.'
  #script = addScript('MachineScript_simplified.py')
  if not comp.getProperty('ParallelRequests'):
    p = comp.createProperty(VC_INTEGER ,'ParallelRequests')
    p.Value = 1
  if not comp.findBehaviour("task"):
    s = comp.createBehaviour(VC_STRINGSIGNAL, 'task')
    s.Connections = [script]
  #WorksProcessInterface
  wpIF = comp.findBehaviour('WorksProcessInterface')
  if not wpIF:
    wpIF = process_node.createBehaviour(VC_ONETOONEINTERFACE, 'WorksProcessInterface')
    awpSection = wpIF.createSection('AttachWorksProcess')
    awpSection.Frame = p_frame
    parF = awpSection.createField(VC_HIERARCHYFIELD,'Parent')
    parF.Node = process_node
    parF.Frame = p_frame
    parF.Parent = True
    wpF = awpSection.createField(VC_INTEGERCOMPATIBILITYFIELD,'WorksProcessOnly')
    wpF.Value = 85208520


# Add connectivity functionality
def addConnectivity():
  script = comp.findBehaviour('PythonScript')
  if not script:
    print 'Error: No PythonScript found.'
  signals = comp.findBehaviour('TO_PLC_DoorIsClosed')
  if not signals:
    comp.createBehaviour(VC_BOOLEANSIGNAL, 'TO_PLC_ProcessIsRunning')
    start_signal = comp.createBehaviour(VC_BOOLEANSIGNAL, 'FROM_PLC_StartProcess')
    start_signal.Connections = [script]
    if door_conf_prop.Value != 'No Door Joint':
      comp.createBehaviour(VC_BOOLEANSIGNAL, 'TO_PLC_DoorIsClosed')
      comp.createBehaviour(VC_BOOLEANSIGNAL, 'TO_PLC_DoorIsOpen')
      open_signal = comp.createBehaviour(VC_BOOLEANSIGNAL, 'FROM_PLC_OpenDoor')
      close_signal = comp.createBehaviour(VC_BOOLEANSIGNAL, 'FROM_PLC_CloseDoor')
      open_signal.Connections = [script]
      close_signal.Connections = [script]
    
    addTimes()
    

def addTimes():
  process_time = comp.getProperty('CycleTimes::ProcessTime')
  if not process_time:
    process_time = getProperty('CycleTime')
    if not process_time:
      process_time = getProperty('ProcessTime')
      if not process_time:
        process_time = comp.createProperty(VC_DISTRIBUTION, 'ProcessTime')
        process_time.Value = 10
        process_time.Quantity = "Time"
  #operator_wtime = getProperty('CycleTimes::OperatorWorkTime')
  #if not operator_wtime:
    #operator_wtime = getProperty('OperatorWorkTime')
    #if not operator_wtime:
      #operator_wtime = comp.createProperty(VC_DISTRIBUTION, 'CycleTimes::OperatorWorkTime')
      #operator_wtime.Value = 0
      #operator_wtime.Quantity = "Time"
  setup_time = getProperty('CycleTimes::SetUpTime') #TODO Check where setup and setdown_time are used and do a workaround
  if not setup_time:
    setup_time = getProperty('SetUpTime')
    if not setup_time:
      setup_time = getProperty('MachineTending::SetUpTime')
      if not setup_time and create_mtending_prop.Value:      
        setup_time = comp.createProperty(VC_DISTRIBUTION, 'MachineTending::SetUpTime')
        setup_time.Value = 4
        setup_time.Quantity = "Time"
  setdown_time = getProperty('CycleTimes::SetDownTime')
  if not setdown_time: 
    setdown_time = getProperty('SetDownTime')
    if not setdown_time:
      setdown_time = getProperty('MachineTending::SetDownTime')
      if not setdown_time and create_mtending_prop.Value:       
        setdown_time = comp.createProperty(VC_DISTRIBUTION, 'MachineTending::SetDownTime')
        setdown_time.Value = 4
        setdown_time.Quantity = "Time"
  return process_time, setup_time, setdown_time
      

def addStatistics():
  if not comp.findBehaviour("Statistics"):
    st = comp.createBehaviour(VC_STATISTICS, 'Statistics')
    st.States = [('Warmup', 1), ('Break', 2), ('Setup', 1), ('Idle', 3), ('Busy', 4), ('Blocked', 5), ('Broken', 6), ('Repair', 7)]


def addProcessModel():
  transport_node = comp.findBehaviour( 'TransportNode')
  if not transport_node:
    transport_node = comp.createBehaviour('rTransportNode', 'TransportNode')
  #transport_node.ProcessExecutor = process_executor # is needed?
    transport_node.ComponentContainer = cont
    transport_node.VisualPositionFrame = p_frame
    transport_node.DefaultProductPositionFrame = p_frame
    transport_node.DefaultResourcePositionFrame = r_frame
  process_executor = comp.findBehaviour( 'ProcessExecutor__HIDE__')
  if not process_executor:
    process_executor = comp.createBehaviour('rProcessExecutor', 'ProcessExecutor__HIDE__')
    process_executor.TransportNode = transport_node
    #print 'You need to set the Process Executor property Transport Node from Null to TransportNode'
  #process_handler = comp.findBehaviour('PythonProcessHandler')
  #if not process_handler:
    #process_handler = comp.createBehaviour('rPythonProcessHandler', 'PythonProcessHandler')
    #process_handler.Script = content
  process_time, setup_time, setdown_time = addTimes()
  
  
  if door_conf_prop.Value != 'No Door Joint': #TODO: Check where J1 and controller are used and disable if no door joint
    door_index = getServoIndex()
    controller = comp.findBehaviour(door_controller_prop.Value)
    J1 = controller.Joints[door_index]
  
  # Add statements
  process = process_executor.Processes
  if not process:
    process = process_executor.addProcess(comp.Name)
    p = process.addStatement(VC_STATEMENT_SETSTATISTICSSTATE)
    p.Statistics = 'Statistics'
    p.State = 'Idle'
    p = process.addStatement(VC_STATEMENT_TRANSPORTIN)
    p.ProductPositionFrame = p_frame
    p.ResourcePositionFrame = r_frame
    p = process.addStatement(VC_STATEMENT_SETSTATISTICSSTATE)
    p.Statistics = 'Statistics'
    p.State = 'Busy'
    if door_conf_prop.Value != 'No Door Joint':
      p = process.addStatement(VC_STATEMENT_PROCESSDELAY)
      p.Distribution = 1.0
      p = process.addStatement(VC_STATEMENT_MOVEJOINT)
      p.Controller = door_controller_prop.Value
      p.Joint = J1.Name
      if state_prop.Value == 'Door is Open':
        p.TargetValue = str(J1.MaxLimit)
      else:
        p.TargetValue = str(J1.InitialValue)
      if setup_time:
        p.MotionTime = str(setup_time.Value)
      else:
        p.MotionTime = '2.0'
    p = process.addStatement(VC_STATEMENT_PROCESSDELAY)
    if process_time:
      p.Distribution = process_time.Value
      p.Expression = process_time.Name
      p.TimeSource = VC_TIMESOURCE_EXPRESSION
    else:
      p.Distribution = 15.0
    #p = process.addStatement(VC_STATEMENT_PROCESS)
    #p.Process = process_handler
    #p.Name = 'Machine Process'
    if door_conf_prop.Value != 'No Door Joint':
      p = process.addStatement(VC_STATEMENT_MOVEJOINT)
      p.Controller = door_controller_prop.Value
      p.Joint = J1.Name
      if state_prop.Value == 'Door is Open':
        p.TargetValue = str(J1.InitialValue)
      else:
        p.TargetValue = str(J1.MaxLimit)
      if setdown_time:
        p.MotionTime = str(setdown_time.Value)
      else:
        p.MotionTime = '2.0'
    p = process.addStatement(VC_STATEMENT_SETSTATISTICSSTATE)
    p.Statistics = 'Statistics'
    p.State = 'Blocked'
    p = process.addStatement(VC_STATEMENT_TRANSPORTOUT)
    p.ResourcePositionFrame = r_frame
  

def addMachineTending():
  script = comp.findBehaviour('PythonScript')
  if not script:
    print 'Error: No PythonScript found.'
  # Create machine tending properties
  addTimes()
  pIndex = comp.getProperty('ProcessIndex')
  if not pIndex:
    pIndex = comp.getProperty('MachineTending::ProcessIndex')
    if not pIndex:
      pIndex = comp.createProperty(VC_INTEGER, 'MachineTending::ProcessIndex')
      pIndex.Value = 1
  idfilt = comp.getProperty('ProductID_filter')
  if not idfilt:
    idfilt = comp.getProperty('MachineTending::ProductID_filter')
    if not idfilt:
      idfilt = comp.createProperty(VC_STRING, 'MachineTending::ProductID_filter')
      idfilt.Value = '111,222,333'
  # create machine tending behaviours
  trans = comp.findBehaviour('TransSignal')
  if not trans:
    trans = comp.createBehaviour(VC_BOOLEANSIGNAL, 'TransSignal')
    trans.Connections = [script]
  cont.TransitionSignal = trans
  evas = comp.findBehaviour('Re_evaluateMT_Signal')
  if not evas:
    evas = comp.createBehaviour(VC_BOOLEANSIGNAL, 'Re_evaluateMT_Signal')
  #reqs = createMachineBehaviour(comp, VC_COMPONENTSIGNAL, 'RequestSignal')
  actions = comp.findBehaviour('Resourcing')
  if not actions:
    actions = comp.createBehaviour(VC_ACTIONCONTAINER, 'Resourcing')
    actions.Connections = [script]
  old_resourceIF = comp.findBehaviour('ResourceInterface')
  if old_resourceIF:
    if not old_resourceIF.IsConnected:
      old_resourceIF.delete()
    else:
      print comp.Name, 'ResourceInterface connected!'
  old_resourceIF = comp.findBehaviour('ResourceInterface')
  if not old_resourceIF:
    resourceIF = comp.createBehaviour(VC_ONETOMANYINTERFACE, "ResourceInterface")
    resourceIF.IsAbstract = True
    resourceIF.ConnectionEditName = "General::Add or Remove Process Manager"
    mtSection = resourceIF.Sections[0]
    mtSection.Name = 'MachineTending'
    mtSection.Frame = p_frame
    mtActField = mtSection.createField(VC_ACTIONFIELD, 'Actions')
    mtActField.Actions = actions
    mtActField.Connection = 1
    mtICField = mtSection.createField(VC_INTEGERCOMPATIBILITYFIELD,'MachineTendingOnly')
    mtICField.Value = 4160
    ReEvalField = mtSection.createField(VC_SIGNALFIELD,'ReEvaluationRequest')
    ReEvalField.Connection = 0
    ReEvalField.Signal = evas
  else:
    print 'Could not create Resource Interface'


def addScript(script_name):
  script = comp.findBehaviour('PythonScript')
  if script:
    print 'Component already has a pythonScript. Please remove or rename it to add the new functionalities.'
  else:
    script = comp.createBehaviour(VC_PYTHONSCRIPT, 'PythonScript')
  return script


def addScriptContent(script_name):
  script = comp.findBehaviour('PythonScript')
  if script:
    uri = getCommandPath()[8:]
    head, tail = os.path.split(uri)
    uri = os.path.join( head, script_name)
    with open(uri, 'r') as script_file:
      content = script_file.read()
      content = content.replace('SERVO_NAME', door_controller_prop.Value)
      if state_prop.Value == 'Door is Open':
        content = content.replace('INIT_STATE', '"Door is Open"')
      else:
        content = content.replace('INIT_STATE', '"Door is Closed"')
      door_index = getServoIndex()
      content = content.replace('DOOR_JOINT_INDEX', str(door_index))
    script.Script = content
  else:
    print 'Error with adding script content to the machine'
  return script


def getServoIndex():
  if door_conf_prop.Value == 'No Door Joint':
    return 0
  contr = comp.findBehaviour(door_controller_prop.Value)
  for i, j in enumerate(contr.Joints):
    if j.Name == door_conf_prop.Value:
      break
  return i


def findAllNodes():
  loop_nodes = [comp]
  nodes = []
  while loop_nodes:
    node = loop_nodes.pop(0)
    if node != comp:
      nodes.append(node)
    loop_nodes.extend( [x for x in node.Children if x.Type == 32768] ) #VC_NODE
  return nodes


#Hide and show properties in the action panel
def prop_changed(prop):
  if finalized:
    if prop.Name == 'Servo Controller':
      if prop.Value == 'No Servo':
        state_prop.IsVisible = False
        door_conf_prop.IsVisible = False
        door_conf_prop.Value = 'No Door Joint'
      else:
        door_conf_prop.IsVisible = True
        door_conf_prop.Value = door_conf_prop.StepValues[0]
        if door_conf_prop.Value != 'No Door Joint':
          state_prop.IsVisible = True
    elif prop.Name == 'Door Joint':
      if prop.Value == 'No Door Joint':
        state_prop.IsVisible = False
      else:
        state_prop.IsVisible = True


# Not in use at the moment
def addFailureModes():
  # create failure properties
  mtbf = comp.getProperty('Failure::MTBF')
  if not mtbf:
    mtbf = comp.createProperty(VC_DISTRIBUTION, 'Failure::MTBF')
    mtbf.Quantity = 'Time'
  mttr = comp.getProperty('Failure::MTTR')
  if not mttr:
    mttr = comp.createProperty(VC_DISTRIBUTION, 'Failure::MTTR')
    mttr.Quantity = 'Time'
  broken = comp.getProperty('Broken')
  if not broken:
    broken = comp.createProperty(VC_BOOLEAN, 'Broken')


addState(None)

