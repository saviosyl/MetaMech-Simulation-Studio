#-----------------------#
#                       #
# EXTERNAL AXIS OPTION  #
#                       #
#-----------------------#

# MODIFY THE MOUNTINTERFACE IF CONTROL CHANGED
def ModifyInterface(iface):
  global control_prop, servo
  section = iface.Sections[0]
  if control_prop.Value == CONTROL_OPTIONS[1]:
    if comp.findBehavioursByType(VC_TOOLCONTAINER):
      amount_of_fields = 3
    else: 
      amount_of_fields = 2
    if len(section.Fields) < amount_of_fields:
      field = section.createField(VC_JOINTEXPORTFIELD, 'JointExport')
      field.Export = True
      field.Controller = servo
  else:
    try:
      section.deleteField(2)
    except:
      pass

#SHOWS/HIDES I/O PROPERTIES ACCORDING TO CONTROL PROPERTY VALUE
def ControlChanged(arg):
  global control_prop
  if arg.Value:
    ModifyInterface(comp.findBehaviour(ROBOT_INTERFACE_NAME))
    if arg.Value == CONTROL_OPTIONS[0]:
      ShowHideProperties(show_list=[p for p in comp.Properties if TABNAME in p.Name])
    else:
      ShowHideProperties(hide_list=[p for p in comp.Properties if TABNAME in p.Name],show_list=[control_prop])

def ShowHideProperties(hide_list=[],show_list=[]):
  for p in hide_list:
    if p not in show_list:
      p.IsVisible = False
  for p in show_list:
    p.IsVisible = True
    
if control_prop:
  control_prop.OnChanged = ControlChanged
