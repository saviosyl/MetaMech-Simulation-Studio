from vcScript import *
import vcMatrix

comp = getComponent()
app = getApplication()
servo = comp.findBehaviour("TYPEME_SERVO_CONTROLLER_NAME")

## GLOBALS ##
TABNAME = ""
ACTION_NAME = "Action"
REVERSED_ACTION = False
STATE_NAME = "State"
IN_PREFIX = "IN"
OUT_PREFIX = "OUT"
JOINT_IO_NAMES = {} # "JointName":[["IN_ToReset","IN_ToSet"],["OUT_IsReset","OUT_IsSet"]]
JOINT_PROPS = {}
JOINT_OUTPUT_SIGNALS = {}
OUTPUT_SIGNAL_NAMES = []
INPUT_SIGNAL_NAMES = []
# LOOPS EACH JOINT
for joint_index, joint in enumerate(servo.Joints):
  if joint.Name in JOINT_IO_NAMES:
    # GET PROPERTIES FOR MIN AND MAX VALUES
    reset_state_name, set_state_name = JOINT_IO_NAMES[joint.Name][1]
    reset_val_prop = comp.getProperty(joint.Name+"_"+reset_state_name+"Value")
    set_val_prop = comp.getProperty(joint.Name+"_"+set_state_name+"Value")
    motion_time_prop = comp.getProperty(joint.Name+"_MotionTime")
    JOINT_PROPS[joint_index] = [reset_val_prop, set_val_prop, motion_time_prop]
    # GET OUTPUT SIGNALS FOR MIN AND MAX STATES
    reset_state_signal_name = OUT_PREFIX+"_"+joint.Name+"_"+reset_state_name+STATE_NAME
    set_state_signal_name = OUT_PREFIX+"_"+joint.Name+"_"+set_state_name+STATE_NAME
    JOINT_OUTPUT_SIGNALS[joint_index] = [comp.findBehaviour(reset_state_signal_name),comp.findBehaviour(set_state_signal_name)]
    OUTPUT_SIGNAL_NAMES += [reset_state_signal_name,set_state_signal_name]
    # GET INPUT SIGNALS FOR ACTION, SET, RESET
    reset_action_name, set_action_name = JOINT_IO_NAMES[joint.Name][0]
    for name in [ACTION_NAME,reset_action_name,set_action_name]:
      signal_name=IN_PREFIX+"_"+joint.Name+"_"+name
      signal = comp.findBehaviour(signal_name)
      if signal:
        INPUT_SIGNAL_NAMES.append(signal_name)

#---------------------#
#                     #
#       LOGIC         #
#                     #
#---------------------#

# SET NEW SERVO TARGETS
def SetCurrentTarget():
  for i in range(servo.JointCount):
    servo.setJointTarget(i,servo.getJointValue(i))

def SetTarget(joint_index, joint_value = 0, motion_time = 0):
  servo.setJointTarget(joint_index,joint_value)
  if motion_time != 0:
    servo.setMotionTime(motion_time)

def GripperAction(set_action, joint_index):
  global JOINT_PROPS
  suspendRun()
  motion_time = 0
  motion_time_prop = JOINT_PROPS[joint_index][2]
  if motion_time_prop: 
    motion_time = motion_time_prop.Value
  if set_action: #OPEN
    set_val_prop = JOINT_PROPS[joint_index][1]
    target = set_val_prop.Value
  else: #RESET/CLOSE
    reset_val_prop = JOINT_PROPS[joint_index][0]
    target = reset_val_prop.Value
  SetTarget(joint_index, target, motion_time)
  resumeRun()
  
# LISTEN THE INCOMING SIGNALS
def OnSignal( signal ):
  global targets
  joint_index = -1
  for jname in JOINT_IO_NAMES:
    if jname in signal.Name:
      joint_name = jname
      prefix, signal_name = signal.Name.split("_"+jname+"_")
      joint_index = servo.Joints.index(servo.findJoint(joint_name))
      break
  if joint_index == -1:
    return
  else:
    if ACTION_NAME in signal_name:
      if (signal.Value and not REVERSED_ACTION) or (not signal.Value and REVERSED_ACTION):
        GripperAction(True,joint_index)
      else:
        GripperAction(False,joint_index)
    elif signal.Value:
      reset_name, set_name = JOINT_IO_NAMES[joint_name][0]
      if set_name in signal_name:
        GripperAction(True,joint_index)
      elif reset_name in signal_name:
        GripperAction(False,joint_index)

# SET OUTPUT SIGNAL VALUES
def SetOutputSignals(reset = False):
  global JOINT_PROPS
  for joint_index, joint in enumerate(servo.Joints):
    if joint.Name in JOINT_IO_NAMES:
      set_val_prop = JOINT_PROPS[joint_index][0]
      reset_val_prop = JOINT_PROPS[joint_index][1]
      set_state_signal = JOINT_OUTPUT_SIGNALS[joint_index][0]
      reset_state_signal = JOINT_OUTPUT_SIGNALS[joint_index][1]
      if all([set_val_prop, reset_val_prop, set_state_signal, reset_state_signal]):
        if (joint.CurrentValue == reset_val_prop.Value and not reset) or (joint.CurrentValue == reset_val_prop.Value and joint.CurrentValue == servo.getJointTarget(joint_index) and reset ):
          reset_state_signal.signal(True)
        else:
          reset_state_signal.signal(False)
        if (joint.CurrentValue == set_val_prop.Value and not reset) or (joint.CurrentValue == set_val_prop.Value and joint.CurrentValue == servo.getJointTarget(joint_index) and reset ):
          set_state_signal.signal(True)
        else:
          set_state_signal.signal(False)

# DRIVES THE SERVO
def OnRun():
  if servo:
    SetCurrentTarget()
    while True:
      SetOutputSignals(False)
      condition(lambda:[i for i in range(servo.JointCount) if (round(servo.getJointTarget(i),2) != round(servo.getJointValue(i),2))])
      SetOutputSignals(True)
      servo.move()
      delay(0.01)
