from vcApplication import *
import os.path

localize = findCommand('netCommand')
# category names
localize.execute('SetLocalizationCommand', 'English', 'Component Wizards', 'Gallery', 'Name', 'Component Wizards')
localize.execute('SetLocalizationCommand', 'German', 'Component Wizards', 'Gallery', 'Name', 'Komponenten-Wizards')
localize.execute('SetLocalizationCommand', 'Chinese', 'Component Wizards', 'Gallery', 'Name', '组件向导')
localize.execute('SetLocalizationCommand', 'TraditionalChinese', 'Component Wizards', 'Gallery', 'Name', '元件精靈')
localize.execute('SetLocalizationCommand', 'Japanese', 'Component Wizards', 'Gallery', 'Name', 'コンポーネントウィザード')
localize.execute('SetLocalizationCommand', 'Korean', 'Component Wizards', 'Gallery', 'Name', '컴포넌트 마법사')
localize.execute('SetLocalizationCommand', 'Spanish', 'Component Wizards', 'Gallery', 'Name', 'Tutoriales de componentes')
localize.execute('SetLocalizationCommand', 'French', 'Component Wizards', 'Gallery', 'Name', 'Assistants de composants')

def OnStart():
  cmduri = getApplicationPath() + 'EOAT_Wizard.py'
  cmd = loadCommand("EOAT_Wizard", cmduri)
  addMenuItem(VC_MENU_MODELING_WIZARDS + '/Component Wizards', "End Effector", -1, "EOAT_Wizard")
  addMenuButton(VC_MENU_MODELING_WIZARDS_LITE, "End Effector", "EOAT_Wizard", VC_TOOLSIZE_IMAGE_AND_TEXT_LARGE)

  cmduri = getApplicationPath() + 'IO_ControlsWizard.py'
  cmd = loadCommand("IO_ControlsWizard", cmduri)
  addMenuItem(VC_MENU_MODELING_WIZARDS + '/Component Wizards', "IO-Control", -1, "IO_ControlsWizard")
  addMenuButton(VC_MENU_MODELING_WIZARDS_LITE, "IO-Control", "IO_ControlsWizard", VC_TOOLSIZE_IMAGE_AND_TEXT_LARGE)

  cmduri = getApplicationPath() + 'PositionerWizard.py'
  cmd = loadCommand("PositionerWizard", cmduri)
  addMenuItem(VC_MENU_MODELING_WIZARDS + '/Component Wizards', "Positioner", -1, "PositionerWizard")
  addMenuButton(VC_MENU_MODELING_WIZARDS_LITE, "Positioner", "PositionerWizard",  VC_TOOLSIZE_IMAGE_AND_TEXT_LARGE)

  cmduri = getApplicationPath() + 'ConveyorWizard.py'
  cmd = loadCommand("ConveyorWizard", cmduri)
  addMenuItem(VC_MENU_MODELING_WIZARDS + '/Component Wizards', "Conveyor", -1, "ConveyorWizard")
  addMenuButton(VC_MENU_MODELING_WIZARDS_LITE, "Conveyor", "ConveyorWizard", VC_TOOLSIZE_IMAGE_AND_TEXT_LARGE)

  cmduri = getApplicationPath() + 'SensorWizard.py'
  cmd = loadCommand("SensorWizard", cmduri)
  addMenuItem(VC_MENU_MODELING_WIZARDS + '/Component Wizards', "Sensor", -1, "SensorWizard")

  cmduri = getApplicationPath() + 'MachineWizard.py'
  if os.path.isfile(cmduri.replace('file:///', '')):
    cmd = loadCommand('MachineWizard',cmduri)
    addMenuItem(VC_MENU_MODELING_WIZARDS + '/Component Wizards', "Machine", -1, "MachineWizard")

