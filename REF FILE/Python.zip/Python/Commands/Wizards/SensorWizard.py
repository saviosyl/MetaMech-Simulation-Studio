from vcCommand import *

app = getApplication()
cmd = getCommand() 


def createSensor(arg):
  sType = getProperty('Type').Value
  sName = getProperty('Sensor Name').Value
  pathName = getProperty('Path').Value
  signalType = getProperty( 'Signal Type' ).Value
  frameName = getProperty( 'Sensor Frame' ).Value
  connectToName = getProperty( 'Connect signal to' ).Value
  #
  # SANITY CHECK
  if sType == 'Path':
    if not node.getBehaviour(pathName):
      print 'Sensor Wizard Error: Path behavior must be defined.'
      return
    if not node.findFeature(frameName):
      print 'Sensor Wizard Error: Sensor frame must be defined.'
      return
  if sType == 'Processor':
    if frameName != '** Create New **' and not node.findFeature(frameName):
      print 'Sensor Wizard Error: Invalid Sensor frame.'
      return
  #
  # CREATE SENSOR
  sensor = node.createBehaviour(VC_COMPONENTPATHSENSOR, sName)
  sensor.TriggerAt = VC_PATH_ORIGIN_TRIGGER
  #
  # ASSIGN FRAME
  if frameName == '** Create New **':
    frame = node.RootFeature.createFeature(VC_FRAME, sName+'__frame')
  else:
    frame = node.findFeature(frameName)
  sensor.Frame = frame
  #
  # CREATE SIGNAL AND ASSIGN IT
  if signalType == 'Boolean Signal':
    signal = node.createBehaviour(VC_BOOLEANSIGNAL, sName+'Signal')
    sensor.BoolSignal = signal
    value_line = 'val = theSignal.Value'
  else:
    signal = node.createBehaviour(VC_COMPONENTSIGNAL, sName+'Signal')
    sensor.ComponentSignal = signal
    value_line = 'part = theSignal.Value'
    
  if sType == 'Path':
    #
    # ADD SENSOR IN PATH'S SENSORS
    path = node.findBehaviour(pathName)
    list_of_sensors = path.Sensors
    list_of_sensors.append(sensor)
    path.Sensors = list_of_sensors
    path.update()
    script_content = temp_script_path % (signal.Name, path.Name, value_line)
  elif sType == 'Processor':
    #
    # CREATE SENSOR IFACE
    iface_name = sName+'Interface'
    iface = node.createBehaviour(VC_ONETOONEINTERFACE, iface_name)
    iface_section = iface.createSection('SensorSection')
    iface_section.Frame = frame
    iface_field = iface_section.createField(VC_PROCESSORFIELD, 'ProcessorField')
    iface_field.Parent = False
    iface_field.Sensor = sensor
    script_content = temp_script_processor % (signal.Name, iface_name, value_line)
  #
  # CONNECT SIGNAL TO SOMETHING
  if connectToName == '** Create New PythonScript **':
    python_script_beh = node.Component.createBehaviour(VC_PYTHONSCRIPT, 'PythonScript')
    c = signal.Connections
    c.append(python_script_beh)
    signal.Connections = c
    python_script_beh.Script = script_content
  elif connectToName:
    c = signal.Connections
    c.append( node.Component.findBehaviour( connectToName ) )
    signal.Connections = c
    
  print 'Done. You may close the wizard now.'



def setFrames(arg):
  path = node.getBehaviour(getProperty('Path').Value)
  if path:
    frame_prop = getProperty('Sensor Frame')
    frame_prop.StepValues = [x.Name for x in path.Path]


def typePropChanged(arg):
  frames = []
  feas = [node.RootFeature]
  while feas:
    # Traverse all features to find frames
    fea = feas.pop(0)
    if fea.Type == VC_FRAME:
      frames.append( fea )
    feas.extend( fea.Children )
  frameNames = [x.Name for x in frames]
  if arg.Value == 'Path':
    path_prop.IsVisible = True
  else:
    path_prop.IsVisible = False
    frameNames.append('** Create New **')
  frame_prop.StepValues = frameNames


def OnStart():
  global node #node is locked to the selected after launching the command
  global type_prop, button_prop, path_prop, frame_prop 
  try:
    node = app.CurrentContext.ActiveNode
  except:
    print 'Select a link in the component tree and try again.'
    return
  
  type_prop = createProperty(VC_STRING, 'Type', VC_PROPERTY_STEP)
  type_prop.StepValues = ['Path', 'Processor']
  type_prop.Value = 'Path'
  type_prop.Group = 0
  type_prop.OnChanged = typePropChanged
  name_prop = createProperty(VC_STRING, 'Sensor Name')
  name_prop.Value = 'Sensor'
  name_prop.Group = 5
  # PATH PROP
  paths = node.getBehavioursByType( VC_ONEWAYPATH )
  paths.extend( node.getBehavioursByType( VC_TWOWAYPATH ) )
  path_prop = createProperty(VC_STRING, 'Path', VC_PROPERTY_STEP)
  path_prop.IsVisible = True
  path_names = [x.Name for x in paths]
  if not path_names:
    path_names = ['*NULL*']
  path_prop.StepValues = path_names
  path_prop.Group = 10
  path_prop.OnChanged = setFrames
  # SIGNAL PROP
  signal_prop = createProperty(VC_STRING, 'Signal Type' , VC_PROPERTY_STEP)
  signal_prop.StepValues = ['Boolean Signal','Component Signal']
  signal_prop.Value = 'Component Signal'
  signal_prop.Group = 20
  # FRAME PROP
  frames = []
  feas = [node.RootFeature]
  while feas:
    # Traverse all features to find frames
    fea = feas.pop(0)
    if fea.Type == VC_FRAME:
      frames.append( fea )
    feas.extend( fea.Children )
  frameNames = [x.Name for x in frames]
  frame_prop = createProperty(VC_STRING, 'Sensor Frame', VC_PROPERTY_STEP)
  frame_prop.StepValues = frameNames
  frame_prop.Group = 30
  # CONNECT TO PROP
  behNames = [x.Name for x in node.Component.Behaviours]
  behNames.insert(0, '** Create New PythonScript **')
  connect_to_prop = createProperty(VC_STRING, 'Connect signal to', VC_PROPERTY_STEP)
  connect_to_prop.StepValues = behNames
  connect_to_prop.Group = 40
  # BUTTON PROP
  button_prop = createProperty(VC_BUTTON, 'Create Sensor')
  button_prop.OnChanged = createSensor
  button_prop.Group = 50
  #
  executeInActionPanel()
  return True


temp_script_path = '''
from vcScript import *

def OnSignal( signal ):
  #print signal.Name, signal.Value
  pass

def OnRun():
  comp = getComponent()
  theSignal = comp.findBehaviour('%s')
  path = comp.findBehaviour('%s')
  
  while True:
    triggerCondition(lambda: getTrigger() == theSignal and theSignal.Value)
    %s
    delay(1)

'''

temp_script_processor = '''
from vcScript import *

def OnSignal( signal ):
  #print signal.Name, signal.Value
  pass

def OnRun():
  comp = getComponent()
  theSignal = comp.findBehaviour('%s')
  iface = comp.findBehaviour('%s')
  if iface.ConnectedToSections:
    path = iface.ConnectedToSections[0].Fields[0].Path #the path where this component is connected to
  else:
    path = None

  while True:
    triggerCondition(lambda: getTrigger() == theSignal and theSignal.Value)
    %s
    delay(1)

'''

addState( None )

