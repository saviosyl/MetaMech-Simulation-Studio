from vcScript import *

comp = getComponent()
app = getApplication()


def OnSignal(signal):
  global triggerSignals, tasks
  try:
    if signal in triggerSignals: 
      tasks.append([signal.Name, signal.Value])
  except:
    pass


def OnRun():
  global triggerSignals, tasks, doorOpenValue, doorClosedValue
  global processingTime, setUpTime, setDownTime, target
  global signal_val, reqs, worksTasks
  global cont, servo, resourcing
  
  #If the component has transport node and there are transport links connected to it then PM logic is used instead
  transportNode = comp.findBehaviour('TransportNode')
  if transportNode:
    if transportNode.TransportLinks:
      return # use PM logic
  
  #Assign properties to variables
  processingTime = comp.getProperty('ProcessTime')
  if processingTime:
    processingTime = processingTime.Value
  else:
    processingTime = 10.0
  setUpTime = comp.getProperty('MachineTending::SetUpTime')
  if setUpTime:
    setUpTime = setUpTime.Value
  else:
    setUpTime = 4.0
  setDownTime = comp.getProperty('MachineTending::SetDownTime')
  if setDownTime:
    setDownTime = setDownTime.Value
  else:
    setDownTime = 4.0
  init_state_prop = INIT_STATE
  #Door joint settings
  if servo:
    if servo.Joints:
      doorJoint = servo.Joints[DOOR_JOINT_INDEX]
      if init_state_prop == "Door is Open":
        doorOpenValue = float(doorJoint.InitialValue)
        if float(doorJoint.InitialValue) != float(doorJoint.MaxLimit):
          doorClosedValue = float(doorJoint.MaxLimit)
        else:
          doorClosedValue = float(doorJoint.MinLimit)
      elif init_state_prop == "Door is Closed":
        if float(doorJoint.InitialValue) != float(doorJoint.MaxLimit):
          doorOpenValue = float(doorJoint.MaxLimit)
        else:
          doorOpenValue = float(doorJoint.MinLimit)
        doorClosedValue = float(doorJoint.InitialValue)
      else:
        print comp.Name, 'Error defining door initial state'
      if doorOpen and doorClosed:
        if doorJoint.Dof.VALUE == doorOpenValue:
          doorOpen.signal(True)
        elif doorJoint.Dof.VALUE == doorClosedValue:
          doorClosed.signal(True)

  reqs = []
  tasks = []
  worksTasks = []
  triggerNames = ['FROM_PLC_OpenDoor', 'FROM_PLC_CloseDoor', 'FROM_PLC_StartProcess', 'task', 'TransSignal']
  triggerSignals = map(comp.findBehaviour, triggerNames) # main loop reacts to these signals
  #cont.OnTransition = contTrans #Machine tending functionalities removed
  cont.CapacityAvailable = True
  
  #Open the doors at the beginning of the simulation
  if servo:
    if servo.Joints:
      if doorJoint.Dof.VALUE == doorClosedValue:
        if False: #TO USE: Switch this to -> if True:
          moveDoors(True)
  
  # MAIN LOOP
  while True:
    stats.State = "Idle"
    condition(lambda: tasks)
    if tasks:
      signal_name, signal_val = tasks.pop(0)
      stats.State = "Busy"
      # Connectivity events
      if signal_name == "FROM_PLC_CloseDoor" and signal_val:
        moveDoors(False)
      elif signal_name == "FROM_PLC_OpenDoor" and signal_val:
        moveDoors(True)
      elif signal_name == "FROM_PLC_StartProcess" and signal_val:
        machineProcess(processingTime)
      #Works process   
      elif signal_name == "task":
        worksProcess()
      #Machine tending process
      elif signal_name == "TransSignal" and signal_val:
        pass #Machine tending functionalities removed
        machineTendingProcess()
      #else:
        #print comp.Name, 'received unknown signal ', signal_name


def worksProcess():
  for i in range(comp.ParallelRequests):
    vals = signal_val.split(",")
    processTime = float(vals[0])
    worksProcessComponent = worksProcessInterface.ConnectedComponent
    reqs.append(worksProcessComponent)
    worksTasks.append(signal_val)
    part = None
    comps = worksProcessComponent.ChildComponents
    if len(comps):
      part = comps[0]
  
  moveDoors(False)
  machineProcess(processTime, part)
  moveDoors(True)
  
  for i in range(len(reqs)):
    sig = reqs[i].findBehaviour("TaskDone")
    sig.signal(worksTasks[i])
    delay(0.0)

#Not in use
def machineTendingProcess():
  part = None
  comps = cont.Components
  if len(comps):
    part = comps[0]
  
  moveDoors(False)
  machineProcess(processingTime, part)
  moveDoors(True)
  
  resourcing.use('',VC_ACTION_TRANSPORT, part, comp)
 
 
def moveDoors(opening):
  if servo:
    if servo.Joints:
      if opening:
        if doorClosed:
          doorClosed.signal(False)
        servo.setJointTarget(DOOR_JOINT_INDEX, doorOpenValue)
        servo.setMotionTime(setDownTime)
        servo.move()
        if doorOpen:
          doorOpen.signal(True)
      else:
        if doorOpen:
          doorOpen.signal(False)
        servo.setJointTarget(DOOR_JOINT_INDEX, doorClosedValue)
        servo.setMotionTime(setUpTime)
        servo.move()
        if doorClosed:
          doorClosed.signal(True)


def machineProcess(time, part = None):
  # Here you can add your custom machine process
  # By default the machine process is simply a delay
  if running:
    running.signal(True)
  delay(time) #Remove the delay and add advanced functionalities below if desired
  
  # Uncomment and modify to translate a joint
  # Get the dimensions of the part on the works process
  #partHeight = part.BoundDiagonal.Z*2)
  #partDepth = max(part.BoundDiagonal.Y, part.BoundDiagonal.X)
  #translateJoint(time, partHeight, partDepth)
  
  # Uncomment and modify to spin a joint
  #spinJoint(time)
  
  if running:
    running.signal(False)


def translateJoint(time):
  #Example motions
  #Modify the servo indexes, motion ranges and times for your machine
  servo.setJointTarget(1, 0)
  servo.setMotionTime(time/2)
  servo.move()
  servo.setJointTarget(1, 500)
  servo.setMotionTime(time/2)
  servo.move()
 
 
def spinJoint(time):
  #Example of advanced machining motions
  #Modify the servo indexes and add advanced motions for your machine
  t = time / 10
  rot = 360.0 * t
  for i in range(10):
    servo.setJointTarget(1, rot)
    servo.setMotionTime(t)
    servo.move()
    servo.setJointTarget(1,0)
    servo.moveImmediate()


def contTrans(comp, in_out):
  global cont
  if in_out:
    cont.CapacityAvailable = False
  else:
    cont.CapacityAvailable = True
    
''' Removed machine tending functionalities
# Show Machine Tending library related properties upon connecting to manager
def machine_tending_connected(*args):
  for prop in MT_props:
    prop.IsVisible = True
  sel_comps = app.SelectionManager.getSelection(VC_SELECTION_COMPONENT)
  app.SelectionManager.clear()
  app.SelectionManager.setSelection(sel_comps)


# Automatically hide Machine Tending library related properties    
def machine_tending_disconnected(*args):
  for prop in MT_props:
    prop.IsVisible = False
  sel_comps = app.SelectionManager.getSelection(VC_SELECTION_COMPONENT)
  app.SelectionManager.clear()
  app.SelectionManager.setSelection(sel_comps)
'''

servo = comp.findBehaviour('SERVO_NAME')
stats = comp.getBehaviour('Statistics')
cont = comp.findBehaviour("ProcessContainer__HIDE__")
worksProcessInterface = comp.findBehaviour('WorksProcessInterface')
doorClosed = comp.findBehaviour('TO_PLC_DoorIsClosed')
doorOpen = comp.findBehaviour('TO_PLC_DoorIsOpen')
running = comp.findBehaviour('TO_PLC_ProcessIsRunning')
task = comp.findBehaviour('task')

''' Removed machine tending functionalities
resourcing = comp.findBehaviour('Resourcing')
MT_ResourceInterface = comp.findBehaviour('ResourceInterface')


MT_props = []
all_props = comp.Properties
for prop in all_props:
  if 'MachineTending::' in prop.Name:
    MT_props.append(prop)

if MT_ResourceInterface:
  MT_ResourceInterface.OnConnect = machine_tending_connected
  MT_ResourceInterface.OnDisconnect = machine_tending_disconnected
'''