from __future__ import with_statement
from vcCommand import *
from vcHelpers.Selection import *
import os.path

app = getApplication()

TABNAME = ""
WIZARD_NAME = "IO_ControlsWizard"
SCRIPT_NAME = "IO_Controls"
ACTION_NAME = "Action"
STATE_NAME = "State"
IN_PREFIX = "IN"
OUT_PREFIX = "OUT"
INPUT_SIGNALS_STEP_VALUES = ['One ActionSignal', 'Two Separate Signals', 'Three Signals (Both Options Above)']
STATE_MAP = {
"Open":[["Open","Close"],["Open","Closed"]],
"Closed":[["Open","Close"],["Open","Closed"]],
"Left":[["Right","Left"],["Right","Left"]],
"Right":[["Right","Left"],["Right","Left"]],
"Up":[["Up","Down"],["Up","Down"]],
"Down":[["Up","Down"],["Up","Down"]]}
#"Left":[["Left","Right"],["Left","Right"]],
#"Right":[["Left","Right"],["Left","Right"]],

INPUT_NAME_STEP_VALUES = [ACTION_NAME]
STATE_NAME_STEP_VALUES = []
for state_name in STATE_MAP:
  for input_name in STATE_MAP[state_name][0]:
    if input_name not in INPUT_NAME_STEP_VALUES:
      INPUT_NAME_STEP_VALUES.append(input_name)
  for output_name in STATE_MAP[state_name][1]:
    if output_name not in STATE_NAME_STEP_VALUES:
      STATE_NAME_STEP_VALUES.append(output_name)

def LocalizeDescription(prop_name, language, translation):
  localize.execute('SetLocalizationCommand', language, 'Python', WIZARD_NAME+'.'+prop_name, 'Description', translation)

def first_state():
  global comp, appl, controls_prop, create_tools_prop, messages_prop, finalized, info_prop, servos
  global all_IO_control_props, joints_selection_props, input_signals_prop, cmd_joint_props, cmd_joint_selections
  cmd = getCommand()
  for p in cmd.Properties:
    deleteProperty(p)
  context = app.CurrentContext
  if context.Id != VC_CONTEXT_AUTHOR:
    'This command can be called from modeling context only'
    return
  comp = context.ActiveComponent
  if not comp:
    warning('Please select 1 Component and 1 Component only.')
    return

  finalized = False
  group = 0
  servos = comp.findBehavioursByType(VC_SERVOCONTROLLER)
  if not servos:
    warning("No ServoController found. Please add first ServoController.")
    #return
  
  all_IO_control_props = []

  pname = 'InputSignals'
  input_signals_prop = createProperty(VC_STRING, pname, VC_PROPERTY_STEP)
  input_signals_prop.StepValues = INPUT_SIGNALS_STEP_VALUES
  input_signals_prop.Group = group = group + 10
  input_signals_prop.IsVisible = True
  input_signals_prop.Value = INPUT_SIGNALS_STEP_VALUES[0]
  all_IO_control_props.append(input_signals_prop)
  if not servos:
    input_signals_prop.StepValues = ["None. (No ServoController found)"]
    input_signals_prop.Value = "None. (No ServoController found)"
    
    input_signals_prop.WritableWhenSimulating = False
    input_signals_prop.WritableWhenDisconnected = False
    input_signals_prop.WritableWhenConnected = False

  i_in = 99
  i_out = 102

  joints_selection_props = []
  cmd_joint_selections = {}
  cmd_joint_props = {}

  for servo in servos:
    for j in servo.Joints:
      joint_props = []
      pname = j.Name
      LocalizeDescription(pname, 'English', joint_tooltip_EN)
      #LocalizeDescription(pname, 'German', joint_tooltip_GE)
      prop = createProperty(VC_BOOLEAN, pname)
      prop.IsVisible = True
      prop.Group = group = group + 10
      prop.Value = True
      prop.OnChanged = UpdateJointProperties
      joints_selection_props.append(prop)
      cmd_joint_selections[pname] = prop
      all_IO_control_props.append(prop)

      pname = j.Name + ': CurrentState'
      LocalizeDescription(pname, 'English', current_state_tooltip_EN)
      #LocalizeDescription(pname, 'German', current_state_tooltip_GE)
      prop = createProperty(VC_STRING, pname, VC_PROPERTY_STEP)
      prop.IsVisible = True
      prop.StepValues = STATE_NAME_STEP_VALUES
      prop.Value = STATE_NAME_STEP_VALUES[0]
      prop.Group = group = group + 10
      joint_props.append(prop)
      all_IO_control_props.append(prop)

      cmd_joint_props[j.Name] = joint_props

  pname = 'Apply'
  appl = createProperty(VC_BUTTON, pname)
  appl.OnChanged = second_state
  appl.Group = group = group + 10
  if not servos:
    appl.WritableWhenSimulating = False
    appl.WritableWhenDisconnected = False
    appl.WritableWhenConnected = False
  
  pname = 'Help'
  info_prop = createProperty(VC_BUTTON, pname)
  info_prop.IsVisible = True
  info_prop.OnChanged = InfoMessageBox
  info_prop.Group = group = group + 10

  pname = 'DisplayMessages'  
  messages_prop = createProperty(VC_BOOLEAN, pname)
  messages_prop.Value = False 
  messages_prop.IsVisible = False # THIS FUNCTIONALITY IS HIDDEN
  messages_prop.Group = group = group + 10

  executeInActionPanel()
  finalized = True


def InfoMessageBox(arg):
  global info_prop, servos
  global input_signals_prop, cmd_joint_selections
  msg = ""
  if not servos:
    msg += "There are no ServoController behaviour found in the component. \n Please define the kinematic links and degrees-of-freedom (Dofs) first, in order to use controls for the end-effector.\n"
  if servos:
    msg += "Wizard would create the following with the current settings:\n"
    amount_of_servos = 0
    amount_of_joints = 0
    amount_of_input_signals = input_signals_prop.StepValues.index(input_signals_prop.Value)+1
    for servo in servos:
      servo_included = False
      for j in servo.Joints:
        if cmd_joint_selections[j.Name].Value:
          servo_included = True
          amount_of_joints += 1
      if servo_included:
        amount_of_servos += 1
    if amount_of_servos>0 and amount_of_joints>0:
      if len(TABNAME)>0:
        tab = ' under "{}"-tab'.format(TABNAME[0:-2])
      else:
        tab = ''
      msg += '- {} properties for joint movement control{}\n'.format(amount_of_joints*3, tab)
      msg += '- {} input signal(s)\n'.format(amount_of_joints*amount_of_input_signals)
      msg += '- {} output signals\n'.format(amount_of_joints*2)
      msg += '- {} python script(s)\n'.format(amount_of_servos)
    msg += "\nNote: The behaviours and the properties with the same name will be re-created and the ones that have no use anymore will be deleted."
    msg += "\n\nNote: Enable PrintChanges to track execution of the wizard in the output panel."
  else:
    msg = "Wizard cannot be used, unless component has at least one ServoController.\n"
  printMessage(msg)  
  ok = app.messageBox(msg,VC_MESSAGE_TYPE_INFO,VC_MESSAGE_BUTTONS_OK)

def UpdateJointProperties(arg):
  cmd = getCommand()
  prop = cmd.getProperty(arg.Name+": CurrentState")
  if arg.Value:
    prop.IsVisible = True
  else:
    prop.IsVisible = False

def second_state(arg):
  global appl, controls_prop
  printMessage("Executing.")
  printMessage('Deleting old properties')
  for prop in comp.Properties:
    if len(TABNAME) > 0 and prop.Name[0:len(TABNAME)] == TABNAME:
      printMessage('Deleting property '+prop.Name, 30)
      comp.deleteProperty(prop)
  servos = comp.findBehavioursByType(VC_SERVOCONTROLLER)
  if servos:
    for servo in servos:
      for j in servo.Joints:
        for state_name in STATE_NAME_STEP_VALUES:
          prop = comp.getProperty(j.Name+"_"+state_name+"Value")
          if prop:
            printMessage('Deleting property '+prop.Name, 30)
            comp.deleteProperty(prop)
  printMessage('Deleting old behaviours')
  for beh in comp.Behaviours:
    if beh.Type == VC_BOOLEANSIGNAL and (beh.Name[0:len(IN_PREFIX)]==IN_PREFIX) or (beh.Name[0:len(OUT_PREFIX)]==OUT_PREFIX):
      printMessage('Deleting signal '+ beh.Name,30)
      beh.delete()
    elif beh.Name[0:len(SCRIPT_NAME)] == SCRIPT_NAME:
      beh.delete()
  AddIOLogic(comp)
  print '{}: {}'.format(WIZARD_NAME, "Done. You may close Wizard now.")


# CREATE SIGNALS AND CONNECT INPUTS TO THE SCRIPT
def CreateAndConnectSignal(signal_name, script = None):
  signal = comp.findBehaviour(signal_name)
  if not signal:
    signal = comp.createBehaviour(VC_BOOLEANSIGNAL,signal_name)
    printMessage('Creating signals "{}".'.format(signal_name),30)
  if script:
    cons = signal.Connections
    if script:
      cons.append(script)
      printMessage('Connecting signal {} to script "{}".'.format(signal_name, script.Name),30)
      signal.Connections = cons
  return signal

def getProperty(type, name, constant = VC_PROPERTY_DEFAULT, def_val = None, step_vals = None, writable=False, quantity = None, visible = True):
  prop = comp.getProperty(name)
  if prop:
    printMessage('Property "{}" exists already. Deleting and creating new.'.format(name))
    comp.deleteProperty(prop)
  prop = comp.createProperty(type, name, constant)
  if writable:
    prop.WritableWhenConnected = True
  else:
    prop.WritableWhenConnected = False
  if not visible:
    comp.Visible = False
  if quantity:
    prop.Quantity = quantity
  if step_vals:
    prop.StepValues = step_vals
    prop.Value = ""
  if def_val:
    prop.Value = def_val
  return prop

def RemoveTabname(name, tabnames):
  for tabname in tabnames:
    tabname = tabname + "::"
    if tabname in name:
      name = name.replace(tabname,"")
  return name

def AddIOLogic(comp):
  global cmd_joint_selections, cmd_joint_props, input_signals_prop
  tabnames = []
  for p in comp.Properties:
    if "::" in p.Name:
      tabname = p.Name.split("::")[0]
      if tabname not in tabnames:
        tabnames.append(tabname)
  properties = dict( [(x.Name.split("::")[-1], x.Value) for x in comp.Properties] ) # dictionario of all component property names (without tabname) and values
  servos = comp.findBehavioursByType(VC_SERVOCONTROLLER)
  #mapped_servo_joints = {}
  
  uri = getCommandPath()[8:]
  head, tail = os.path.split(uri)
  uri1 = os.path.join(head, 'Logic.py')
  with open(uri1,'r') as temp_script:
    logic_script = temp_script.read() 

  group = 0
  input_signal_names = []
  output_signal_names = []
  scripts = {}
  for servo in servos:
    JOINT_IO_NAMES = ""
    servo_joints_used = False
    added_joints = []
    for j in servo.Joints:
      if cmd_joint_selections[j.Name].Value:
        added_joints.append(j)
        servo_joints_used = True
        # check if the joint is currently set or reset and define the direction of the movement
        try:
          min_val = float(eval(RemoveTabname(j.MinValue, tabnames), properties))
        except:
          min_val = 0
        try:
          max_val = float(eval(RemoveTabname(j.MaxValue, tabnames), properties))
        except:
          max_val = min_val + 100
        current_state = cmd_joint_props[j.Name][0].Value
        joint_is_reversed = STATE_MAP[current_state][1].index(current_state)
        mid_point = min_val + ( max_val - min_val) / 2
        if ((j.CurrentValue < mid_point) and joint_is_reversed ) or ((j.CurrentValue >= mid_point) and not joint_is_reversed):
          set_value = min_val
          reset_value = max_val
        else:
          set_value = max_val
          reset_value = min_val
        reset_action_name, set_action_name = STATE_MAP[current_state][0]
        reset_state_name, set_state_name = STATE_MAP[current_state][1]
        for node in getGivenComponentsNodes(comp):
          if node.Dof:
            if node.Dof.Name == j.Dof.Name: 
              if node.JointType == VC_JOINTTYPE_ROTATIONAL or node.JointType == VC_JOINTTYPE_ROTATIONAL_FOLLOWER or node.JointType == VC_JOINT_ROTATIONAL :
                jquantity = "Angle"
              else:
                jquantity = "Distance"
        reset_val_prop = getProperty(VC_REAL,j.Name+"_"+reset_state_name+"Value", def_val = reset_value, writable = True, quantity = jquantity) #Right
        reset_val_prop.Group = group = group + 10
        set_val_prop = getProperty(VC_REAL,j.Name+"_"+set_state_name+"Value", def_val = set_value, writable = True, quantity = jquantity) #Left
        set_val_prop.Group = group = group + 10
        motion_time = getProperty(VC_REAL,j.Name+"_"+"MotionTime", def_val = 0, writable = True, quantity = "Time" )
        motion_time.Group = group = group + 10
        JOINT_IO_NAMES += '"{0}":[["{1}","{2}"],["{3}","{4}"]],'.format(j.Name,reset_action_name,set_action_name,reset_state_name,set_state_name)
    if len(JOINT_IO_NAMES)>0 and JOINT_IO_NAMES[-1] == ',':
      JOINT_IO_NAMES = JOINT_IO_NAMES[:-1]
    if not servo_joints_used: # all joints exluded in servo
      printMessage('Skipping servo "{}", since it is not used.'.format(servo.Name))
      continue
    if len(servos) > 1:
      if " " in servo.Name:
        warning("No spaces allowed in servo controller name. Removing them.")
        servo.Name = servo.Name.replace(" ","") 
      script_name = SCRIPT_NAME+'_'+servo.Name
    else:
      script_name = SCRIPT_NAME
    if len(servos) > 1:
      printMessage('Creating script "{}" for "{}".'.format(SCRIPT_NAME,servo.Name))
    else:
      printMessage('Creating script "{}".'.format(SCRIPT_NAME))
    script = comp.findBehaviour(script_name)
    if script:
      script.delete()
    script = comp.createBehaviour(VC_SCRIPT, script_name)
    script_content = logic_script.replace('TYPEME_SERVO_CONTROLLER_NAME', servo.Name)
    script_content = script_content.replace('TYPEME_THIS_SCRIPT_NAME', script_name)
    #script_content = script_content.replace('TABNAME = ""', 'TABNAME = "{}"'.format(SCRIPT_NAME))
    script_content = script_content.replace('JOINT_IO_NAMES = {}', 'JOINT_IO_NAMES = {%s}'%(JOINT_IO_NAMES))
    
    printMessage('Creating input signals and connecting them to scipt "{}".'.format(script.Name))
    for joint in added_joints:
      joint_name = joint.Name
      current_state = cmd_joint_props[joint_name][0].Value
      in1_name, in2_name = STATE_MAP[current_state][0]
      if input_signals_prop.Value == INPUT_SIGNALS_STEP_VALUES[0]:
        action_signals = [ACTION_NAME]
      elif input_signals_prop.Value == INPUT_SIGNALS_STEP_VALUES[1]:
        action_signals = [in1_name,in2_name]
      elif input_signals_prop.Value == INPUT_SIGNALS_STEP_VALUES[2]:
        action_signals = [ACTION_NAME,in1_name,in2_name]
      # CREATE INPUT SIGNALS FOR OPENING, CLOSING AND OPENCLOSEACTION
      for name in action_signals:
        signal_name=IN_PREFIX+"_"+joint_name+"_"+name
        input_signal_names.append(signal_name)
        CreateAndConnectSignal(signal_name, script)
    scripts[script_name] = script_content

    printMessage('Creating output signals')
    for joint in added_joints:
      joint_name = joint.Name
      current_state = cmd_joint_props[joint_name][0].Value
      # CREATE OUTPUT SIGNALS FOR MIN AND MAX STATE
      for name in STATE_MAP[current_state][1]:
        signal_name=OUT_PREFIX+"_"+joint_name+"_"+name+STATE_NAME
        output_signal_names.append(signal_name)
        signal = CreateAndConnectSignal(signal_name)

  printMessage('Compiling scripts.')
  for s in scripts:
    beh = comp.getBehaviour(s)
    if beh:
      beh.Script = scripts[s]
    else:
      warning('{} Not found'.format(s))

def warning(s):
  print '{} error: {}'.format(WIZARD_NAME, s)

def printMessage(s,i=0):
  global messages_prop
  if messages_prop.Value:
    if i>0:
      print '{}... {}'.format(i*" ", s)
    else:
      print '{}: {}'.format(WIZARD_NAME, s)

addState( first_state )

#
# language translations
#
localize = app.findCommand('netCommand')
joint_tooltip_EN = 'Adds IO-controls for this joint'
current_state_tooltip_EN = 'Define how the joint is currently positioned.'