from __future__ import with_statement
from vcCommand import *
from vcHelpers.Selection import *
import os.path

app = getApplication()

TABNAME = "Control::"
WIZARD_NAME = "EOAT_Wizard"
SCRIPT_NAME = "GripperLogic"
MOUNT_FRAME_NAME = "MountFrame"
ROBOT_INTERFACE_NAME = "EOAT_MountInterface"
ACTION_NAME = "Action"
STATE_NAME = "State"
IN_PREFIX = "IN"
OUT_PREFIX = "OUT"
INPUT_SIGNALS_STEP_VALUES = ['One ActionSignal to Open/Close', 'Two Separate Signals to Open/Close', 'Three Signals (Both Options Above)']
TOOL_CONTAINER_STEP_VALUES = ['Null','Add a Tool Center Point']
CONTROL_OPTIONS = ["IO","ExternalAxis"]
STATE_MAP = {
"Open":[["Open","Close"],["Open","Closed"]],
"Closed":[["Open","Close"],["Open","Closed"]]}
INPUT_NAME_STEP_VALUES = [ACTION_NAME]
STATE_NAME_STEP_VALUES = []
for state_name in STATE_MAP:
  for input_name in STATE_MAP[state_name][0]:
    if input_name not in INPUT_NAME_STEP_VALUES:
      INPUT_NAME_STEP_VALUES.append(input_name)
  for output_name in STATE_MAP[state_name][1]:
    if output_name not in STATE_NAME_STEP_VALUES:
      STATE_NAME_STEP_VALUES.append(output_name)
RESET_ACTION_NAMES = []
SET_ACTION_NAMES = []
RESET_STATE_NAMES = []
SET_STATE_NAMES = []
for state_name in STATE_MAP:
  reset_action_name, set_action_name = STATE_MAP[state_name][0]
  if reset_action_name not in RESET_ACTION_NAMES:
    RESET_ACTION_NAMES.append(reset_action_name)
  if set_action_name not in SET_ACTION_NAMES:
    SET_ACTION_NAMES.append(set_action_name)
  reset_state, set_state = STATE_MAP[state_name][1]
  if reset_state not in RESET_STATE_NAMES:
    RESET_STATE_NAMES.append(reset_state)
  if set_state not in SET_STATE_NAMES:
    SET_STATE_NAMES.append(set_state)
  
def LocalizeDescription(prop_name, language, translation):
  localize.execute('SetLocalizationCommand', language, 'Python', WIZARD_NAME+'.'+prop_name, 'Description', translation)

def first_state():
  global comp, appl, controls_prop, create_tools_prop, messages_prop, finalized, info_prop, servos
  global all_IO_control_props, joints_selection_props, input_signals_prop, cmd_joint_props, cmd_joint_selections
  cmd = getCommand()
  for p in cmd.Properties:
    deleteProperty(p)
  context = app.CurrentContext
  if context.Id != VC_CONTEXT_AUTHOR:
    'This command can be called from modeling context only'
    return
  comp = context.ActiveComponent
  if not comp:
    warning('Please select 1 Component and 1 Component only.')
    return

  finalized = False
  group = 0
  pname = 'Controls'
  controls_prop = createProperty(VC_STRING, pname, VC_PROPERTY_STEP)
  controls_prop.Group = group = group + 10
  controls_prop.OnChanged = OnControlPropertyChanged
  servos = comp.findBehavioursByType(VC_SERVOCONTROLLER)
  if servos:
    controls_prop.StepValues = ["None", "IO", "ExternalAxis", "IO / ExternalAxis"]
    controls_prop.Value = "None"
  else:
    controls_prop.StepValues = ["None. (No ServoController found)"]
    controls_prop.Value = controls_prop.StepValues[0]
    controls_prop.WritableWhenSimulating = False
    controls_prop.WritableWhenDisconnected = False
    controls_prop.WritableWhenConnected = False
  
  pname = 'TCP'
  create_tools_prop = createProperty(VC_STRING, pname, VC_PROPERTY_STEP)
  create_tools_prop.StepValues = TOOL_CONTAINER_STEP_VALUES
  create_tools_prop.Value = TOOL_CONTAINER_STEP_VALUES[1]
  create_tools_prop.Group = group = group + 10

  all_IO_control_props = []

  pname = 'InputSignals'
  input_signals_prop = createProperty(VC_STRING, pname, VC_PROPERTY_STEP)
  input_signals_prop.StepValues = INPUT_SIGNALS_STEP_VALUES
  input_signals_prop.Group = group = group + 10
  input_signals_prop.IsVisible = False
  input_signals_prop.Value = INPUT_SIGNALS_STEP_VALUES[1]
  input_signals_prop.OnChanged = UpdateJointProperties
  all_IO_control_props.append(input_signals_prop)

  i_in = 100
  i_out = 101

  joints_selection_props = []
  cmd_joint_selections = {}
  cmd_joint_props = {}

  for servo in servos:
    for j in servo.Joints:
      joint_props = []
      pname = j.Name
      LocalizeDescription(pname, 'English', joint_tooltip_EN)
      LocalizeDescription(pname, 'Spanish', joint_tooltip_ES)
      LocalizeDescription(pname, 'Korean', joint_tooltip_KR)
      LocalizeDescription(pname, 'Chinese', joint_tooltip_ZHS)
      LocalizeDescription(pname, 'Traditional Chinese', joint_tooltip_ZHT)
      LocalizeDescription(pname, 'Japanese', joint_tooltip_JP)
      LocalizeDescription(pname, 'German', joint_tooltip_DE)
      LocalizeDescription(pname, 'French', joint_tooltip_FR)
      prop = createProperty(VC_BOOLEAN, pname)
      prop.IsVisible = False
      prop.Group = group = group + 10
      prop.Value = False
      prop.OnChanged = UpdateJointProperties
      joints_selection_props.append(prop)
      cmd_joint_selections[pname] = prop
      all_IO_control_props.append(prop)

      pname = j.Name + ': CurrentState'
      LocalizeDescription(pname, 'English', current_state_tooltip_EN)
      LocalizeDescription(pname, 'Spanish', current_state_tooltip_ES)
      LocalizeDescription(pname, 'Korean', current_state_tooltip_KR)
      LocalizeDescription(pname, 'Chinese', current_state_tooltip_ZHS)
      LocalizeDescription(pname, 'Traditional Chinese', current_state_tooltip_ZHT)
      LocalizeDescription(pname, 'Japanese', current_state_tooltip_JP)
      LocalizeDescription(pname, 'German', current_state_tooltip_DE)
      LocalizeDescription(pname, 'French', current_state_tooltip_FR)
      prop = createProperty(VC_STRING, pname, VC_PROPERTY_STEP)
      prop.IsVisible = False
      prop.StepValues = STATE_NAME_STEP_VALUES
      prop.Value = STATE_NAME_STEP_VALUES[0]
      prop.Group = group = group + 10
      prop.OnChanged = UpdateJointProperties
      joint_props.append(prop)
      all_IO_control_props.append(prop)

      in_port_prop_names = map(lambda x: "{}: {}_{}_Port".format(j.Name, IN_PREFIX, x), INPUT_NAME_STEP_VALUES)
      for i, pname in enumerate(in_port_prop_names):
        LocalizeDescription(pname, 'English', port_in_tooltip_EN)
        LocalizeDescription(pname, 'Spanish', port_in_tooltip_ES)
        LocalizeDescription(pname, 'Korean', port_in_tooltip_KR)
        LocalizeDescription(pname, 'Chinese', port_in_tooltip_ZHS)
        LocalizeDescription(pname, 'Traditional Chinese', port_in_tooltip_ZHT)
        LocalizeDescription(pname, 'Japanese', port_in_tooltip_JP)
        LocalizeDescription(pname, 'German', port_in_tooltip_DE)
        LocalizeDescription(pname, 'French', port_in_tooltip_FR)
        prop = createProperty(VC_INTEGER, pname)
        prop.IsVisible = False
        prop.Group = group = group + 10
        prop.Value = i_in 
        i_in += 1
        if i != 0:
          i_in -= 2 * ((i-1) % 2)
        prop.OnChanged = UniformInputPortIndexes
        joint_props.append(prop)
        all_IO_control_props.append(prop)
      i_in += 2

      out_port_prop_names = map(lambda x: "{}: {}_{}{}_Port".format(j.Name, OUT_PREFIX, x, STATE_NAME), STATE_NAME_STEP_VALUES)
      for i, pname in enumerate(out_port_prop_names):
        LocalizeDescription(pname, 'English', port_in_tooltip_EN)
        LocalizeDescription(pname, 'Spanish', port_in_tooltip_ES)
        LocalizeDescription(pname, 'Korean', port_in_tooltip_KR)
        LocalizeDescription(pname, 'Chinese', port_in_tooltip_ZHT)
        LocalizeDescription(pname, 'Traditional Chinese', port_in_tooltip_ZHS)
        LocalizeDescription(pname, 'Japanese', port_in_tooltip_JP)
        LocalizeDescription(pname, 'French', port_in_tooltip_FR)
        prop = createProperty(VC_INTEGER, pname)
        prop.IsVisible = False
        prop.Group = group = group + 10
        prop.Value = i_out
        i_out += 1 - 2 * ((i) % 2)
        prop.OnChanged = UniformOutputPortIndexes
        joint_props.append(prop)
        all_IO_control_props.append(prop)
      i_out += 3
      cmd_joint_props[j.Name] = joint_props

  pname = 'Apply'
  appl = createProperty(VC_BUTTON, pname)
  appl.OnChanged = second_state
  appl.Group = group = group + 10
  
  pname = 'Help'
  info_prop = createProperty(VC_BUTTON, pname)
  info_prop.IsVisible = True
  info_prop.OnChanged = InfoMessageBox
  info_prop.Group = group = group + 10

  pname = 'PrintChanges'  
  messages_prop = createProperty(VC_BOOLEAN, pname)
  messages_prop.Value = False 
  messages_prop.IsVisible = True # THIS FUNCTIONALITY IS HIDDEN
  messages_prop.Group = group = group + 10

  executeInActionPanel()
  finalized = True

def InfoMessageBox(arg):
  global controls_prop, create_tools_prop, servos, info_prop
  global input_signals_prop, cmd_joint_selections
  msg = ""
  msg += "With the current settings the wizard would create the following:\n"
  msg += '- "{}"-feature in root of the component\n'.format(MOUNT_FRAME_NAME)
  msg += '- "{}"-behaviour\n'.format(ROBOT_INTERFACE_NAME)
  if create_tools_prop.Value != TOOL_CONTAINER_STEP_VALUES[0]: #"Null"
    msg += '- ToolContainer with one tool center point (TCP)\n'
  if controls_prop.Value in ["IO", "IO / ExternalAxis"]:
    if servos:
      amount_of_servos = 0
      amount_of_joints = 0
      amount_of_input_signals = input_signals_prop.StepValues.index(input_signals_prop.Value)+1
      for servo in servos:
        servo_included = False
        for j in servo.Joints:
          if cmd_joint_selections[j.Name].Value:
            servo_included = True
            amount_of_joints += 1
        if servo_included:
          amount_of_servos += 1
      if amount_of_servos>0 and amount_of_joints>0:
        if len(TABNAME)>0:
          tab = ' under "{}"-tab'.format(TABNAME[0:-2])
        else:
          tab = ''
        if controls_prop.Value == "IO / ExternalAxis":
          msg += '- "ControlMode"-property{} to change the controls (IO/ExternalAxis) in end effector\n'.format(tab)
        msg += '- {} properties for joint movement control{}\n'.format(amount_of_joints*3, tab)
        msg += '- "AutoConnectIOs"-property{}\n'.format(tab)
        msg += '- {} properties to define robot ports{}\n'.format(amount_of_joints*(amount_of_input_signals+2), tab)
        msg += '- {} input signal(s)\n'.format(amount_of_joints*amount_of_input_signals)
        msg += '- {} output signals\n'.format(amount_of_joints*2)
        msg += '- {} python script(s)\n'.format(amount_of_servos)

  msg += "\nNote: The behaviours and the properties with the same name will be re-created and the ones that have no use anymore will be deleted."
  msg += "\n\nNote: Enable PrintChanges to track execution of the wizard in the output panel."
  if not servos:
    msg += "\n\nNote: There are no ServoController behaviour found in the component. " 
    msg += "Please define the kinematic links and degrees-of-freedom (Dofs) first, in order to use controls for the end effector.\n\n"

  printMessage(msg)
  ok = app.messageBox(msg,VC_MESSAGE_TYPE_INFO,VC_MESSAGE_BUTTONS_OK)

def UniformInputPortIndexes(prop):
  if "Action" in prop.Name:
    return
  else:
    cmd = getCommand()
    joint_name, signal_name = prop.Name.split(': ')
    prefix, input_name, port = signal_name.split('_')
    if input_name in SET_ACTION_NAMES:
      for set_name in SET_ACTION_NAMES:
        if input_name != set_name:
          other_prop_name = prop.Name.replace(input_name, set_name) 
          other_prop = cmd.getProperty(other_prop_name)
          other_prop.Value = prop.Value
    elif input_name in RESET_ACTION_NAMES:
      for reset_name in RESET_ACTION_NAMES:
        if input_name != reset_name:
          other_prop_name = prop.Name.replace(input_name, reset_name) 
          other_prop = cmd.getProperty(other_prop_name)
          other_prop.Value = prop.Value

def UniformOutputPortIndexes(prop):
  cmd = getCommand()
  joint_name, signal_name = prop.Name.split(': ')
  prefix, output_state_name, port = signal_name.split('_')
  output_name = output_state_name.replace("State","")
  if output_name in RESET_STATE_NAMES:
    for state_name in RESET_STATE_NAMES:
      if output_name != state_name:
        other_prop_name = prop.Name.replace(output_name, state_name) 
        other_prop = cmd.getProperty(other_prop_name)
        other_prop.Value = prop.Value
  elif output_name in SET_STATE_NAMES:
    for state_name in SET_STATE_NAMES:
      if output_name != state_name:
        other_prop_name = prop.Name.replace(output_name, state_name) 
        other_prop = cmd.getProperty(other_prop_name)
        other_prop.Value = prop.Value

def OnControlPropertyChanged(arg):
  global all_IO_control_props, controls_prop, input_signals_prop, joints_selection_props, finalized
  if not finalized:
    return
  if arg.Value == 'None' or arg.Value == 'ExternalAxis':
    for prop in all_IO_control_props:
      prop.IsVisible = False
  else:
    #for prop in all_IO_control_props:
    #  prop.IsVisible = True # shows all IO-properties
    input_signals_prop.IsVisible = True
    for prop in joints_selection_props:
      prop.IsVisible = True
      prop.Value = True # expands all joint properties
    UpdateJointProperties('FOO')

def UpdateJointProperties(arg):
  global joints_selection_props, cmd_joint_props, input_signals_prop, finalized
  if not finalized:
    return
  for joint_sel in joints_selection_props:
    joint_props = cmd_joint_props[joint_sel.Name]
    if joint_sel.Value:
      current_state_prop = joint_props[0]
      current_state_prop.IsVisible = True
      action_prop = joint_props[1]
      if input_signals_prop.Value != INPUT_SIGNALS_STEP_VALUES[1]:
        action_prop.IsVisible = True
      else:
        action_prop.IsVisible = False
      for prop in joint_props[2:]:
        if input_signals_prop.Value == INPUT_SIGNALS_STEP_VALUES[0] and IN_PREFIX in prop.Name:
          prop.IsVisible = False
        else:
          key1, key2 = STATE_MAP[current_state_prop.Value][0]
          if key1 in prop.Name or key2 in prop.Name:
            prop.IsVisible = True
          else:
            prop.IsVisible = False
    else:
      for prop in joint_props:
        prop.IsVisible = False

def second_state(arg):
  global appl, controls_prop
  printMessage("Executing.")
  iface = AddInterface(comp)
  printMessage('Deleting old properties')
  for prop in comp.Properties:
    if len(TABNAME) > 0 and prop.Name[0:len(TABNAME)] == TABNAME:
      printMessage('Deleting property '+prop.Name, 30)
      comp.deleteProperty(prop)
  servos = comp.findBehavioursByType(VC_SERVOCONTROLLER)
  if servos:
    for servo in servos:
      for j in servo.Joints:
        prop = comp.getProperty(j.Name+"_MotionTime")
        if prop:
          printMessage('Deleting property '+prop.Name, 30)
          comp.deleteProperty(prop)
        for state_name in STATE_NAME_STEP_VALUES:
          prop = comp.getProperty(j.Name+"_"+state_name+"Value")
          if prop:
            printMessage('Deleting property '+prop.Name, 30)
            comp.deleteProperty(prop)
  printMessage('Deleting old behaviours')
  for beh in comp.Behaviours:
    if not beh:
      continue
    elif beh.Type == VC_BOOLEANSIGNAL and (beh.Name[0:len(IN_PREFIX)]==IN_PREFIX) or (beh.Name[0:len(OUT_PREFIX)]==OUT_PREFIX):
      printMessage('Deleting signal '+ beh.Name,30)
      beh.delete()
    elif beh.Name[0:len(SCRIPT_NAME)] == SCRIPT_NAME:
      beh.delete()
  if controls_prop.Value == "None":
    pass
  elif controls_prop.Value == 'ExternalAxis':
    servo = servos[0]
    add_joint_export_field(iface, servo)
  elif controls_prop.Value == "IO":
    AddLogic(comp,False)
  elif controls_prop.Value == 'IO / ExternalAxis':
    AddLogic(comp,True)

  print '{}: {}'.format(WIZARD_NAME, "Done. You may close Wizard now.")

# CREATE MOUNTFRAME AND MOUNTINTERFACE
def AddInterface(comp):
  global create_tools_prop
  frame = comp.findFeature(MOUNT_FRAME_NAME)
  if not frame:
    printMessage("Creating MountFrame to RootFeature.")
    frame = comp.RootFeature.createFeature(VC_FRAME, MOUNT_FRAME_NAME)  
  iface = comp.findBehaviour(ROBOT_INTERFACE_NAME)
  if iface:
    printMessage("Deleting old MountInterface.")
    iface.delete()
  printMessage("Creating new MountInterface")
  iface = comp.createBehaviour(VC_ONETOONEINTERFACE,ROBOT_INTERFACE_NAME)
  printMessage("Creating new Section",30)
  section = iface.createSection("RobotTool")
  section.Frame = frame
  printMessage("Creating new HierarchyField.",30)
  pnp_field = section.createField(VC_HIERARCHYFIELD,"Hierarchy")
  pnp_field.Node = comp
  pnp_field.Frame = frame
  pnp_field.Parent = False
  tool_lists = comp.findBehavioursByType(VC_TOOLCONTAINER)
  if create_tools_prop.Value != TOOL_CONTAINER_STEP_VALUES[0]: # "Null"
    if not tool_lists:
      tc = comp.createBehaviour(VC_TOOLCONTAINER, "ToolContainer")
      base_frame = tc.addTool()
      base_frame.Name = "TCP"
      tool_lists.append(tc)
  if tool_lists:
    tc = tool_lists[0]
    printMessage("Creating new ToolField.",30)
    tool_field = section.createField(VC_TOOLEXPORTFIELD,"TCP")
    tool_field.ToolList = tc
    tool_field.Export = True
  return iface

def add_joint_export_field(iface, servo):
  section = iface.Sections[0]
  printMessage("Creating new JointExportField.",30)
  field = section.createField(VC_JOINTEXPORTFIELD , 'JointExport')
  field.Controller = servo
  field.Export = True

# CREATE SIGNALS AND CONNECT INPUTS TO THE SCRIPT
def CreateAndConnectSignal(signal_name, script = None):
  signal = comp.findBehaviour(signal_name)
  if not signal:
    signal = comp.createBehaviour(VC_BOOLEANSIGNAL,signal_name)
    printMessage('Creating signals "{}".'.format(signal_name),30)
  if script:
    cons = signal.Connections
    if script:
      cons.append(script)
      printMessage('Connecting signal {} to script "{}".'.format(signal_name, script.Name),30)
      signal.Connections = cons
  return signal

def getProperty(type, name, constant = VC_PROPERTY_DEFAULT, def_val = None, step_vals = None, writable=False, quantity = None, visible = True):
  prop = comp.getProperty(name)
  if prop:
    printMessage('Property "{}" exists already. Deleting and creating new.'.format(name))
    comp.deleteProperty(prop)
  prop = comp.createProperty(type, name, constant)
  if writable:
    prop.WritableWhenConnected = True
  else:
    prop.WritableWhenConnected = False
  if not visible:
    comp.Visible = False
  if quantity:
    prop.Quantity = quantity
  if step_vals:
    prop.StepValues = step_vals
    prop.Value = ""
  if def_val:
    prop.Value = def_val
  return prop

def RemoveTabname(name, tabnames):
  for tabname in tabnames:
    tabname = tabname + "::"
    if tabname in name:
      name = name.replace(tabname,"")
  return name

def AddLogic(comp,ex_axis_option):
  global cmd_joint_selections, cmd_joint_props, input_signals_prop
  tabnames = []
  for p in comp.Properties:
    if "::" in p.Name:
      tabname = p.Name.split("::")[0]
      if tabname not in tabnames:
        tabnames.append(tabname)
  properties = dict( [(x.Name.split("::")[-1], x.Value) for x in comp.Properties] ) # dictionario of all component property names (without tabname) and values
  servos = comp.findBehavioursByType(VC_SERVOCONTROLLER)
  #mapped_servo_joints = {}
  
  uri = getCommandPath()[8:]
  head, tail = os.path.split(uri)
  uri1 = os.path.join(head, 'Logic.py')
  uri2 = os.path.join(head, 'AutoIOs.py')
  uri3 = os.path.join(head, 'ExternalAxis.py')
  with open(uri1,'r') as temp_script:
    logic_script = temp_script.read() 
  with open(uri2,'r') as temp_script:
    auto_io_script = temp_script.read() 
  with open(uri3, 'r') as temp_script:
    ex_axis_script = temp_script.read()

  group = 0
  if ex_axis_option:
    # CREATE PORT PROPERTIES TO "Control"-TAB
    control_prop = getProperty(VC_STRING, TABNAME+"ControlMode", VC_PROPERTY_STEP, step_vals = CONTROL_OPTIONS)
    control_prop.Group = group = group + 10
    control_prop.Value = CONTROL_OPTIONS[0]
  autoIOs_prop = getProperty(VC_BOOLEAN, TABNAME+"AutoConnectIOs", def_val=True,writable=True)
  autoIOs_prop.Group = 990
  input_signal_names = {}
  output_signal_names = {}
  scripts = {}
  for servo in servos:
    JOINT_IO_NAMES = ""
    servo_joints_used = False
    added_joints = []
    for j in servo.Joints:
      if cmd_joint_selections[j.Name].Value:
        added_joints.append(j)
        servo_joints_used = True
        # check if the joint is currently set or reset and define the direction of the movement
        try:
          min_val = float(eval(RemoveTabname(j.MinValue, tabnames), properties))
        except:
          min_val = 0
        try:
          max_val = float(eval(RemoveTabname(j.MaxValue, tabnames), properties))
        except:
          max_val = min_val + 100
        current_state = cmd_joint_props[j.Name][0].Value
        # OnTrue always close, OnFalse always open, but define which end is open and which close
        joint_is_reversed = STATE_MAP[current_state][1].index(current_state)
        mid_point = min_val + ( max_val - min_val) / 2
        if ((j.CurrentValue < mid_point) and joint_is_reversed ) or ((j.CurrentValue >= mid_point) and not joint_is_reversed):
          set_value = min_val
          reset_value = max_val
        else:
          set_value = max_val
          reset_value = min_val
        reset_action_name, set_action_name = STATE_MAP[current_state][0]
        reset_state_name, set_state_name = STATE_MAP[current_state][1]
        for node in getGivenComponentsNodes(comp):
          if node.Dof:
            if node.Dof.Name == j.Dof.Name: 
              if node.JointType == VC_JOINTTYPE_ROTATIONAL or node.JointType == VC_JOINTTYPE_ROTATIONAL_FOLLOWER or node.JointType == VC_JOINT_ROTATIONAL :
                jquantity = "Angle"
              else:
                jquantity = "Distance"
        reset_val_prop = getProperty(VC_REAL,j.Name+"_"+reset_state_name+"Value", def_val = reset_value, writable = True, quantity = jquantity) #Right
        reset_val_prop.Group = group = group + 10
        set_val_prop = getProperty(VC_REAL,j.Name+"_"+set_state_name+"Value", def_val = set_value, writable = True, quantity = jquantity) #Left
        set_val_prop.Group = group = group + 10
        motion_time = getProperty(VC_REAL,j.Name+"_"+"MotionTime", def_val = 0, writable = True, quantity = "Time" )
        motion_time.Group = group = group + 10
        JOINT_IO_NAMES += '"{0}":[["{1}","{2}"],["{3}","{4}"]],'.format(j.Name,reset_action_name,set_action_name,reset_state_name,set_state_name)
    if len(JOINT_IO_NAMES)>0 and JOINT_IO_NAMES[-1] == ',':
      JOINT_IO_NAMES = JOINT_IO_NAMES[:-1]
    if not servo_joints_used: # all joints exluded in servo
      printMessage('Skipping servo "{}", since it is not used.'.format(servo.Name))
      continue
    if len(servos) > 1:
      if " " in servo.Name:
        warning("No spaces allowed in servo controller name. Removing them.")
        servo.Name = servo.Name.replace(" ","") 
      script_name = SCRIPT_NAME+'_'+servo.Name
    else:
      script_name = SCRIPT_NAME
    if len(servos) > 1:
      printMessage('Creating script "{}" for "{}".'.format(SCRIPT_NAME,servo.Name))
    else:
      printMessage('Creating script "{}".'.format(SCRIPT_NAME))
    script = comp.findBehaviour(script_name)
    if script:
      script.delete()
    script = comp.createBehaviour(VC_SCRIPT, script_name)
    script_content = logic_script.replace('TYPEME_SERVO_CONTROLLER_NAME', servo.Name)
    script_content = script_content.replace('TYPEME_THIS_SCRIPT_NAME', script_name)
    script_content = script_content.replace('TABNAME = ""', 'TABNAME = "{}"'.format(TABNAME))
    script_content = script_content.replace('JOINT_IO_NAMES = {}', 'JOINT_IO_NAMES = {%s}'%(JOINT_IO_NAMES))

    if len(servos) > 1:
      printMessage('Adding IO-controls in "{}" for "{}".'.format(SCRIPT_NAME,servo.Name))
    else:
      printMessage('Adding IO-controls in "{}".'.format(SCRIPT_NAME))
    script_content += auto_io_script

    if ex_axis_option:
      if len(servos) > 1:
        printMessage('Adding ExternalAxis option in "{}" for "{}".'.format(SCRIPT_NAME,servo.Name))
      else:
        printMessage('Adding ExternalAxis option in "{}".'.format(SCRIPT_NAME))
      script_content += ex_axis_script

    printMessage('Creating input signals and connecting them to scipt "{}".'.format(script.Name))
    for joint in added_joints:
      joint_name = joint.Name
      current_state = cmd_joint_props[joint_name][0].Value
      in1_name, in2_name = STATE_MAP[current_state][0]
      if input_signals_prop.Value == INPUT_SIGNALS_STEP_VALUES[0]:
        action_signals = [ACTION_NAME]
      elif input_signals_prop.Value == INPUT_SIGNALS_STEP_VALUES[1]:
        action_signals = [in1_name,in2_name]
      elif input_signals_prop.Value == INPUT_SIGNALS_STEP_VALUES[2]:
        action_signals = [ACTION_NAME,in1_name,in2_name]
      # CREATE INPUT SIGNALS FOR OPENING, CLOSING AND OPENCLOSEACTION
      for name in action_signals:
        signal_name = IN_PREFIX+"_"+joint_name+"_"+name
        for prop in cmd_joint_props[joint_name]:
          if prop.Name == "{}: {}_{}_Port".format(joint_name, IN_PREFIX, name):
            port_value = int(prop.Value)
        input_signal_names[signal_name] = port_value
        CreateAndConnectSignal(signal_name, script)
    scripts[script_name] = script_content

    printMessage('Creating output signals')
    for joint in added_joints:
      joint_name = joint.Name
      current_state = cmd_joint_props[joint_name][0].Value
      # CREATE OUTPUT SIGNALS FOR MIN AND MAX STATE
      for name in STATE_MAP[current_state][1]:
        signal_name=OUT_PREFIX+"_"+joint_name+"_"+name+STATE_NAME
        for prop in cmd_joint_props[joint_name]:
          if prop.Name == "{}: {}_{}{}_Port".format(joint_name, OUT_PREFIX, name, STATE_NAME):
            port_value = int(prop.Value)
        output_signal_names[signal_name] = port_value
        signal = CreateAndConnectSignal(signal_name)

  group = 1000

  # CREATE PORT PROPERTIES TO "Control"-TAB
  printMessage('Creating port properties to control tab')
  for name in input_signal_names:
    pname = TABNAME+name+"_Port"
    port_prop = comp.getProperty(pname)
    if not port_prop:
      port_prop = getProperty(VC_INTEGER, pname, def_val=input_signal_names[name])
      port_prop.Group = group = group + 10

  for name in output_signal_names:
    pname = TABNAME+name+"_Port"
    port_prop = comp.getProperty(pname)
    if not port_prop:
      port_prop = getProperty(VC_INTEGER, pname, def_val=output_signal_names[name])
      port_prop.Group = group = group + 10

  printMessage('Compiling scripts.')
  for s in scripts:
    beh = comp.getBehaviour(s)
    if beh:
      beh.Script = scripts[s]
    else:
      warning('{} Not found'.format(s))

def warning(s):
  print '{} error: {}'.format(WIZARD_NAME, s)

def printMessage(s,i=0):
  global messages_prop
  if messages_prop.Value:
    if i>0:
      print '{}... {}'.format(i*" ", s)
    else:
      print '{}: {}'.format(WIZARD_NAME, s)

addState( first_state )


# language translations for EOAT_Wizard.py
localize = app.findCommand('netCommand')

#ENGLISH
joint_tooltip_EN = 'Adds IO-controls for this joint'
current_state_tooltip_EN = 'Define how the joint is currently positioned'
port_in_tooltip_EN = 'Define to which robot output port this input signal will be auto-connected'
port_out_tooltip_EN = 'Define to which robot input port this output signal will be auto-connected'

#SPANISH
joint_tooltip_ES = 'Añade controles IO para esta junta'
current_state_tooltip_ES = 'Definir cómo está colocada la junta actualmente'
port_in_tooltip_ES = 'Definir a qué puerto de salida del robot se autoconectará esta señal de entrada'
port_out_tooltip_ES = 'Definir a qué puerto de entrada del robot se autoconectará esta señal de salida'

#KOREAN
joint_tooltip_KR = '이 조인트에 IO-컨트롤 추가'
current_state_tooltip_KR = '조인트의 현재 위치 정의'
port_in_tooltip_KR = '이 입력 시그널에 대해 어떤 로봇 출력 포트가 자동 연결되는지 정의'
port_out_tooltip_KR = '이 출력 시그널에 대해 어떤 로봇 입력 포트가 자동 연결되는지 정의'

#SIMPLIFIED CHINESE
joint_tooltip_ZHS = ' 为此关节添加IO控件'
current_state_tooltip_ZHS = '定义关节当前的位置 '
port_in_tooltip_ZHS = ' 定义此输入信号将自动连接到哪个机器人输出端口'
port_out_tooltip_ZHS = ' 定义此输出信号将自动连接到哪个机器人输入端口'


#TRADITIONAL CHINESE
joint_tooltip_ZHT = '為這個關節添加IO控件'
current_state_tooltip_ZHT = '定義關節目前如何定位'
port_in_tooltip_ZHT = '定義這個輸入信號將會自動地連接到哪個機器人輸出連接埠'
port_out_tooltip_ZHT = '定義這個輸出信號將會自動地連接到哪個機器人輸入連接埠'

#GERMAN
joint_tooltip_DE = 'Fügt Ein-/Ausgabe-Steuerungen für dieses Gelenk hinzu'
current_state_tooltip_DE = 'Definieren Sie, wie das Gelenk aktuell positioniert ist'
port_in_tooltip_DE = 'Definieren Sie, mit welchem Roboter-Ausgabeport dieses Eingabesignal automatisch verbunden wird'
port_out_tooltip_DE = 'Definieren Sie, mit welchem Roboter-Eingabeport dieses Ausgabesignal automatisch verbunden wird'

#JAPANESE
joint_tooltip_JP = 'このジョイントにIOコントロールを追加します'
current_state_tooltip_JP = 'ジョイントの現在の位置を定義します'
port_in_tooltip_JP = 'この入力シグナルをどのロボット出力ポートに自動接続するかを定義します'
port_out_tooltip_JP = 'この出力シグナルをどのロボット入力ポートに自動接続するかを定義します'

#FRENCH
joint_tooltip_FR = "Permet d'ajouter des commandes d'entrées-sorties pour cette articulation"
current_state_tooltip_FR = "Permet de définir la position actuelle de l'articulation"
port_in_tooltip_FR = "Permet de définir à quel port de sortie du robot ce signal d'entrée sera automatiquement connecté"
port_out_tooltip_FR = "Permet de définir à quel port d'entrée du robot ce signal de sortie sera automatiquement connecté"
