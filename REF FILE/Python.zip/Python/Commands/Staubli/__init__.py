from vcApplication import *

def OnStart():
  cmd = findCommand("RslToVal3V7")
  if cmd:
    deleteCommand("RslToVal3V7")
  cmduri = getApplicationPath() + 'RslToVal3V7.py'
  cmd = loadCommand("RslToVal3V7", cmduri)
  cmd.createProperty( VC_STRING, "Mappings" )
  cmd.createProperty( VC_STRING, "Robot" )
  cmd.createProperty( VC_BOOLEAN, "Succeeded")
  cmd.createProperty( VC_BOOLEAN, "WriteUnmapped")
  cmd.createProperty( VC_STRING, "ApplicationName")
  cmd.createProperty( VC_STRING, "ApplicationPath")