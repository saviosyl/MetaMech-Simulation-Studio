#**********************************************************************
#   * Visual Components 
#
#   * modified: 30-Nov-2020
#   * Modified folderPath variable to use unicode UTF-8 string
#
#   * modified: 20-Nov-2020
#   * Fixed timer function, restored some of the VC defaults, and minor code cleanup
#       Fixed and modified timer function to collect up to 49 timestamps per main program cycle. 
#           The timestamps are reset at cycle start. 
#           Similar timestamp logic is used for both CS8 and CS9. Both UIs also show the timestamps.
#       Conveyor tracking disabled by default
#       Restored waitEndMove insertion logic to match program execution in VC
#       Removed automatic renaming of all VC robot routines with invalid Val3 names to "vcHelperMove"
#
#   * modified: 30-Aug-2020
#   * Several modifications in the Val3 result:
#       new program, taskOfTime to calculate step time
#       in tracking change "vcHelperLinearMove" to "vcHelperMove" in order to match the maximum length 
#       in CS8C new encoder link
#       removed all waitEndMove added after a RSI routine
#       add a waitEndMove after each delay present in the RSL program 
#       add more "same" configuration type in order to create less configuration problem in Val3 
#   
#   * modified: 18-Aug-2017
#   * Fixed to support new robot configuration names
#
#   * modified: 09-June-2017
#   * Visual Components: 4.0 Migration changes
#       Major refactoring and cleanup
#       Selection changes
#       New executor and statement structure support
#       Support for program flow statements and variables
#       All messages are now localizable
#       Added motion description variable generation
#       Now by default generates synchronous movements like in simulation
#   
#   * modified: 03.11.2016
#   * Bug correction in Base Frame Change post Pro
#   
#   * modified: 05.10.2016
#   * Bug correction in Base Frame Change post Pro
#   * Bug correction in Timer program 
#
#   * modified: 27.05.2015
#   * STÄUBLI Modification : 
#      Add joint value
#   * STÄUBLI Modification : 
#      New Val3 Program with Tracking
#     
#   * modified: 08.07.2013
#   * STÄUBLI Modification : 
#     Configuration correction for RX260/270 TX340SH and Righty ARM
#     Bug Correction for FRAME et 4 Axis Arm Tools generation
#
#**********************************************************************

from vcCommand import *
import os, os.path, sys, string
import xml.dom.minidom
import vcMatrix
import vcVector
import re
import StringIO
import json
from math import *
from itertools import groupby
from itertools import ifilter

app = getApplication()

CONVEYOR_TRACKING_ENABLED = False
USE_SYNCHRONOUS_MOVEMENT = True

# Data structure for Point information
class Point:
  pass
# Data structure for Joint information
class Joint:
  pass
# Data structure for Tool information
class Tool:
  pass
# Data structure for Base information
class Base:
  pass
# Data structure for I/O mapping information
class Mapping:
  pass
# Main structure for holding sets of VC robot program variables
class ProgramVariables:
  pass
# Data structure for program variable information
class ProgramVariable:
  def __init__(self, name, type, initialValue):
    self.Name = name
    self.Type = type
    self.Value = initialValue

# Represents a motion description structure in VAL 3 application.
class MotionDescription:

  VariableName = "mMotionSettings"

  def __init__(self, motionStatement):
    self.VariableIndex = 0 # Assigned later
    self.Statements = [] # Statements that use this description.

    # Set VAL 3 defaults
    self.accel = 100     # Maximum permitted joint acceleration as a % of the nominal acceleration of the robot.
    self.vel = 100       # Maximum permitted joint speed as a % of the nominal speed of the robot.
    self.decel = 100     # Maximum permitted joint deceleration as a % of the nominal deceleration of the robot.
    self.tvel = 99999    # Maximum permitted translational speed of the tool center point, in mm/s or inches/s depending on the unit of length of the application.
    self.rvel = 99999    # Maximum permitted rotational speed of the tool center point, in degrees per second.
    self.blend = "joint" # Blend mode: off (no blending), joint or Cartesian (blending).
    self.leave = 50      # In joint and Cartesian blend mode, distance between the target point at which blending starts and the next point, in mm or inches, depending on the unit of length of the application.
    self.reach = 50      # In joint and Cartesian blend mode, distance between the target point at which blending stops and the next point, in mm or inches, depending on the unit of length of the application.
    
    if motionStatement == None:
      return
    
    # VAL 3 doesn't seem to have velocity or time based blending
    if motionStatement.AccuracyMethod == VC_MOTIONTARGET_AM_DISTANCE:
      self.leave = motionStatement.AccuracyValue
      self.reach = motionStatement.AccuracyValue
    else:
      writeWarningMessage("StaubliPPUnsupportedAccuracyMethod", 
                          [motionStatement.Positions[0].Name, motionStatement.ParentRoutine.Name])
      

    if motionStatement.Type == VC_STATEMENT_PTPMOTION:
      self.accel = motionStatement.JointForce * 100
      self.decel = motionStatement.JointForce * 100
      self.vel = motionStatement.JointSpeed * 100

    if motionStatement.Type == VC_STATEMENT_LINMOTION:
      self.tvel = motionStatement.MaxSpeed
      self.rvel = motionStatement.MaxAngularSpeed
      self.blend = "Cartesian" # VC doesn't have the different blending coordinate system options.

  def __eq__(self, rhs):
    if not isinstance(rhs, MotionDescription):
      return False
    
    return (self.accel == rhs.accel and
            self.vel   == rhs.vel   and
            self.decel == rhs.decel and
            self.tvel  == rhs.tvel  and
            self.rvel  == rhs.rvel  and
            self.blend == rhs.blend and
            self.leave == rhs.leave and
            self.reach == rhs.reach)

PPVersion = "20.11.2020"
indent = '  '

def getActiveExecutor():
  teach = app.TeachContext
  routine = teach.ActiveScope
  if routine:
    program = routine.Program
    if program:
      return program.Executor

def getActiveProgram():
  teach = app.TeachContext
  routine = teach.ActiveScope
  if routine:
    return routine.Program

def getActiveRoutine():
  teach = app.TeachContext
  routine = teach.ActiveScope
  return routine.Program

# first_state() routine
def first_state():
  # Global variables
  global executor, Scara, motiontarget, programs, tools, frames, points, motionDescriptions, joints, Robot, bTrackingRSL, bfMoving_1, bfMoving_2
  global inputMappings, outputMappings, IOs, writeUnmapped, warnings, firstMotion, wem_statements, PPVersion, depth
  global ConfigurationsList, dotNetCommand
  global isCS9, SmartTrackBase,bTracking,bTrackingPick,bTrackingPlace
  global ConveyorCompIN,ConveyorCompOUT
  # Set succeeded property to false by default
  successProp = getProperty("Succeeded")
  successProp.Value = False
  robotName = getProperty("Robot").Value
  warnings = 0
  Robot = app.findComponent(robotName)
  
  if CONVEYOR_TRACKING_ENABLED:
    #MICH 03/07/20
    # Search for a SmartTrackingBase attached to the robot
    iFace = Robot.findBehaviour("RobotPositioner")
    if(iFace.ConnectedComponent):
      if(iFace.ConnectedComponent.Name.find("SmartDoubleTrackingBase") >= 0):
        SmartTrackBase = iFace.ConnectedComponent
        bTracking = True
      else:
        bTracking = False
    else:
      bTracking = False

    if(bTracking==True):
      iFace = SmartTrackBase.findBehaviour("InConvInterface")
      if(iFace.ConnectedComponent):
          ConveyorCompIN = iFace.ConnectedComponent
      iFace = SmartTrackBase.findBehaviour("OutConvInterface")
      if(iFace.ConnectedComponent):
          ConveyorCompOUT = iFace.ConnectedComponent
  else:
    bTracking = False

  # Create containers
  programs = [] # programs
  tools = [] # tools
  frames = [] # bases
  points = [] # points
  joints = [] # joints
  IOs = [] # I/Os
  inputMappings = [] # input mappings
  outputMappings = [] # output mappings
  wem_statements = [] # waitEndMove statements
  motionDescriptions = []
  bTrackingRSL = False
  bfMoving_1 = False
  bfMoving_2 = False
  bTrackingPick = False
  bTrackingPlace = False
  dotNetCommand = app.findCommand('netCommand')

  if CONVEYOR_TRACKING_ENABLED:
    if bTracking:
      writeOutputMessage("StaubliPPPostProcessingStarted", ["Tracking enabled !"])
    else:
      writeOutputMessage("StaubliPPPostProcessingStarted", ["Tracking disabled !"])
    
  # Start post-processing
  # Post-processing for robot '%s' started.
  writeOutputMessage("StaubliPPPostProcessingStarted", [robotName])

  # Get executor
  executor = getActiveExecutor()
  if not executor:
    # No program selected, post-processing aborted.
    writeOutputMessage("StaubliPPErrorNoProgramSelected", None, True)
    return

  # MICH 03/07/20
  # Get controller Type
  if executor.Controller.Name.find("CS8") >= 0:
    isCS9 = False
  else:
    isCS9 = True

  # Add programs:
  # All programs include main, start, stop, timer and userinterface programs
  programs.append("start")
  programs.append("robotCycle")
  programs.append("stop")
  programs.append("initRobot")
  programs.append("main")
  programs.append("timer")
  programs.append("taskOfTimer")

  #MICH 03/07/20
  if(not isCS9) :
    programs.append("HMI")
  else:
    programs.append("click_StartStop")

  if CONVEYOR_TRACKING_ENABLED:
    if bTracking==True:
      if(SmartTrackBase.RslPick == False):
        programs.append("initTracking_1")
        programs.append("trackingPick")
        bTrackingPick = True
      if(SmartTrackBase.RslPlace == False):
        programs.append("initTracking_2")
        programs.append("trackingPlace")
        bTrackingPlace = True
  
  # get all configs and store them to a global list
  ConfigurationsList = getConfigNames(executor)
  # Create a motion target
  motiontarget = executor.Controller.createTarget()
  # Check robot type
  Scara = (executor.Controller.JointCount == 4)

  folderPath = getProperty("ApplicationPath").Value
  projectName = getProperty("ApplicationName").Value
  folderPath = folderPath + "\\" + projectName
  folderPath = unicode(folderPath, "utf-8")
  
  # Make new application folder if does not exist already
  if os.path.isdir(folderPath) == False:
    os.mkdir(folderPath)
  if(isCS9):
    if os.path.isdir(folderPath + "\\interface") == False:
      os.mkdir(folderPath + "\\interface")

  projectFileName = folderPath + "\\" + projectName + ".pjx"
  dataFileName = folderPath + "\\" + projectName + ".dtx"
  htmlFileName = folderPath + "\\interface\\HMI.html"
  bindingsFileName = folderPath + "\\interface\\HMI.bindings.json"
  
  try:
    project = open(projectFileName, "w")
  except:
    # Cannot open file '%s' for writing. Post-processing aborted.
    writeOutputMessage("StaubliPPErrorCannotWriteFile", [projectFileName], True)
    return

  try:
    data = open(dataFileName, "w")
  except:
    # Cannot open file '%s' for writing. Post-processing aborted.
    writeOutputMessage("StaubliPPErrorCannotWriteFile", [dataFileName], True)
    return

  if isCS9:
    try:
      hmi = open(htmlFileName, "w")
    except:
      # Cannot open file '%s' for writing. Post-processing aborted.
      writeOutputMessage("StaubliPPErrorCannotWriteFile", [htmlFileName], True)
      return
    try:
      bindings = open(bindingsFileName, "w")
    except:
      # Cannot open file '%s' for writing. Post-processing aborted.
      writeOutputMessage("StaubliPPErrorCannotWriteFile", [bindingsFileName], True)
      return

  mappingString = getProperty("Mappings").Value
  writeUnmapped = getProperty("WriteUnmapped").Value
  # Read mapping information passed from the parent application
  readMappingData(mappingString)
  # Read data from RSL Program (I/Os, Tools, Bases, Points)
  readDataFromRSLProgram()

  if CONVEYOR_TRACKING_ENABLED:
    # Create data for tracking
    if bTracking==True:
      createDataForTrackingProgram()

  # Write project file    
  writeProjectFile(project, projectName)
  # Write data file
  writeDataFile(data)
  if isCS9:
    writeHTMLInterface(hmi)
    writeJSONBindingsInterface(bindings)
  
  # Search for the first motion statement for timer routines
  # Removed: It is not really possible to know which motion statement will be executed first now 
  # that we have program flow control statements. This would need to be handled at runtime.
  # firstMotion = findFirstMotionStatement(executor.Program.MainRoutine)

  # Search for statements that should be followed by waitEndMove instruction
  wem_statements = []
  findWaitEndMoveStatements(executor.Program.MainRoutine, wem_statements)
  for routine in executor.Program.Routines:
    findWaitEndMoveStatements(routine, wem_statements)
  
  # Write program files
  for i in programs:
    programFileName = folderPath + "\\" + i + ".pgx"
    try:
      program = open(programFileName, "w")
    except:
      # Cannot open file '%s' for writing. Post-processing aborted.
      writeOutputMessage("StaubliPPErrorCannotWriteFile", [programFileName], True)
      return
    # Create start, stop and main programs by default. There is no equivalent for Start and Stop routines
    # in RSL so routine is passed as None
    # Write start
    if i == "start":
      writeProgramFile(program, None, i)
    # Write main 
    elif i == "main":
      writeProgramFile(program, executor.Program.MainRoutine, i)
    # Write stop
    elif i == "stop":
      writeProgramFile(program, None, i)
    # Write timer
    elif i == "timer":
      writeProgramFile(program, None, i)
    elif i == "taskOfTimer":
      writeProgramFile(program, None, i)
    # Write UserInterface
    elif i == "UserInterface":
      writeProgramFile(program, None, i)
    elif i == "HMI":
      writeProgramFile(program, None, i)
    elif i == "initRobot":
      writeProgramFile(program, None, i)
    elif i == "robotCycle":
      writeProgramFile(program, None, i)
    elif i == "click_StartStop":
      writeProgramFile(program, None, i)
    elif i == "initTracking_1" and CONVEYOR_TRACKING_ENABLED and bTracking==True:
      writeProgramFile(program, None, i)
    elif i == "initTracking_2" and CONVEYOR_TRACKING_ENABLED and bTracking==True:
      writeProgramFile(program, None, i)
    elif i == "trackingPick" and CONVEYOR_TRACKING_ENABLED and bTracking==True:
      writeProgramFile(program, None, i)
    elif i == "trackingPlace" and CONVEYOR_TRACKING_ENABLED and bTracking==True:
      writeProgramFile(program, None, i)
    # Write subroutines
    else:
      for subRoutine in executor.Program.Routines:
        if subRoutine.Name == i:
          writeProgramFile(program, subRoutine, i)
  
  # Post processing succeeded 
  # Post-processing for robot '%s' success. %s warnings.
  writeOutputMessage("StaubliPPPostProcessingSuccess", [robotName, warnings])
  # Note! For a realistic cycle time use SRS 2013 with Emulator version s7.7 or newer.
  writeOutputMessage("StaubliPPRealisticCycleTimeNote", None)
  # Post processor release: '%s'
  writeOutputMessage("StaubliPPPostProcessorVersionMessage", [PPVersion])
  successProp.Value = True
  return

# Writes a predefined error message to the output panel using current application language. 
# The messages are defined for different languages in the application's resource dll files.
# messageId = localization string key
# parameterList = substitutions in the message, processed using .NET's string.Format()
def writeWarningMessage(messageId, parameterList):
  global warnings
  warnings += 1

  # Write warnings as error messages (third parameter = True).
  if parameterList != None:
    dotNetCommand.execute('StaubliOutputLocalizedMessage', messageId, True, *parameterList)
  else:
    dotNetCommand.execute('StaubliOutputLocalizedMessage', messageId, True)

# Writes a predefined message to the output panel using current application language. 
# The messages are defined for different languages in the application's resource dll files.
# messageId = localization string key
# parameterList = substitutions in the message, processed using .NET's string.Format()
def writeOutputMessage(messageId, parameterList, isError = False):
  if parameterList != None:
    dotNetCommand.execute('StaubliOutputLocalizedMessage', messageId, isError, *parameterList)
  else:
    dotNetCommand.execute('StaubliOutputLocalizedMessage', messageId, isError)

# Fetches localized strings from the .NET side.
# Returns a list of strings in the current application language.
def getLocalizedString(localizationKeysList):
  
  dotNetCommand.execute('StaubliGetLocalizedTextAction', *localizationKeysList)
  results = []

  for key in localizationKeysList:
    # The .NET side writes the results to properties of this post processor command
    prop = getProperty(key)
    
    if prop != None:
      results.append(prop.Value)
      deleteProperty(prop)
    else:
      # Some error has occured, use the key as fallback
      results.append(key)
  
  return results

# Reads a mapping data passed as a string parameter
def readMappingData(mappingString):
  # Get 'CS8 IO > Visual Components Internal Robot IO' mappings
  # Mappings are passed as a string that is in the form:
  # Port is input / output|Port number|Connected actions on the port|Signals connected to the port|Controller IO variable name|Data flow direction for this connection
  # Different mapping items are separated with \r\n
  # Special ASCII unit separator and group separator characters are used as delimiters
  
  if mappingString != "":
    mappingData = mappingString.split('\r\n')
    # Go through the mappings
    for i in mappingData:
      mappingSplitted = i.split('')
      # If a robot input, save to input mappings
      comment = 'Connected '
      if mappingSplitted[2].strip():
        mapped_actions = mappingSplitted[2].split('')
        comment += 'Actions: [' + ', '.join(mapped_actions) + ']  '
      if mappingSplitted[3].strip():
        mapped_signals = mappingSplitted[3].split('')
        comment += 'Signals: [' + ', '.join(mapped_signals) + ']'
      if mappingSplitted[5] == 'SimulationToController':
        mapping = Mapping()
        mapping.CS8Signal = mappingSplitted[4]
        mapping.VCPort = mappingSplitted[1]
        mapping.VariableName = "dIn%s" % mapping.VCPort
        mapping.Comment = comment
        if any(map(lambda im: im.VCPort == mapping.VCPort, inputMappings)):
          # Warning: Ignoring additional CS8 I/O mapping for input / output port %s
          messageId = "StaubliPPWarningAdditionalMappingOutput" if mappingSplitted[0] == "Output" else "StaubliPPWarningAdditionalMappingInput"
          writeWarningMessage(messageId, [mapping.VCPort])
        else:
          inputMappings.append(mapping)
      
      #If a robot output, save to output mappings
      if mappingSplitted[5] == 'ControllerToSimulation':
        mapping = Mapping()
        mapping.CS8Signal = mappingSplitted[4]
        mapping.VCPort = mappingSplitted[1]
        mapping.VariableName = "dOut%s" % mapping.VCPort
        mapping.Comment = comment

        if any(map(lambda im: im.VCPort == mapping.VCPort, outputMappings)):
          # Warning: Ignoring additional CS8 I/O mapping for input / output port %s
          messageId = "StaubliPPWarningAdditionalMappingOutput" if mappingSplitted[0] == "Output" else "StaubliPPWarningAdditionalMappingInput"
          writeWarningMessage(messageId, [mapping.VCPort])
        else:
          outputMappings.append(mapping)
  return

def isValidVariableName(name):
  # Name must be 1-15 characters in length, can only contain alphanumeric characters and can't start with a number.
  return len(name) > 0 and len(name) <= 15 and re.match("^[a-zA-Z0-9_]+$", name) and not re.match("^[0-9]", name)

# Read all data that will be saved as variables from the RSL routines
def readDataFromRSLProgram():
  global variables

  # Stores information about variables defined in the VC robot program.
  variables = ProgramVariables()
  variables.globals = []  # List of ProgramVariable objects of component properties
  variables.routines = {} # Dictionary with routine name as key and ProgramVariable objects as value
  
  # Set up conversions for common constants in expressions
  _trueVar = ProgramVariable("True", VC_BOOLEAN, "")
  _trueVar.Val3Name = "true"
  _falseVar = ProgramVariable("False", VC_BOOLEAN, "")
  _falseVar.Val3Name = "false"
  variables.constants = [_trueVar, _falseVar]

  # Skip common properties of Stäubli robot components to avoid creating unnecessary variables
  globalsToSkip = ["Name", "Visible", "BOM", "BOMname", "BOMdescription",
                   "Category", "J1", "J2", "J3", "J4", "J5", "J6",
                   "WorkSpaceLefty", "WorkSpaceRighty", "HardStop", "LogoTilt",
                   "StrokeLimit", "Joint4Limit", "ConfigName1", "ConfigName2",
                   "JointSign1", "JointSign2", "JointSign3", "JointSign4"]

  # Read component properties that may be used as variables in any routine
  for prop in executor.Component.Properties:
    if (prop.Type in [VC_BOOLEAN, VC_INTEGER, VC_REAL, VC_STRING] and
        not prop.Name in globalsToSkip and
        not prop.Name.startswith("SignalActions::") and
        not prop.Name.startswith("StaubliOption::") and
        not prop.Name.startswith("WorkSpace::") and
        not prop.Name.startswith("JointZeroOffset")):
      
      # Also skip all invalid variables but log warnings for them
      if isValidVariableName(prop.Name):
        variable = ProgramVariable(prop.Name, prop.Type, prop.Value)
        variables.globals.append(variable)
      else:
        # Robot component property '%s' has invalid name for a VAL 3 variable.
        writeWarningMessage("StaubliPPWarningInvalidComponentPropertyName", [prop.Name])

  allRoutines = [executor.Program.MainRoutine]
  allRoutines.extend(executor.Program.Routines)

  for routine in allRoutines:
    variables.routines[routine.Name] = []

    # Routine names can only be 14 characters because the collection variable's
    # name will have a type identifier at front. e.g. bMain
    if not isValidVariableName(routine.Name) or len(routine.Name) > 14:
      # Sequence '%s' has invalid name for a VAL 3 variable or it is longer than 14 characters." % routine.Name
      writeWarningMessage("StaubliPPWarningInvalidSequenceName", [routine.Name])
    
    # Read all routine variables
    for prop in routine.Properties:
      if prop.Name == "Name": continue
      variable = ProgramVariable(prop.Name, prop.Type, prop.Value)
      variables.routines[routine.Name].append(variable)
      if not isValidVariableName(prop.Name):
        # Variable '%s' in sequence '%s' has invalid name for a VAL 3 variable.
        writeWarningMessage("StaubliPPWarningInvalidVariableName", [prop.Name, routine.Name])

    if routine != executor.Program.MainRoutine:
      # Update a list of routines in the program
      programs.append(routine.Name)
    
    # Collect information from all statements in the routine
    for statement in routine.Statements:
      for stat in iterateStatementTree(statement):
        getToolData(stat)
        getPointData(stat)
        getJointData(stat)
        getBaseData(stat)
        getMotionData(stat)

  return

# Create all data that will be saved as variables needed by tracking programs
def createDataForTrackingProgram():
  global variables,bTrackingPick,bTrackingPlace
  createBasesTrackingData()
  if bTrackingPick:
    createPointData("pPick","fMoving_1",[0,0,0,180,0,0],["ssame","esame","wsame"])
  if bTrackingPlace:
    createPointData("pPlace","fMoving_2",[0,0,0,180,0,0],["ssame","esame","wsame"])

# Yields the given statement and all statements from its sub scopes recursively
def iterateStatementTree(statement):
  yield statement

  if (statement.Type == VC_STATEMENT_IF):
    if (statement.ThenScope):
      for stat in statement.ThenScope.Statements:
        for s in iterateStatementTree(stat): yield s
    if (statement.ElseScope):
      for stat in statement.ElseScope.Statements:
        for s in iterateStatementTree(stat): yield s

  if (statement.Type == VC_STATEMENT_WHILE):
    for stat in statement.Scope.Statements:
      for s in iterateStatementTree(stat): yield s

# Writes a project file (.pjx) for the application
def writeProjectFile(project, dataFileName):
  global programs
  doc = xml.dom.minidom.Document()
  # Project element
  Project_el = doc.createElementNS("http://www.staubli.com/robotics/VAL3/Project/3", "Project")
  Project_el.setAttribute("xmlns", "http://www.staubli.com/robotics/VAL3/Project/3")
  doc.appendChild(Project_el)
  # Parameters element
  Parameters_el = doc.createElement("Parameters")
  Parameters_el.setAttribute("millimeterUnit", "true")
  Parameters_el.setAttribute("stackSize", "5000")
  if isCS9:
    Parameters_el.setAttribute("version", "s8.10Cs9_BS1925")
  else:
    Parameters_el.setAttribute("version", "s7.11.2")
    
  Project_el.appendChild(Parameters_el)
  # Programs element
  Programs_el = doc.createElement("Programs")
  Project_el.appendChild(Programs_el)
  # Program elements
  
  for i in programs:
    Program_el = doc.createElement("Program")
    Program_el.setAttribute("file", i + ".pgx")
    Programs_el.appendChild(Program_el)
    if not isValidVariableName(i):
      # Warning: Sequence name '%s' is not valid for a VAL 3 program.
      writeWarningMessage("StaubliPPWarningInvalidProgramName", [i])
  
  # Database element
  Database_el = doc.createElement("Database")
  Project_el.appendChild(Database_el)
  # Data elenent
  Data_el = doc.createElement("Data")
  Data_el.setAttribute("file", "%s" % (dataFileName + ".dtx"))
  Database_el.appendChild(Data_el)

  xml_document = doc.toprettyxml(indent='  ')
  xml_document = xml_document.replace("<?xml version=\"1.0\" ?>", "<?xml version=\"1.0\" encoding=\"utf-8\"?>")
  project.write(xml_document)
  project.close
  return

# Writes the data file (.dtx) for the application
def writeDataFile(data):
  global bfMoving_1, bfMoving_2, isCS9, bTracking
  doc = xml.dom.minidom.Document()
  
  # Database element
  Database_el = doc.createElement("Database")
  Database_el.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
  Database_el.setAttribute("xmlns", "http://www.staubli.com/robotics/VAL3/Data/2")
  doc.appendChild(Database_el)
  
  # Datas element
  Datas_el = doc.createElement("Datas")
  Database_el.appendChild(Datas_el)
  
  # Motion descriptions for motion statements
  if len(motionDescriptions) > 0:
    mdesc_el = createDataElement(doc, "mdesc", MotionDescription.VariableName, str(len(motionDescriptions)))
    Datas_el.appendChild(mdesc_el)

    for mDesc in motionDescriptions:
      descElement = doc.createElement("Value")
      descElement.setAttribute("key",   str(mDesc.VariableIndex))
      descElement.setAttribute("accel", str(mDesc.accel))
      descElement.setAttribute("vel",   str(mDesc.vel))
      descElement.setAttribute("decel", str(mDesc.decel))
      descElement.setAttribute("tvel",  str(mDesc.tvel))
      descElement.setAttribute("rvel",  str(mDesc.rvel))
      descElement.setAttribute("blend", str(mDesc.blend))
      descElement.setAttribute("leave", str(mDesc.leave))
      descElement.setAttribute("reach", str(mDesc.reach))
      mdesc_el.appendChild(descElement)
  
  # IO data elements
  for i in inputMappings:
    IO_el = createDataElement(doc, "dio", i.VariableName, "1")
    Datas_el.appendChild(IO_el)
    Value_el = createIOValueElement(doc, i)
    IO_el.appendChild(Value_el)
  
  for i in outputMappings:
    IO_el = createDataElement(doc, "dio", i.VariableName, "1")
    Value_el = createIOValueElement(doc, i)
    Datas_el.appendChild(IO_el)
    IO_el.appendChild(Value_el)

  varTypesMapping = {
    VC_BOOLEAN:"bool",
    VC_INTEGER:"num",
    VC_REAL:"num",
    VC_STRING:"string"
  }

  # Global variables (component properties) of the VC robot program, create individual variables for each.
  for var in variables.globals:
    Var_el = createDataElement(doc, varTypesMapping[var.Type], var.Name, "1")
    Value_el = createValueElementWithValue(doc, "0", var.Value)
    Datas_el.appendChild(Var_el)
    Var_el.appendChild(Value_el)
    var.Val3Name = var.Name

  # Variables in routines of the VC robot program.
  # These need to be defined as global variables because in VC the values are not reset when entering a routine.
  for routineName, varList in variables.routines.iteritems():

    typeSelector = lambda v:varTypesMapping[v.Type]
    sortedVars = sorted(varList, key=typeSelector)
    
    # Group by variable data type, create collection data elements for each type
    for key, group in groupby(sortedVars, typeSelector):
      _collectionName = key[:1] + routineName
      Collection_el = createCollectionDataElement(doc, key, _collectionName)
      Datas_el.appendChild(Collection_el)
      
      # Add routine variables with their names as keys to the collection
      for var in group:
        Value_el = createValueElementWithValue(doc, var.Name, var.Value)
        Collection_el.appendChild(Value_el)
        var.Val3Name = '%s["%s"]' % (_collectionName, var.Name)

  # Tool data elements
  for i in tools:
    Tool_el = createDataElement(doc, "tool", i.Name, "1")
    Datas_el.appendChild(Tool_el)
    Value_el = createToolValueElement(doc, i)
    Tool_el.appendChild(Value_el)
  
  # Frame data elements
  for i in frames:
    Frame_el = createDataElement(doc, "frame", i.Name, "1")
    Datas_el.appendChild(Frame_el)
    Value_el = createFrameValueElement(doc, i)
    Frame_el.appendChild(Value_el)
    fMov=i
    
    if fMov.Name == "fConveyor_1" and CONVEYOR_TRACKING_ENABLED:
      Frame_el1 = createDataElement(doc, "frame", "fMoving_1", "1")
      Datas_el.appendChild(Frame_el1)
      Value_el = doc.createElement("Value")
      Value_el.setAttribute("key", "0")
      Value_el.setAttribute("x", "%s" % "123")
      Value_el.setAttribute("y", "%s" % "0")
      Value_el.setAttribute("z", "%s" % "0")
      Value_el.setAttribute("rx", "%s" % "0")
      Value_el.setAttribute("ry", "%s" % "0")
      Value_el.setAttribute("rz", "%s" % "0")
      Value_el.setAttribute("fatherId", "fConveyor_1[0]")
      Frame_el1.appendChild(Value_el)
      bfMoving_1=True
    elif fMov.Name == "fConveyor_2" and CONVEYOR_TRACKING_ENABLED:
      Frame_el1 = createDataElement(doc, "frame", "fMoving_2", "1")
      Datas_el.appendChild(Frame_el1)
      Value_el = doc.createElement("Value")
      Value_el.setAttribute("key", "0")
      Value_el.setAttribute("x", "%s" % "0")
      Value_el.setAttribute("y", "%s" % "0")
      Value_el.setAttribute("z", "%s" % "0")
      Value_el.setAttribute("rx", "%s" % "0")
      Value_el.setAttribute("ry", "%s" % "0")
      Value_el.setAttribute("rz", "%s" % "0")
      Value_el.setAttribute("fatherId", "fConveyor_2[0]")
      Frame_el1.appendChild(Value_el)
      bfMoving_2=True

  # Joint data elements
  for i in joints:
    if Scara == True:
      Point_el = createDataElement(doc, "jointRs", i.Name, "1")
    else:
      Point_el = createDataElement(doc, "jointRx", i.Name, "1")
    Datas_el.appendChild(Point_el)
    Value_el = createJointValueElement(doc, i)
    Point_el.appendChild(Value_el)
  
  # Joint data All
  if(Scara):
    joint_el = createDataElement(doc, "jointRs", "jStart", "1")
    Datas_el.appendChild(joint_el)
  else:
    joint_el = createDataElement(doc, "jointRx", "jStart", "1")
    Datas_el.appendChild(joint_el)

  # Point data elements
  for i in points:
    if Scara == True:
      Point_el = createDataElement(doc, "pointRs", i.Name, "1")
    else:
      Point_el = createDataElement(doc, "pointRx", i.Name, "1")
    Datas_el.appendChild(Point_el)
    Value_el = createPointValueElement(doc, i)
    Point_el.appendChild(Value_el)
  
  # Num data All
  num_el = createDataElement(doc, "num", "nWorkingStatus", "1")
  Datas_el.appendChild(num_el) 
  num_el = createDataElement(doc, "num", "nWorkingMode", "1")
  Datas_el.appendChild(num_el)
  num_el = createDataElement(doc, "num", "nMoveID", "1")
  Datas_el.appendChild(num_el)
  num_el = createDataElement(doc, "num", "nLoop", "1")
  Datas_el.appendChild(num_el)
  num_el = createDataElement(doc, "num", "nTraceNum", "1")
  Datas_el.appendChild(num_el)
  num_el = createDataElement(doc, "num", "nIndex", "1")
  Datas_el.appendChild(num_el)
  num_el = createDataElement(doc, "num", "nStartClock", "1")
  Datas_el.appendChild(num_el)
  num_el = createDataElement(doc, "num", "nCycleStartClk", "1")
  Datas_el.appendChild(num_el)
  num_el = createDataElement(doc, "num", "nTimer", "200")
  Datas_el.appendChild(num_el)
  
  if CONVEYOR_TRACKING_ENABLED and bTracking == True:
    
    # Num data for tracking
    num_el = createDataElement(doc, "num", "nConvSpeed", "2")
    
    if bTrackingPick:
      Value_el = createValueElementWithValue(doc, "0", ConveyorCompIN.ConveyorSpeed)
      num_el.appendChild(Value_el)
    if bTrackingPlace :
      Value_el = createValueElementWithValue(doc, "1", ConveyorCompOUT.ConveyorSpeed)
      num_el.appendChild(Value_el)

    Datas_el.appendChild(num_el)
    num_el = createDataElement(doc, "num", "nApproPick", "1")
    Value_el = createValueElementWithValue(doc, "0", SmartTrackBase.ApproPick)
    Datas_el.appendChild(num_el)
    num_el.appendChild(Value_el)
    num_el = createDataElement(doc, "num", "nApproPlace", "1")
    Value_el = createValueElementWithValue(doc, "0", SmartTrackBase.ApproPlace)
    Datas_el.appendChild(num_el)
    num_el.appendChild(Value_el)
    num_el = createDataElement(doc, "num", "nDepartPick", "1")
    Value_el = createValueElementWithValue(doc, "0", SmartTrackBase.DegPick)
    Datas_el.appendChild(num_el)
    num_el.appendChild(Value_el)
    num_el = createDataElement(doc, "num", "nDepartPlace", "1")
    Value_el = createValueElementWithValue(doc, "0", SmartTrackBase.DegPlace)
    Datas_el.appendChild(num_el)
    num_el.appendChild(Value_el)
    num_el = createDataElement(doc, "num", "nStepPick", "1")
    Value_el = createValueElementWithValue(doc, "0", SmartTrackBase.StepIN)
    Datas_el.appendChild(num_el)
    num_el.appendChild(Value_el)
    num_el = createDataElement(doc, "num", "nStepPlace", "1")
    Value_el = createValueElementWithValue(doc, "0", SmartTrackBase.StepOUT)
    Datas_el.appendChild(num_el)
    num_el.appendChild(Value_el)
    num_el = createDataElement(doc, "num", "nDistOutConvIN", "1")
    Value_el = createValueElementWithValue(doc, "0", SmartTrackBase.DistOutConvIN)
    Datas_el.appendChild(num_el)
    num_el.appendChild(Value_el)
    num_el = createDataElement(doc, "num", "nDistOutConvOUT", "1")
    Value_el = createValueElementWithValue(doc, "0", SmartTrackBase.DistOutConvOUT)
    Datas_el.appendChild(num_el)
    num_el.appendChild(Value_el)
    num_el = createDataElement(doc, "num", "nOffsetPick", "1")
    Datas_el.appendChild(num_el)
    num_el = createDataElement(doc, "num", "nOffsetPlace", "1")
    Datas_el.appendChild(num_el)
    num_el = createDataElement(doc, "num", "nMissedPick", "1")
    Datas_el.appendChild(num_el)
    num_el = createDataElement(doc, "num", "nMissedPlace", "1")
    Datas_el.appendChild(num_el)

    # Trsf data nIndex Tracking
    trsf_el = createDataElement(doc, "trsf", "trDetection", "2")
    Datas_el.appendChild(trsf_el)
    
    # Aio data nIndex
    aio_el = createDataElement(doc, "aio", "aEncoder", "2")
    Datas_el.appendChild(aio_el)
    
    Value_el = doc.createElement("Value")
    Value_el.setAttribute("key", "0")
    if not isCS9:
      #Value_el.setAttribute("link","ModbusSrv-0\Modbus-Word\Coder_Conveyor_1")
      Value_el.setAttribute("link","e00CurrPos")
    else:
      Value_el.setAttribute("link","VirtualIOBoards\TrackingSimBoard\%QD8")
    aio_el.appendChild(Value_el)
    
    Value_el = doc.createElement("Value")
    Value_el.setAttribute("key", "1")
    if not isCS9:
      #Value_el.setAttribute("link","ModbusSrv-0\Modbus-Word\Coder_Conveyor_2")
      Value_el.setAttribute("link","e01CurrPos")
    else :
      Value_el.setAttribute("link","VirtualIOBoards\TrackingSimBoard\%QD40")
    aio_el.appendChild(Value_el)

    # Mdesc data Tracking
    mdesc_el = createDataElement(doc, "mdesc", "mNomSpeed", "1")
    Datas_el.appendChild(mdesc_el)
    descElement = doc.createElement("Value")
    descElement.setAttribute("key",   "0")
    descElement.setAttribute("accel", "100")
    descElement.setAttribute("vel",  "100")
    descElement.setAttribute("decel", "100")
    descElement.setAttribute("tvel",  "99999")
    descElement.setAttribute("rvel",  "99999")
    descElement.setAttribute("blend","Cartesian")
    descElement.setAttribute("leave", "50")
    descElement.setAttribute("reach", "50")
    mdesc_el.appendChild(descElement)
  else:
    
    # Mdesc data PicknPlace
    mdesc_el = createDataElement(doc, "mdesc", "mNomSpeed", "1")
    Datas_el.appendChild(mdesc_el)
    descElement = doc.createElement("Value")
    descElement.setAttribute("key",   "0")
    descElement.setAttribute("accel", "100")
    descElement.setAttribute("vel",  "100")
    descElement.setAttribute("decel", "100")
    descElement.setAttribute("tvel",  "99999")
    descElement.setAttribute("rvel",  "99999")
    descElement.setAttribute("blend","Joint")
    descElement.setAttribute("leave", "50")
    descElement.setAttribute("reach", "50")
    mdesc_el.appendChild(descElement)


  #MICH 03/07/20
  # String data
  string_el = createDataElement(doc, "string", "sBtnStartStop", "1")
  Datas_el.appendChild(string_el)
  string_el = createDataElement(doc, "string", "sUserMessage", "1")
  Datas_el.appendChild(string_el)
  string_el = createDataElement(doc, "string", "sAverageCT", "1")
  Datas_el.appendChild(string_el)
  string_el = createDataElement(doc, "string", "sTimer0", "49")
  Datas_el.appendChild(string_el)
  
  # Bool data
  bool_el = createDataElement(doc, "bool", "bLastMove", "1")
  Datas_el.appendChild(bool_el)  
  bool_el = createDataElement(doc, "bool", "bDisStartStop", "1")
  Datas_el.appendChild(bool_el)     
  bool_el = createDataElement(doc, "bool", "bStart", "1")
  Datas_el.appendChild(bool_el)   
  bool_el = createDataElement(doc, "bool", "bStepTimeShow", "1")
  Datas_el.appendChild(bool_el) 
  if not isCS9:
    screen_el = createDataElement(doc, "screen", "sStepTime", "4")
    Datas_el.appendChild(screen_el)
  doc.toprettyxml()
  xml_document = doc.toprettyxml(indent='  ')
  xml_document = xml_document.replace("<?xml version=\"1.0\" ?>", "<?xml version=\"1.0\" encoding=\"utf-8\"?>")
  data.write(xml_document)
  data.close
  return
# end

# Write HTML HMI CS9
def writeHTMLInterface(hmi):
  global bTracking
  if bTracking ==True:
    message = """<!DOCTYPE html SYSTEM "-//W3C//DTD VALHTML Strict//EN">
    <html xmlns="http://www.staubli.com/robotics/2016/03/valhtml">
      <head>
        <meta content="text/html; charset=UTF-8" http-equiv="Content-Type"></meta>
        <meta content="no-cache, no-store, must-revalidate" http-equiv="Cache-Control"></meta>
        <meta content="no-cache" http-equiv="Pragma"></meta>
        <meta content="0" http-equiv="Expires"></meta>
        <script src="/vendor/libs/stblUserPage.min.js" type="text/javascript"></script>
        <link href="/vendor/libs/up.min.v2.css" media="all" rel="stylesheet" type="text/css"></link>
        <meta content="8.10.3" name="src-version"></meta>
      </head>
      <body style="width: 480px; height: 690px; margin: 0">
        <img id="imgStaubli" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAM8AAAA2CAYAAABgHM2OAAAABGdBTUEAANcNO+1PKAAAACBjSFJNAACHCwAAjA8AAP1RAACBQAAAfXYAAOmQAAA85QAAGc0hrlxKAAAA3WlDQ1BJQ0MgUHJvZmlsZQAAKM9jYGB8wAAETECcm1dSFOTupBARGaXAfoGBEQjBIDG5uMA32C2EASf4dg2i9rIuA+mAs7ykoARIfwBikaKQIGegm1iAbL50CFsExE6CsFVA7CKgA4FsE5D6dAjbA8ROgrBjQOzkgiKgmYwFIPNTUouTgewGIDsB5DeItZ8DwW5mFDuTXFpUBnULI+NFBgZCfIQZ+fMZGCy+MDAwT0CIJU1lYNjexsAgcRshprKQgYG/lYFh29WS1IoSZM9D3AYGbPkFwNBnoCZgYAAAb3Y5PLWbw5MAAAAJcEhZcwAAFxAAABcQARhhEdsAABnESURBVHhe7Z0JnFTFmcBf1Tu6e3oOZwBFRdGNSsT1QE3i6m9VTNBIsm4QhQAOMAwz3XMfoOZYV9lcKMz0NHNfDAMSApp4xCBuTPBMYjCJxpNo2FVB5BgGmKO7X79XtV81NROGfkd3Tw/gb/vPr+n6qrvfvFevvq++qvqqHhJOMm1dXVcN9oemUkG4EiF0raYTQVHkGzVNkwTIZGARC/DZJ1pY+0B2yEE1FP4dFsUP0pyOT7xLF/3+2LdSpDi1nBTl8be0f51o+myE8AJd112gGMKQosQM+8mx31BRxDsERLc7ZeWFnCz3r+fMmaNHPkmR4iQyZspTs3mzi37WswBh/ACiwvk8O+mAPvVTSh/FEnoiO23KS3l504P8o5NCW9v6C3VBvz6s61mSiN/KmDTxzdyZM4/yj2NidWPjeWlS2nUa0SeENe3ldAW97/F4wvzjFKcpSVceqMhoTWP7bI3qPkTRJJ59UiAC3Y2x2E1DqHbZsoJDPHtM8DW2X0qIvgq093ZoSPFxLWkvQWTh8rLiZ7hsSkND22U6RuvAPZ0GrbHIswWEUZ8WJnfcW1X0As9KcRqSVOV5+OGODMWtdVEizOZZpwRQ4KDD6fzlmdnueWPh0jW3dS0YDIY6ofAcPGskiOkxvbG6vOhVnhOFb03rt6hAHocvDyvN8cA1qKCUt1gdI8WpBfP3UdPdvelSyRXefqoVhwFW3EmproyF4jS0rbtsIBhsMlUcBhUwNEQruRTF6vq2S0DBHjNTHAZcgwJvPzgmpTgdSYryNDWtP/PwQP/LSEDX8KxTCljtvsws93e5mFTCIfV+LKBMLpoC53A5T0YhCuQ/4XOJi6YgLE7nyRSnIaNWnvXrn3MHtIEndE0fx7MS50QnMlGnktL2RfPmvcelpEIo+TZPWhIZUTRg69atDkLoTC5aAgp2hCdTnIaMWnkO9O5aBi3O9VyMG6hjQYrQU+DA/CAUVmdA9YQXmqFpZIYoylUUCT5QotcEjEKxjG5TKvQTRXiYi0mHkNg8QRGLL/LkCHoCgQkY42wuWgJl8zJPpjgNSdS2R2hft/Gao0eP7gDlifs4VKB/F0XpR737d29YsWKFxrNNefDBB/HESRfcGAiEbkIYLaCEXsw/GgFTtmVl3mouJp0af/N70Kp8kYuGwLVpcG3XVJYU/JVnjaBmTdPfkIANz38YJBCHolxX4lmyg+ekOM0YlfL4Gto2UkLmczFmoPI9de5Z2bMT7dCDO4Pq69umUAndB+7inXDELJZPBBrIckkXFhQU7It8cQyorW9ZCtrRzsUo4NzCRNDvubeidAvPiqKmviUPUWEtF40Az46ULq8obuZyitOQhN22rq4tE4muz+VizIDr9dxoFIcBykfLyz3vVxQXLnFPHDcZSwjcNNonSbh5LBWHceTg3rVIxDWsZeBZ/wAJH0mKMt9KcRjLSj3rsIRXM0XjWcNAq7pPEqU7Uopz+pNwy1Pb2OYVdBLXDQZ3Jiw7xSnlhYX/w7OSRkdHRwZCGc78/LkHeNaY0rJhw9l9Pf2zXC7lxmBI/bMsyjvOnpD5KhgFlX/Flu5Nmy45sL/3ZofTcYsaDr/tUpQdLvnCF092lESKxEhYeXz1rY+B5byLi7GBhD9Vl3mv5VKKFJ9rEnLbWOedUnIFF2MGOvmf8GSKFJ97ElKenJwcGSF8CRdjBov4Qp5MkeJzT0Jum9/vd+jIEbdfTgVBy85Jv3rJPfe8xbNGhc/nOyMsyI8ihGxn65MBRmLdsgrvNi4O09jefenAQL8v3sIUMX6jurzoO1y0JNLHOtTfxUVDkEB3L68oXspFU9Zu2nTewX2H2sEA8hwDKBFkxbG8snjp2zxnmFV1jfkCwndzMWEwQgLG6G9E01+ckJO+beHChQP8I0u2bNmifLT3wM+gQqXxLENESe6oLi18nIsxU7um5Xs6pTdycQSYq4wooY8TVh4iOoPghvGc2EEYv1hVWngzF0dFQ0tnuaqG/VwcawaP9OzNWLFixYhRNjZs7mto/R3cyOt4Vuwg9JvqMs/XuGRJffPainBYreOiIWwUsKqkcDkXTamtbymD813DRWOQcGDSWTlnG42KQn93H1z3mVxMCkSgByQR3V9Z4rU0EIzaNe03CIL+ChcNgeOFqETPv7e4eD/PionW1ta0vhDZA0pyBs8yBtHKhNy2ioqKENHJn7gYF5SQmx6pazINmoyHkKrGFCqTDDDGPz1RcRhgpb6TkOIANMZoBUZYs75WNjGb7U5fz0VTmLIDeVw0RRTFJ40UB5R4Bkmy4jCgsk6A4ljb2Nr5EM8yhVBtFk+aAq3ajngVh6Fhaa6t4sDX3EraEwnP88iK9CZPxo2E8f2r/A0Pd3Vtd/KsuGnuXH8lqP+/cHFMibSvCNVHhONY5W+eChXxh1yMm+iJImNqmpvPhVb+S1w04y+LF883jGg4Hn9b23mE0GlcNIRdL3yn6Zg0EjUcvivhIdoYCKnhB8D6Rya9jdiwYWsmeHteLlqxgb/HhRrSbQ0y9N13eDyLPk5YecBdauDJhBCRdF9v/85tnRs3/hPPiovBwcHZY3kTT+CFE0NtGhoa0mUJPwfJhMswVkQqLQElNV2+wMAIP8GTlmgqmWNXbmC1d4Fr/QYXh2FBraBWd3BxbKACPjyofZ1LURzu+/RmJCA3Fw2B1jXoFDMe42LM1Nd3j9OJfhMXTdGJFnF5E77x0DH9C5zk01xMDCrcdLjn6Cv+lvZ/Y+4Ez7WFDZUDFZG+m9krmSASZSg05FhJdDqqlbKKJFnHt3HARc7lSUOgpaDjslydXDRl+/bt0K2AcrMByvbnPDmC/93zGRgsNJGLhjhdjoqQRr5w/Iuo4SnuzPRqOE/b1bUMtzvN1KNQdc22ZRAl8Y/FxQt6uRgzKg3cDi6b+TotANzjQZzuigwajaqa+XxNU6iIWej/6KrrsV83uBV0v8fjGYxIFrBO3YEjg5ZD5YrTMV6kaJudxQaVfVXTta1cjAIRgUw+d4J/7ty5AZ4V6bBSQXsBKpLhKB8YAtWd7u4aGBj0WBUMlkRaWVxgacBqG9oug77RW1bBt/D3nl1WUWS7zMHf1DFN07Q/W50TVA7BgeULSkuXfsSzhvE1tj5JdfrvXDSit7rcm8PThtQ1tu4Eo2N97xzyw6We/KhRSBZFcmQg3Gt3TxHG86Hl3MTFmIFz+wuc21VcNARctm2VJYW3s/ToKj3ga2hbTAmxHSGJBajIH0gOx8KKwrw/8KyE8TW2zKW68DMumiJScnUFtKJctKWmpsaFZPdOSJ53LCcauHlN4yeMe37/vv2/gErPc6OBSkCryjzWyrOm5cfwZrmwD/5eIVQW02DVIVb7m38ALtl/cNEQhIU/V5V6oxY1MoM1EKKsA27hMtGu6vKiJVwwpKGlcyO4/JbBxNAX/Pbycu9mLg4Dyr9E1zTLFhZat96jGY5zVuTlxTWV0tDRMTk0GN4F98vyflAq3LKswrudpUftr8NNWycrsmHnMl4QFS7Wg6Hf1za23sezEgYKwXZECfgwHsWJILtr4H9TxQGN+CBNppWqFrQdUIEWg6fMgfamgCfNCMDfW8fTpkDll0FxCrloCpSboSEMhOid8GbZ1xAVyTIglhEKhyfzpCkTJuYY781Hie09RRi9EK/iMLQgnWerOILQIwmh33ExOZ3dMm9+qSJLjVwcPTp9uK6hdZvVqIsV9d3Q8dPJV7loCrQJT/JkTDS1dt0NvyniYhRQuCFFduWybaMO9Pf3RP6CBcRGeZra1t4GXxnPRUPgdv82lm2qVILZ3JrdELOWlpVmWCa6QC0j6IlAD1V4C9gAiin+pvZrwGLcwEVDCCHbFs2Z8zEXh2no6pqoabrlbxnQp0vIC9KJPocnTQFD9jibpuFi0kaKaIk3v0yn9G6oL7YL22KBEHpbX5D8duXK+BUodKTvVrAillEHbF4kK8d+XmQItk/DYDDk46Ihkox9pd6Fr3HRHhvlCQRV28BbSVJ+ypOW6ERYxJOmUESfLszN3c3FYVq7u8+H8vwGF42hlI32mV5Qfcvay4lOnoHj8BxjnE6X4aR38Gjgm+DmWv9YQL1OiURFgNjR0b2RDVBYDt8zXE73iG5AspQn4r/fW1H0uE7olVA+UZYjEcDNuFp2ku0rV66MS4EkUbEdUQL+FE+YUFAb9GEknMtFI14r9xZ8j6cj2NzpyBdYqAmXRrB582YXVEjLYWEwAAdLPXm2HWM2rK7r2re4aIooyoZ9xEB/kE1KWl6OKEquR+qa5rPXT2rqh1+1a5qrfPWtv1JDITY6azlSB32dn5R68wwrvyiKZTxpiiiiZxPZLLK/b+BO23uFhd1fmnbpiG3AkqY8Q4ACvSuS0CWiaDzcGS/gw06T07K2x+rCNTd3XaBr+pe5aApGYkzzIozahjbWAph3cqG1xTLNZQaE5wjZ8A/OnUvGgBVGhIiGI0/7evtnw/Es3SyE8Nbj/6YZQYpvgL9l2V+BkxkYl3GOodsFLvACnjSFrSiWMN7IXg5ZHn7BgWtBaWbCeZqOkIERUDEWv7u83DvC+AzR1LFhCrhztlH8hBLrkCMT4Ni2cXqUCN3XXnvtCMVMuvIwmF9YUVJ4lyLLc6HgPuXZCQM3flq/SpvhWLYGIqCrs+BG2X2POrKcMfnG/ra2SUiglrPVSMTfqywq+oCLEbKzWeW2OQ34uC8waNin0cOarQ/ukBXbDjpDQlIJT1qAfp6bG71N8Nq1j7IttK4+JiUX5jqDq7gZS/IVlaUFpiFbwcGBOXbuHhxrd2WJ549cjJna+ha2vsx2ECMjMzOqhR8T5RmitCh/i0t2M19y1K0Q2Nd5/uZONuJjDRVsrSRYqGeLFy60jXtik4pEFdZTQk3DiEA/dlQVF67i4jDp6elBsGgHuWgCEoLB6IGhVatWuaEyWAeMYnS4xJv3Ky6Z0tm5eYKu65F5CSsoNt5T4WggUnEt51USAQzLh06X65plZUXfripeyob+DWET4vC28JhkDsb4GTimbSt8IiLGpTxpiijhDwsWzXuXi8OMqfIwiosX7q8u994FV3cP1JWYlygbQYjG5jxMWdXQMJlSYrvxIhR0TC7bm+9+mAvuiOnGg9ASHszOyDQcPp05c2ZIJ3oPFw1htjSoRY+vYEf6bDACLi6aYbWByDCHB3tnQKWyHDwBA3DwvAnZhsPDhAj38GRSgbK7KBQM7mhq6TQdvWScceaZU0AjLuKiKRijbp6MGebJaIRYTfpGUFW9yUgx7dybpLLS75/kkJwvUZ0mvChOcTluLy0w7lQ2NHf41LBWyUUzAkd69mbabXfFFBET8X2wuqatDhT+PmhdjLeGQoIsidJt8B2eYUxID0//blXZiA3dfQ1tfwSlNQ0EhWNSSVH+uaIoP8oankhtfevz8APrYXtRaK4u8RZzaZj6lo5rw6pmufUVXN0OMFiR5QEI/8MWw/lDhRYvhVP9GlQyS+Vl7j3zUrg4An9LR4euavlcNAT6lnuqSj1xh0qtae34lhbSrA0pnHya7D7H683dy3OGGfOW53i+U1Gx+/DUSy6BCvdLnhU34UDIsCJs2bJFBMWxDVWHG/y8neJEJhSJuN5KcRhgjc4SRfGbhi8s2ioOuzHaCS1PV9emC6DiWe7zgCVxVyyK4/d3ToCKbbtlryQ5DDvaaihsW55pLvd9yyuKq9mL7Zc39GJydZnndklW7oJysBwBU7Uwm3iOwr91q0NXw7YtA9FpVMR7LMD12Q4UIIRfNFIcxklVHsaK6dO1114dPwt8+td5VlxQZLx2Zu/Bo1dAVbXt+FEeEWuFKkgPgeIYriRMNlnpmWfzZIS+4ACbzLT0CIhOYnI7kUwL4Dos7zGU2TvlnryoPgcbQgclXcZFM94rKsg13Bl1iIqiJU9BBbR+mh8VJq2qa4xqaemuTyAPWU4SE9BMhyjG3adubd2ShSiy7QtKormLf9KVh/HYY3N02YFz4cbZmOZodHAHjCBUW2Dvg9KD1eXFv+GCIU0d3dPUkHo/F8ccWZGm8mQEQnTbrYtlRf6MJ01hraeu67brXrAo/ALeou7DvoP906lOLCOMwS8z/O2JQEv6Dk+aku7OiBogAcWw7W9B//Wd0tKCD7kYM0H9yN3Q17Pc9hgMfFjBumno2SlRHka5x/M+2MS4Z4ONYBWFaHQeF03BImYh8aY3m7l+gcHAhrEYXTIEzkRVTxhDQegcnjLHxIAcT4jgKjDK5jF4AFQOkpOTZTjJGtZVO5eNOLFm6G4dT6QFE0Xbx86I4shx/dYtW7Lg/C2XYjBEjG2Df43QdfsN+6EePG016XrKlIehh7WkKA/Fyleh/2Fb6VxOh+W8yCf7eh6AO3gZF08K+gl9HkVRvsKTpkCLMhMqlmlDu9rfeD109B/kogXoJaOnSbBjw8t6G2WEXikuLrZdM7PvUP886HfZLtvu6+9/nicjBPcfngGV13KDD0BzO1yP8nTM1NS050BraOuWS7L1RP8pVR5JUuLeABE644d5chhV02zjtgh40J78xc9yMYqaNc1Xws2yrnBIaNCI9lBsL/IQuBSm8xfDnNCIDAwM2vZnKBVuqW1o7fB1dY1Ya1/XvPbiVf6mOozFV8GY2FU8sNo0an6K0djSOR/KIoOLhiCMLJcGsPCi2vqmRWFVtV0qAYq6f1l50YgJTrhf9rF4gvDK0qX3RK07skNyogIoH5mLhkCrfHDiFy+2HNiKsl5+/4bMiorcuB5ImwjPPfec++2du/4ON+ksnhUbGP9XdWnhcCVncVshIu2BC7F84JTVzjJdTzxxxuE9B94Ea2T64GEsovbKEo9tSP/xrPY3P4IRupeLhmhE/+F9lSUPcJEtOPs+1WlM+yIw/1OSxD5N1/8K7ssN0CIxV+PYhzZAu/Xfy8q8bLlzlBtb29DyONRea1cLCW8QnRhONMM5TdYJnRLbmQAibq0uKRzunzU1NWUPamiv3apOaP12KrJsqzySLAqeJQu/PjRX46tveRsMkKWHAcrTBgrt4aIhI1qejo4nMzQ08HptfYufzUzz7DHh3Z272JLe+BQHUGTx1zwZQUXS9XaKAxCHA5tawN7d+35spThgGd8HxbEsSCMSataR+Dj8vZiCG1nl1DU9A6rEDVCRY1YcYCDrDHc5vEcpDvRR0iE3lkiOq6BlvdXoReJQHLaUASsjW3wipi22VRwGpVOgz3ir3WtgIHB0SHHWtHZ90U5xGGkup23A7Yj7OxA6UAoXfTEUTHlvf8+boESF0Bm3bf7jpaVlw9mExv8AKnAV+g58+vHwYqQIuhDDNkr478VLjUNAapvabqGEmo5KgQXSHQ5lcSQZJ6JkvxejLEkjIrVZqArCQtQqymQBitmvaeptS3NzDctj996Ds+BKY9bC0QDnoiuyUlV5wpMt4PzifvqGFaL0jyDgsBqJELcGC/u8SxdbDsEzhpWHuWvQ7H+fi2w3lrOhEFv7Q+SDVXUt3qamjTE9zcyOLvDT+4J9G8ESWIanG4PWHr93GmsdoXLbWkmdEMM1ImzHUUGnm+BcTCuLLMmPlHrzY1+jcxyK09KtjiBJ0hSeHOZIurOAUPISF5MGwvggxujW+6rLDZ+wDZUZUYRtYwOTxAAYw/zyovwRa6pYIC60psl7GABGoXPGZ0WMEYtVBH/VdvgbiqFzqKWyYlh5qDTAnrwcFbYOrsA5IhaaA9rRT6Elampu77o5stYkTliAX+2atn/t7Q+9D/55Ig+q1WSHc8QuNgNq/x1wfobrYYaACqE6xbSobYggHxPRWQMJ05EgUMxXJo7PHO6PxMvRo4OWu1oyNC1640O2jFgWwrfCDbSck4qDPqioLemOrClVZV7TCcuWdesmgxm5jYtjRQBL4q9cbveXq8u8UfFomkruhOtO2lQBuONdQ5s3vvO3XdeBlRwxr2YASZMU20EORsTi1tW1nk8wZc/MiclNB7fiEFzg00Sjv8gcl/7XgZ6ez45fnjrEgw9SfNYXNoxXjwRugopYBr7mv/KP4gaL4obKkoIR0bW+htZfEovATQbG4utG2/s2d66bFQyErJYahIhIrlhWVLSHy3GzcnX9DIdTsRk9o69VlXpNY89qG1tuxQJeqen61Jj6ARwo7wFwG98kut51BGk/W1Fa2s8/MqWuuaOY6vojXEwK0AcKh7Xwy9CC90oS/o2CyDMFBQWH+MdR1Ld0vAEGxTYQNFZEh3JbeUFepKX1N3f+SCB6hVWTAvV6Z0VxQUxPdY8oj6+xdTPVqe36ESPgJjF3oAf6DXtcTocQCAS2y7JyPhz5C1BqLrBkrA81Wj5xO9DlHo/n/+3Todvb23P6A+Qrmq5dJTvli6CnfT4LncNQwEjEg4OBwT9Aiy64nK59VFV3lJV5k7KZfgpz0Jr2rhvCgdArJ6WHmABQP0KyQ55V7sk3naNJkeJUgLVAiM2qn5ZAE8pm3D0pxUlxOoKRKFYRgTwF7tfonaskAucTBDckt8y7JO5FTilSnAyGGx1fY+OlRMMrIecbzIvm2acESulHisvhKStcYrkPWIoUp5Ioj625c8PUUHDwXl2n7FES6Tz7pMAeSCSJeFNWmlKUl8CujylSnExMuztsU+2+QW0mQcISgdDp0P+wn/FLHBXctEepSB5aXlKSeuhvis8FMY0VsOdhBnoHbkRYmE8ouokSkgnKFNNvzQBlUUVRfANS3e7sjJ8XzJ8/IkQjRYrTnYQUgLl24WDw8qCmXuRQlFvCqsYiaacSnRiG3GAR79U1/T1JFg8QSt8Skfz77Az59dzcsY/eTpFibBCE/wNQFVdPPrszFAAAAABJRU5ErkJggg==" style="top: 8px; position: absolute; left: 8px; width: 205px; height: 54px"></img>
        <img id="imgVC" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJAAAABICAYAAAAZK3z6AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAABlSSURBVHhe7ZwJXFPH1sBvVrISwhJ2kKUgogKKgKKoKC6IOypaXlurT3zaz/peraXt81mqdrG2VevysKW1VaiKS7Va9eFarVotFRErO4R9CUsSSEK2+2aGm5hAghvf7/uq99/fdGbOjMnNnXPPOTN3BoyEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEBEIj8meSQ4cOCQYM8IsLDBwYMHv2TOdLly5VEU0k/QRFdVRUiWkV3kTdIjiNpaIxXScxp9+9QoiM4GVvCVS3v2yi6NVMQmQEx3HwDRSMYh/xFmvihc2EuBfR0eMq5fIObycHh4zzF88uJcRmLF/+P1G/3vj1ul6PY6OiR4bs3r09f8H8ZGVhYSEraNDA9w4c2J9GdMWWLVsmKCmp3CGXyZM1Gg0hxTA2m43xeLzDA4MCt+7YsfUXKBs9evxw0O83FouFTZk6zS8t7e1y1JkgLCzMTa+j1cLynfzfKEjYg+hRYxs6OjqdYTlq5PDI9PT0m6jBhDfeSF12LudcOpPJxG79ds3i5/wZoeJ0ofHGW4OiU7H06sav8Ytj6YTICMXvYymF5fIBUe0FTmGXFJRJPyeqFuFxOIdh3qXuWogEFqiqqk7U6fWYnZ2gGCoPEhLDABTVOCAJCQmc0hJxWWtLazLQNYWjk9NPNizWe+7ublf0er2kubk5sbi4ZAewTv1ifZcuXR5rUB5IeXm11d/wLEJluY09iNO4eUTdOjqFf1dHw1qiZsYJRfBGjM5rJKoPANaHynV/Jzwl94EZsICnt9dhKpWKyeQdnCVLUuIJsRkdHR2JMBfa2yFlM4VCoQBT1w2DwX6jpaXFgUqjqeLiYqedP3962s2bV9N+On0iJjQs2C14cNAHkZERq+bPn68j/slTIRZXoesKDx+O6pouNao/L1Ap4XsUGNdjLQ6MEY51j4NxNEyAbbiyfpXi/Jxe7m7+/GwdjUJ/2WgSCCh0wRVWfF6vAe+Ju7tzHofNaYDl2tq6BUhowmuv/T1CKpV6MxgMbNiwEXsJsUXAj3gFXr+Li6j14483XeqWdrNnzx5NVta+dzdsWN/LFT8JwFUxOjsUixkMJrZiZQpQXgYm7+jwWLF0RTDR5ZmHCv/HnpKbQ+W4/QdEK0hoyUHDNgqmd6ZKf11PiMygzxp5DrdxNFoyoJAKnW3oGqLaJ2lpaSpHB2EmLEvb2+O3bdtmgxoISkpKFsJ4SmgnKFi3bm0pITZquqkL0+m06Prb22T81NQPhd3S/x1yci6OUXR2sjw93bGQkKHYwIGBmFarxSpqayzGcc8iSIEgOkyYgtE4RI2wOD3+Q3Kd4hX1pWljUMUECiVbR6FjC3AKFbkGio3DQe7EU72CSWu4OosO0YAbU6m6HMuLyiMJMQIEwkuhUrBZrC9M3RVGFE1lIEjNgrlC0cm/euVsQcLU2Su3bt05FDX2M+3t0kXwvkSPHoXRaDQsdsJ4JO/s6EyYN69njNUvHvP/HUYF4iRcF4ORsBjjmELBNRS95Nd1wCD0MlSsaRXFVI7HcZzKarWxDX7oZ5mSnpF+UygUtoJAFyutFL9CiLGXX14SDQJiHo1GV/Bs2UcJsVX8/QdssXewz4VlMLNzq66t3rHvu+/ujB8XVzRn1vxNcIaGOj4l69ev5wBrOROWx48fi2QxMaMxKpUC4zV/f//bz4UbMyoQRE71+zdG57cRVevou+JUOaOWEzUzmLq2v9B5bi9Txp+UEKJHRmDHz4B5W1vbFDBAaMZXB2Ii6L5s+fyb33//vcXPNHVhH3/8sTQpaW5MQGDAa/b29vdhXKLV6rDW1raAsvLyd/Lz/igaO3aSP9H9iSkoKIwAltERfAcWGhqCZL6+Ppi3tzdwozrs9u17LyHhM46ZAjnNuibX01gpRLUPgPmRF71FVMygzKhXMKbknySqj0VkZDgKuBUKhatCoR4DlIjV2dk5D8psbXlWg3EztwZISUlRZGdn7YwZO3IwlxfADho08HUHR4di2KZUqZx1WvVVYIkYqPMT0twoSQR6jQ0aNBArLirBCu8XYUWFxSgOgqiUyudiNmamQBDOzIpsnCHsXmfpC12Xt/K4v9XFwSchNTX1pouLixhanPv3C1+srW0MVSpVLnCRL3bi2IfO5noCgnP95cvfqg4c2L/9woWzgUJ74W4oB67N2d7eeTHq9IRotBqkIFevXsOSkpKN6fTps6i9vb3dG84eUeUZppcCQagcz5cplEd4QNWS5cqLiU/tDkzB9fhWmEvb2sfU1TUkwphIYCe4sHr16t7rTASmLqwvFi1K+okoYnl53RNG6OIg0O00VfV+0zF48OBeMdOyZa/NAVbSmUGnK4DFyTVNgYEBuXQ6rQs+BDVVVc/8oqJFBbKZfC0PxELfEFWrUHAtnyrP/Zio9gtcPvMwHcxowAAFyGUy9JS7u7v1aX16ujBrFBTcI0oYFjokuAbmXl5eKPCF0+8uis4DNZqgVuNoxglnWQaamxqWwNzW1vbSwUOZ4abpUHZWuEgk+hW2d3Qqnnk3ZlGBEG7jPsIodBlRA1h+yPGu1jmdPw7vN1N97NixGh6fd08LLIJMJvNmMhkSBoPyFdHcJ/D1RFxcfPqkuPhNGzduDjW8roD5ggV/CbqTd2c7rNvZ2d0rqyxDvmbatEmlXC5PCi1GaXHJJxs3boz65ptvWF999RV/5sx5obW1te/DfoYYKjMz07GpWRIHy06OjmjtqidcHg8tdgI35gEsZ6/Z2OzZL7omJSW5wWQoL0lcYk80/6mwqkCsyH3FOMt1ywPFsfKQ4zqMirevI2r9AlAgo8Kw2ZwcuIJMVC1icGFA+YTSdunLjY1N7xz/4djtzz7dXgGUqWz7tl1lZaWlf7S3S304HHaNnZA7NTs7Gy3MzJ8/XxoaFvoGjLOkMnnED8dOXd+xY0/FnvRvxNVV4ttymdwZxE6KUaNG/QX2v3jxl7jOjg4GnUGX2zsJTkNZT4KDA87S6XQtfJFbX99ktqioVquxqqqyutIScS1M1VXlqNygkHxLdPlTYd0CAdi/FW7CKYwHK7/WYDoaY4v+wMXF8aSfn5/Oz88XGxQ80OqNpeCUn4D2/EjRY0WwDqf5U+Onxjg5Oe4EVqYRGBXPlpZWX7Va4y0U2kl9fAdkLH71rzHHjx+vRh9AsGPH5xkiZ+cQPp9/kMfj6WhUqgtwi0I+37bREXxWcPBwr7S0f6JFUYmkyQPEaSddXV2O7d692+KSBwje64T2drvgtdXXd4duQMfF4H8nYdKqNT9q1OqTRELltpY2FOD/2Xho8Nl1dnSyXpq3D1ogw6sOU3CG4N6PmlEh8H0YISJ5jnioAkGUR0RHMF3nnJ4KBFRKQ6HyhrIS6wsJEclzRp8uzADNftgnlqb1FJbLBVJ5nm8eSYGY48/cANP6nUQVgVPoKg2ufZmokjynPJICQXTcwA+A0hgX86hs9538mRVWF/dIng8eWYG4k87VYTaiDahCY4vFVM93UZnkueaRgmhTlD94/kGl8tJsZtw/SIjMgC9Ai/4oWdbQ3Lyys6MzAL4isLGxwWxt+fk6vXbtsmVLzhm2k8IXmp1y9Zs1tTULVCrVULgaDPsyGPQLYBq884cfjvTavhEdPW5lh0w+GZZFLqJbOTmnu5XahLi4aYlNDQ3obTiTybx7K/e6UdkTExPtcZxWDSYE3ZufwB0AU/18aZtU7OrqLOXy+TsPHcq8gdpM+Mc/UgPy8++s1ag1Czs7O9G/ZbNZUiaDcTgkbPDmzz77DC00GkhKejFdq9Et02g0Uh9fv+itWzc/WAYHJCYmrQezkPdA2nD46IF/QdnSpStmtre1/oA6WAAeCti3/xs0ZomzEiMwGh2teLe1tq84f/GM2TLAvHmLhuN6/W8MJqPu++/3uW/c+FFE3u081L8vGAyGImH6FO8XX3xR8vrra0Lv3StIBb85saOjk0ahUOA4Ylqd7rCv74DDe/dmHHpkC2SARRWFW1MeuKH958vXTt8vKt4GlceGZXPb2VmUS6FS7jc3S4ZSKbQv2tra0HdC5cm/cz+r4F7BJtA3iMNm5bp7uOfiGJ4vk8ljxZXVRyJHRKeiDzaBTqOPxyiU6SjhWK92CLhxawx9nESidwgxQq2msyorxJySklKsrq4ea6hvhG/Oh4LvnV5TW5dcXlZ2PSFhltnnxsRMDLry8883mpualyhVSqmzyCnXyckxV6lSKSQtrUsuXbz688qVr48juiPKSsow+B2VlWLBH/cKPiXERoqLS1G7pKXFuCFfpVI6Q1lpaRnW0NAAUqNZkslkRiXFaTQR7AtTp6JjS899ToWFhagNJgiLwRLV1tZihlRVVW1srzGR19c3tEPlWbjwpYjr16790twkWaDRaGlMG2Yuy4aVCx4eibRdmph3O/9ASsprbz62AlFm5CqIYi90Gkp2a2vbOCqNVjwiYkTU1asXh50+82N4XNy4wQODAmNFzvaTU1JS0KpybXXTFqVSmchgMBvBUz/o4uVz4SdOHAm/fv3n0MioiLehtnep1R/Ex88yeyEpsBNMI4pYc3MzZ82aNWa7DXfs2OHd2toSTlQxuVxOlHrzYvLCuRMmxrADAn3ZUcOHh4DPzgM3C2tsaPogLS0NvQODA4PrdL+o1Wohl8f9burUiV6nTp8Ih7+Ly2V6MW0YB3U6vXPurdwD1raINDU1T05KeumRd0Xa2QmwCRPHsuG1mabQsMFDiC5mKJUqTkFB8UqiahEvH7fT8Hca0ujoka9BuUBgiwWayL0HuPlBeZVY/GVXl5ojFArFi19dHALGJfzqtYvhIaHBbu4eHnPd3F1zmEzKNti3X0hJWTEzNGQEHhYWgS9ZkoLeFVnjk08+8R4ZFYOHDA3HX33lrxb3TU+ZknAEto+OHldpuj00MiJaGT58JB4/dYYCts9PXITeVRlYsGDRHCifEDtZOXxYFD4MXA/RhJgxI8kNymGfPXv2JBBixIoVb3iHhUZoYRtwgx9CWVJS8iZYjx41Trl165dGa2Fg09ubnCPANcE+4Jo3EWJsxPCodCibPGkaahsbM+EM0YQYOjR8PZSPGxuXToiw5OTFy5BsXNxDXw7PnbsggfhcNbhmfVTkGOWGDZ/4EM3YkCHDhsP28PCR6ExbT958IxV9V8yYCb2+KzV1vT8YS3Qfli9/zeIeeAOPbYGsUXi/GG18Z9IZFzIy0nMIsUVu/ZqbqFAoMD6fj3l6u+0gxGY4Obmg3QDA93oPGlRoPKkBnjaMTqdhLs7O2bDeJGk225+t6VInw9xOaJcDt2oA64B9/fXXsajxIeza9akYPP3IQoqcHNFD0NrSit6oM+i0w6tX/7XXrPPdD99tZLFY3bsFcMpqlJtAo9O/g+/FpDLZxHkz54US4n4D3J98ECbcBNacdef270YFfhoUijYB8ADooZVK2+2Q0Ar9pkAAdKOFDg69AtCeAD8bAHMQT9yGJzKQsAfTp086DRUAKuW1a9eRWd22bVcYGAwWCLalPA7/O+jmQPwSkZ6e7gjbYQBfU1M3Epb9/PxPw4AccvNm7oPTAn2Qk5MjAAOB7klZaRl6v9fa2oquVY9hVo8CgUAZtTU2NnCysrLMrJRE0lzHYttsxvU4TaboNFqb/kKj1WC2AsFqcCtALFOz4NNPdzz1/qzIyEgxCL7Rg1RaWr5qzpykTYBe1hfSLwoEtz+0t7cTbgYXd+fWEYlE6PiCLY8HxsUycKYGZx0QNps7AuZ3796lQoVSq7Wd23d9dh5YGTB56+LcunUbnepTypShGq3WBfw71ebNm3YrlQp0TFlc/vAj8XDLx+7dXy0DFg4e0dZ5ebidzcw8GAFjIgjc+2wNH59uzwGPXf/22210rYYfplapsYEDQ7ZDZW5qlkS8/vobc4gmq3R0dGBjxkw4YZqmTk6weLqXx+M5JibOvCWwFVyByv+f/5zp0+U8CjCI9vf1fZsGLL26S00tKy195/Dh4w1xcfFFCfGzNq1Z87YxnusXBeLxBBOJIsZhsYiSdSg0qifMQbCN6tZgsbotiFKhQFPXwruFYJD0GAhmkZzL5R6FClX4R+EUWC/4o3AMbAeu8Rysg1kgzDCho333RuUeHDxwdBGMRWDKyswuq6yoRFt03dzdTh46eugXqVQqQh0B8OSsNQSCBxOgWrF5yKHDcUpGxvZGb2/Po/Da7t29h2KrvgDTZkwmlU43TVKZvNdRKgifx/N2cnJiOIoc/wWvUdIsSV65ciWympDHXqchyDqw79PAwKAptgLbXGCNMD0IBZoamwKqa2reuXTx4u+zZ89bByx+H3flMaBQ9HeJIqbRPfylvE6rQ9sp1OBG9QW84RAGs/tI/guBvkjzHQhrgOO6QzCnUKkJ0IIo1V3Ijbq6OCP3IxR299Oq1cYbaopEIlkIbvB7MFVUVHhzOBzMw9P9Ix7PZi5sFwi4TagjoKuriyj1Rqd78Dv4trZEqRvgZlGQ2tTckUKlUBXNEknA3/62qs/92MCqYItfTQ6wE3LZhmQrYEcTzWZAq1dZWYkdOXLwMovNvgLX0spKxB8KOE9/eun77/eejY0dE5Gc/FKAr5/P63YCwRWopHBaX1Fe+X5jY0tqvyhQYmKiGG7IgtgwmH3+pQ8ImNZehLke1znCgUdCC8BAG8JkMJFbbJNJvWDeqei4BfPk5IU3oJsDpts/L69YBCxVBLwOCk2PAnAGjV4C86oqtHu1F+PGjtkwMChoevDgoOmzZs+Yvvatv3NPnTr+tmGzGTDlN0HMhfpKpXKrprW2tp4oYVhY+BAzfxkY4I92a16+fFJib2+HrquoqGhVX5YaDtLq1atLLl++rDKkM2fOWNRgHDdGAbift88GEAvhzZLm+IFDAnxgjPi0wIMJq1f/reTYseztl6+cjwkePGgSk8lUQcsPXNuqflEgiA3T5gLM26TtFk2tKc4uIrQgptXovE+dOmVx7eTDDz+JhTMuCI/PRQonkbSieleXGs2GFi1a1MhkMC7AnX8V5UUHgSLBp7dg79696GZX19Zeh7lBEXsSPCTo5sGD+05mZe07mZb2r5MzZszo1REMOrpWXK+zujShUCiRhbO15UuB+zA70WLDYhuDTy6f9QGYGGjbWtuGeHl7hxHipwJaIAP7D+zNcXBwuKnV6ljgmlZBBXroesBjsn//3hxXN1c0y25paXPuNwWiUSnobb1UKhvTc3GvJ2FhQw7DoBJEwODmq/9BiM3IyTkXBbUcuBVpV9eAH6HMxVmEZlgg9oEZAgS3aNZXWlqKFJfL4x0zuA2RCE3OMGB+Lf7Fj0eBz7NFU3SdTjfV2kxE3aVCrpNpw+y1+V+v7w7CISdOnKhjczibgWumSVok6FTr06J/YIEQHq4uaCmhSlz10Af5STFYPQ6H3dhvCuTl4/6To6NjhUatxn65ejN7Trz5X/HYsmVLQHLyK+gpXrdunRjMoJDClZdXrpo1a4FZjJKa+s8EpUL5PnyCvAcMyMjOTlNDOZiyvwBzd1dXmCEcRXbZ0OTDeAqenKDT9ca/3uEickE5UOon/p00Br4ZKHsjsG60Mz+d2zJv3jyjy4V/nSNuQvybcK2Ky+Vohg4N+4hoMqLTmg9wQMAAMCNjqlokLYTEEjiIaY64ZmVlucFkWiY6GMGJGMjAt5nf3hCJnK7I5R3GGPJxAcGxY2zs5PRVq1b1MgTwoEFrS9t0WBba2e3rNwX69ttvVa5u7pOAGW+ER3Iq62uL4qfOKJsxY27mrFnzyjL3Z98qKiw6Alc5Yf/4+FkbPDw9SrUajbO4svJWfPzMo7HjJq2PHTc589y580fBZ9DsHexP2tqyjO+l6urRX4DByioqkbuEREVFlYGnGu1NBrOzpsmTJxv3O9OoVOR+5HKTwyWPCYiHpJFRI1KAguhlcnlyfZ2kImZ07IaYmInrDxw4nA/ijc00Gl0D3PKizz//qNf+cXi6xJSMjIxGgV33w2MNOPjbt+2qS//317Uwbd+221he+spys0VRS0ri5e2FZmRPyo1ruYuBgi+7euXG7zFjxpfNmD43Mypi9Pq4iVPv1FRX/w6XGYAbuz8sPOTtflMgyP79GaVBg17w9PTy3A+CW5va2jpfcaV4UUV5hS9QLKXQXvg+8FzocYGruuHhIUEv+PttZzDoytqa2tktra3vtbS2LAKBsCJ4UNAHDg62swwnMuBaE+jHgTfGzo7fCWWQpUuXysHgnoZyJpPxo+FdG+TW77nFUE6nM+wyM090+zMAtFTdN7jvZQQDX3yx9bivH5gD+vnmA0vkKZXJ/iltb3+vrU06EEyh80dEDJ907NhhM/dFoxLfAdxwTxwdBR8BK6SA7VTagyEwXBe0vDKZHL487ZUwOoYWReFqvKFvTzIy0i87OjqgGRO8DovA7yZST4aFj/zOy9NjJ4fLlYDJg69YLF6kVKneA5OfoTwel+Lh6bYlMnLYUBBga58+TO+D3bu/jG9ubqa+8IJP8cKFC822O/Rk165dsRUVVRwnJ5eqtWtXP/xo9f8RYNYoKCwsHaNWd2Genm4X4Dl8oumZBDzAAXfuFAR0KdSYj7+P9N1337K6Ik9CQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkLy3IJh/wUW8smsiLaLywAAAABJRU5ErkJggg==" style="height: 72px; width: 144px; top: 8px; position: absolute; left: 318px"></img>
        <button id="btnStartStop" style="width: 136px; height: 41px; left: 174px; position: absolute; top: 641px">Start</button>
        <label id="lblUserMessage" style="font-family: Open Sans; text-align: center; width: 421px; height: 22px; top: 256px; position: absolute; left: 30px">Label</label>
        <hr id="hl1" style="width: 464px; height: 2px; top: 87px; position: absolute; left: 8px"></hr>
        <img id="imgApp" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAM0AAACiCAYAAADiHknmAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAGhGSURBVHhe7X0HgB1Vvf5vZm4ve7f3zaZuEgghCaH33gkqRcFO1Yco8lSe+v6IPkUe4Hs8ngUBnw3QgNIVaaGEHoH03rb3csvePvf/fWfubDYQIIEQdsP9krMzd/qcc75fO2WkgAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACCiiggAJ2EVp++bFALpfTYrHB/bWMeVA6m9ma7u5/sWLmzEh+dwEFFGBj0aJFjnBv78x0Iv5GLmeCO4SZS8Zj/X097V9ZuHChkT+0gAIKILZu3VqSTiW35NmyHcxsJtfb2fbnAnEKKGAUktHoJXmO7BDZdCrX1rz54ba2tpPb29sr8qcVUMDHEz09PcFEPPanPD/eEV1tze35UwrYSeRyoi1ZcpvTXP2tYC53rSO/ea/HxyIQkEwM3+Zyey/N/9wh+rraxOEJlBYXFw/kNxXwDlix8FzXtMrecwxH+t8153CDnkv4TVMimuZ9E0x6LusofsVw7PuyPu/WnvwpexU+FqRJRCO3uXz+SzXtnV833NctazaunX7wwUety28qYBTi6742xR3dMtmMDh0mWubKnN5XqmumjGQplmrdgT+6iJlxxsRRfYteeep/aXX/2msdtHfgnWvRXgJYXnokPHi3P1B0/mjS2OvYr9aHwwOytbn5zH32m/OI2lGAxF/+7CSXo/0GiJST9XS4SMycSDYnOVOZZoL/kgNBNAPJqYlGwhBY5JCnGbcmSY8nljPke6HGN2+xdo5/4JX3boAQZjadHiI57ESMXicMh0M03ZjT0dExKb/pY4v4q5+cnHn5iL+6jTfW6dJ6ri4gjBM7QALx6qL5dNH9uhheDfmGbVn8HzYlFUPK5KQPmzaDRFt1TfrMpD+WS/73wNq5n7SuPv6x15OGSKVSsLlNGZ1Gk4hJ1w3JZlM9NTU1m/OnfeyQW3JpeXrp2Tc5HFtXG47uT2ha+m3OfQqEGA7oki7SxQR5TBe0iRtE8ujiAqHE5RC3IyT+uEdSQ6aEh7IST+QkYchV+UuMe+z1pOnu7q7JZLKhTCYjTNlsVpHGXtoE0g1ITs1Rlj/tYwdz1dlX5LTXNjvSq652mBFXfrMywVLQGN26U95MemS9DjKkc2LGTUljX9TUxAMNpNc4JVpRKVpDicSLgmLUTpeZ1U6pAqGiEVOGU4kjel8+pV5ddJxjrydNZWVlB4p4ENpG0um0Io5NHps4JI2mgTS6NOZP+1ghurzporS25tasNx4wYXLlQIIUKnuPxyPrXEF5PRmS17s8EhnOSlF0WHIJUzLwWfojOfGBXnqFIRGjWgJ1CXGVDou/KCbhgTZJGaZUBXWZgutlY+4BKb0wnL/luMbHxTyrSiaTwkTyvJVAJA1YI06nM5Q/5WOF/t7yf+/pykhXf0a6oRU64d2vTBfJ+iGvtPXAL+nLyHA0KV4QJpPMSQY+zMBwTrxZU/SQLsOmX7zFGdEcpspHf3FKpkyLiKcKjlClAyQyZJLL/XB50+cKpNnTQOU2Vq9eHFy/fv3U1cuWHbB62T8P2LB69QFtS5b48oe8DThHGx4e9sRiMYlGoypxPR6Pq0QikUAqEpSTKuusjxd6N8bMrvVJibZAkMCZj2Tp38HZR+3wekWKikzxGRA60awkYZbR2R8eNMXw65IzoJXMCnEFErgSXSAmA74NTmaQAL6O1DvF8MQ+k1v7jcm833jHmCfN5vWrDt24ZvndG1YvX7Fh1fIBp4TCeia53uUylrjdniWall0S93te3Lpx7Q/Wrl52Wf60EQwNdU9OJJITSJZwOIzfQyMpEokoEpE8pqn8mob8aR8rJM3gohK/A+QwJJHKidublbJQWEpLwhIKxcTtTipzLBo1kVdw7qFl9DjUDUiRBYFyDlYjDxJlF5fQOKMB7mgV4syGn78gv2VcA68zNrF5/ZpTzGz2Vo/bPdXng7iDz6EZBqQfJSDDw3x0FBr8kkwmLS6XS1q2bpFNmzd/4vSzPvEAr9Hc3Fza0dbc63F7NI8/qMww24+hWcb2GbfbLX6/HxUmKH1dHTGHx3/MK6+88sZ5552HWrF3g51UFzT+8ZNibr3R9CcaswFdkiBC84akuMpdooMM4Yghvb0u6WwflqL+AamtcIgj4JAyPSdlk1zigrZJ+mZISYOtaQaRhpGU7kYCslimQa61xt/0OW+cbm0cvxizmiaTSh/i8bin+gN+8aFSh0pLkcokWFwGGzkkXpDA6w+o5HR71e9AUbEk4vHj85egGeZZs2at1tbZrbQJiVVSUiJVVVXS0FAv9XW1Ul5WKj6fR3LZjPi8Xv9QX9dPPw6ESb765VmfbPjZ04Zn3UKtJtUoVQ7JQtNk3boUT/JI69qURKIuGRzUkNIyOJSCpjZlGD5PeCCjNIzybxI5MXMkCxty2FE8xcuPAghD7lDbGMm9wvwds6SJJxLO8spqKSqFXvcFkeMOaApNaQs74kVQ8xjQQITD6ZTY8PDlD97/l2cWPfXEjxPD0W+2t7fL5s2bqHWktbVVLZk62jtkYHBIhuMJaB1TXCBeMBQSaKWjlryLjzTewc6V2VeO+5lhvPKGVjl0VK7GkFwJCOMDYZCXmSy1ty6lE1yyZdUwfL6UJBIxSaZSEkvAPANpYpGsasjMDKMcUkiJJK5MOcMlTbO8hiHsVS4dI5HscY0xSxrN0CaRHJpOQoAs+Eui2GQh7HWaWDS7aMLVVFc7ujo7j+5oa/3umlWrrvZ6oEVwXAoOP5ckmAfbvD6ftYSn68M6f/sC0FYBvzOVis1QF96LgHfXEi8ed6YZfXq9Fuq4Sq8TRw6mlkC7mHDazZyuyGIlnADzN5tNgDRpCKk0hFNWhjMwvMJZMZIgz1BWsiBRFtomG06JiWMtLWNXqXw55ReRvqzEA7k3rV/jG2OSNG1tbT5d04MkAiu65bdkRsLFdvg4kUio33bYmD7KhEmT5bQzzpBDDz9cZs/ZXw477FDZd8Z0mF5uiYbDMjAwoAICjKDxfDuCRoKSnE5oKz1nTreeZPziF7/4xRl33XWXIn/81QsmR148+B+Z8s6HpDZRJdXQ2tAuAu2Sg1DK5UAcE8QxNSTojCw1uSkl1YbEepLwVEzxOaHhVXuLKY54TqJY4jBYZJo4Es0S7g7AZEvJQEtShrrY7AlQqOG/CX9mff854vA5Vlk7xjfGJGnq6uqGUYkj7A9GQrBC2yYZiUFtweTAfiZuI0rh9zROnCzlFZVSXVsvEydPlRn7zJL9Zs+W2fvNkpkzpkl1eYlokJzxWFRFz2wCKU2FEjYMhxi6a6q64DjFm2++6Yf/9jAExBtPPr3owcHIqqWusvCJ7hJNtFJo7iASnPwctAvJklUmmUUWJiVAzKyKGEsiK14zJyGnJqUl1EoQLFFYADwEhNA8mrhCpqS64pKCfxOVaukfrFY+j7LYcJyWzcmsyQ+CXN5X1AOOc4xZ88zQtWGWGSU/HXgmmmH8TaKMJo19zLZj3TjWA7PLL4FgkZSUVUh1XYPUTZgok5umy7Tp06Wmpko8LgMZANMtr70yqDnsTuNyOsYtaZ58+tnLVq1e0204nNI0Y4bHTK84q9sZC9AU00LQLnhnmmKZjCHptI73hiYahuk0nJZEPC1pJJPhZPgrDqQiCKRy/GwEB2ZA09RUOcTl0yXIUDPup5FEIKLP3yqRrmIpLXNIcRWIGMd1ezIysMUtvWtdEl/tWK/VLn7ResrxDUtEjzF0dXUFOtu23jh1atPlvqDVSG9rGiZitNaxf4/eT9gaiLDXR2/LZjOSTMQlGglLJp0RD/wbPZdloOD5OQceelT+sHGBh5Ys8Q2uXvvbwYG+c5kHk6dMlbKyqJR4bxWXu1dqJ7pV0CSTgXZh5CsNjULzF6qAeZKCf5Kggw/TK4lleghapz8jrphnICSOu/wO35taUX2f9La06LM/k+zrfO5gp3/FHcVT3eKrdYrgmrFBJ7R3kegw81BgYnhy8BsHxOU1xenRn3GXrzg2/7jjGmOSNMQ/X3nhB9OmTb82WGL1obT9ltHJJhI1Bc0rEojaiJWAFYQYTRJiNHlGJ14nGY/J0EC/dHV2wN9JfeuQI4++SR08xtHf3x9a/NJL97c1Nx+bRj41NjZKbe0bUlP9CPIlJRoEgddjiAZTywnfxOlD/rDFHv4IG3UZCUvCwadzn0DK9OO4AUl4pfy/A3PO+Wnp/GuG8rcawfr/O/oYZ1nzIpLGP4V5LtBSmsS6U+IIQFsX6dDaMGVonrHhOCHPGOXL9wrSjFnzTNeNYRKFYIUmKWhCsQUflUQl+iMkDKNg9GfYBqMiYdAYJA+TbdrZ5ptt2tlEsYMMXPf4AlJRXSONExpxDc/1fZ3N+6kHGKPoeO0/Tu978fx7u5ff3BIIFKFC5qShPiJlpXdLMPCAxCIJyfSmxRXOiN/MSHGNIYFqp7iLkA9umKaUHylo7BRqNpY5kEcfyEpRxP9kaXD+nAkXL/m3HRGG8E08JANLlrdkpBMJRAk4JASN5oOJ5oTZ5sB2A0nHjTSno806c/xjzGqaF55b9JlpU6feXVZVq8jCKBcrNolAkrDy7wg8ZmdA0tjgOUyZNPyaZEIG+7qlc90TUlLafO3kg278Yf6wMYHFixfNT5vmzMG+/s8l4+F5E7wryjyyWTrSQfhurVLi7hM3TC6vNwsBgsrNfl9+Pf++FBRcQktDWKiQMcyxNHyXxEBGEh3ZrHMg9MOaC1//EY5614xcfUdDbVGNsy3Q6JLATDZrUWMzuGAFVJhUQwH4aPUIMH+tB1e8rZvTeMSYJc0bryy6pLpm4q+rG9hb33rMF198UYWMy8rKVNcXkoeapa6ubqTijybN6HUVERpZokBRuLl0Lwq0X3LJrWImOyU72CJebb0YnUulZWufJBu8100/te0H6sQxgIcfffi70LT/gRfTYjFqlFKYYbWSANHjg1ul2lgi0yY8I+5aQ4wS2EYjgoFLpnweMaScBHHg17BFPx01JdWrZXKtckHluavuVae8B7aCNJ46Z5uvziW+ff2KlBZpaB1YpFEJHGL0LJcBaQIF0nyoWPPMbQd6qw54tX7abNF0S6ssWbJEhoeHZcOGDTJ16lRljhUFA1gWQ7L6IDlbYBZ4JRVdBdOALdabsES5JTbDfE9ILtUFidepNFfA2KquOQKUb7IPEjqALOnPyeZmkKqp8fYpx73xrrPY7AksWrTI0z/Y97u21vbzEolhqaqskGgsKhWVNeKH0AhHwnh8hwSKiuSYw++SYHAFznpr0eIFSRhGvfLJhElGbZPpc7YYA+Xn+4556qX8we8Jksbf4GzzVIM0+wWwxSINvE/cJi+Y+AjUMkjmsPsJo+S1k7Bl3GPMkia3YqFraMP/DPlmHuIZ1l0oghwqQxCSsQOFMCRORwoF3w8ypGCPr8cZeBUl5bbBngDi+dcNeXmZLpUlptSU52TFBl0O3i8r3f26LHpNlyn1pjRUiRw1MyOVpTix35SNW+DrTKq4Z8Ypaz/SnrmLFj1S3TeYeHD9unUHbd2yWeXBPvvsI6VlFewrJyRRe0cHNG9QKiurZdLEdTJ1yh35s/HyaoElG1Uo8ZknkP6Q/GJGsewIPBRf5/hi8YWLd2nqqh6QxtnoanNVOsSzX5HaZpGGDdJZuemmHvnWv5bLjf/ZK/PmuOW4Q33P6KFCIOBDhTbrvJSWGV5htP1egvHfSCj7f3BS/0ecsXvFmXhctNgzoqeWwcxYg4qAWgBH164jNmzrpLbClFWbdGnv0WXlRl3CMU3+/oJT1m4GET0ZmViVk+mNppSTMPlzuHCK9pF2MHz0Hw+dGommV27d0nxQT3eXGLoh06ZNk/r6RqVd3TBPXW6fNMCE1TRT6morcAxHFDMjLGnP0K+AIEricxMTexy3BTZpa+o/6T7w5QW7ShgL5XDyUYFUnlPLMMeszEvj+o8+GpU7fzMgfX1Zuf+BCHbpVEd7BcYkaThh+cqVy89P+BrLszGaEIxyobxZ7lzm1ylAmVg31Lp1uqTBn01bs7JyVVqyaZEX/mnI3KlZueJTabny3LRcd3FK/uPSpDSVxqQiFJWTDsrIrEmmcCoiO0c0Osw9ZbRzPhIsWvTYDN00H+juGSh1GDr8uEqZO2+eVNc2SCqdkq7OLvgycYlGI5LJsNNpGu+dkv4BP85GTjCD4LOw/US1zDMhH2WLszP3SunXHCu/2eQ84bH7ea/3BV8DG6CtCJzK+W2kcbk0OfPMgLzySlyuvrpMZu/n4f1r1c69AGOSNMcee2ymu7tX35wKTewfhJMaNmXNyrSsBgm6WjKSwLZ4D1J3VhKdWUl2ZSWFlME6U6o9Ky88k5RnXk6JHjPli8en5BufTEnIZYoDlckEkdJwhEuDmlRX6TLQaUo0DunrQaFb5S5s5ilztX503T7M7E2pVMbldjkkC21RX18roeIS8bjZSClSFAqoaJ/DkRsZUEd/T0l8EmU0WeDo59Y4OnMvVl4tQ9+e7Djl2f/VPuDwB9/0E0EaHcIlv+EtuPrqcjyzU77+jU659JJitgmV5BaeS7E07pGvImMPa9asKR9aetuR0vPCV4rT60/cAIJkqnWZWqRLCE/tQAVnfIAOLV+DiiEDEySWhIsDTbNsXVaGjZzUFOvKMonD6U2jmkAgqzHufPGyYk0mNBlSVaZLCcjjYXtDBOTpM6W92SHBqSccWHzsH5aoB9qDoOM/MNg1mM3m3JxaauOmTTJn//1kKByXoqKACm4wCkgyZTMZiSfi0t3dA9NtqgT8mhwy+zs4ABfqzYjZ7t+U6y65zph66J+0Wde9dbDL+0Yut8KVXvyJYSOoG/r+9Gkof5mr9CvJx5xcf32P0kYnHOuTeft6RfzFTk17dnvHcxxiTGoaYsaMGb0Hn/9f90+oq/gJOwWW1RhSGdAlA9WfrtBFn2CIUWdIzKvLVlTyJUszsvAfKVn4QkrWbi35vw2JWa+u7M/K+rgpbbDdBmG1ZKs08U7RpXK2IfUHOaR8jkOcIIwJYplOTUxWRiS2XURS/qUfBWEIJxCJxtyxGOc0iEhFBXwV+CxVFcXYhyJD3aRGYaMh+8qx0dbAcng4LsOxmJgb0pncK+4ncyumn2Ec9toUx9mP/353EobQtFkpPEJum6Z5u8qpqHDIPX8akvo6JzQN9r+e2D+/a1xjzJLGhlF66FqPxyGhSl2CqOBuaASN2gNPTu3ig9qpqDVkQo0udWWazJ5R0T55/wl3TJu2/8NN5Ybs22DIbKT9QbD9q/G7woAvo8uUoC71IGMFrlECx9ULDeWA/2REoZHS7pQ4i27PP8IexxFHHBFJJhIbB/oHZHBwkGN8JJmGiqQgR+VUC0Uc1bEVpGGnVZd0bl0t04b+/GQ6fPQs/fjXTtTPuP9RHvphgf6MasDcAWGIGMzCiy8qhoa0LMFcmVmjVsY5xjxp0lO/NJQK1WUiMMPCcGSHUKnp5wzAjOK8W4Oo6IOo9GG3SABkSIb1nrnnLHqp6bBTfjZvwoxv13vrb64tP+jmytC8//BEjMu0XudlerfzMqPfcZk74rjMla794auv13b//YkKeeaZsmVb26Z/Nlp+cdk+l77+8/wjfCSA7/If9FH6+wakp6sT5levMsMUYRRxLPJQ41DLGJr+yyItfHhDRk73HPGrteqwDxt8gB3zRaGtPS2V0DYTG/MjNgPpvWIyRqsMxjBalv76kN4V33upD45IAnnPibYZnfFBS3B6ITcKLQfipBgc6AV5wn7xHHaR89hjr9tp2/mqq676sdvt/m53d/evf/Ob34yZVus77/z151vbWm6ORmPlbNCcOLFRyspLJGey1Qr/YHaqf2autbSkdvL8+fPzo78+fEQ6/lHp33xlp+aBvp872qehM8Wsz8nf/x6Ve+4ZlF/9b4343DB/h3LXGVXLx0wPi/eLMalpUBmcLS1r929b+8v/jUdffCrhACkgUaPQMgMD0DLwVThHcAqahjKMUbCGMkMmFoFI6ajUu6fOtq60c0in082BQICNhud0dXV9HmlMjKe56KJLf7/grE9NnH/Agd8KhUKyadMWMdkFZhRh8D8rOf3yPUkYQl/+kENTcXlixybakiVxpAS0pCW/NMM5Ta2Mc3yopDHfnNRkrkJaPuFwc1njofw9vPyL7zi3WO8b9XUDy4/7dt/S017WWz71ZqbzR/+iJ/7hK4IPU4lUHzKkDr5IuVsXH6qIkcyJE2TyODRxQ/tw6ff7Eski9y61r0yYMMHLDqDNzc3Lqqqqfo+0Ib/rI8ecOXNip59+5l0++DU1tXWyfsNmCI+YtTMnazSHfupJJ53xofouO0Tve1uATU0u+GO6xGAJKOhmtbUyvrHbSGOubZxprmn8hrm+4S5zff2G3Lr6nOZLrdV0JCO7WNMyL2paaq0n/WRz5rXJ4cQrc16OLT7sp5EX5104vKz+Z9Gl9UuhwVuNzLobjOyyeW5nv3g8OfF5c1LkA1FAmHpok2lw7mfA+Z/m1aU6jhfoyYreC+nbmZVoOCeByum3zJp13i5Fiqqrq1XnNvgHO+46/RGjvb392HA4IqGSkISKQ7JxU/Pm4487XT/xhDNnnnDM6U/kD9vDaEGGgQzv4tfU1Dhk7hyPhEL5aqbLuB5GbuMDkcZcVVuWWTXhivSa+pXiyK7S3On/0hzZC0CSKWJkKVm2JcNaanpGDBkOOrKdB7d3r/9O92DbH7NRuSqX0War8D7sdS1nigMF4oHt5fdpEvJrUg4TrQLbSxOmBCBotX5TIl2mJNpN0UEWLevMumsP/8WMzz/9b9bT7TyGhobWsRMntM2YnDZ1zZqVs1xOj5SGyqS6ql6yabP+3nvv/UhNa29Zk1sRxuoSkIdtplks6u3Nyve/X67Io6CblbkV5+ajAuMX7zvjzdemzDMNaX51/fCty7uT+ySysFtdyCwnyYGlkkL5DGSXDrYwcp1twm4soEGmNujSEBRZ+0ZCYuG0xJFSkbTqTGg4cRiO9SVN8Q5mxT1kiglHv7vFlA2bsrJsc1ZaYJ75oCS00IRn0/WfOKp6wcP/Am3BG+0S4Mu4ObkGW9XHIjZsXt+RSiWgYdbLuvWrkZ0ZZ0UFg+UfDfqf+uz+cCdHfaQpX7ajwG5Nc+d65Fe/GpAl/0yovZohnpyvd9yHnd9XxptL648SZ/beYclV3vdwXConOeT4E9zigr+h+juhMqspsLjkDKVpLNWd8rfDgh2S0zCt+rZkZWVLTibNNsRfivM9mgShWTzYr4dhdg3nZHgoJ50wwSJxTdJG2cMZveqm6snlJxp+5/Ge4sn7eCvnPwWuJLI5Ty8WfyhuPHeXGiVbW1ubXnrppV/pur7mkEMO+VfOhpPfNWbw0EMPzRsM976G2vinZNa84ZIvXrIsv2uPYNGiax1zzBePMoe7fh5PRmfEofGnToNk44ec9mN/N5YtZTCDFJbjr0CBiSphCU4sY/ppeuWbf1f7xil2mTTxl4+c5C7dsFHzWqNkl65IyzDEzpEnu0WH06dECnvWwt+QOH4wpZC4HZmWwe9sFOYUSKUj5RI5WQni+Cc7pbxOlwDKwRHH+TgmNpiT5k5Ttcdkdd9W09f49eO++eKDvRvvvEiX3O0aO9fiFfAHb8I13C4cF7Pi8EBNzZy8t/zuGBwcLIGGaXM6nV71OzywekbTzH3UzjGERx55pMTjN/rwvJef84nP/Dq/+UOH+dg5pUOlW65Lm8PnGdFUZQyFvqkvK22DTrngIOS4Ig1HbpIwVnUaIQ0jfIowTChzLjP6v+qhN2/m7vEKvukuwe3I7JuL5bQs/AgDZJi7n1OOOp6dCJFhqh8Y8gp    5xrUczCtmWjqWkyT8j2QHfBoQwM22FmgTBxK/29g02ZDGKpFimGVO2MH0Uzasz8ob61A4/YZEKxZ0BY/77eWVJ/1aSajW1e1zIu0dWmxoSGLRMEgbllh3t/Ss3SjLX1sp2XB0p0OboVAo8uBDf3E+vehxeezxR+XJJx4fk/MNt7Vt2dfQDY09vPcUOu87ffJgdNlT3tTQFR4zXRk2crJFIC3dRbJPCR5ECSvrWKvELdA0G0n8nd/HAHUuZ85RP8YxRl55Z5F5Zd7VRrD9JvszJCZyQpGD9GNSkyxgiSubUTAGfogWgWMPoryNommcB6Ll2IcKPk8KROzpM6ULGiYOLdQ77JGnu+eLt2K61FbXsA/WUHFJyfPF5tbqSqNlvhGChDMMuFCc7QQaLzwsW7qiUjbpoKPmn/Dl5/N3eU888cQTZcPxyJ9S6WTRMUedcALuM+acm6OPPvJ36Uz287qmPbp48Qtn5Dd/aIj//eSJLw+uX+wyzLr9653S7/RIMuMW9zD8z2hM4jFT5k6FT+9Doe5rzRHAArbIkv9QFsCGWMUZVIUMzHQ9rW1yly2bonaOU+yyptGdhiXFrTwRHflmwLF3QGM43Ej8zf55+O0s1sVZrqt96vD8OQpcx91pWvGDpp3NWdncmpVu+C/spbxhoFT+suUQ6Y55ZcvmrfLiSy/LAw89HPrzn/98xktvrJufTmetlnEUDmeFzMAk5ETmmUyGXeZ36duOJ554Yl95ZVlnWXmpdywShjj11NOvLKmonD9v3gHX5Dd9aBh8/islLtl8/5BD6rK+ckkGSiXkdEmFNiQuPSEZlGeaQpBlmE95jqjyoHXOxDFQTPxQbf9QVnr6fTIcrZucWHV2k3X0+ATFwy7BXDL5Ns07fKmKgoEcau5Sah0ueTUmUpG/GTGDOSbwS9QAKHsfAdPOhJMfhVYJw3+JJ3MCZaE0zOq+MnmsbX+lxWwoycX/WNaXu+ULJ1SJrzSgvibMaFsukZL44LA090QkNOmov03c95jbS0pKni0uLn7PUYkrVqxwLXrm6a61a9f4amvq9/3ud787Zho3Pwpk75v3Bz0w+NmOkENKQ+Uww/tVTwT1BTTs74aWGQ6bchBDyfRpZlnfD2LhZnBMPM55t01JoMzjsQpxOgIS8IsEg31iZCKiDwUu0ie89Bt1s3EIuwrvNMxI+QaBGaWiY/T3wAclbQgu7US1zDpvk4vbaI6BRLkeaAmYYSZ8HWayCqxQfUMqrYeGeax1NiQVTsZ2kkRpFCRrDElWBqNJSK+0JKGSEskMCJdG4jIjnOX++RdePe2+vyy8/+mnn+h/5pmnl7z66qvXbty48SA8wQ6x7777Zv7+2OPXvLF0xbd7enoYwvhYQ0sMn8e5nqsDleJI92ELzCqUhe6B+eVigi+KZAtJGODqPCKT8Us0XC6p+ETxexpk4qSINE5qlrLKZjHMiLz2zzmcJuvC/OHjEtvedidhvnDeLC317HIJ4kc+06xRYUgkCAMCStMgEdAmOZhdWg9YAZvWHgDGP1TdQ9Q2qKZRSKXmQY/cs+EgSZlOdYzSLvmlPZsml06U4JdPqpaSSjyE28kPQEkmDuJA07T3RWRZc0Y2d6Xg7hhqxhqOR+Gsk01N03oCQf/jPm/g2aqqsperqhpWvJ92nb0ZyGNd/jgpm20MSS4bE73EkCjK0g8BmcYS7qn0xk1JtmVkDnwdYTNDk0eVO0+NDNSI25sSM90hXu5TF0XCefyMeusWp1T7snHX601B7bx7UQPGH1T93VVkF03v1/2DJYokvIIff7huYMl84jYmZgmHEcNfYTCAHCBpmIdqNzKSpOE3HAeiIkscF8vm7oy0trUp34RQmoZpRNPAb0mn5bzDS6W8KgCp55Q0tEsamic+NCw9A8OypiMrXWFIQ4chnIyCA7XgQKuPPpWVlUhtTa3qMVxbX7e+KBB4wuXyPF9WVvlUbW1tj7rpxxjmK79uMrfcslYmwMTqh2mQMMUB4jj9uvpKWgy+THcSptqGtOwzESwKoOAnuSTn1CUFVqXj5dLdWYIyWyNTpqOAWdBYKFOd7XVMHdjQXeHUjh2fozj5SruM7BPT/6AXDX52hDRwDFV347eShlkC0phtMMcGLNKQKFwSqP8yhP0cG7MhWi/uA38kHN7L+YXbO7qkpaVVWlpbpK+vH+fwExC4FtQT5yuuL9GkscYrTq9DsumMpGFDR8Jp6YlkpTdKwnD6WX6fk9OvajC52Z7DmSb5aOqP8OsCZWWlarLBCQ31UlVdvSrgDzzvdDr/HgiEnpkyZcoOp2TdmzF8z/kNzuzyZmMyzF8PtEdvFkYDCw7F60N+YlsPudSRkYbGPGnqnGKCUMPDE1CoW6W1xS2ltVmpLMsrEhKGdYFNEiBNrlULa/t/skTTriOdxh1YtXcZmScO/ILha/6tIgpJ4kZCZo6YZrwqk02azqxkYZ6NJo1aR4pAy/RFYZoNN0p46jeEH6V1u1xq2llWbh7HT/xt3rxFmptbpKOjI9/L19I8NjgYi8n6kK2V7G124jPxmvy/I3DK24qKcotEExrMstLypUVFwWdBoieKi8tfnjBhQn/+0L0a6T/OjKYb034zZEgEmt+Piu4qMtRE5uxSOJjMSRbCqbIB5hk0kJQ7JAF73Qii3LwoGwg4jeoFZWc5rFiSMEwMAG32PmEcsmTcThz4DtXn3RFZ+b/7+nt+vFzzwluntiF5fKyMSG81z+jT9JqSgLYhSBrmI8HpmNlY1z6Qk3+an5Jk8XxJwdTCGaoCc5gvp511wawiCVLq8xA5Nfl5c/NWaWtrl87OTlU2ihi8qFryWaxt+U38O2rdgq3xbIzsUxeEAvX6pLKyQn3UtqG+PhsKhZ72+32P4rrPH3jgYa9bB78/5BZd68hNm6w6iGqOTEarvmiT2jEGkF04K5drTEo7TK4sCiu9MSllXl1c/KgTNAojna6+jJTY0TMQKu6sF69t3bJFm3nIImdhK8JgnUvOjLOl5gv6MU/9noeOR4yqQrsG84WmrZpjaIIiCaNjnM6VtY5XtBMVAX0ZkCLWklX5B2tJnLCL2Z7DQ9Ig1aaunKz0fUkyxbMlC6dHtbVwCd+FPgw1D7/wDCceZPIoAil24nrpVFp9gJZ+UCvMOX5JwNpvwSbOe74prqWOsZcK207iZTh/NL8MDS3E4QQDxaGiZz0e73NOp/HYAQccujp/6LvCbPnNcWD+tVCTB2iG4cfDWjtwffhuz0AIXaPXXPSRTR3VtmSJr2r1OTGZ5pQkNM0GGKiZZEbMNQmpKTbEX8mP2kKAbU0jD2ANYN0EcVJVTeIpbbYyiqQhYWhKvMU0M1vca3TvNftzMkh1w3GIbbViF5F64ajvaKn11ztC0DYMP9JEo3nGK9qJAmcQf+CzJDrZKwCbwJwMsovBNhe0Uw7rrd2mLJFzJFN5lGqoNKF+ciCLHS2zPmtHEmWUn+Lz+0CgoKrE1mczWPFwwZwm4aGw+nozE7/sTALSn9kZUPOMaJv3hKY0YW1tDQexSXVVZVcwGHwaGvL5XM7xBIi8eUefVo+t+eUSn8dxgKpYvBelCIF15k1fX/wvlfOuPMfauOeReOXXTcba/1ibm+qGEDOkN6fDEsjCJM5IbmVcJgR1KW10qe/YVHp0cYJYKX+JOBpNMYrg7Nh5TZIoLYN1EoeEGdRT+pbqg7WTnxjXH6zd6SqyI/Q/dv4Vzr7nb/UF06IX4VLUNjTT3Eg02ahpEsisDjjprVmJ079BRnK8uDeADOfx0DS9fTl5KXqcxGvO5NBjRRa79lp/8Zt/8yRSxAMZ2ODm8bjFHwxIEIlayNIs1EL0h3LC6Vw3b7H8oZ6enu200A5h3cpe7CTYUqFJsCgoNTU10tg4ARqpssvv8z/qdLqe1bTUk0cccVI7j3xp4beXz2wIzgpUhGCWwbzBeSrIMZyU3q4B6YwYz8xb8IOPbM5j856zm9LJ19fmpoE0IEgcZdWV0KUX1kJ4KCXxDQmpg5lcP9ktvv6MhGqckiquEP+UuGh+lhsuQolI2NoGBILwzGgbtQu0U3fuqwRjGfm3e//o/dunv6Z3Pvc/fiPJbmCWdkbiqIAIHUZImhScP2h4cdI0Q4YGijXxV+hW8C2Wk0h/Tp5qm5XtKv2UYX18iV8cxrl5R19n/zJGvhgBG1WdLQJxwjyr+4ylhWjGBTjsGb+tSqnOxYPxa87sktPc0qJIFOeMlDsk0S5QBofSBxuB+o1nxrOWFJdIZVWlIlFpSckm+EjPBKOvfWZaedZbVFUsus8FhYOzYYpmwwnp7Q1LV1R75uBzrv/ISJO4dUaT6Y8p0mTh5KdgfkUNTYaGNWhBXQYHszLUmxTXUFIaUEbTsD9Q6RJ93wbxBeHT8OUp9PilNfzPDEMD9aAWdBoX6gtWL7TuMr7xgUlDdD3y6a/l2p+9xaen+EEsKBhUeORbDKQZHAZp8IOEiSZFKup0KZ9kKGVkZEGCKEy3AVNebQm+ObTPf53V09P1qVwuuwA+zZFut9PgRHgWgWCyYalCyajoSmPYT4/tthaiT5SGGcd1j9cjfphQo7WQCjvn/1HzbN3ajLRVOhhQwDVGfCAbrAR5jFrNg/fNr3Kv+p/fYP1U1+Qan7e4uFjOPqRMZjc4pLi6GP4AbFqQxkzD9AzHpQ+k6QFpjrjgxo+OND+pbUpXGGvNJmgaFFIGxEnDDIubusTiGsw0gd8IayudhDCEoIpkZEbYlFL4eZVTB0Xj+9IUQ2oe3kcC3tjW4q7MRc5PPPNU/hbjHruFNETnQ5/8prP72Zs9BjIMv9mIyfFovRFTeuDTOGGu1TY5pKjW4AeGVehSQ8ZmBnMSC+ekJRJqn//VTXXW1UTuuOOXf4hEI59lBIu+jP0JQFuTcTpWuy2G2mLkRVBoIwRSfhBJlFYNnfSBqIXoi9haSP3DRampWqB9tmzZKltAokgk+hZTLk+Gt8AiBVesdesXf/C/RSq1XT1TVs4/pkEOmhaQkNI0buW7kTRpkKa/NyL9meBW/5SjDzj44BPZf2WPYwikMct0pWlS0DBZmNFZnyEZaM50zpBkihob+QXSmChkE1reAeFYNGRKVUlZqtiTWKanpSInrmYR/316eu5t+mm3QlzuPdhtpDE73vSHnzotCvtdaRoVQIGG6enHL47x38ephi87UIl0CNhIHJqI4Wj6OBxfE3O2ly1oHyHNnXfe9oNwZPDa+oYGVOCwdHZ0w2coSrkcri0wfZpIIJpArJi2GecAMSwC8bXy1RcPoios/B9+8pwEJKEY0iaJ6Ifwi2qWhrFIRAwNDoFAWxSBOju7FPFGtJB1aYsM1qpaf+tydCoPBKQU95veYMr86UEprgop84whdDbOZmCeDfRHZUOfIWHXVKkoZxtR0dNer/fvgUDxC/Pnz/9Ao0nN1XcExZ+bqWUz7McvubSxQXM6e7VJX0qoA/LoBmn0En1tdopLksgLE6TJsTcA8tZE3uagqbMmSJNEOYM0OsrPCfPbhxSKulYVL1i9b/5Sey12G2mIvrtntjrdPXVZkMSEIKdG4Dgbg18TZr1OcDwFzN0yTQ1fHsa+SQxftmWlrd05MPPrHWWomKrW3XXXby/r7u7+1cQpEyUJX2TrlhYpLiuNlwTLgg6HY0p/f+8ZkNwLwJtDHbDhSBiqIWoXmnL8TU0xUtEBVcVRgUma0STicSoih4odYEQu76CPkAPHt7a2KzOutbVNevtGK4EdkUWt8HFkYmmZuBxOaevvg8YNy0FT/XLiAVVSAk2jkTT0x/AM6TxpVrcl5LElPaqRl+HtutpaaZjQkC0OhZ4NBoPPg+DPpVLmi8cee+x2lf2dYG68vUq07G/wQCcjL+hGqkdmXuBZeY174F3+QJtyGTQDLIO7v3hiuv+Jx9OTXJKANUDCiB8+Jn0UB/KTCfllpiBEIJAMkMYBwnjjOfFHPGsDZ66YwevszditpGn/2/Rfpwf7LnGi3nNUpubEDViXUbNp4/L7jhloFynVpZ/DAXD3CSgYIyUyOCDiLG06evJnX3qO1/rzn+8+p7Oz/d6JkyeqSrthwyYJFhfJwQccFuBcYOqGwPPPP1+yceO6U6AJzkKlOBXaJ0QtxGqhZtUHgZQPxNA0nmM7CqkKbptyVjCBPpHbYzWs8qtj2yJySIoM1JAxkNgKa29FSkLqqkNYGXG9Iq9XaotCSuOu7eiQFK9LMiPNrHXIcXMrpSwfCGAQI53MSAqqd6A/huMT8uLqcJ707DtnVVI+T1VVpdTX1Ut9fV0yGCx6AtsWQ1w8c8ghR75qC5u3ouXl//lFXYXjK9veG8g/K0GCx5Ly++C+X/0Cf/ffeugZMbP54eQEl8TZmAyhJjDPxI08dFrJ4CTseCd2r2GgzMnJT1Cunj7HU75PrTlBXXgvxnZ5+UHR89ChX80YG38+XMRxMZxIPIcKhVLBXThRN9tpOFDNB0Kxu5oTlq4b5GEXm2GsJ3KV35ty8eqf8FoLF951QGtry5LJUyerPmLr1q4TLzRBXX3D/DNOPuOf6oZvAcfFLF36z0Pj8fgC0OMMVIlpzlFmHDULYfdJ26aESB5WIFRzSE5FNgYU6DdRC/nYLhRQQQVH3hdipbMJ19Pdo7r59HZ1SQjmS/fQkLT0s78crquIa/lX2WxGqoKmHL5PiZRVFonhdaHukTRpSUYSEkVa3ZGSjZ1p1Y3I7mxK0rL/HB9YreOZiotDNOFUG1FNTXUEBF8M7fQUrMjHFy1atPK666x+XX//v2/fVl9iXjp9SjXux+/9o8IDzA9G7aKDMWnuMx+Zfdr3z+T27l+ffmQs9uZz8XqnxEGGrAfHs9UfmsZA2RlYOqBtoGuEwpFNdC6UsXfYFM+g/4+eTy37nLrBXoyRarM78Prrrx52/bfOemFiRUbmzxE5YL4uRVNRObEvCds9wHEYGZho0CycXCMdhnSHWnegIngipvRGy//U+OW1n+G1Hn/88do1a5a3NTQ2qOjXunUbGMeVipKyY8899zPP8Jh3Ayqs9uhf/jKpOzz4SayfZZqZQ2nFMSDA+sceByQJpbjVQMoKmT9ZkYiEsE05i0A06WwtxMZVj9JCViXksfxqcjKZUMEEhrRbWltVYyuvReLwOrxveVCkqsyD93Kqe8ZhBw3H0tI7lJUBhmhBTIvYVrKejQ9nL8mfkYdVhCouKR4x52pqqvo9Hv9il8vxXKLtxdMqXQPHzZxUDk0ehD8JyUUy4znMWEoGeiPSk/Q/sv9p/6ZI03PHacf2J5Y+3QuzTKOMYYu/B/cFWXSUn4OkgQ/q1OHL4NXdEEjOOAiE544mD/np5AV37/K8c+MN23J+N+Cee+459corr/wbzRxWlIDXkBOP0GXB8SKzD9bhcFNgwe+AFoKwEjecHo0NniCPMZiTwUH/P2sv2jqf11q8+IHgsuVbw9XVVVJaViYbN2xUn5soLi6+4ILzP3ePuuEugLO5DA72L0gk4qeCLKejMvrdbqsvD5+VpGBFJIFYUQmrXloEGk0ivt9oX4hm3OiInCIJKiWPYT+5TZs2K1+orb1dBRTs6zFZsDQJzUe7PUr9zq/zMRRJ1PNwO5cWRi6RB6/JczkT57TZk6XWMyxNgZjMmATfqgSk8bBbhkWabDSpInZdw85fHvKpH32V56/7xexrMum+62MlhgzidwrWgg6SUG0ZsMUMdoFC4hTALmgeD6fcQipBWf5t8REidedNO//8U/bqka9W7dgN4Hcya2pqKrjOisVC5tDlh5425fIfGPKFL+ckvAb+QgSqPJwTdz+IM2SKCxpI1VHrSWbkrr1WrR1xxNkRXGeAFZSV0+GEBY0K4fZ4pqsjdxFnnHHGwGc/+/nfXnzxZedPnTqj2O8PnJJKZf47PpzclEyklNnlhP3I+sh7plIppRXwKgArr6H8DH4LRvVCCPjwLC51HL9/SU24GeTo7ra+hWlAKnj8Hqmtr5VDDztEzv7EArnk4i/LmWecLgfMm6v8E5fLCZ/JpZIT62yTcjjhx5C4tg+myJJPFmsUUeyEv2rFihJayVOC61TkZNnSZdKysU21pyRTWTXS1R7tmoBJyNGvw2oELJugLThT6UldKJNuaD32hNHZu7nMIa4al3hqPOKt8Yq/1iuBRmjKRpcEavHcfkOGU6YUBQZlaKhrt9WpsQqrFHYDfvzjH//jV7/61UmcpZKkURIvb1qwEjC8+/2vxOVzJ0LTxFHOKBinAakFKZXmrDUgUrhHl8SEL9Q1nnSj6nJy++2/WO0L+GbQbm/eulUG4CuUl1f+7NPnXnC1uuluwgN/e2Cfga6eM2BCwYzLHuyCXcMKrEwzVEJ+BJZaRL1PXvJvAyosNRCOUxE5EI1ai9Leblj1wxcjKZkX1FZ2p1TO6sKQNscNsZ8ceyxs03I7KhpuU0xRsEjDpbVSOqFIfKVu6ds6JJHumHqmOZOL5OhZIWmaCE1THFCahmakalCFD9XXF5XWVHU85Zl4H3y356c2/9cXetMbDu/GYwxAy6RRRgbKyOMzQG4KDFoMuni9KD8oLRfMND/ypBzHP/L0wXLwGd8tmjlz5ticqnQ34QOT5oEHHgj+/Oc/v3r16tXfGxoaon0yAha83aLPtpAvnZORay9DxcsXNm/OlOmBRIePw7mZO2XuGbMvfkrNgn/nnb9aBIl9zOSpU6W9rRUFPCDFZWX3XHjeZz+0b/tDY5a3tm49JZlOLgAJToZvEWSbDh+UJLLba2wzbvu6vc3sGh3SZhCA789e2sFgkeqpQDOM2cB2Gvo6PKanu1e1DbW1tam2IV5cXX7UPSx+WBk4mixF1X7p3tgv4S6QRZmRTFnZp8EL0pTINJs0qPhsX8mOIs3LG9OysiUhDQ0NyieqLk6J19kGbbRJhtPrJJ6J4Y4sSwPvYYAwMMmCmhQVIQU01eUwEDPl1gfP6Pr3H/3sHb8MYG7630bRjH1RAeAo5SKSyjbrM67cnN89brBdke8KFi5caNx8883faG1t/VY0Gh2ZYM+uUIRNFi5ZKU4/VpOffx+28SjSqD8DOcnAVIuBNFtjlVfN//qa/+auO+745W2ogpc2zWiS7q4u9TWwkvLy5y4498Kjuf/DBj8Y29nZeng8mTgH2uEkvNpkEohkMXMWIUy82zYCjfY38hVbVV4rgkbtwi4+dPK9Xq/yhZjUgDucSA7Yx6cSSWihZjXsgUEFanAGLayLWtcumxiSQKVXejcPSrgTFRvblcajhuQ9kedTKl1y2D7FMp0+TcgiDQnDBtUU+7uBNIvXDMsyEE718cM9ioqCam4Fkqihvg6/I3jmDmjC1bjmZhwTh+Ug2C4S9ON4FHdpb0b+9Y8HtcRT+s/uuusuVX42zK2/OEuy2g14xRlvr3LmEGySP0lWfq5PvXx5fuOYxvsmzWGHHRZEgYZp07OACGY4EwuPFYTb+ZuVirPyH7i/IXffCOfZ7gWbBzttmgMgTbcpa7q8SwaT5tFnXdcxfNddv70pFotePXV6kwwNDsCE6RR/UdEbX7zwS/Pyp+4x4J20Bx5YOGtwMPwJVMxTUCEPAoHyfeOggfC+rKQMb6twtjLjbBLlCYR8GQlp41iSjtqIPg0bVkMhaCGPV+UZi8Y+nlqLPRQ2bd6sGlgjmbAUNwYUWSIky6hrj5CG10eqC+XkgGlFMrWxTNxF/hHS8N5JkKavPyovruXUVwlVTna7EN+DgQg7qFBeXib19fXQRDVSXDwErdOMY9aI37tZ/FpCSntM+cxNNXhshxxx+BFH/ehHP3pevTTQ9up/tdZWekd6e6gHVvmyrR7kNK1bct45+sTPdeQ3jVm8b9J861vfCt53331hkoOSkuRhYuHxN7dblcgiDc2ayRMcct//aFLKcTS8iFWXVB80rdeUODL+jS05iTonP+2e94PPRyL9nx4cHLxp2oxpqkdya0u7hEpLIxee/1l+r+4jxUOLHiofau0/O5lKngppeYpuOHwqGgewXxzfn7BC3JYWsnKb      hk6+kuP97XYcVmJl+qGy0v+jtA8GoIWcHPZtmXK2FuK1OeCObUNsXO3vH8hrKu63jqFpRt/JqWdkvwanTKkPgTQ+MUiaFO+VlVQ0AT8xKS+uT0g6C/+SmiavbSytaSc+Ov9QIOjQQsVSWlqqem/XVJdLZWm3FMe3yM/u7Ydg65Jjjz3u4GuuueZV9ba5nH7vrZcNHDirpqi+vlwcLjhCVkZYwDX53PFYUoyKmdM9lSeuy+8Zsxj19LsGZsZ+++3XjUpdRlKQMPntamlrIBLIKkRTyko98tefZ6SmiNpIHaYqA+WqA1om2WfK65tz0paaINJ0uQkTZms6nZpUU1etJGdzc6t4g/7EYQceUdzU1DRmOgGyUXXZsjdOjCfjp+A9z4R0bnSBQMyLNPJBCQ/kEfPCrpCqDqqzyRz+H6WFGEwAgXgeQ9pFsIMYULA6rFL60zzcFtbmaFV7DgUGFOKJxEieU0uRQKVBQ1hfvRxlmaJvhvxOaTIIX0TN2gOTkY2pJO1o0vAp1fq2B1awV/lORdCQ7ME9dcpkqays5PzYL2HXo4ahPepODjZvXvF43+Qar0yfUCr+sqDo8OmozSgw8HCSHhxWsxK5qudNKJt2Sot15bGLUdmw6zjkkEOeh4l2BDOZJGEh0+bnEn6OWpJQBJfc98ebMzKlahtp+AQoJ/FEUMHg0yzdYsq6cL24Zl6M4z0qLMvPfbvdTonGYqrvU21lfTmnks1fYUwBRNH++te/zh6K9J2OSnsW3vMAB0NnJAYrOqO7qITKFELa3owjqIGspCJtyENlxkG70BRkRE711GYfOZ4PAvFkmlwkWiqZUsRhRI4k6u7pUeSxr8lE2KSwkm2O2e1D2xLLRy1HMHod4DWx4FZ1ZfwmyevgC7GNraaqMju86R9GU32RTIeJ6C2FX+Vzq/dmFI+zoyrSpJwy4ahr3nLxsYn3/ZCXXHLJlMcee2w9CgpCwyKNbZKwkLjNlqw2mPnXfT0lB06HpISQYSaTME6XJgGcmm7NyqpmU1Y7zhJf9RwVRHC73KoNg9dS5gOkIcj0Ash0V1FR8V0gbti6+tjEI488Ut3b33UWfIUvQgPMBoH8zBNqlXSGU45agQR2EuV2u4JaC1ZyLvK+Sj4ix2ACK78XEpu+ECU951GwugZZEjyVsgjEsDanwbKmw2qV4diwuvg2HowiifqZJ4tazS/V3zxG/bAJSNiro8nJ5HEZcsqcALRMsTRB03jZK0GRBseCMAx9JwdiEk67Y9NO+F7AusrYxnb5sTN46qlHGgcGoue0tbV98YYbbp5lF7SSiHnSkEB21MwGiUR86byUHHkAzQvcHErI49Wkyg/TAP4Mo2frWk3ZUvwF8Zc2qkpBbaMa/UgaViyYEbxu1kzTaf7qgjM/+Ut14XGAJUuW+FatXXZ8OpU5CyQ4EZnfyHfi+zB/mH+WsLGEw0hlVqWEDFP/rcrI41UnU/pC1EK4DrUQfSFr7oRtJOSYIpIIpq709fZJC8zc1rZWFdZmh1ZFl3xNsIlib9j2O498maq/I+vbno3akc9nJ7/HkGP3hWnWWCrTGkrFUxIQw8eeGNA0MC/NVFYSIM1gxtvS5znw1OOPP3WluugYxlty5J3xyCMPfS6Vin8+kUgej8zXWAg//elNIw1yIwWEAlQObX6dSxYwicRjfvhNkboaTTxu64tnxTkcBw0TA9/6+zRZmz5cMmWHKPOD7RlK04A0dp8x2ueqkJC8Xt91n1hw7rj8Lj0qlPbgg/fNGQwPnY2Kfyp8lHnsGscKzIpMH45vaRPIzl+CHZqt+motGb1TpMubaFxX3XughYIwlRigsK/Bi1JTsWyoiWwzjiYd/NORe7xjzeD9uLAeYPslEn0t1TMB5KF2DIA0R87wSlNjiUypLxV3MQjtzZMGz5EFaeL9MWmNemTtQDknKml1udyPw39b7Hbri4455pSteCbrJmMEO0WadevWuZcvfz1hEcLqYpJEeuXlV+XJJ59WGWbZ11YkhImFNzw8PFKItJUbqg35wTegNXDNSRMNCSEr+jdm1TdpNqenS49xkLiDVUpSsh2DPhB9Gg1VySoqgksNTq3rWZfX962zTjvrNWv7+MaTTz5Y1dbW84lMNnNq1sydBLJ4mKc0yajFlX+oHPY8gZQv9FYg71VlZZDA0kDURIzAKTMur4Vss5mmnPKb3hJQ4HxyLS0tI5bDW4G7kB/WGpY2cVjOXFdLJC6DXl0OnOJS/gxJ4wr5rf5vOJemWTaZkRg0zZvNKfnros0QkA4V2q5vqJdGDqGurFyP530CmvN5w3A9ddRRR33kUwfvFGmI++//86ZMJjuJ6yRCPB6XoaGwPL/4RXn1FX4K0uo2Y+9nIICZxvAkC4zaotiflC8v6JdDjkemdWRlsMWUTR0lsj59tGj++hGyeH00y9yoJNv8IZXJuB6jSw6n+9YLz//slfkdex3YqNrR0XpSPDFMDXQ25E21bcYRJBDX7XFCKt9RktsK0zqOxzCpKbDyAo+/rd4Jli/Entr2UAnCOhYaC5ZEe3uHIg/HDfXCrLNhP4e6/ijiMLGM7MRr+V2mzGl0KtNsEpIKe3udIBXuhefJJDIS6Y/KPzcn5Zk3OkaEggpIYOlBPaivr5PGiY2csFFKS0tWYf/zECp/93iKnpk/f/4enzp4p0nzyCMPfjKTSX0Xptk8nKbOoySiXfzcc4tl9eq1MjAwIBMnTZQIJJYVx29UoVJbCxE1/iWy/5wWSff5pblnloSN2TDDYIqhINWUtB43KsK2x2LmJxJxJT39INRwPCkev+/uz3368+P6cw07C1RE7YEH7p03ODh0Nsy2BTB59oHpgiw1lDTf1qjK9jCr8r9dC1kVmlyiyaQ0C4kB4UbtNaKFKNyUFrIqrq2FSLj4cFw2qbB2s+qtzamBeQ913fySZcUlBZtFGjyXmZKZMMengjCNdSXiAmkc7P/Ga5M08bSEoWleA2lWbh7EO1hakIl1Ri35DzfjbwpWaqFJqGf1dXVmUVHRUhzzLB7hCV13vXzYYYd96FMHb5+3O4Fnn31y3tDQ0OUgz6eRqUFuY0aFwxE1DDgStkLN9ouzcEekx6iMoORkVIwahb2FqYnyvAJo3mVg3sWg0eAzwYwgmUqKQzII7eb0eP5x0ecvPiV/8McKDz/8cF1/f9eCtJk9K5fNHmk4HD7mHWGZz9v3jWNiKW9f0BaJVEVnMIEEysCMxroXgouCjmFjNwSZ0mZ5EvE4mnH0hXp7e5Upx5lNqZFswti+jGq0RT3gMwWcKWmq9cik+mLxBL3igqZRcyPwviBNX19MXlqfkGSajcE2aUa3F1lLQv3OL4lQKKSmDZ7QOEEmNDRkfT7fK9i3SNfNJ53O4KsfdG6FHWH7vNwF0ITo6mp9Go75oWxHscGMisWGUeGhHZBx6sXtTMDLqwxBgdLBpa3N7TZ4PO1qXoPdbij1HA6nRTwcHwz4oc2GxO33rfvy5y56X0ME9ia8+eab/pUrl52YSMYXQICdiHpU53JT+EBLIA+phZinIwSCJrIr3TYo24r/R2khyx+iYKNkpxaiNrJ8IUsIUgvRhKN/yzA2xwtZQYVmCLahbQRizwQ8C58n4NHEBx8nyE94A4lkFsn6ejfrxMhnUfisfE7WHTyseuZ8YpVVi/xbWKvWO/E8WjgN8IXq62rpG6VgwdDn/Ru08FOJRHbpzs6t8G6w7vw+cc+f/nBLJBK+kvmuNAb9ELy8DWYWNQYzWL00M4OCbxRRCBJk6dJlsn7dBjVr/9y5c6B5tg33tU0OhqD7eqF9dX3dFV+58mNPmtFAJdUW3r/wwOFIeEEmmz0VFXZ/l8ups6Jb/dAYMcuqclBCCGlHZpz6m6/wVu8Ei0D8/XZfiNexyocE4lwJ9HUH+gdAnlblDzEqx6CRxc28NlK3ydcJVS+4tMgysk1pF/Ih/xtncMmNXNhQ297yFvYvXq+qukr5QtRG1dXVCbfbxTkonsb1Fx96aBZa6dgdRzveBdvfbRdx//0Lrx4aCt+kpAkSM6u9o5O2ppok3HohC8rOpfc3ChwazPnF6As9eP/D8G28MnPmdJk3b46aF8DqPGhlGnOK2ond5zXDGP7G177pz1+mgB2Aw8Xb27d+Er4gSJQ5ChUcrhAsAtRYNWSBRMD6CIGQv6xkqnaPgBXcShR8tvbiuWxopg80WgvxOtQYJEUykZQETGtqoa6uLtna3CJt0EbWTD4kAe/DcrUqIe9vJ5b1yHp+33ZL9Xfb75ENCtv9ULC38Bn5GZX6+lqYc41SXl4ecRiOJ0GgZzXNeB7+0E59CeLtd9gFPPS3+88M9w8+RBOAhKCzyGgah/eecMJxqi8SpRMzU4VB2f6AYxmKjsViyu7lizDK8uc/3ctckH1mzpB5B8yFWeBTmWJlDJcwH5DRrZBgaRTek/94+rQXXnjh79aTFPBueOKJJ0JdXe3HJ1PJsyHgTkFmVrDthnlrEYH93GjG0Qe1fAor7/MXsImEBSikypBJ+SR5LURfiKYce2pbvpBFRloK9IMSJNEwhWREmXH0gzhuaBiaaVs5WxVyZJ1Ltbptv43Rv7fbs/1hwNs2jGxhpJaROX4VLwDyNzZMLj3yyCPf88PGb7/iLuCpp/4+vaure40tjWiKvfTyy7JmzTqZN3d/mTVrX1UYNLVouunQFH2QNDTbrC4xlkom7rlnofKFZu27j8yZt78Uw8Hj41l5Yy2pxe7/y4PKbjacjl+3bG25jHsL2Hlce+21+qxZsw4cCvfdnM1mDqfJ7IJPyjKi4GMggaYWt6t2IZrIikT5Cygo9igCWVqITr/Vo0FpIQhCCr2iohC0kNUuRAKRkAQDCTTlqI0YyiaJOG6oExqJ1xtNmu1uO6ou5H/sEG8/x8aOz+EzVlaU33nQQYd99bzz3vsTIO98550AJIVv8eJFMWaaTZx/vv6GLFu6XCZNnihHHHEYcpbbVR5LdW21dHd2qgxjhmyTaJr85b4H1HzKM2ZMl4MPPlBNUTQ684gnnnxannziaRSwMxYMBK9Yvnz5b9WOAnYZd/zmttucTuNSlh19HS5ZSPwuKbUQy5KdS9nzg+tWpd8m6EgYq1Ss8rWWVrIbZLf5Qm41kykjcrQ8VCCI10JS2koFFNLKnLMCCi0qKjc4ODQiVEfqgvoLjKwQ2/3YDm/b85bz6CeXlBZ3/u///LImv/E9YT3R+wTsw2FkZJtd8fmCVHmMijEEzc69lC70RZxMKBDOzcyI2Ij0yUsyDgVmhlPSpfJhUzvhj0q1tbVyzNFHm1d+7cobC4T5YDBRoTmRCL8yx0rNxMgb/UwO9uvv60dZ5Idpw+xi2ZEIdPTZdYomF7VLLscyovCzyMQyZflzaATb3ZhomnPMz4YNG2X1qjWyBeY7/ZwoTDXOv8DJRIJFkPbVFTJ7ziw56eQT5XOfvRDpAjn88EOVI8/6okiJZ1dpZOWtP7bH6D1q78iKwKcplbKyYgqNXfoK3QciTR5quh67gjPzaYrRb2EmWskiBl+OUsyKuFgZbUdO6ExSCFC9M2Izmiz29Wl/Tpo8KdfV01mpNhbw/oHiUGF/VEYmkoIEYj6z8fIF+KbLly1TBGFDJiOcPI7Ds9lKz1JJYVsCJOK+DAiklNV2JIJQxD3YFYr1ggRi2xyJx646q1atVpNA0jxjMCgeH8Y1siCcQ0IlQWmY2CCHHnqwfOITC+Tii74kZ515uszeb5aUlZZuTyC+z8gP/HkPEvHhy0pLZMrUiahPjZAg2a1q507iA5MGmsS6IXMRiZKJURq20xAWOayMpAnggP1s/x4Zw4ElnUiukzQsBPxQ51vHWut+f2BrRXll6Q3X/+e/qA0FvG/oukMJLJaP0g5MIAV/c+5sDmSjj+mBkGPjswOCjr2k2T2KzjusLuG3gFhuPDeTSo0QyG5msKosyi5PInUfkgjXpFlEq4RRVfq5a0Ge5ctXyMaNG5UWYsAgmUAdQg31BTxSWl4iM/edIcefcJx8+tPnyZe++Hk59pijVLCJhKc2s2mi7jvyY7ut6nGoYabPmCqhooCEgiHUWa+ax3pn8YFJg4xuVhWbT4PnohRiYubRzCLsik91bkszmzBMBCUYnU+ShoSzyTYCXBs/nV//+tfH9PiZ8YJgMFCnLACl9VEOikBstDQVWWgmswzo4ygtBEFIK8EDAvl8EIzYFkM5cWCgmucAwpIhaFoZ1BbUUPRR6KvQbyHJqIVUrWVtUXXA6hmivqkKLUTykZT8ZhD94jWr10iLGs7dr7YrU86lSxG0EEfzHnDgAXL6GacqLXTuOZ+UA+cfIFWVleraNk2Y7BU+c2NDnTQ1TYY5iGd1edVsqCDzLg1o/MCkQYavz6+qh2VbC7tCUH1SDXObnfjSVM82IUYnjgVRx0BKkXA8RmHkzXkvvYKz4Fi/CvggMDTNv03TW+YyfyufElqD/gt2Kc2gEvwU+qL0g0gQDtvgPNlOrPMziJs2bZHenl5FFvqxFIIkAq/B8uQcD9zHiQttX2jEksJBfA7WGxJUmfhIFKDd3T2yZs1aWQEtRJ+IEzOGh4aUKcdGCA8IXFpRIlObpsiRRx8h5577KUWik048QTVfFOE5eAvWr6lTGqWuvloNzXYaLqXNmhn+7ui84dprv3sI82Vn8IFJ4/P5t1NtlBq0Yem3DA4MWoIlD0ocqmgWjg3FB2QYJxlnxrEthwXGZJNlG3LO6dMnTs3/KOADIMmwMvLbEmAWaahtmO+srBR6VlnBrKJvkjet6KOwYtv71H6sb9ywQbXPkUSMq8VUW1xckYKBBJKI9SKTSSl/lyQimailSCLLH2L0jU8HAvG6uBe1m08JYkO17TVvbQGBVioiselhgFoIlT8F05ETsxcVB6SyulzmzJutAgoXXvgZOebYo6BhamHiFcOXKVPTrjHU/dzzL6lgR3l5WXb2YQfsdDDgA5OmqKh0M95zpHordQsVzSWHDozsAU9YICqjkckkChMLjmDGUD0zAxnHp8R7OzRZt25jIQiwG8AKqoiiiLNN49AXsQQWv17HwWu2FrKT5fuQaHZvDfYpDKPi2tdw0mcBUWrqqo7IZeVT8XjyD9ForIdahlNUsZMl/RneYxhE4JBsEokNoKzEqmNoXhuxzGm2s24oLeR1K3+IwaIeaDZG45a+uVTWrV0rnZ2dqu8izXs1Pa/XJdF4FMK7X8oryxRh+GkTapeHH3lMOjq6VB097Kgj//1TJ3+q28qZ98YHJs28efMGkVH86owCM40ZQukzFB411AEHMH5vZ+xbQZvZBbJRyrHQ6Ey+FcxCZGW99auA3QGWh10mXKq8z2sha5gAybE9caxeA9Z5JA8LhudYZLKEIJc+l7fnkksu/+ull3zl853tPdVOwzgE5XpDJBpbHY0NZ3ldaiA2hBL0Wzh6lBWffpXSRJxHAESmT6QIRK0IK4bmovKxQCKGAHq6umTl0mVy5+2/l3++tgRaqEVdawiptLREmWTJZFo2bt4s//jHU8oNABGzMDWv+cw5n/mpeoCdxAcmDTJnyOvxRCk1KL2wQUXQKBXYr2w06GQyysHMHQEzA4kkow1M0qj0Nk3DlmIlnEZm8yzg/QNlVIEqmP9lgRXdFlosFjUhPLZt7/uww+eoaoNLqOPzZa9IxoICSiZXdakVgN/Lueiiy1+57JKvXnPFV67cp7y0aiaqw7cjkdjzAwNDOTZ4j3TDcblBwqT6TAnHZlFz0M+y6g/rAK9vEUgl/PI4dQkV+eSAuTOVxmEEjkMXqJF43UQ8KSuhlZ5+6jn1fCBcprSi7DN/ufcvN6gH3AV8YNIQMKneyK+qWq0aypxQjZAcbwVfggSxyWKDL0K/hpnPDGLhWdj+QPg822ZqLOB9A4So5ZLEschjVXTmu+odAHDkLE0vmzD2kj4OS4S/eRZ9VZYbfRYbPG7+lHceVXnhhReuv+KrV944bcr0U4JFRY+EhyIwsTao9hu2CzGgVFZepjqEMhbGMDh9Gi5puvN7ruQpk0Ug6/md9GtAPAhyK6wNQcw6989/vikvv/Sacg3cHnekuq72wvvvu/9eddIuYreQxjQzS/OrCiQMoytRaBq7AGxQKtl9kN4KNnDyeDuCsx2r8gDhVGEX8MGgpo8aBavKKQGYX0M5wlxW5MhXSjvRPFI0y//msAMu6cva2/DvPcO4jz12f0M2l1yia9qZ/fA76MsO9g1Ke2u7bFy/WdrbOgSmnPKtysrK1PzStGJIUo7mZTRO1SdqRKdXfURXDJf6nhHPoUXD4MVrS96QpctWKA0JMoUrK0pP+tNdf1qYf4xdxm4hDbJvY35FgeFCmmdJqFhKLkohu/rzN19kR+CIQWY4SfNWstlAJpXmVwv4AGBDJcvETgSruhXNyqpBYOwGNRojhEDlVOfkf9OfsUw4Tq9lXc/Mme9JGs1wXOZ2O2c2TqyX4447Wg48cK4a91IE/8OFOhSLx6Wzq1s2b9oqvX39qmsW60VRKCjlIAZn2yExlKbDs+sgjtvrB3nZs57+FeuZLitWrFLa0evztUydOu2khQvvf9l6gveH3aNp9NxaO7MIqka+DB04th4rkDhIjIxs59OMIGfF9bHGY+gIskBs8NpMMM/Uh6MKeP/gB7hQFNtsKcDOX/qSHLJBQlC4qSJgyvsRBMtFCTWcwHNoFdDkZk9pdTwu/k7WxGiYWasseT32PZwwaYLMnb+/lFeWS3Fpsbp4BH5NqCTUm0okr92yyZoppw0aqH9gAPfl3HceKa8oU84+zTE2rLI90PazVIdT1EOf39dSXVVzzO233/6KuvkHwG4hjd/tttpq8pnI4c/WyEtdRUJGg4VC0mwjBM9gUt1kVGFR2sXoD+GQkb35FafhaOLPAt4/jj2WoxXNt8X0Wck497SN7YQbyiJPGVWuI7YDFox0qqHs9FXzyGbS7zmROYo6mF/FVVnYDINrMK0cEh7kt0pNaZretCpUWnIUSLieJn8imZDBwQFVr9jVZwi+0OBgOGP1IjFUlCykelOzf1wO+4c42vT1uXPmHXn33XfvUsfMd8JuIU04nOpCBqAQkIN4cWa2GnmJTGT37tFgqI8vZ3Emn/F5BAI+VTDskk5to4qJh4w6LJlMOZYsWbKdlCxg12EJLTtzrQy2zWiGggk10nME+X1cxbk8lpdgYsdNdrexwWtrowj0ztBq7Hsr5K/b09kj/Dxj46TGp8pKKo686l+uWg1WVjHETJORFgkjYn6fT3Xjcbld95WVVM3SDcf3hmPxF8IRa0KWBHwkWDuv1NXWH3/zzTfvUqfMd8NuIc35558fR0Z15n8qaUFVyVg6Y+WjskWpTWbqdmHLPNi+o8ZYsIGTIcZRTqkNnOrt7OwcF3P+jlVQ6MD/cOd/5mGZz/hvEQJbVJRzO+RLEgua3jZUnzAlKDkOxz5fe8/GQk3X3syvWsifW1peakVfB8P/fskll6gpmeLxeDF7m7BO0SRjpNXu5+YvCrSde+65K7/4uS//5OKLLj+ioW5ircPhvMjj9t1QU1V/1O9+9zt+c3e3YbeQJo+RPmgEpQAzUrXVqMywtlsOPtXw2yWR6suEcxgsYDCAEzJYBbl9AvFg8BbwftHa2uqB4LJaFLeDNfBMlREF244CNkq7WBqBRcpE8wyblIayygjlnMu857Dh5i2trVFoBfYBozAlUrgWrQyv3ytTZ84YsRWLAoFp1GY0DUkWRvZIIMLl9GzXlevUU0/t+MLnvvybCy/43DU7MxJzV7HbSIOM2sDMssGX4ssx7GxlrTpGZSobOEcXCPdyn+oMiHPstgK7K419HhPR39/dqFYKeF/o7V1r5aXK+HziAkvmPVeoadh1ZcdAWahWRvzHki33FJBsm1H74Is49J0IBJg5P+/Z0dml2masgWt+NSMRyVFbUTsSlYVZHiBZGZW1voTtUKYat0Hz7FIv5Q+K3UYaqMl1ihDIRJJC9ROCGo0NW9+CVDnMv1jQr6HqV1vzu3gMM0CN        sYDUoXnGRilu3zb1jzqQ8wNMVBcr4H2BE8LY+TmSoFwoqFQeEygL+qX5YtsO5Es2XyYEQ74kDCU/r6EEXibbpna+C2Ai1rHMLTJYg+G8Hq/aB1OPqmekdRxCto5Mto9jj2tqNtYjyN/3vNfuxG4jjeFydWwrALYO02kzrDEVDGPm9xE0AVSrMo4bvZ0LtuCOmGeQYHZB2oVBUg6Ew6M91AJ2EcXFOZ2CzU5W/uc7aqICW6VBc4v6Bshv4GFsi1Eb8udQoLGHMctF1+CPoozok2ZSyREf952A6wfZq50mudX50xqoyOeB+d5lRfksQAhP4HYey6T8LUU4kaDXvUc/ObjbSOPU9Q3WC1svrT4yBGefBOC4GgtWASlNgxe3wfy3C45RERYe+yLxXG5/K3G0XG6mdWYB7w8lEFhW5VZ5ms9blovK57x/Qb/TJhX+j4DCbjTh2LXFbqOh1lFlnki95wdncXgNr0WrhOYYNQ6fg0RyeVyx/GEKEKIl3E+y8HhqG94by0w67dyjAxN3G2mKijxbSRi+NF/GejFrwBnDzlbG50mDTGUm27/xRy15LqMijJpRy7CrONdVRqIgmRipCQ+Gv3r9DT+595Zbbpmbv30Bu4CsN+tW3e9RDna+UkOwOwxNYq5TgDEKqsqIJ7GcuIaazvKgZlHkwToDATxKlS0shO37Dr4zcF9nGvdkXVCMQ7LJDK01YnI98MADtbqmKSmr+r7lNQ3vARMyDo00YsbtCew20pxwwoIuZGrEylBrCABNNGobds8eIQgyl6aX3VajyKLIZu1nDJ6ShtP/sIMe97FQWTAkEickTCSTrlQyeU46k3r2Zz/72U5PvVOAhcHWwUaaVOxKwxZzlgfzl+s2kVgehCoflKddfrY2sJNqHkC5wFBS/dnY+MgBZgM9PcdDqL1r7w34QPuQpCOaBtt4X4aRsW9EU7W3twfpv/DeyncCYXi86ongMHZpfP/uwG4hzZIlS0J//vOfb00m0z5KMGY6wUAAfZeBgUGVwXYBsJCYARRbVuazQKxC4DlK0+R7tfJaiiww8RieHAABWUiqBVqTwauuuuo9becCtuGGG24IDg30XsPGPybmLSsfCUTisPzYl8wqQ8vPUeRg+ZFI+G+VWV7743h2nETRosySEosOq9b6SDjy/d6ezvaf/PiHj9x8839+duHChdv5oezKg3J3Kq2SJwTrAwUmr+l2uyPWkYycxWp4DKUshTC1DH/z2d3uPRs5Iz4wae68884rFy9evH7NmtVXDA2FDWscuKWe2VWcjZVDyEQ7o0kQ2s6EJbUsIjHzmBg942/6NNaIPpAFSw6d7untVcTh6D9kalsup5+Ja1gisYD3xLXXXjtnaLDvzXgy+UmOs0fFVoKJecyADQUTy46VkWVkmXAWgexE4WZpI+6HdgLZeDwFoT0vN+dMo4AEB0AM8/REKvmH5q7m7SKeGzdu9BqGHrC1l3LsAZY9txkOfbPaADidRp3VGG4dqwgE8N4et2uPRs6ID0yaSCQSgFquoPrk0FH6LywIkocqm6qUnS8twjBDaDtb0osRE1vDMLFQ2FWiqalJzfbOQuCHVXt7+tR3aRiXDxUXh/2BwLcNwznt6quv3m5IQgE7BicjufGG6692OvTXNE2fzHzu7uqWnp4eVcFpPjOvOf6JxIkn4ooQ9syX7I9GEqVBIiX0uI+EwXZO20STmaThBPhhlL8TVgBNLprg7H8cZbODlkvmH0cBvmuQS0UaLO2uO8qfwoasmVPz6RGoU9YXsXGs0kr5dd7TG/Dttu4xO4sPTBr4Lb8E+x9Vdikc/wjUc3dPr5pRkRlLMqiReHhBS1qBIFgy42liWYSxJJplJmSkpLREjZ/gNKYce07Hr7SkJIbfPwn4g5O+863v3AjC2CG5At4Da9as+mYqk74J9r+D2p8RSuZzd1eP6jXc1dmtPtJEgUetUVJcoionBR9/s2eGVTbweVB2JJIiTN6EpvSPkHBY97k5hp+zrDolg4o9GAmbw/H4V791xbe2q9yx2GDe5LJ+29qD9YObQIoR8wzkU5EzmoaKNKg3KghBy8TtHX/m2Ve/+tWBf736X88AAQ70eD1PcCCZ0+mWaAzSB5lbU1srpaVl+M0x35bZRvJQtTIjlIpXEssqAEo8RtBCRSF+T4TjJlIlxcW3OUPuad///v/7HsjyoX8ebm9DR0dbVWdXp3CgFyNk7BfIWSo5yTzbVkiWjvYO6enuUYKMn+bjuBaOX2GPDjV7DLQPp6xlmSptRLMZ+3julMmTZdKECezqosqOLfYplDGskLCZNE+75aZb3vbZepDWZ0fnyBKbFPRpCFcuN2Keob5UcD8tE4s0MOthoSjo+vgzz2x85zvfWfJv3/m3k1xO16EBv+/xUCiUKSkplbq6evUhoMGBoRH1T/KkGE7Gi1Na8RsmQyigPmUqDKkRnDg/GwwG73GHfNO++93vX/79b37/PeP+BewYEEqPIF+f7erqynXDJOOXyjImyOP3qXEoFeUVEFLFqPRBmVBfr4YYsx2Ec46xTFh2tv9jaZdh9ZuT+A3B17R7HZMw/DJEFGUcDg9tSCfSh9xyyy3/yD/GdnA49HqabyQKWUMycNXuXWCazhFzzjAcjawrIxN9KNJY/o2W08Zn9Gw0rrnmmpf/7d++d3LA75zt8Xnv9vv8WZKAKr2nt1+ZbSQPNQq3hcPwW7CNEosDnYphGkDL3Oct8h2E61xwzTeu2eOZsrfhzjt/98zvf3/XMU3TZs6Dc39Lb1/fZo6IpOZJphJiqAnIA2o4Mb/GzfEoNLE4+R+/I8OJKnrgW7LsLL91UPlCMZRhAMfxWPYZTENLDITVTDJvOjTnYb/85S9X5x/hbYA+UX3JWPltIkDtKE3I4NE555wzYs5hXxnNeBU1M3As/tkaqrSodKenXtpdwG0/XNx0000zYIL9v2w2cy5sYge1DKxRSLiQ6tTZ1tKufBaO9oRftAgO/nXQWvxabwEfIi666AvHDA/HP4e8/7Tb7fKx4qsJUdi2BhONvgXH7LPdhdpFSXqnQyoqq5RlQNOtCBYEmwiolTg0mf4n1h+d2TTzgveaPviOO351vT/gv2ZgaACarkzKK8pxX4ds2rIV5mCs518u+9rI/HbXX/+jtU63s4nzSoeKQ7BCSlTXLE7TNHf2Ac7R3W32BD500tgAeRrg8l8LvXueaea89GsoMCA9BgzdWO5waD+86qpv8XuIBexBXHvttYF161YvwOrFDqfjSJDHoM/DqWdd7BQJDcAJ9uh7Kn8UEp9mEsnFoAJNqv4hzlUWycI0/+Htt93+Q3Xh98Af//i7u50u4zN9AwNSWVmuZp4RU1PzkuE+6y6/+Ksj31S94T9/3Auzr8wLUtOcDAaLJRyN0Afr/foVV1XiGZWRt6ewx0hjAzZuEVRrMV7UhJTqb29vz1x33XW7fcxDAbuOyy77wsRwNHERVi9wOZ2T6aNQk1hTcrmtjpXQQiQSnfg4tFAnfKRoJDoMsn3hjtvuuM+60nvj9jt+dW8w6D9nMDzEr5CpGWRIznUbNsAM05+69MtfOSF/qPz0hh/n+A0bkobkCgSKVIQ2ncm0Xfrlyxr2etIUMD5A8y0eT3xJM7RPuV1uP3ufk0BYUQ4/zbG2jg6aapvdDvdpv/vd79bkT90p/P73v1miO/QDaPrx0xclpaWSSqRl7Yb1vP4jX/78xWfyuBtv/NEk0RybGDnzMeoHgvl9QfWlNPhCz1x60eXHqgvuQez2QEABewcYPLj77j9/obS4oiwYKPpJJp3t6OrsNvmJx3aQhfMhQ8M8E4/G5+0qYYg4ex3A6R+Z8Qag6UezXXc4Rrr6OxzuajuyZoecCbYduT3ujySiWiBNAe+KW2+9NXnLLbd+7/jjTmxoqG/cNxFPXheLDfdFo9FfdrV3nfjggw/u8vh79jvzejyz6CORNNYsNnY/RFNchmOk13IkEitTpGGImf/YsJkzVS8FaKQ93rBJFEhTwE7hvPPOy15//fVr/vCHu35w2aVfOei6/3fdN5599tn3FbVitCuZTBiM0DGMTB+JUA2bjCQb2kiDpcfjmqRIAzKpcDOOZW8A9kzQdGNL/rA9igJpCthlHHTQQZtmzZr1voM3S5YsKYfiMGyH2p6ZiN1icvin645tPZzTmaAiito+qmET+9wOR4911J5FgTQF7HG8+eZLLhBAY+UnaHZRw9hdaECeUb5KrpGEYcdfEsYijUWuaDL+gaaXfb8okKaAPY6ysvqJDFmzBwBBn4ZrdmdNp+Yc6Xdm6Ead3RtAmXL4Zw8n8Rm+d/wqwYeJAmkK2OPo7Gylphnl3FuGmuWn6JL0JEd6E8CXqVC+D7bb5hkDCFxfsICjhfc8CqQpYI+juLhkCis9GKASI2LUOhwegu3Dtf7aEZ9GM4xp1CrWcSSXJqlUEmSSFuuIPY8CaQrY4xgY6IPioJllTVFMLlDrcIyPw+HI2n3J/va3v7nh33hJGu63iMYpahNss/lIws1EgTQF7HH4fP4mpV0A5duANSSG+szHqOmNly171pPLmR42eJI0ijFY8vMtOTPbah2151EgTQF7HByXw/qvtAz9FPxTw6g5nZNj2ziadDowl2RRHUUzHDidU0t+hqW3t7/kxhtv9OcP3aMokKaAPQ7wwEGVYs0oZGkaNl6qQIAmIw2Wf/zjH7/X3d3NEaBqKIAarpAfEvDMomcP37Jly0fy/dUCaQrY44CGmcI2GU6Cr7QN/pEQ1CJOl3OkC006nT76r395UP5090J55OG/q1G9TK+9skQNzf75z3++3Zcq9hQKpClgz0MXJ7UKJ2NhJ0yCQQGqIE03RkgDXyZF8wz/pXlri/zXzf8jN9xwk5pJpzhU/DgOoaOzx1EgTQF7HKDJJDr3dtsLaz57ODMYABK1W0eJzJw5c9LMmTPa+Ylzy7fJqqmk3G73Q8uWLTstf9geR4E0BexxaJrhpmYhYdSgNrBGjeQFQKORVv6DDz54aMrkSaH5B8yT+QfOk5raGpkwoUHOPvus17HbOuEjQIE0BXwEyDWycyZBbUNNQ3ON2gTbRz7kpEb0anIlZ7uprqqS+fPmyuz9ZnGKsO0+wb+nUSBNAXsUCxcuDHHJ8DH/Wq38edLgn8Pp6FUb8rj99t/85oQTTj5/8uRJP6yorP5RbV3DgTfccMMf87s/ElhPXEABewg33XRTUyDoWcvoWXFxkRrz73J6pbW9XTo7OmT/WXMDJ5988nbfphlrKGiaAvYoDCNXQllt9VSmtuEcZtb3iNjQ6XK5tpvzeSyiQJoC9ijC4XClNQk+5/kmaawvBfAzHelMun1Pz2H2flAgTQF7FB6PbypJwvm77c+vM5TMuaKz6axceumlzvyhYxYF0hSwx3Duuee6Xn/jjUv59QFOqs5ezewJwEky2Alz2dJltYtfWnxO/vAxiwJpCthjgL9y8AuLX5zx6KOPyYuLX1JfKiCB6M+8+tKr8sLzL0hFaUXBPCugABu6U6+mL7Nq1WpZu2a9/PWvD8kTjz8lzz23WNasXsNWz1xJScmK/OFjFtY32wooYA9gzuw5Q52dndOz2WwT22To12zauFnWrVuvAgH7zdr32kcf/dtf8oePWRTaaQrYo7j44osnaZq5aeXK1dLX36/IQhx22KEdZ5/9iYnnnXfemJ/Xu2CeFbBHMWfOnFDOzJlz5+4vhx5ykKjloQdLbW3tqvFAGKJAmgL2KK644oo33R7XKalU+rni4mKZ0NAgZWXlLYlE8if5Q8Y4RP4/c86DeLAqmJYAAAAASUVORK5CYII=" style="top: 97px; height: 162px; width: 205px; position: absolute; left: 138px"></img>
        <label id="lblMissedPick" style="width: 40px; height: 22px; left: 288px; position: absolute; top: 275px">0</label>
        <label id="lblMissedPlace" style="width: 38px; height: 22px; left: 289px; position: absolute; top: 294px">0</label>
        <label id="lbl1" style="text-align: right; width: 107px; height: 22px; left: 172px; position: absolute; top: 275px">Missed Pick :</label>
        <label id="lbl2" style="width: 107px; height: 22px; text-align: right; left: 173px; position: absolute; top: 294px">Missed Place :</label>
        <input id="nmbStepPick" style="width: 49px; height: 26px; top: 538px; position: absolute; left: 178px" type="number" value="0"></input>
        <label id="lbl4" style="text-align: right; height: 24px; width: 84px; top: 540px; position: absolute; left: 86px">Step Pick :</label>
        <label id="lbl5" style="text-align: right; width: 87px; height: 24px; top: 540px; position: absolute; left: 254px">Step Place :</label>
        <input id="nmbStepPlace" style="width: 49px; height: 26px; top: 539px; position: absolute; left: 348px" type="number" value="0"></input>
        <input id="nmbSpeedOUT" style="width: 49px; height: 26px; top: 573px; position: absolute; left: 348px" type="number" value="0"></input>
        <label id="lbl7" style="text-align: right; width: 91px; height: 24px; top: 574px; position: absolute; left: 250px">Speed OUT :</label>
        <label id="lbl6" style="text-align: right; height: 24px; width: 84px; top: 574px; position: absolute; left: 86px">Speed IN :</label>
        <input id="nmbSpeedIN" style="width: 49px; height: 26px; top: 573px; position: absolute; left: 178px" type="number" value="0"></input>
        <input id="nmbDistOutIN" style="width: 49px; height: 26px; top: 607px; position: absolute; left: 178px" type="number" value="0"></input>
        <label id="lbl8" style="text-align: right; height: 24px; width: 84px; top: 608px; position: absolute; left: 86px">DistOut IN :</label>
        <label id="lbl9" style="text-align: right; width: 105px; height: 24px; top: 608px; position: absolute; left: 236px">DistOut OUT :</label>
        <input id="nmbDistOUTOut" style="width: 49px; height: 26px; top: 607px; position: absolute; left: 348px" type="number" value="0"></input>
        <label id="lbl3" style="text-align: right; width: 158px; height: 22px; left: 122px; position: absolute; top: 316px">Average cycle time :</label>
        <label id="lblAvCT" style="width: 50px; height: 22px; left: 290px; position: absolute; top: 316px">0</label>
        <select size="2" style="left: 8px; position: absolute; top: 357px; width: 464px; height: 276px; text-align: left; font-family: Roboto Mono;" id="Timer0">
          <option>Option1</option>
          <option style="background-color: #00FFDD">Option2</option>
          <option>Option3</option>
          <option style="background-color: #00FFDD">Option4</option>
          <option>Option5</option>
          <option style="background-color: #00FFDD">Option6</option>
          <option>Option7</option>
          <option style="background-color: #00FFDD">Option8</option>
          <option>Option9</option>
          <option style="background-color: #00FFDD">Option10</option>
          <option>Option11</option>
          <option style="background-color: #00FFDD">Option12</option>
          <option>Option13</option>
          <option style="background-color: #00FFDD">Option14</option>
          <option>Option15</option>
          <option style="background-color: #00FFDD">Option16</option>
          <option>Option17</option>
          <option style="background-color: #00FFDD">Option18</option>
          <option>Option19</option>
          <option style="background-color: #00FFDD">Option20</option>
          <option>Option21</option>
          <option style="background-color: #00FFDD">Option22</option>
          <option>Option23</option>
          <option style="background-color: #00FFDD">Option24</option>
          <option>Option25</option>
          <option style="background-color: #00FFDD">Option26</option>
          <option>Option27</option>
          <option style="background-color: #00FFDD">Option28</option>
          <option>Option29</option>
          <option style="background-color: #00FFDD">Option30</option>
          <option>Option31</option>
          <option style="background-color: #00FFDD">Option32</option>
          <option>Option33</option>
          <option style="background-color: #00FFDD">Option34</option>
          <option>Option35</option>
          <option style="background-color: #00FFDD">Option36</option>
          <option>Option37</option>
          <option style="background-color: #00FFDD">Option38</option>
          <option>Option39</option>
          <option style="background-color: #00FFDD">Option40</option>
          <option>Option41</option>
          <option style="background-color: #00FFDD">Option42</option>
          <option>Option43</option>
          <option style="background-color: #00FFDD">Option44</option>
          <option>Option45</option>
          <option style="background-color: #00FFDD">Option46</option>
          <option>Option47</option>
          <option style="background-color: #00FFDD">Option48</option>
          <option>Option49</option>
        </select>
        <label style="text-align: center; width: 464px; height: 22px; left: 8px; position: absolute; top: 335px" id="lbl3_Copy1">Timestamps from current cycle:</label>
      </body>
    </html>
    """
  else:
    message = """<!DOCTYPE html SYSTEM "-//W3C//DTD VALHTML Strict//EN">
    <html xmlns="http://www.staubli.com/robotics/2016/03/valhtml">
      <head>
        <meta content="text/html; charset=UTF-8" http-equiv="Content-Type"></meta>
        <meta content="no-cache, no-store, must-revalidate" http-equiv="Cache-Control"></meta>
        <meta content="no-cache" http-equiv="Pragma"></meta>
        <meta content="0" http-equiv="Expires"></meta>
        <script src="/vendor/libs/stblUserPage.min.js" type="text/javascript"></script>
        <link href="/vendor/libs/up.min.v2.css" media="all" rel="stylesheet" type="text/css"></link>
        <meta content="8.10.3" name="src-version"></meta>
      </head>
      <body style="width: 480px; height: 690px; margin: 0">
        <img id="imgStaubli" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAM8AAAA2CAYAAABgHM2OAAAABGdBTUEAANcNO+1PKAAAACBjSFJNAACHCwAAjA8AAP1RAACBQAAAfXYAAOmQAAA85QAAGc0hrlxKAAAA3WlDQ1BJQ0MgUHJvZmlsZQAAKM9jYGB8wAAETECcm1dSFOTupBARGaXAfoGBEQjBIDG5uMA32C2EASf4dg2i9rIuA+mAs7ykoARIfwBikaKQIGegm1iAbL50CFsExE6CsFVA7CKgA4FsE5D6dAjbA8ROgrBjQOzkgiKgmYwFIPNTUouTgewGIDsB5DeItZ8DwW5mFDuTXFpUBnULI+NFBgZCfIQZ+fMZGCy+MDAwT0CIJU1lYNjexsAgcRshprKQgYG/lYFh29WS1IoSZM9D3AYGbPkFwNBnoCZgYAAAb3Y5PLWbw5MAAAAJcEhZcwAAFxAAABcQARhhEdsAABnESURBVHhe7Z0JnFTFmcBf1Tu6e3oOZwBFRdGNSsT1QE3i6m9VTNBIsm4QhQAOMAwz3XMfoOZYV9lcKMz0NHNfDAMSApp4xCBuTPBMYjCJxpNo2FVB5BgGmKO7X79XtV81NROGfkd3Tw/gb/vPr+n6qrvfvFevvq++qvqqHhJOMm1dXVcN9oemUkG4EiF0raYTQVHkGzVNkwTIZGARC/DZJ1pY+0B2yEE1FP4dFsUP0pyOT7xLF/3+2LdSpDi1nBTl8be0f51o+myE8AJd112gGMKQosQM+8mx31BRxDsERLc7ZeWFnCz3r+fMmaNHPkmR4iQyZspTs3mzi37WswBh/ACiwvk8O+mAPvVTSh/FEnoiO23KS3l504P8o5NCW9v6C3VBvz6s61mSiN/KmDTxzdyZM4/yj2NidWPjeWlS2nUa0SeENe3ldAW97/F4wvzjFKcpSVceqMhoTWP7bI3qPkTRJJ59UiAC3Y2x2E1DqHbZsoJDPHtM8DW2X0qIvgq093ZoSPFxLWkvQWTh8rLiZ7hsSkND22U6RuvAPZ0GrbHIswWEUZ8WJnfcW1X0As9KcRqSVOV5+OGODMWtdVEizOZZpwRQ4KDD6fzlmdnueWPh0jW3dS0YDIY6ofAcPGskiOkxvbG6vOhVnhOFb03rt6hAHocvDyvN8cA1qKCUt1gdI8WpBfP3UdPdvelSyRXefqoVhwFW3EmproyF4jS0rbtsIBhsMlUcBhUwNEQruRTF6vq2S0DBHjNTHAZcgwJvPzgmpTgdSYryNDWtP/PwQP/LSEDX8KxTCljtvsws93e5mFTCIfV+LKBMLpoC53A5T0YhCuQ/4XOJi6YgLE7nyRSnIaNWnvXrn3MHtIEndE0fx7MS50QnMlGnktL2RfPmvcelpEIo+TZPWhIZUTRg69atDkLoTC5aAgp2hCdTnIaMWnkO9O5aBi3O9VyMG6hjQYrQU+DA/CAUVmdA9YQXmqFpZIYoylUUCT5QotcEjEKxjG5TKvQTRXiYi0mHkNg8QRGLL/LkCHoCgQkY42wuWgJl8zJPpjgNSdS2R2hft/Gao0eP7gDlifs4VKB/F0XpR737d29YsWKFxrNNefDBB/HESRfcGAiEbkIYLaCEXsw/GgFTtmVl3mouJp0af/N70Kp8kYuGwLVpcG3XVJYU/JVnjaBmTdPfkIANz38YJBCHolxX4lmyg+ekOM0YlfL4Gto2UkLmczFmoPI9de5Z2bMT7dCDO4Pq69umUAndB+7inXDELJZPBBrIckkXFhQU7It8cQyorW9ZCtrRzsUo4NzCRNDvubeidAvPiqKmviUPUWEtF40Az46ULq8obuZyitOQhN22rq4tE4muz+VizIDr9dxoFIcBykfLyz3vVxQXLnFPHDcZSwjcNNonSbh5LBWHceTg3rVIxDWsZeBZ/wAJH0mKMt9KcRjLSj3rsIRXM0XjWcNAq7pPEqU7Uopz+pNwy1Pb2OYVdBLXDQZ3Jiw7xSnlhYX/w7OSRkdHRwZCGc78/LkHeNaY0rJhw9l9Pf2zXC7lxmBI/bMsyjvOnpD5KhgFlX/Flu5Nmy45sL/3ZofTcYsaDr/tUpQdLvnCF092lESKxEhYeXz1rY+B5byLi7GBhD9Vl3mv5VKKFJ9rEnLbWOedUnIFF2MGOvmf8GSKFJ97ElKenJwcGSF8CRdjBov4Qp5MkeJzT0Jum9/vd+jIEbdfTgVBy85Jv3rJPfe8xbNGhc/nOyMsyI8ihGxn65MBRmLdsgrvNi4O09jefenAQL8v3sIUMX6jurzoO1y0JNLHOtTfxUVDkEB3L68oXspFU9Zu2nTewX2H2sEA8hwDKBFkxbG8snjp2zxnmFV1jfkCwndzMWEwQgLG6G9E01+ckJO+beHChQP8I0u2bNmifLT3wM+gQqXxLENESe6oLi18nIsxU7um5Xs6pTdycQSYq4wooY8TVh4iOoPghvGc2EEYv1hVWngzF0dFQ0tnuaqG/VwcawaP9OzNWLFixYhRNjZs7mto/R3cyOt4Vuwg9JvqMs/XuGRJffPainBYreOiIWwUsKqkcDkXTamtbymD813DRWOQcGDSWTlnG42KQn93H1z3mVxMCkSgByQR3V9Z4rU0EIzaNe03CIL+ChcNgeOFqETPv7e4eD/PionW1ta0vhDZA0pyBs8yBtHKhNy2ioqKENHJn7gYF5SQmx6pazINmoyHkKrGFCqTDDDGPz1RcRhgpb6TkOIANMZoBUZYs75WNjGb7U5fz0VTmLIDeVw0RRTFJ40UB5R4Bkmy4jCgsk6A4ljb2Nr5EM8yhVBtFk+aAq3ajngVh6Fhaa6t4sDX3EraEwnP88iK9CZPxo2E8f2r/A0Pd3Vtd/KsuGnuXH8lqP+/cHFMibSvCNVHhONY5W+eChXxh1yMm+iJImNqmpvPhVb+S1w04y+LF883jGg4Hn9b23mE0GlcNIRdL3yn6Zg0EjUcvivhIdoYCKnhB8D6Rya9jdiwYWsmeHteLlqxgb/HhRrSbQ0y9N13eDyLPk5YecBdauDJhBCRdF9v/85tnRs3/hPPiovBwcHZY3kTT+CFE0NtGhoa0mUJPwfJhMswVkQqLQElNV2+wMAIP8GTlmgqmWNXbmC1d4Fr/QYXh2FBraBWd3BxbKACPjyofZ1LURzu+/RmJCA3Fw2B1jXoFDMe42LM1Nd3j9OJfhMXTdGJFnF5E77x0DH9C5zk01xMDCrcdLjn6Cv+lvZ/Y+4Ez7WFDZUDFZG+m9krmSASZSg05FhJdDqqlbKKJFnHt3HARc7lSUOgpaDjslydXDRl+/bt0K2AcrMByvbnPDmC/93zGRgsNJGLhjhdjoqQRr5w/Iuo4SnuzPRqOE/b1bUMtzvN1KNQdc22ZRAl8Y/FxQt6uRgzKg3cDi6b+TotANzjQZzuigwajaqa+XxNU6iIWej/6KrrsV83uBV0v8fjGYxIFrBO3YEjg5ZD5YrTMV6kaJudxQaVfVXTta1cjAIRgUw+d4J/7ty5AZ4V6bBSQXsBKpLhKB8YAtWd7u4aGBj0WBUMlkRaWVxgacBqG9oug77RW1bBt/D3nl1WUWS7zMHf1DFN07Q/W50TVA7BgeULSkuXfsSzhvE1tj5JdfrvXDSit7rcm8PThtQ1tu4Eo2N97xzyw6We/KhRSBZFcmQg3Gt3TxHG86Hl3MTFmIFz+wuc21VcNARctm2VJYW3s/ToKj3ga2hbTAmxHSGJBajIH0gOx8KKwrw/8KyE8TW2zKW68DMumiJScnUFtKJctKWmpsaFZPdOSJ53LCcauHlN4yeMe37/vv2/gErPc6OBSkCryjzWyrOm5cfwZrmwD/5eIVQW02DVIVb7m38ALtl/cNEQhIU/V5V6oxY1MoM1EKKsA27hMtGu6vKiJVwwpKGlcyO4/JbBxNAX/Pbycu9mLg4Dyr9E1zTLFhZat96jGY5zVuTlxTWV0tDRMTk0GN4F98vyflAq3LKswrudpUftr8NNWycrsmHnMl4QFS7Wg6Hf1za23sezEgYKwXZECfgwHsWJILtr4H9TxQGN+CBNppWqFrQdUIEWg6fMgfamgCfNCMDfW8fTpkDll0FxCrloCpSboSEMhOid8GbZ1xAVyTIglhEKhyfzpCkTJuYY781Hie09RRi9EK/iMLQgnWerOILQIwmh33ExOZ3dMm9+qSJLjVwcPTp9uK6hdZvVqIsV9d3Q8dPJV7loCrQJT/JkTDS1dt0NvyniYhRQuCFFduWybaMO9Pf3RP6CBcRGeZra1t4GXxnPRUPgdv82lm2qVILZ3JrdELOWlpVmWCa6QC0j6IlAD1V4C9gAiin+pvZrwGLcwEVDCCHbFs2Z8zEXh2no6pqoabrlbxnQp0vIC9KJPocnTQFD9jibpuFi0kaKaIk3v0yn9G6oL7YL22KBEHpbX5D8duXK+BUodKTvVrAillEHbF4kK8d+XmQItk/DYDDk46Ihkox9pd6Fr3HRHhvlCQRV28BbSVJ+ypOW6ERYxJOmUESfLszN3c3FYVq7u8+H8vwGF42hlI32mV5Qfcvay4lOnoHj8BxjnE6X4aR38Gjgm+DmWv9YQL1OiURFgNjR0b2RDVBYDt8zXE73iG5AspQn4r/fW1H0uE7olVA+UZYjEcDNuFp2ku0rV66MS4EkUbEdUQL+FE+YUFAb9GEknMtFI14r9xZ8j6cj2NzpyBdYqAmXRrB582YXVEjLYWEwAAdLPXm2HWM2rK7r2re4aIooyoZ9xEB/kE1KWl6OKEquR+qa5rPXT2rqh1+1a5qrfPWtv1JDITY6azlSB32dn5R68wwrvyiKZTxpiiiiZxPZLLK/b+BO23uFhd1fmnbpiG3AkqY8Q4ACvSuS0CWiaDzcGS/gw06T07K2x+rCNTd3XaBr+pe5aApGYkzzIozahjbWAph3cqG1xTLNZQaE5wjZ8A/OnUvGgBVGhIiGI0/7evtnw/Es3SyE8Nbj/6YZQYpvgL9l2V+BkxkYl3GOodsFLvACnjSFrSiWMN7IXg5ZHn7BgWtBaWbCeZqOkIERUDEWv7u83DvC+AzR1LFhCrhztlH8hBLrkCMT4Ni2cXqUCN3XXnvtCMVMuvIwmF9YUVJ4lyLLc6HgPuXZCQM3flq/SpvhWLYGIqCrs+BG2X2POrKcMfnG/ra2SUiglrPVSMTfqywq+oCLEbKzWeW2OQ34uC8waNin0cOarQ/ukBXbDjpDQlIJT1qAfp6bG71N8Nq1j7IttK4+JiUX5jqDq7gZS/IVlaUFpiFbwcGBOXbuHhxrd2WJ549cjJna+ha2vsx2ECMjMzOqhR8T5RmitCh/i0t2M19y1K0Q2Nd5/uZONuJjDRVsrSRYqGeLFy60jXtik4pEFdZTQk3DiEA/dlQVF67i4jDp6elBsGgHuWgCEoLB6IGhVatWuaEyWAeMYnS4xJv3Ky6Z0tm5eYKu65F5CSsoNt5T4WggUnEt51USAQzLh06X65plZUXfripeyob+DWET4vC28JhkDsb4GTimbSt8IiLGpTxpiijhDwsWzXuXi8OMqfIwiosX7q8u994FV3cP1JWYlygbQYjG5jxMWdXQMJlSYrvxIhR0TC7bm+9+mAvuiOnGg9ASHszOyDQcPp05c2ZIJ3oPFw1htjSoRY+vYEf6bDACLi6aYbWByDCHB3tnQKWyHDwBA3DwvAnZhsPDhAj38GRSgbK7KBQM7mhq6TQdvWScceaZU0AjLuKiKRijbp6MGebJaIRYTfpGUFW9yUgx7dybpLLS75/kkJwvUZ0mvChOcTluLy0w7lQ2NHf41LBWyUUzAkd69mbabXfFFBET8X2wuqatDhT+PmhdjLeGQoIsidJt8B2eYUxID0//blXZiA3dfQ1tfwSlNQ0EhWNSSVH+uaIoP8oankhtfevz8APrYXtRaK4u8RZzaZj6lo5rw6pmufUVXN0OMFiR5QEI/8MWw/lDhRYvhVP9GlQyS+Vl7j3zUrg4An9LR4euavlcNAT6lnuqSj1xh0qtae34lhbSrA0pnHya7D7H683dy3OGGfOW53i+U1Gx+/DUSy6BCvdLnhU34UDIsCJs2bJFBMWxDVWHG/y8neJEJhSJuN5KcRhgjc4SRfGbhi8s2ioOuzHaCS1PV9emC6DiWe7zgCVxVyyK4/d3ToCKbbtlryQ5DDvaaihsW55pLvd9yyuKq9mL7Zc39GJydZnndklW7oJysBwBU7Uwm3iOwr91q0NXw7YtA9FpVMR7LMD12Q4UIIRfNFIcxklVHsaK6dO1114dPwt8+td5VlxQZLx2Zu/Bo1dAVbXt+FEeEWuFKkgPgeIYriRMNlnpmWfzZIS+4ACbzLT0CIhOYnI7kUwL4Dos7zGU2TvlnryoPgcbQgclXcZFM94rKsg13Bl1iIqiJU9BBbR+mh8VJq2qa4xqaemuTyAPWU4SE9BMhyjG3adubd2ShSiy7QtKormLf9KVh/HYY3N02YFz4cbZmOZodHAHjCBUW2Dvg9KD1eXFv+GCIU0d3dPUkHo/F8ccWZGm8mQEQnTbrYtlRf6MJ01hraeu67brXrAo/ALeou7DvoP906lOLCOMwS8z/O2JQEv6Dk+aku7OiBogAcWw7W9B//Wd0tKCD7kYM0H9yN3Q17Pc9hgMfFjBumno2SlRHka5x/M+2MS4Z4ONYBWFaHQeF03BImYh8aY3m7l+gcHAhrEYXTIEzkRVTxhDQegcnjLHxIAcT4jgKjDK5jF4AFQOkpOTZTjJGtZVO5eNOLFm6G4dT6QFE0Xbx86I4shx/dYtW7Lg/C2XYjBEjG2Df43QdfsN+6EePG016XrKlIehh7WkKA/Fyleh/2Fb6VxOh+W8yCf7eh6AO3gZF08K+gl9HkVRvsKTpkCLMhMqlmlDu9rfeD109B/kogXoJaOnSbBjw8t6G2WEXikuLrZdM7PvUP886HfZLtvu6+9/nicjBPcfngGV13KDD0BzO1yP8nTM1NS050BraOuWS7L1RP8pVR5JUuLeABE644d5chhV02zjtgh40J78xc9yMYqaNc1Xws2yrnBIaNCI9lBsL/IQuBSm8xfDnNCIDAwM2vZnKBVuqW1o7fB1dY1Ya1/XvPbiVf6mOozFV8GY2FU8sNo0an6K0djSOR/KIoOLhiCMLJcGsPCi2vqmRWFVtV0qAYq6f1l50YgJTrhf9rF4gvDK0qX3RK07skNyogIoH5mLhkCrfHDiFy+2HNiKsl5+/4bMiorcuB5ImwjPPfec++2du/4ON+ksnhUbGP9XdWnhcCVncVshIu2BC7F84JTVzjJdTzxxxuE9B94Ea2T64GEsovbKEo9tSP/xrPY3P4IRupeLhmhE/+F9lSUPcJEtOPs+1WlM+yIw/1OSxD5N1/8K7ssN0CIxV+PYhzZAu/Xfy8q8bLlzlBtb29DyONRea1cLCW8QnRhONMM5TdYJnRLbmQAibq0uKRzunzU1NWUPamiv3apOaP12KrJsqzySLAqeJQu/PjRX46tveRsMkKWHAcrTBgrt4aIhI1qejo4nMzQ08HptfYufzUzz7DHh3Z272JLe+BQHUGTx1zwZQUXS9XaKAxCHA5tawN7d+35spThgGd8HxbEsSCMSataR+Dj8vZiCG1nl1DU9A6rEDVCRY1YcYCDrDHc5vEcpDvRR0iE3lkiOq6BlvdXoReJQHLaUASsjW3wipi22VRwGpVOgz3ir3WtgIHB0SHHWtHZ90U5xGGkup23A7Yj7OxA6UAoXfTEUTHlvf8+boESF0Bm3bf7jpaVlw9mExv8AKnAV+g58+vHwYqQIuhDDNkr478VLjUNAapvabqGEmo5KgQXSHQ5lcSQZJ6JkvxejLEkjIrVZqArCQtQqymQBitmvaeptS3NzDctj996Ds+BKY9bC0QDnoiuyUlV5wpMt4PzifvqGFaL0jyDgsBqJELcGC/u8SxdbDsEzhpWHuWvQ7H+fi2w3lrOhEFv7Q+SDVXUt3qamjTE9zcyOLvDT+4J9G8ESWIanG4PWHr93GmsdoXLbWkmdEMM1ImzHUUGnm+BcTCuLLMmPlHrzY1+jcxyK09KtjiBJ0hSeHOZIurOAUPISF5MGwvggxujW+6rLDZ+wDZUZUYRtYwOTxAAYw/zyovwRa6pYIC60psl7GABGoXPGZ0WMEYtVBH/VdvgbiqFzqKWyYlh5qDTAnrwcFbYOrsA5IhaaA9rRT6Elampu77o5stYkTliAX+2atn/t7Q+9D/55Ig+q1WSHc8QuNgNq/x1wfobrYYaACqE6xbSobYggHxPRWQMJ05EgUMxXJo7PHO6PxMvRo4OWu1oyNC1640O2jFgWwrfCDbSck4qDPqioLemOrClVZV7TCcuWdesmgxm5jYtjRQBL4q9cbveXq8u8UfFomkruhOtO2lQBuONdQ5s3vvO3XdeBlRwxr2YASZMU20EORsTi1tW1nk8wZc/MiclNB7fiEFzg00Sjv8gcl/7XgZ6ez45fnjrEgw9SfNYXNoxXjwRugopYBr7mv/KP4gaL4obKkoIR0bW+htZfEovATQbG4utG2/s2d66bFQyErJYahIhIrlhWVLSHy3GzcnX9DIdTsRk9o69VlXpNY89qG1tuxQJeqen61Jj6ARwo7wFwG98kut51BGk/W1Fa2s8/MqWuuaOY6vojXEwK0AcKh7Xwy9CC90oS/o2CyDMFBQWH+MdR1Ld0vAEGxTYQNFZEh3JbeUFepKX1N3f+SCB6hVWTAvV6Z0VxQUxPdY8oj6+xdTPVqe36ESPgJjF3oAf6DXtcTocQCAS2y7JyPhz5C1BqLrBkrA81Wj5xO9DlHo/n/+3Todvb23P6A+Qrmq5dJTvli6CnfT4LncNQwEjEg4OBwT9Aiy64nK59VFV3lJV5k7KZfgpz0Jr2rhvCgdArJ6WHmABQP0KyQ55V7sk3naNJkeJUgLVAiM2qn5ZAE8pm3D0pxUlxOoKRKFYRgTwF7tfonaskAucTBDckt8y7JO5FTilSnAyGGx1fY+OlRMMrIecbzIvm2acESulHisvhKStcYrkPWIoUp5Ioj625c8PUUHDwXl2n7FES6Tz7pMAeSCSJeFNWmlKUl8CujylSnExMuztsU+2+QW0mQcISgdDp0P+wn/FLHBXctEepSB5aXlKSeuhvis8FMY0VsOdhBnoHbkRYmE8ouokSkgnKFNNvzQBlUUVRfANS3e7sjJ8XzJ8/IkQjRYrTnYQUgLl24WDw8qCmXuRQlFvCqsYiaacSnRiG3GAR79U1/T1JFg8QSt8Skfz77Az59dzcsY/eTpFibBCE/wNQFVdPPrszFAAAAABJRU5ErkJggg==" style="top: 8px; position: absolute; left: 8px; width: 205px; height: 54px"></img>
        <img id="imgVC" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJAAAABICAYAAAAZK3z6AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAABlSSURBVHhe7ZwJXFPH1sBvVrISwhJ2kKUgogKKgKKoKC6IOypaXlurT3zaz/peraXt81mqdrG2VevysKW1VaiKS7Va9eFarVotFRErO4R9CUsSSEK2+2aGm5hAghvf7/uq99/fdGbOjMnNnXPPOTN3BoyEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEBEIj8meSQ4cOCQYM8IsLDBwYMHv2TOdLly5VEU0k/QRFdVRUiWkV3kTdIjiNpaIxXScxp9+9QoiM4GVvCVS3v2yi6NVMQmQEx3HwDRSMYh/xFmvihc2EuBfR0eMq5fIObycHh4zzF88uJcRmLF/+P1G/3vj1ul6PY6OiR4bs3r09f8H8ZGVhYSEraNDA9w4c2J9GdMWWLVsmKCmp3CGXyZM1Gg0hxTA2m43xeLzDA4MCt+7YsfUXKBs9evxw0O83FouFTZk6zS8t7e1y1JkgLCzMTa+j1cLynfzfKEjYg+hRYxs6OjqdYTlq5PDI9PT0m6jBhDfeSF12LudcOpPJxG79ds3i5/wZoeJ0ofHGW4OiU7H06sav8Ytj6YTICMXvYymF5fIBUe0FTmGXFJRJPyeqFuFxOIdh3qXuWogEFqiqqk7U6fWYnZ2gGCoPEhLDABTVOCAJCQmc0hJxWWtLazLQNYWjk9NPNizWe+7ublf0er2kubk5sbi4ZAewTv1ifZcuXR5rUB5IeXm11d/wLEJluY09iNO4eUTdOjqFf1dHw1qiZsYJRfBGjM5rJKoPANaHynV/Jzwl94EZsICnt9dhKpWKyeQdnCVLUuIJsRkdHR2JMBfa2yFlM4VCoQBT1w2DwX6jpaXFgUqjqeLiYqedP3962s2bV9N+On0iJjQs2C14cNAHkZERq+bPn68j/slTIRZXoesKDx+O6pouNao/L1Ap4XsUGNdjLQ6MEY51j4NxNEyAbbiyfpXi/Jxe7m7+/GwdjUJ/2WgSCCh0wRVWfF6vAe+Ju7tzHofNaYDl2tq6BUhowmuv/T1CKpV6MxgMbNiwEXsJsUXAj3gFXr+Li6j14483XeqWdrNnzx5NVta+dzdsWN/LFT8JwFUxOjsUixkMJrZiZQpQXgYm7+jwWLF0RTDR5ZmHCv/HnpKbQ+W4/QdEK0hoyUHDNgqmd6ZKf11PiMygzxp5DrdxNFoyoJAKnW3oGqLaJ2lpaSpHB2EmLEvb2+O3bdtmgxoISkpKFsJ4SmgnKFi3bm0pITZquqkL0+m06Prb22T81NQPhd3S/x1yci6OUXR2sjw93bGQkKHYwIGBmFarxSpqayzGcc8iSIEgOkyYgtE4RI2wOD3+Q3Kd4hX1pWljUMUECiVbR6FjC3AKFbkGio3DQe7EU72CSWu4OosO0YAbU6m6HMuLyiMJMQIEwkuhUrBZrC9M3RVGFE1lIEjNgrlC0cm/euVsQcLU2Su3bt05FDX2M+3t0kXwvkSPHoXRaDQsdsJ4JO/s6EyYN69njNUvHvP/HUYF4iRcF4ORsBjjmELBNRS95Nd1wCD0MlSsaRXFVI7HcZzKarWxDX7oZ5mSnpF+UygUtoJAFyutFL9CiLGXX14SDQJiHo1GV/Bs2UcJsVX8/QdssXewz4VlMLNzq66t3rHvu+/ujB8XVzRn1vxNcIaGOj4l69ev5wBrOROWx48fi2QxMaMxKpUC4zV/f//bz4UbMyoQRE71+zdG57cRVevou+JUOaOWEzUzmLq2v9B5bi9Txp+UEKJHRmDHz4B5W1vbFDBAaMZXB2Ii6L5s+fyb33//vcXPNHVhH3/8sTQpaW5MQGDAa/b29vdhXKLV6rDW1raAsvLyd/Lz/igaO3aSP9H9iSkoKIwAltERfAcWGhqCZL6+Ppi3tzdwozrs9u17LyHhM46ZAjnNuibX01gpRLUPgPmRF71FVMygzKhXMKbknySqj0VkZDgKuBUKhatCoR4DlIjV2dk5D8psbXlWg3EztwZISUlRZGdn7YwZO3IwlxfADho08HUHR4di2KZUqZx1WvVVYIkYqPMT0twoSQR6jQ0aNBArLirBCu8XYUWFxSgOgqiUyudiNmamQBDOzIpsnCHsXmfpC12Xt/K4v9XFwSchNTX1pouLixhanPv3C1+srW0MVSpVLnCRL3bi2IfO5noCgnP95cvfqg4c2L/9woWzgUJ74W4oB67N2d7eeTHq9IRotBqkIFevXsOSkpKN6fTps6i9vb3dG84eUeUZppcCQagcz5cplEd4QNWS5cqLiU/tDkzB9fhWmEvb2sfU1TUkwphIYCe4sHr16t7rTASmLqwvFi1K+okoYnl53RNG6OIg0O00VfV+0zF48OBeMdOyZa/NAVbSmUGnK4DFyTVNgYEBuXQ6rQs+BDVVVc/8oqJFBbKZfC0PxELfEFWrUHAtnyrP/Zio9gtcPvMwHcxowAAFyGUy9JS7u7v1aX16ujBrFBTcI0oYFjokuAbmXl5eKPCF0+8uis4DNZqgVuNoxglnWQaamxqWwNzW1vbSwUOZ4abpUHZWuEgk+hW2d3Qqnnk3ZlGBEG7jPsIodBlRA1h+yPGu1jmdPw7vN1N97NixGh6fd08LLIJMJvNmMhkSBoPyFdHcJ/D1RFxcfPqkuPhNGzduDjW8roD5ggV/CbqTd2c7rNvZ2d0rqyxDvmbatEmlXC5PCi1GaXHJJxs3boz65ptvWF999RV/5sx5obW1te/DfoYYKjMz07GpWRIHy06OjmjtqidcHg8tdgI35gEsZ6/Z2OzZL7omJSW5wWQoL0lcYk80/6mwqkCsyH3FOMt1ywPFsfKQ4zqMirevI2r9AlAgo8Kw2ZwcuIJMVC1icGFA+YTSdunLjY1N7xz/4djtzz7dXgGUqWz7tl1lZaWlf7S3S304HHaNnZA7NTs7Gy3MzJ8/XxoaFvoGjLOkMnnED8dOXd+xY0/FnvRvxNVV4ttymdwZxE6KUaNG/QX2v3jxl7jOjg4GnUGX2zsJTkNZT4KDA87S6XQtfJFbX99ktqioVquxqqqyutIScS1M1VXlqNygkHxLdPlTYd0CAdi/FW7CKYwHK7/WYDoaY4v+wMXF8aSfn5/Oz88XGxQ80OqNpeCUn4D2/EjRY0WwDqf5U+Onxjg5Oe4EVqYRGBXPlpZWX7Va4y0U2kl9fAdkLH71rzHHjx+vRh9AsGPH5xkiZ+cQPp9/kMfj6WhUqgtwi0I+37bREXxWcPBwr7S0f6JFUYmkyQPEaSddXV2O7d692+KSBwje64T2drvgtdXXd4duQMfF4H8nYdKqNT9q1OqTRELltpY2FOD/2Xho8Nl1dnSyXpq3D1ogw6sOU3CG4N6PmlEh8H0YISJ5jnioAkGUR0RHMF3nnJ4KBFRKQ6HyhrIS6wsJEclzRp8uzADNftgnlqb1FJbLBVJ5nm8eSYGY48/cANP6nUQVgVPoKg2ufZmokjynPJICQXTcwA+A0hgX86hs9538mRVWF/dIng8eWYG4k87VYTaiDahCY4vFVM93UZnkueaRgmhTlD94/kGl8tJsZtw/SIjMgC9Ai/4oWdbQ3Lyys6MzAL4isLGxwWxt+fk6vXbtsmVLzhm2k8IXmp1y9Zs1tTULVCrVULgaDPsyGPQLYBq884cfjvTavhEdPW5lh0w+GZZFLqJbOTmnu5XahLi4aYlNDQ3obTiTybx7K/e6UdkTExPtcZxWDSYE3ZufwB0AU/18aZtU7OrqLOXy+TsPHcq8gdpM+Mc/UgPy8++s1ag1Czs7O9G/ZbNZUiaDcTgkbPDmzz77DC00GkhKejFdq9Et02g0Uh9fv+itWzc/WAYHJCYmrQezkPdA2nD46IF/QdnSpStmtre1/oA6WAAeCti3/xs0ZomzEiMwGh2teLe1tq84f/GM2TLAvHmLhuN6/W8MJqPu++/3uW/c+FFE3u081L8vGAyGImH6FO8XX3xR8vrra0Lv3StIBb85saOjk0ahUOA4Ylqd7rCv74DDe/dmHHpkC2SARRWFW1MeuKH958vXTt8vKt4GlceGZXPb2VmUS6FS7jc3S4ZSKbQv2tra0HdC5cm/cz+r4F7BJtA3iMNm5bp7uOfiGJ4vk8ljxZXVRyJHRKeiDzaBTqOPxyiU6SjhWK92CLhxawx9nESidwgxQq2msyorxJySklKsrq4ea6hvhG/Oh4LvnV5TW5dcXlZ2PSFhltnnxsRMDLry8883mpualyhVSqmzyCnXyckxV6lSKSQtrUsuXbz688qVr48juiPKSsow+B2VlWLBH/cKPiXERoqLS1G7pKXFuCFfpVI6Q1lpaRnW0NAAUqNZkslkRiXFaTQR7AtTp6JjS899ToWFhagNJgiLwRLV1tZihlRVVW1srzGR19c3tEPlWbjwpYjr16790twkWaDRaGlMG2Yuy4aVCx4eibRdmph3O/9ASsprbz62AlFm5CqIYi90Gkp2a2vbOCqNVjwiYkTU1asXh50+82N4XNy4wQODAmNFzvaTU1JS0KpybXXTFqVSmchgMBvBUz/o4uVz4SdOHAm/fv3n0MioiLehtnep1R/Ex88yeyEpsBNMI4pYc3MzZ82aNWa7DXfs2OHd2toSTlQxuVxOlHrzYvLCuRMmxrADAn3ZUcOHh4DPzgM3C2tsaPogLS0NvQODA4PrdL+o1Wohl8f9burUiV6nTp8Ih7+Ly2V6MW0YB3U6vXPurdwD1raINDU1T05KeumRd0Xa2QmwCRPHsuG1mabQsMFDiC5mKJUqTkFB8UqiahEvH7fT8Hca0ujoka9BuUBgiwWayL0HuPlBeZVY/GVXl5ojFArFi19dHALGJfzqtYvhIaHBbu4eHnPd3F1zmEzKNti3X0hJWTEzNGQEHhYWgS9ZkoLeFVnjk08+8R4ZFYOHDA3HX33lrxb3TU+ZknAEto+OHldpuj00MiJaGT58JB4/dYYCts9PXITeVRlYsGDRHCifEDtZOXxYFD4MXA/RhJgxI8kNymGfPXv2JBBixIoVb3iHhUZoYRtwgx9CWVJS8iZYjx41Trl165dGa2Fg09ubnCPANcE+4Jo3EWJsxPCodCibPGkaahsbM+EM0YQYOjR8PZSPGxuXToiw5OTFy5BsXNxDXw7PnbsggfhcNbhmfVTkGOWGDZ/4EM3YkCHDhsP28PCR6ExbT958IxV9V8yYCb2+KzV1vT8YS3Qfli9/zeIeeAOPbYGsUXi/GG18Z9IZFzIy0nMIsUVu/ZqbqFAoMD6fj3l6u+0gxGY4Obmg3QDA93oPGlRoPKkBnjaMTqdhLs7O2bDeJGk225+t6VInw9xOaJcDt2oA64B9/fXXsajxIeza9akYPP3IQoqcHNFD0NrSit6oM+i0w6tX/7XXrPPdD99tZLFY3bsFcMpqlJtAo9O/g+/FpDLZxHkz54US4n4D3J98ECbcBNacdef270YFfhoUijYB8ADooZVK2+2Q0Ar9pkAAdKOFDg69AtCeAD8bAHMQT9yGJzKQsAfTp086DRUAKuW1a9eRWd22bVcYGAwWCLalPA7/O+jmQPwSkZ6e7gjbYQBfU1M3Epb9/PxPw4AccvNm7oPTAn2Qk5MjAAOB7klZaRl6v9fa2oquVY9hVo8CgUAZtTU2NnCysrLMrJRE0lzHYttsxvU4TaboNFqb/kKj1WC2AsFqcCtALFOz4NNPdzz1/qzIyEgxCL7Rg1RaWr5qzpykTYBe1hfSLwoEtz+0t7cTbgYXd+fWEYlE6PiCLY8HxsUycKYGZx0QNps7AuZ3796lQoVSq7Wd23d9dh5YGTB56+LcunUbnepTypShGq3WBfw71ebNm3YrlQp0TFlc/vAj8XDLx+7dXy0DFg4e0dZ5ebidzcw8GAFjIgjc+2wNH59uzwGPXf/22210rYYfplapsYEDQ7ZDZW5qlkS8/vobc4gmq3R0dGBjxkw4YZqmTk6weLqXx+M5JibOvCWwFVyByv+f/5zp0+U8CjCI9vf1fZsGLL26S00tKy195/Dh4w1xcfFFCfGzNq1Z87YxnusXBeLxBBOJIsZhsYiSdSg0qifMQbCN6tZgsbotiFKhQFPXwruFYJD0GAhmkZzL5R6FClX4R+EUWC/4o3AMbAeu8Rysg1kgzDCho333RuUeHDxwdBGMRWDKyswuq6yoRFt03dzdTh46eugXqVQqQh0B8OSsNQSCBxOgWrF5yKHDcUpGxvZGb2/Po/Da7t29h2KrvgDTZkwmlU43TVKZvNdRKgifx/N2cnJiOIoc/wWvUdIsSV65ciWympDHXqchyDqw79PAwKAptgLbXGCNMD0IBZoamwKqa2reuXTx4u+zZ89bByx+H3flMaBQ9HeJIqbRPfylvE6rQ9sp1OBG9QW84RAGs/tI/guBvkjzHQhrgOO6QzCnUKkJ0IIo1V3Ijbq6OCP3IxR299Oq1cYbaopEIlkIbvB7MFVUVHhzOBzMw9P9Ix7PZi5sFwi4TagjoKuriyj1Rqd78Dv4trZEqRvgZlGQ2tTckUKlUBXNEknA3/62qs/92MCqYItfTQ6wE3LZhmQrYEcTzWZAq1dZWYkdOXLwMovNvgLX0spKxB8KOE9/eun77/eejY0dE5Gc/FKAr5/P63YCwRWopHBaX1Fe+X5jY0tqvyhQYmKiGG7IgtgwmH3+pQ8ImNZehLke1znCgUdCC8BAG8JkMJFbbJNJvWDeqei4BfPk5IU3oJsDpts/L69YBCxVBLwOCk2PAnAGjV4C86oqtHu1F+PGjtkwMChoevDgoOmzZs+Yvvatv3NPnTr+tmGzGTDlN0HMhfpKpXKrprW2tp4oYVhY+BAzfxkY4I92a16+fFJib2+HrquoqGhVX5YaDtLq1atLLl++rDKkM2fOWNRgHDdGAbift88GEAvhzZLm+IFDAnxgjPi0wIMJq1f/reTYseztl6+cjwkePGgSk8lUQcsPXNuqflEgiA3T5gLM26TtFk2tKc4uIrQgptXovE+dOmVx7eTDDz+JhTMuCI/PRQonkbSieleXGs2GFi1a1MhkMC7AnX8V5UUHgSLBp7dg79696GZX19Zeh7lBEXsSPCTo5sGD+05mZe07mZb2r5MzZszo1REMOrpWXK+zujShUCiRhbO15UuB+zA70WLDYhuDTy6f9QGYGGjbWtuGeHl7hxHipwJaIAP7D+zNcXBwuKnV6ljgmlZBBXroesBjsn//3hxXN1c0y25paXPuNwWiUSnobb1UKhvTc3GvJ2FhQw7DoBJEwODmq/9BiM3IyTkXBbUcuBVpV9eAH6HMxVmEZlgg9oEZAgS3aNZXWlqKFJfL4x0zuA2RCE3OMGB+Lf7Fj0eBz7NFU3SdTjfV2kxE3aVCrpNpw+y1+V+v7w7CISdOnKhjczibgWumSVok6FTr06J/YIEQHq4uaCmhSlz10Af5STFYPQ6H3dhvCuTl4/6To6NjhUatxn65ejN7Trz5X/HYsmVLQHLyK+gpXrdunRjMoJDClZdXrpo1a4FZjJKa+s8EpUL5PnyCvAcMyMjOTlNDOZiyvwBzd1dXmCEcRXbZ0OTDeAqenKDT9ca/3uEickE5UOon/p00Br4ZKHsjsG60Mz+d2zJv3jyjy4V/nSNuQvybcK2Ky+Vohg4N+4hoMqLTmg9wQMAAMCNjqlokLYTEEjiIaY64ZmVlucFkWiY6GMGJGMjAt5nf3hCJnK7I5R3GGPJxAcGxY2zs5PRVq1b1MgTwoEFrS9t0WBba2e3rNwX69ttvVa5u7pOAGW+ER3Iq62uL4qfOKJsxY27mrFnzyjL3Z98qKiw6Alc5Yf/4+FkbPDw9SrUajbO4svJWfPzMo7HjJq2PHTc589y580fBZ9DsHexP2tqyjO+l6urRX4DByioqkbuEREVFlYGnGu1NBrOzpsmTJxv3O9OoVOR+5HKTwyWPCYiHpJFRI1KAguhlcnlyfZ2kImZ07IaYmInrDxw4nA/ijc00Gl0D3PKizz//qNf+cXi6xJSMjIxGgV33w2MNOPjbt+2qS//317Uwbd+221he+spys0VRS0ri5e2FZmRPyo1ruYuBgi+7euXG7zFjxpfNmD43Mypi9Pq4iVPv1FRX/w6XGYAbuz8sPOTtflMgyP79GaVBg17w9PTy3A+CW5va2jpfcaV4UUV5hS9QLKXQXvg+8FzocYGruuHhIUEv+PttZzDoytqa2tktra3vtbS2LAKBsCJ4UNAHDg62swwnMuBaE+jHgTfGzo7fCWWQpUuXysHgnoZyJpPxo+FdG+TW77nFUE6nM+wyM090+zMAtFTdN7jvZQQDX3yx9bivH5gD+vnmA0vkKZXJ/iltb3+vrU06EEyh80dEDJ907NhhM/dFoxLfAdxwTxwdBR8BK6SA7VTagyEwXBe0vDKZHL487ZUwOoYWReFqvKFvTzIy0i87OjqgGRO8DovA7yZST4aFj/zOy9NjJ4fLlYDJg69YLF6kVKneA5OfoTwel+Lh6bYlMnLYUBBga58+TO+D3bu/jG9ubqa+8IJP8cKFC822O/Rk165dsRUVVRwnJ5eqtWtXP/xo9f8RYNYoKCwsHaNWd2Genm4X4Dl8oumZBDzAAXfuFAR0KdSYj7+P9N1337K6Ik9CQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkLy3IJh/wUW8smsiLaLywAAAABJRU5ErkJggg==" style="height: 72px; width: 144px; top: 8px; position: absolute; left: 318px"></img>
        <button id="btnStartStop" style="left: 172px; width: 136px; height: 41px; position: absolute; top: 641px">Start</button>
        <label id="lblUserMessage" style="font-family: Open Sans; top: 267px; position: absolute; left: 30px; text-align: center; width: 421px; height: 22px">Label</label>
        <hr id="hl1" style="width: 464px; height: 2px; top: 87px; position: absolute; left: 8px"></hr>
        <img id="imgApp" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAM0AAACiCAYAAADiHknmAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAGhGSURBVHhe7X0HgB1Vvf5vZm4ve7f3zaZuEgghCaH33gkqRcFO1Yco8lSe+v6IPkUe4Hs8ngUBnw3QgNIVaaGEHoH03rb3csvePvf/fWfubDYQIIEQdsP9krMzd/qcc75fO2WkgAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACCiiggAJ2EVp++bFALpfTYrHB/bWMeVA6m9ma7u5/sWLmzEh+dwEFFGBj0aJFjnBv78x0Iv5GLmeCO4SZS8Zj/X097V9ZuHChkT+0gAIKILZu3VqSTiW35NmyHcxsJtfb2fbnAnEKKGAUktHoJXmO7BDZdCrX1rz54ba2tpPb29sr8qcVUMDHEz09PcFEPPanPD/eEV1tze35UwrYSeRyoi1ZcpvTXP2tYC53rSO/ea/HxyIQkEwM3+Zyey/N/9wh+rraxOEJlBYXFw/kNxXwDlix8FzXtMrecwxH+t8153CDnkv4TVMimuZ9E0x6LusofsVw7PuyPu/WnvwpexU+FqRJRCO3uXz+SzXtnV833NctazaunX7wwUety28qYBTi6742xR3dMtmMDh0mWubKnN5XqmumjGQplmrdgT+6iJlxxsRRfYteeep/aXX/2msdtHfgnWvRXgJYXnokPHi3P1B0/mjS2OvYr9aHwwOytbn5zH32m/OI2lGAxF/+7CSXo/0GiJST9XS4SMycSDYnOVOZZoL/kgNBNAPJqYlGwhBY5JCnGbcmSY8nljPke6HGN2+xdo5/4JX3boAQZjadHiI57ESMXicMh0M03ZjT0dExKb/pY4v4q5+cnHn5iL+6jTfW6dJ6ri4gjBM7QALx6qL5dNH9uhheDfmGbVn8HzYlFUPK5KQPmzaDRFt1TfrMpD+WS/73wNq5n7SuPv6x15OGSKVSsLlNGZ1Gk4hJ1w3JZlM9NTU1m/OnfeyQW3JpeXrp2Tc5HFtXG47uT2ha+m3OfQqEGA7oki7SxQR5TBe0iRtE8ujiAqHE5RC3IyT+uEdSQ6aEh7IST+QkYchV+UuMe+z1pOnu7q7JZLKhTCYjTNlsVpHGXtoE0g1ITs1Rlj/tYwdz1dlX5LTXNjvSq652mBFXfrMywVLQGN26U95MemS9DjKkc2LGTUljX9TUxAMNpNc4JVpRKVpDicSLgmLUTpeZ1U6pAqGiEVOGU4kjel8+pV5ddJxjrydNZWVlB4p4ENpG0um0Io5NHps4JI2mgTS6NOZP+1ghurzporS25tasNx4wYXLlQIIUKnuPxyPrXEF5PRmS17s8EhnOSlF0WHIJUzLwWfojOfGBXnqFIRGjWgJ1CXGVDou/KCbhgTZJGaZUBXWZgutlY+4BKb0wnL/luMbHxTyrSiaTwkTyvJVAJA1YI06nM5Q/5WOF/t7yf+/pykhXf0a6oRU64d2vTBfJ+iGvtPXAL+nLyHA0KV4QJpPMSQY+zMBwTrxZU/SQLsOmX7zFGdEcpspHf3FKpkyLiKcKjlClAyQyZJLL/XB50+cKpNnTQOU2Vq9eHFy/fv3U1cuWHbB62T8P2LB69QFtS5b48oe8DThHGx4e9sRiMYlGoypxPR6Pq0QikUAqEpSTKuusjxd6N8bMrvVJibZAkMCZj2Tp38HZR+3wekWKikzxGRA60awkYZbR2R8eNMXw65IzoJXMCnEFErgSXSAmA74NTmaQAL6O1DvF8MQ+k1v7jcm833jHmCfN5vWrDt24ZvndG1YvX7Fh1fIBp4TCeia53uUylrjdniWall0S93te3Lpx7Q/Wrl52Wf60EQwNdU9OJJITSJZwOIzfQyMpEokoEpE8pqn8mob8aR8rJM3gohK/A+QwJJHKidublbJQWEpLwhIKxcTtTipzLBo1kVdw7qFl9DjUDUiRBYFyDlYjDxJlF5fQOKMB7mgV4syGn78gv2VcA68zNrF5/ZpTzGz2Vo/bPdXng7iDz6EZBqQfJSDDw3x0FBr8kkwmLS6XS1q2bpFNmzd/4vSzPvEAr9Hc3Fza0dbc63F7NI8/qMww24+hWcb2GbfbLX6/HxUmKH1dHTGHx3/MK6+88sZ5552HWrF3g51UFzT+8ZNibr3R9CcaswFdkiBC84akuMpdooMM4Yghvb0u6WwflqL+AamtcIgj4JAyPSdlk1zigrZJ+mZISYOtaQaRhpGU7kYCslimQa61xt/0OW+cbm0cvxizmiaTSh/i8bin+gN+8aFSh0pLkcokWFwGGzkkXpDA6w+o5HR71e9AUbEk4vHj85egGeZZs2at1tbZrbQJiVVSUiJVVVXS0FAv9XW1Ul5WKj6fR3LZjPi8Xv9QX9dPPw6ESb765VmfbPjZ04Zn3UKtJtUoVQ7JQtNk3boUT/JI69qURKIuGRzUkNIyOJSCpjZlGD5PeCCjNIzybxI5MXMkCxty2FE8xcuPAghD7lDbGMm9wvwds6SJJxLO8spqKSqFXvcFkeMOaApNaQs74kVQ8xjQQITD6ZTY8PDlD97/l2cWPfXEjxPD0W+2t7fL5s2bqHWktbVVLZk62jtkYHBIhuMJaB1TXCBeMBQSaKWjlryLjzTewc6V2VeO+5lhvPKGVjl0VK7GkFwJCOMDYZCXmSy1ty6lE1yyZdUwfL6UJBIxSaZSEkvAPANpYpGsasjMDKMcUkiJJK5MOcMlTbO8hiHsVS4dI5HscY0xSxrN0CaRHJpOQoAs+Eui2GQh7HWaWDS7aMLVVFc7ujo7j+5oa/3umlWrrvZ6oEVwXAoOP5ckmAfbvD6ftYSn68M6f/sC0FYBvzOVis1QF96LgHfXEi8ed6YZfXq9Fuq4Sq8TRw6mlkC7mHDazZyuyGIlnADzN5tNgDRpCKk0hFNWhjMwvMJZMZIgz1BWsiBRFtomG06JiWMtLWNXqXw55ReRvqzEA7k3rV/jG2OSNG1tbT5d04MkAiu65bdkRsLFdvg4kUio33bYmD7KhEmT5bQzzpBDDz9cZs/ZXw477FDZd8Z0mF5uiYbDMjAwoAICjKDxfDuCRoKSnE5oKz1nTreeZPziF7/4xRl33XWXIn/81QsmR148+B+Z8s6HpDZRJdXQ2tAuAu2Sg1DK5UAcE8QxNSTojCw1uSkl1YbEepLwVEzxOaHhVXuLKY54TqJY4jBYZJo4Es0S7g7AZEvJQEtShrrY7AlQqOG/CX9mff854vA5Vlk7xjfGJGnq6uqGUYkj7A9GQrBC2yYZiUFtweTAfiZuI0rh9zROnCzlFZVSXVsvEydPlRn7zJL9Zs+W2fvNkpkzpkl1eYlokJzxWFRFz2wCKU2FEjYMhxi6a6q64DjFm2++6Yf/9jAExBtPPr3owcHIqqWusvCJ7hJNtFJo7iASnPwctAvJklUmmUUWJiVAzKyKGEsiK14zJyGnJqUl1EoQLFFYADwEhNA8mrhCpqS64pKCfxOVaukfrFY+j7LYcJyWzcmsyQ+CXN5X1AOOc4xZ88zQtWGWGSU/HXgmmmH8TaKMJo19zLZj3TjWA7PLL4FgkZSUVUh1XYPUTZgok5umy7Tp06Wmpko8LgMZANMtr70yqDnsTuNyOsYtaZ58+tnLVq1e0204nNI0Y4bHTK84q9sZC9AU00LQLnhnmmKZjCHptI73hiYahuk0nJZEPC1pJJPhZPgrDqQiCKRy/GwEB2ZA09RUOcTl0yXIUDPup5FEIKLP3yqRrmIpLXNIcRWIGMd1ezIysMUtvWtdEl/tWK/VLn7ResrxDUtEjzF0dXUFOtu23jh1atPlvqDVSG9rGiZitNaxf4/eT9gaiLDXR2/LZjOSTMQlGglLJp0RD/wbPZdloOD5OQceelT+sHGBh5Ys8Q2uXvvbwYG+c5kHk6dMlbKyqJR4bxWXu1dqJ7pV0CSTgXZh5CsNjULzF6qAeZKCf5Kggw/TK4lleghapz8jrphnICSOu/wO35taUX2f9La06LM/k+zrfO5gp3/FHcVT3eKrdYrgmrFBJ7R3kegw81BgYnhy8BsHxOU1xenRn3GXrzg2/7jjGmOSNMQ/X3nhB9OmTb82WGL1obT9ltHJJhI1Bc0rEojaiJWAFYQYTRJiNHlGJ14nGY/J0EC/dHV2wN9JfeuQI4++SR08xtHf3x9a/NJL97c1Nx+bRj41NjZKbe0bUlP9CPIlJRoEgddjiAZTywnfxOlD/rDFHv4IG3UZCUvCwadzn0DK9OO4AUl4pfy/A3PO+Wnp/GuG8rcawfr/O/oYZ1nzIpLGP4V5LtBSmsS6U+IIQFsX6dDaMGVonrHhOCHPGOXL9wrSjFnzTNeNYRKFYIUmKWhCsQUflUQl+iMkDKNg9GfYBqMiYdAYJA+TbdrZ5ptt2tlEsYMMXPf4AlJRXSONExpxDc/1fZ3N+6kHGKPoeO0/Tu978fx7u5ff3BIIFKFC5qShPiJlpXdLMPCAxCIJyfSmxRXOiN/MSHGNIYFqp7iLkA9umKaUHylo7BRqNpY5kEcfyEpRxP9kaXD+nAkXL/m3HRGG8E08JANLlrdkpBMJRAk4JASN5oOJ5oTZ5sB2A0nHjTSno806c/xjzGqaF55b9JlpU6feXVZVq8jCKBcrNolAkrDy7wg8ZmdA0tjgOUyZNPyaZEIG+7qlc90TUlLafO3kg278Yf6wMYHFixfNT5vmzMG+/s8l4+F5E7wryjyyWTrSQfhurVLi7hM3TC6vNwsBgsrNfl9+Pf++FBRcQktDWKiQMcyxNHyXxEBGEh3ZrHMg9MOaC1//EY5614xcfUdDbVGNsy3Q6JLATDZrUWMzuGAFVJhUQwH4aPUIMH+tB1e8rZvTeMSYJc0bryy6pLpm4q+rG9hb33rMF198UYWMy8rKVNcXkoeapa6ubqTijybN6HUVERpZokBRuLl0Lwq0X3LJrWImOyU72CJebb0YnUulZWufJBu8100/te0H6sQxgIcfffi70LT/gRfTYjFqlFKYYbWSANHjg1ul2lgi0yY8I+5aQ4wS2EYjgoFLpnweMaScBHHg17BFPx01JdWrZXKtckHluavuVae8B7aCNJ46Z5uvziW+ff2KlBZpaB1YpFEJHGL0LJcBaQIF0nyoWPPMbQd6qw54tX7abNF0S6ssWbJEhoeHZcOGDTJ16lRljhUFA1gWQ7L6IDlbYBZ4JRVdBdOALdabsES5JTbDfE9ILtUFidepNFfA2KquOQKUb7IPEjqALOnPyeZmkKqp8fYpx73xrrPY7AksWrTI0z/Y97u21vbzEolhqaqskGgsKhWVNeKH0AhHwnh8hwSKiuSYw++SYHAFznpr0eIFSRhGvfLJhElGbZPpc7YYA+Xn+4556qX8we8Jksbf4GzzVIM0+wWwxSINvE/cJi+Y+AjUMkjmsPsJo+S1k7Bl3GPMkia3YqFraMP/DPlmHuIZ1l0oghwqQxCSsQOFMCRORwoF3w8ypGCPr8cZeBUl5bbBngDi+dcNeXmZLpUlptSU52TFBl0O3i8r3f26LHpNlyn1pjRUiRw1MyOVpTix35SNW+DrTKq4Z8Ypaz/SnrmLFj1S3TeYeHD9unUHbd2yWeXBPvvsI6VlFewrJyRRe0cHNG9QKiurZdLEdTJ1yh35s/HyaoElG1Uo8ZknkP6Q/GJGsewIPBRf5/hi8YWLd2nqqh6QxtnoanNVOsSzX5HaZpGGDdJZuemmHvnWv5bLjf/ZK/PmuOW4Q33P6KFCIOBDhTbrvJSWGV5htP1egvHfSCj7f3BS/0ecsXvFmXhctNgzoqeWwcxYg4qAWgBH164jNmzrpLbClFWbdGnv0WXlRl3CMU3+/oJT1m4GET0ZmViVk+mNppSTMPlzuHCK9pF2MHz0Hw+dGommV27d0nxQT3eXGLoh06ZNk/r6RqVd3TBPXW6fNMCE1TRT6morcAxHFDMjLGnP0K+AIEricxMTexy3BTZpa+o/6T7w5QW7ShgL5XDyUYFUnlPLMMeszEvj+o8+GpU7fzMgfX1Zuf+BCHbpVEd7BcYkaThh+cqVy89P+BrLszGaEIxyobxZ7lzm1ylAmVg31Lp1uqTBn01bs7JyVVqyaZEX/mnI3KlZueJTabny3LRcd3FK/uPSpDSVxqQiFJWTDsrIrEmmcCoiO0c0Osw9ZbRzPhIsWvTYDN00H+juGSh1GDr8uEqZO2+eVNc2SCqdkq7OLvgycYlGI5LJsNNpGu+dkv4BP85GTjCD4LOw/US1zDMhH2WLszP3SunXHCu/2eQ84bH7ea/3BV8DG6CtCJzK+W2kcbk0OfPMgLzySlyuvrpMZu/n4f1r1c69AGOSNMcee2ymu7tX35wKTewfhJMaNmXNyrSsBgm6WjKSwLZ4D1J3VhKdWUl2ZSWFlME6U6o9Ky88k5RnXk6JHjPli8en5BufTEnIZYoDlckEkdJwhEuDmlRX6TLQaUo0DunrQaFb5S5s5ilztX503T7M7E2pVMbldjkkC21RX18roeIS8bjZSClSFAqoaJ/DkRsZUEd/T0l8EmU0WeDo59Y4OnMvVl4tQ9+e7Djl2f/VPuDwB9/0E0EaHcIlv+EtuPrqcjyzU77+jU659JJitgmV5BaeS7E07pGvImMPa9asKR9aetuR0vPCV4rT60/cAIJkqnWZWqRLCE/tQAVnfIAOLV+DiiEDEySWhIsDTbNsXVaGjZzUFOvKMonD6U2jmkAgqzHufPGyYk0mNBlSVaZLCcjjYXtDBOTpM6W92SHBqSccWHzsH5aoB9qDoOM/MNg1mM3m3JxaauOmTTJn//1kKByXoqKACm4wCkgyZTMZiSfi0t3dA9NtqgT8mhwy+zs4ABfqzYjZ7t+U6y65zph66J+0Wde9dbDL+0Yut8KVXvyJYSOoG/r+9Gkof5mr9CvJx5xcf32P0kYnHOuTeft6RfzFTk17dnvHcxxiTGoaYsaMGb0Hn/9f90+oq/gJOwWW1RhSGdAlA9WfrtBFn2CIUWdIzKvLVlTyJUszsvAfKVn4QkrWbi35vw2JWa+u7M/K+rgpbbDdBmG1ZKs08U7RpXK2IfUHOaR8jkOcIIwJYplOTUxWRiS2XURS/qUfBWEIJxCJxtyxGOc0iEhFBXwV+CxVFcXYhyJD3aRGYaMh+8qx0dbAcng4LsOxmJgb0pncK+4ncyumn2Ec9toUx9mP/353EobQtFkpPEJum6Z5u8qpqHDIPX8akvo6JzQN9r+e2D+/a1xjzJLGhlF66FqPxyGhSl2CqOBuaASN2gNPTu3ig9qpqDVkQo0udWWazJ5R0T55/wl3TJu2/8NN5Ybs22DIbKT9QbD9q/G7woAvo8uUoC71IGMFrlECx9ULDeWA/2REoZHS7pQ4i27PP8IexxFHHBFJJhIbB/oHZHBwkGN8JJmGiqQgR+VUC0Uc1bEVpGGnVZd0bl0t04b+/GQ6fPQs/fjXTtTPuP9RHvphgf6MasDcAWGIGMzCiy8qhoa0LMFcmVmjVsY5xjxp0lO/NJQK1WUiMMPCcGSHUKnp5wzAjOK8W4Oo6IOo9GG3SABkSIb1nrnnLHqp6bBTfjZvwoxv13vrb64tP+jmytC8//BEjMu0XudlerfzMqPfcZk74rjMla794auv13b//YkKeeaZsmVb26Z/Nlp+cdk+l77+8/wjfCSA7/If9FH6+wakp6sT5levMsMUYRRxLPJQ41DLGJr+yyItfHhDRk73HPGrteqwDxt8gB3zRaGtPS2V0DYTG/MjNgPpvWIyRqsMxjBalv76kN4V33upD45IAnnPibYZnfFBS3B6ITcKLQfipBgc6AV5wn7xHHaR89hjr9tp2/mqq676sdvt/m53d/evf/Ob34yZVus77/z151vbWm6ORmPlbNCcOLFRyspLJGey1Qr/YHaqf2autbSkdvL8+fPzo78+fEQ6/lHp33xlp+aBvp872qehM8Wsz8nf/x6Ve+4ZlF/9b4343DB/h3LXGVXLx0wPi/eLMalpUBmcLS1r929b+8v/jUdffCrhACkgUaPQMgMD0DLwVThHcAqahjKMUbCGMkMmFoFI6ajUu6fOtq60c0in082BQICNhud0dXV9HmlMjKe56KJLf7/grE9NnH/Agd8KhUKyadMWMdkFZhRh8D8rOf3yPUkYQl/+kENTcXlixybakiVxpAS0pCW/NMM5Ta2Mc3yopDHfnNRkrkJaPuFwc1njofw9vPyL7zi3WO8b9XUDy4/7dt/S017WWz71ZqbzR/+iJ/7hK4IPU4lUHzKkDr5IuVsXH6qIkcyJE2TyODRxQ/tw6ff7Eski9y61r0yYMMHLDqDNzc3Lqqqqfo+0Ib/rI8ecOXNip59+5l0++DU1tXWyfsNmCI+YtTMnazSHfupJJ53xofouO0Tve1uATU0u+GO6xGAJKOhmtbUyvrHbSGOubZxprmn8hrm+4S5zff2G3Lr6nOZLrdV0JCO7WNMyL2paaq0n/WRz5rXJ4cQrc16OLT7sp5EX5104vKz+Z9Gl9UuhwVuNzLobjOyyeW5nv3g8OfF5c1LkA1FAmHpok2lw7mfA+Z/m1aU6jhfoyYreC+nbmZVoOCeByum3zJp13i5Fiqqrq1XnNvgHO+46/RGjvb392HA4IqGSkISKQ7JxU/Pm4487XT/xhDNnnnDM6U/kD9vDaEGGgQzv4tfU1Dhk7hyPhEL5aqbLuB5GbuMDkcZcVVuWWTXhivSa+pXiyK7S3On/0hzZC0CSKWJkKVm2JcNaanpGDBkOOrKdB7d3r/9O92DbH7NRuSqX0War8D7sdS1nigMF4oHt5fdpEvJrUg4TrQLbSxOmBCBotX5TIl2mJNpN0UEWLevMumsP/8WMzz/9b9bT7TyGhobWsRMntM2YnDZ1zZqVs1xOj5SGyqS6ql6yabP+3nvv/UhNa29Zk1sRxuoSkIdtplks6u3Nyve/X67Io6CblbkV5+ajAuMX7zvjzdemzDMNaX51/fCty7uT+ySysFtdyCwnyYGlkkL5DGSXDrYwcp1twm4soEGmNujSEBRZ+0ZCYuG0xJFSkbTqTGg4cRiO9SVN8Q5mxT1kiglHv7vFlA2bsrJsc1ZaYJ75oCS00IRn0/WfOKp6wcP/Am3BG+0S4Mu4ObkGW9XHIjZsXt+RSiWgYdbLuvWrkZ0ZZ0UFg+UfDfqf+uz+cCdHfaQpX7ajwG5Nc+d65Fe/GpAl/0yovZohnpyvd9yHnd9XxptL648SZ/beYclV3vdwXConOeT4E9zigr+h+juhMqspsLjkDKVpLNWd8rfDgh2S0zCt+rZkZWVLTibNNsRfivM9mgShWTzYr4dhdg3nZHgoJ50wwSJxTdJG2cMZveqm6snlJxp+5/Ge4sn7eCvnPwWuJLI5Ty8WfyhuPHeXGiVbW1ubXnrppV/pur7mkEMO+VfOhpPfNWbw0EMPzRsM976G2vinZNa84ZIvXrIsv2uPYNGiax1zzBePMoe7fh5PRmfEofGnToNk44ec9mN/N5YtZTCDFJbjr0CBiSphCU4sY/ppeuWbf1f7xil2mTTxl4+c5C7dsFHzWqNkl65IyzDEzpEnu0WH06dECnvWwt+QOH4wpZC4HZmWwe9sFOYUSKUj5RI5WQni+Cc7pbxOlwDKwRHH+TgmNpiT5k5Ttcdkdd9W09f49eO++eKDvRvvvEiX3O0aO9fiFfAHb8I13C4cF7Pi8EBNzZy8t/zuGBwcLIGGaXM6nV71OzywekbTzH3UzjGERx55pMTjN/rwvJef84nP/Dq/+UOH+dg5pUOlW65Lm8PnGdFUZQyFvqkvK22DTrngIOS4Ig1HbpIwVnUaIQ0jfIowTChzLjP6v+qhN2/m7vEKvukuwe3I7JuL5bQs/AgDZJi7n1OOOp6dCJFhqh8Y8gp    5xrUczCtmWjqWkyT8j2QHfBoQwM22FmgTBxK/29g02ZDGKpFimGVO2MH0Uzasz8ob61A4/YZEKxZ0BY/77eWVJ/1aSajW1e1zIu0dWmxoSGLRMEgbllh3t/Ss3SjLX1sp2XB0p0OboVAo8uBDf3E+vehxeezxR+XJJx4fk/MNt7Vt2dfQDY09vPcUOu87ffJgdNlT3tTQFR4zXRk2crJFIC3dRbJPCR5ECSvrWKvELdA0G0n8nd/HAHUuZ85RP8YxRl55Z5F5Zd7VRrD9JvszJCZyQpGD9GNSkyxgiSubUTAGfogWgWMPoryNommcB6Ll2IcKPk8KROzpM6ULGiYOLdQ77JGnu+eLt2K61FbXsA/WUHFJyfPF5tbqSqNlvhGChDMMuFCc7QQaLzwsW7qiUjbpoKPmn/Dl5/N3eU888cQTZcPxyJ9S6WTRMUedcALuM+acm6OPPvJ36Uz287qmPbp48Qtn5Dd/aIj//eSJLw+uX+wyzLr9653S7/RIMuMW9zD8z2hM4jFT5k6FT+9Doe5rzRHAArbIkv9QFsCGWMUZVIUMzHQ9rW1yly2bonaOU+yyptGdhiXFrTwRHflmwLF3QGM43Ej8zf55+O0s1sVZrqt96vD8OQpcx91pWvGDpp3NWdncmpVu+C/spbxhoFT+suUQ6Y55ZcvmrfLiSy/LAw89HPrzn/98xktvrJufTmetlnEUDmeFzMAk5ETmmUyGXeZ36duOJ554Yl95ZVlnWXmpdywShjj11NOvLKmonD9v3gHX5Dd9aBh8/islLtl8/5BD6rK+ckkGSiXkdEmFNiQuPSEZlGeaQpBlmE95jqjyoHXOxDFQTPxQbf9QVnr6fTIcrZucWHV2k3X0+ATFwy7BXDL5Ns07fKmKgoEcau5Sah0ueTUmUpG/GTGDOSbwS9QAKHsfAdPOhJMfhVYJw3+JJ3MCZaE0zOq+MnmsbX+lxWwoycX/WNaXu+ULJ1SJrzSgvibMaFsukZL44LA090QkNOmov03c95jbS0pKni0uLn7PUYkrVqxwLXrm6a61a9f4amvq9/3ud787Zho3Pwpk75v3Bz0w+NmOkENKQ+Uww/tVTwT1BTTs74aWGQ6bchBDyfRpZlnfD2LhZnBMPM55t01JoMzjsQpxOgIS8IsEg31iZCKiDwUu0ie89Bt1s3EIuwrvNMxI+QaBGaWiY/T3wAclbQgu7US1zDpvk4vbaI6BRLkeaAmYYSZ8HWayCqxQfUMqrYeGeax1NiQVTsZ2kkRpFCRrDElWBqNJSK+0JKGSEskMCJdG4jIjnOX++RdePe2+vyy8/+mnn+h/5pmnl7z66qvXbty48SA8wQ6x7777Zv7+2OPXvLF0xbd7enoYwvhYQ0sMn8e5nqsDleJI92ELzCqUhe6B+eVigi+KZAtJGODqPCKT8Us0XC6p+ETxexpk4qSINE5qlrLKZjHMiLz2zzmcJuvC/OHjEtvedidhvnDeLC317HIJ4kc+06xRYUgkCAMCStMgEdAmOZhdWg9YAZvWHgDGP1TdQ9Q2qKZRSKXmQY/cs+EgSZlOdYzSLvmlPZsml06U4JdPqpaSSjyE28kPQEkmDuJA07T3RWRZc0Y2d6Xg7hhqxhqOR+Gsk01N03oCQf/jPm/g2aqqsperqhpWvJ92nb0ZyGNd/jgpm20MSS4bE73EkCjK0g8BmcYS7qn0xk1JtmVkDnwdYTNDk0eVO0+NDNSI25sSM90hXu5TF0XCefyMeusWp1T7snHX601B7bx7UQPGH1T93VVkF03v1/2DJYokvIIff7huYMl84jYmZgmHEcNfYTCAHCBpmIdqNzKSpOE3HAeiIkscF8vm7oy0trUp34RQmoZpRNPAb0mn5bzDS6W8KgCp55Q0tEsamic+NCw9A8OypiMrXWFIQ4chnIyCA7XgQKuPPpWVlUhtTa3qMVxbX7e+KBB4wuXyPF9WVvlUbW1tj7rpxxjmK79uMrfcslYmwMTqh2mQMMUB4jj9uvpKWgy+THcSptqGtOwzESwKoOAnuSTn1CUFVqXj5dLdWYIyWyNTpqOAWdBYKFOd7XVMHdjQXeHUjh2fozj5SruM7BPT/6AXDX52hDRwDFV347eShlkC0phtMMcGLNKQKFwSqP8yhP0cG7MhWi/uA38kHN7L+YXbO7qkpaVVWlpbpK+vH+fwExC4FtQT5yuuL9GkscYrTq9DsumMpGFDR8Jp6YlkpTdKwnD6WX6fk9OvajC52Z7DmSb5aOqP8OsCZWWlarLBCQ31UlVdvSrgDzzvdDr/HgiEnpkyZcoOp2TdmzF8z/kNzuzyZmMyzF8PtEdvFkYDCw7F60N+YlsPudSRkYbGPGnqnGKCUMPDE1CoW6W1xS2ltVmpLMsrEhKGdYFNEiBNrlULa/t/skTTriOdxh1YtXcZmScO/ILha/6tIgpJ4kZCZo6YZrwqk02azqxkYZ6NJo1aR4pAy/RFYZoNN0p46jeEH6V1u1xq2llWbh7HT/xt3rxFmptbpKOjI9/L19I8NjgYi8n6kK2V7G124jPxmvy/I3DK24qKcotEExrMstLypUVFwWdBoieKi8tfnjBhQn/+0L0a6T/OjKYb034zZEgEmt+Piu4qMtRE5uxSOJjMSRbCqbIB5hk0kJQ7JAF73Qii3LwoGwg4jeoFZWc5rFiSMEwMAG32PmEcsmTcThz4DtXn3RFZ+b/7+nt+vFzzwluntiF5fKyMSG81z+jT9JqSgLYhSBrmI8HpmNlY1z6Qk3+an5Jk8XxJwdTCGaoCc5gvp511wawiCVLq8xA5Nfl5c/NWaWtrl87OTlU2ihi8qFryWaxt+U38O2rdgq3xbIzsUxeEAvX6pLKyQn3UtqG+PhsKhZ72+32P4rrPH3jgYa9bB78/5BZd68hNm6w6iGqOTEarvmiT2jEGkF04K5drTEo7TK4sCiu9MSllXl1c/KgTNAojna6+jJTY0TMQKu6sF69t3bJFm3nIImdhK8JgnUvOjLOl5gv6MU/9noeOR4yqQrsG84WmrZpjaIIiCaNjnM6VtY5XtBMVAX0ZkCLWklX5B2tJnLCL2Z7DQ9Ig1aaunKz0fUkyxbMlC6dHtbVwCd+FPgw1D7/wDCceZPIoAil24nrpVFp9gJZ+UCvMOX5JwNpvwSbOe74prqWOsZcK207iZTh/NL8MDS3E4QQDxaGiZz0e73NOp/HYAQccujp/6LvCbPnNcWD+tVCTB2iG4cfDWjtwffhuz0AIXaPXXPSRTR3VtmSJr2r1OTGZ5pQkNM0GGKiZZEbMNQmpKTbEX8mP2kKAbU0jD2ANYN0EcVJVTeIpbbYyiqQhYWhKvMU0M1vca3TvNftzMkh1w3GIbbViF5F64ajvaKn11ztC0DYMP9JEo3nGK9qJAmcQf+CzJDrZKwCbwJwMsovBNhe0Uw7rrd2mLJFzJFN5lGqoNKF+ciCLHS2zPmtHEmWUn+Lz+0CgoKrE1mczWPFwwZwm4aGw+nozE7/sTALSn9kZUPOMaJv3hKY0YW1tDQexSXVVZVcwGHwaGvL5XM7xBIi8eUefVo+t+eUSn8dxgKpYvBelCIF15k1fX/wvlfOuPMfauOeReOXXTcba/1ibm+qGEDOkN6fDEsjCJM5IbmVcJgR1KW10qe/YVHp0cYJYKX+JOBpNMYrg7Nh5TZIoLYN1EoeEGdRT+pbqg7WTnxjXH6zd6SqyI/Q/dv4Vzr7nb/UF06IX4VLUNjTT3Eg02ahpEsisDjjprVmJ079BRnK8uDeADOfx0DS9fTl5KXqcxGvO5NBjRRa79lp/8Zt/8yRSxAMZ2ODm8bjFHwxIEIlayNIs1EL0h3LC6Vw3b7H8oZ6enu200A5h3cpe7CTYUqFJsCgoNTU10tg4ARqpssvv8z/qdLqe1bTUk0cccVI7j3xp4beXz2wIzgpUhGCWwbzBeSrIMZyU3q4B6YwYz8xb8IOPbM5j856zm9LJ19fmpoE0IEgcZdWV0KUX1kJ4KCXxDQmpg5lcP9ktvv6MhGqckiquEP+UuGh+lhsuQolI2NoGBILwzGgbtQu0U3fuqwRjGfm3e//o/dunv6Z3Pvc/fiPJbmCWdkbiqIAIHUZImhScP2h4cdI0Q4YGijXxV+hW8C2Wk0h/Tp5qm5XtKv2UYX18iV8cxrl5R19n/zJGvhgBG1WdLQJxwjyr+4ylhWjGBTjsGb+tSqnOxYPxa87sktPc0qJIFOeMlDsk0S5QBofSBxuB+o1nxrOWFJdIZVWlIlFpSckm+EjPBKOvfWZaedZbVFUsus8FhYOzYYpmwwnp7Q1LV1R75uBzrv/ISJO4dUaT6Y8p0mTh5KdgfkUNTYaGNWhBXQYHszLUmxTXUFIaUEbTsD9Q6RJ93wbxBeHT8OUp9PilNfzPDEMD9aAWdBoX6gtWL7TuMr7xgUlDdD3y6a/l2p+9xaen+EEsKBhUeORbDKQZHAZp8IOEiSZFKup0KZ9kKGVkZEGCKEy3AVNebQm+ObTPf53V09P1qVwuuwA+zZFut9PgRHgWgWCyYalCyajoSmPYT4/tthaiT5SGGcd1j9cjfphQo7WQCjvn/1HzbN3ajLRVOhhQwDVGfCAbrAR5jFrNg/fNr3Kv+p/fYP1U1+Qan7e4uFjOPqRMZjc4pLi6GP4AbFqQxkzD9AzHpQ+k6QFpjrjgxo+OND+pbUpXGGvNJmgaFFIGxEnDDIubusTiGsw0gd8IayudhDCEoIpkZEbYlFL4eZVTB0Xj+9IUQ2oe3kcC3tjW4q7MRc5PPPNU/hbjHruFNETnQ5/8prP72Zs9BjIMv9mIyfFovRFTeuDTOGGu1TY5pKjW4AeGVehSQ8ZmBnMSC+ekJRJqn//VTXXW1UTuuOOXf4hEI59lBIu+jP0JQFuTcTpWuy2G2mLkRVBoIwRSfhBJlFYNnfSBqIXoi9haSP3DRampWqB9tmzZKltAokgk+hZTLk+Gt8AiBVesdesXf/C/RSq1XT1TVs4/pkEOmhaQkNI0buW7kTRpkKa/NyL9meBW/5SjDzj44BPZf2WPYwikMct0pWlS0DBZmNFZnyEZaM50zpBkihob+QXSmChkE1reAeFYNGRKVUlZqtiTWKanpSInrmYR/316eu5t+mm3QlzuPdhtpDE73vSHnzotCvtdaRoVQIGG6enHL47x38ephi87UIl0CNhIHJqI4Wj6OBxfE3O2ly1oHyHNnXfe9oNwZPDa+oYGVOCwdHZ0w2coSrkcri0wfZpIIJpArJi2GecAMSwC8bXy1RcPoios/B9+8pwEJKEY0iaJ6Ifwi2qWhrFIRAwNDoFAWxSBOju7FPFGtJB1aYsM1qpaf+tydCoPBKQU95veYMr86UEprgop84whdDbOZmCeDfRHZUOfIWHXVKkoZxtR0dNer/fvgUDxC/Pnz/9Ao0nN1XcExZ+bqWUz7McvubSxQXM6e7VJX0qoA/LoBmn0En1tdopLksgLE6TJsTcA8tZE3uagqbMmSJNEOYM0OsrPCfPbhxSKulYVL1i9b/5Sey12G2mIvrtntjrdPXVZkMSEIKdG4Dgbg18TZr1OcDwFzN0yTQ1fHsa+SQxftmWlrd05MPPrHWWomKrW3XXXby/r7u7+1cQpEyUJX2TrlhYpLiuNlwTLgg6HY0p/f+8ZkNwLwJtDHbDhSBiqIWoXmnL8TU0xUtEBVcVRgUma0STicSoih4odYEQu76CPkAPHt7a2KzOutbVNevtGK4EdkUWt8HFkYmmZuBxOaevvg8YNy0FT/XLiAVVSAk2jkTT0x/AM6TxpVrcl5LElPaqRl+HtutpaaZjQkC0OhZ4NBoPPg+DPpVLmi8cee+x2lf2dYG68vUq07G/wQCcjL+hGqkdmXuBZeY174F3+QJtyGTQDLIO7v3hiuv+Jx9OTXJKANUDCiB8+Jn0UB/KTCfllpiBEIJAMkMYBwnjjOfFHPGsDZ66YwevszditpGn/2/Rfpwf7LnGi3nNUpubEDViXUbNp4/L7jhloFynVpZ/DAXD3CSgYIyUyOCDiLG06evJnX3qO1/rzn+8+p7Oz/d6JkyeqSrthwyYJFhfJwQccFuBcYOqGwPPPP1+yceO6U6AJzkKlOBXaJ0QtxGqhZtUHgZQPxNA0nmM7CqkKbptyVjCBPpHbYzWs8qtj2yJySIoM1JAxkNgKa29FSkLqqkNYGXG9Iq9XaotCSuOu7eiQFK9LMiPNrHXIcXMrpSwfCGAQI53MSAqqd6A/huMT8uLqcJ707DtnVVI+T1VVpdTX1Ut9fV0yGCx6AtsWQ1w8c8ghR75qC5u3ouXl//lFXYXjK9veG8g/K0GCx5Ly++C+X/0Cf/ffeugZMbP54eQEl8TZmAyhJjDPxI08dFrJ4CTseCd2r2GgzMnJT1Cunj7HU75PrTlBXXgvxnZ5+UHR89ChX80YG38+XMRxMZxIPIcKhVLBXThRN9tpOFDNB0Kxu5oTlq4b5GEXm2GsJ3KV35ty8eqf8FoLF951QGtry5LJUyerPmLr1q4TLzRBXX3D/DNOPuOf6oZvAcfFLF36z0Pj8fgC0OMMVIlpzlFmHDULYfdJ26aESB5WIFRzSE5FNgYU6DdRC/nYLhRQQQVH3hdipbMJ19Pdo7r59HZ1SQjmS/fQkLT0s78crquIa/lX2WxGqoKmHL5PiZRVFonhdaHukTRpSUYSEkVa3ZGSjZ1p1Y3I7mxK0rL/HB9YreOZiotDNOFUG1FNTXUEBF8M7fQUrMjHFy1atPK666x+XX//v2/fVl9iXjp9SjXux+/9o8IDzA9G7aKDMWnuMx+Zfdr3z+T27l+ffmQs9uZz8XqnxEGGrAfHs9UfmsZA2RlYOqBtoGuEwpFNdC6UsXfYFM+g/4+eTy37nLrBXoyRarM78Prrrx52/bfOemFiRUbmzxE5YL4uRVNRObEvCds9wHEYGZho0CycXCMdhnSHWnegIngipvRGy//U+OW1n+G1Hn/88do1a5a3NTQ2qOjXunUbGMeVipKyY8899zPP8Jh3Ayqs9uhf/jKpOzz4SayfZZqZQ2nFMSDA+sceByQJpbjVQMoKmT9ZkYiEsE05i0A06WwtxMZVj9JCViXksfxqcjKZUMEEhrRbWltVYyuvReLwOrxveVCkqsyD93Kqe8ZhBw3H0tI7lJUBhmhBTIvYVrKejQ9nL8mfkYdVhCouKR4x52pqqvo9Hv9il8vxXKLtxdMqXQPHzZxUDk0ehD8JyUUy4znMWEoGeiPSk/Q/sv9p/6ZI03PHacf2J5Y+3QuzTKOMYYu/B/cFWXSUn4OkgQ/q1OHL4NXdEEjOOAiE544mD/np5AV37/K8c+MN23J+N+Cee+459corr/wbzRxWlIDXkBOP0GXB8SKzD9bhcFNgwe+AFoKwEjecHo0NniCPMZiTwUH/P2sv2jqf11q8+IHgsuVbw9XVVVJaViYbN2xUn5soLi6+4ILzP3ePuuEugLO5DA72L0gk4qeCLKejMvrdbqsvD5+VpGBFJIFYUQmrXloEGk0ivt9oX4hm3OiInCIJKiWPYT+5TZs2K1+orb1dBRTs6zFZsDQJzUe7PUr9zq/zMRRJ1PNwO5cWRi6RB6/JczkT57TZk6XWMyxNgZjMmATfqgSk8bBbhkWabDSpInZdw85fHvKpH32V56/7xexrMum+62MlhgzidwrWgg6SUG0ZsMUMdoFC4hTALmgeD6fcQipBWf5t8REidedNO//8U/bqka9W7dgN4Hcya2pqKrjOisVC5tDlh5425fIfGPKFL+ckvAb+QgSqPJwTdz+IM2SKCxpI1VHrSWbkrr1WrR1xxNkRXGeAFZSV0+GEBY0K4fZ4pqsjdxFnnHHGwGc/+/nfXnzxZedPnTqj2O8PnJJKZf47PpzclEyklNnlhP3I+sh7plIppRXwKgArr6H8DH4LRvVCCPjwLC51HL9/SU24GeTo7ra+hWlAKnj8Hqmtr5VDDztEzv7EArnk4i/LmWecLgfMm6v8E5fLCZ/JpZIT62yTcjjhx5C4tg+myJJPFmsUUeyEv2rFihJayVOC61TkZNnSZdKysU21pyRTWTXS1R7tmoBJyNGvw2oELJugLThT6UldKJNuaD32hNHZu7nMIa4al3hqPOKt8Yq/1iuBRmjKRpcEavHcfkOGU6YUBQZlaKhrt9WpsQqrFHYDfvzjH//jV7/61UmcpZKkURIvb1qwEjC8+/2vxOVzJ0LTxFHOKBinAakFKZXmrDUgUrhHl8SEL9Q1nnSj6nJy++2/WO0L+GbQbm/eulUG4CuUl1f+7NPnXnC1uuluwgN/e2Cfga6eM2BCwYzLHuyCXcMKrEwzVEJ+BJZaRL1PXvJvAyosNRCOUxE5EI1ai9Leblj1wxcjKZkX1FZ2p1TO6sKQNscNsZ8ceyxs03I7KhpuU0xRsEjDpbVSOqFIfKVu6ds6JJHumHqmOZOL5OhZIWmaCE1THFCahmakalCFD9XXF5XWVHU85Zl4H3y356c2/9cXetMbDu/GYwxAy6RRRgbKyOMzQG4KDFoMuni9KD8oLRfMND/ypBzHP/L0wXLwGd8tmjlz5ticqnQ34QOT5oEHHgj+/Oc/v3r16tXfGxoaon0yAha83aLPtpAvnZORay9DxcsXNm/OlOmBRIePw7mZO2XuGbMvfkrNgn/nnb9aBIl9zOSpU6W9rRUFPCDFZWX3XHjeZz+0b/tDY5a3tm49JZlOLgAJToZvEWSbDh+UJLLba2wzbvu6vc3sGh3SZhCA789e2sFgkeqpQDOM2cB2Gvo6PKanu1e1DbW1tam2IV5cXX7UPSx+WBk4mixF1X7p3tgv4S6QRZmRTFnZp8EL0pTINJs0qPhsX8mOIs3LG9OysiUhDQ0NyieqLk6J19kGbbRJhtPrJJ6J4Y4sSwPvYYAwMMmCmhQVIQU01eUwEDPl1gfP6Pr3H/3sHb8MYG7630bRjH1RAeAo5SKSyjbrM67cnN89brBdke8KFi5caNx8883faG1t/VY0Gh2ZYM+uUIRNFi5ZKU4/VpOffx+28SjSqD8DOcnAVIuBNFtjlVfN//qa/+auO+745W2ogpc2zWiS7q4u9TWwkvLy5y4498Kjuf/DBj8Y29nZeng8mTgH2uEkvNpkEohkMXMWIUy82zYCjfY38hVbVV4rgkbtwi4+dPK9Xq/yhZjUgDucSA7Yx6cSSWihZjXsgUEFanAGLayLWtcumxiSQKVXejcPSrgTFRvblcajhuQ9kedTKl1y2D7FMp0+TcgiDQnDBtUU+7uBNIvXDMsyEE718cM9ioqCam4Fkqihvg6/I3jmDmjC1bjmZhwTh+Ug2C4S9ON4FHdpb0b+9Y8HtcRT+s/uuusuVX42zK2/OEuy2g14xRlvr3LmEGySP0lWfq5PvXx5fuOYxvsmzWGHHRZEgYZp07OACGY4EwuPFYTb+ZuVirPyH7i/IXffCOfZ7gWbBzttmgMgTbcpa7q8SwaT5tFnXdcxfNddv70pFotePXV6kwwNDsCE6RR/UdEbX7zwS/Pyp+4x4J20Bx5YOGtwMPwJVMxTUCEPAoHyfeOggfC+rKQMb6twtjLjbBLlCYR8GQlp41iSjtqIPg0bVkMhaCGPV+UZi8Y+nlqLPRQ2bd6sGlgjmbAUNwYUWSIky6hrj5CG10eqC+XkgGlFMrWxTNxF/hHS8N5JkKavPyovruXUVwlVTna7EN+DgQg7qFBeXib19fXQRDVSXDwErdOMY9aI37tZ/FpCSntM+cxNNXhshxxx+BFH/ehHP3pevTTQ9up/tdZWekd6e6gHVvmyrR7kNK1bct45+sTPdeQ3jVm8b9J861vfCt53331hkoOSkuRhYuHxN7dblcgiDc2ayRMcct//aFLKcTS8iFWXVB80rdeUODL+jS05iTonP+2e94PPRyL9nx4cHLxp2oxpqkdya0u7hEpLIxee/1l+r+4jxUOLHiofau0/O5lKngppeYpuOHwqGgewXxzfn7BC3JYWsnKb      hk6+kuP97XYcVmJl+qGy0v+jtA8GoIWcHPZtmXK2FuK1OeCObUNsXO3vH8hrKu63jqFpRt/JqWdkvwanTKkPgTQ+MUiaFO+VlVQ0AT8xKS+uT0g6C/+SmiavbSytaSc+Ov9QIOjQQsVSWlqqem/XVJdLZWm3FMe3yM/u7Ydg65Jjjz3u4GuuueZV9ba5nH7vrZcNHDirpqi+vlwcLjhCVkZYwDX53PFYUoyKmdM9lSeuy+8Zsxj19LsGZsZ+++3XjUpdRlKQMPntamlrIBLIKkRTyko98tefZ6SmiNpIHaYqA+WqA1om2WfK65tz0paaINJ0uQkTZms6nZpUU1etJGdzc6t4g/7EYQceUdzU1DRmOgGyUXXZsjdOjCfjp+A9z4R0bnSBQMyLNPJBCQ/kEfPCrpCqDqqzyRz+H6WFGEwAgXgeQ9pFsIMYULA6rFL60zzcFtbmaFV7DgUGFOKJxEieU0uRQKVBQ1hfvRxlmaJvhvxOaTIIX0TN2gOTkY2pJO1o0vAp1fq2B1awV/lORdCQ7ME9dcpkqays5PzYL2HXo4ahPepODjZvXvF43+Qar0yfUCr+sqDo8OmozSgw8HCSHhxWsxK5qudNKJt2Sot15bGLUdmw6zjkkEOeh4l2BDOZJGEh0+bnEn6OWpJQBJfc98ebMzKlahtp+AQoJ/FEUMHg0yzdYsq6cL24Zl6M4z0qLMvPfbvdTonGYqrvU21lfTmnks1fYUwBRNH++te/zh6K9J2OSnsW3vMAB0NnJAYrOqO7qITKFELa3owjqIGspCJtyENlxkG70BRkRE711GYfOZ4PAvFkmlwkWiqZUsRhRI4k6u7pUeSxr8lE2KSwkm2O2e1D2xLLRy1HMHod4DWx4FZ1ZfwmyevgC7GNraaqMju86R9GU32RTIeJ6C2FX+Vzq/dmFI+zoyrSpJwy4ahr3nLxsYn3/ZCXXHLJlMcee2w9CgpCwyKNbZKwkLjNlqw2mPnXfT0lB06HpISQYSaTME6XJgGcmm7NyqpmU1Y7zhJf9RwVRHC73KoNg9dS5gOkIcj0Ash0V1FR8V0gbti6+tjEI488Ut3b33UWfIUvQgPMBoH8zBNqlXSGU45agQR2EuV2u4JaC1ZyLvK+Sj4ix2ACK78XEpu+ECU951GwugZZEjyVsgjEsDanwbKmw2qV4diwuvg2HowiifqZJ4tazS/V3zxG/bAJSNiro8nJ5HEZcsqcALRMsTRB03jZK0GRBseCMAx9JwdiEk67Y9NO+F7AusrYxnb5sTN46qlHGgcGoue0tbV98YYbbp5lF7SSiHnSkEB21MwGiUR86byUHHkAzQvcHErI49Wkyg/TAP4Mo2frWk3ZUvwF8Zc2qkpBbaMa/UgaViyYEbxu1kzTaf7qgjM/+Ut14XGAJUuW+FatXXZ8OpU5CyQ4EZnfyHfi+zB/mH+WsLGEw0hlVqWEDFP/rcrI41UnU/pC1EK4DrUQfSFr7oRtJOSYIpIIpq709fZJC8zc1rZWFdZmh1ZFl3xNsIlib9j2O498maq/I+vbno3akc9nJ7/HkGP3hWnWWCrTGkrFUxIQw8eeGNA0MC/NVFYSIM1gxtvS5znw1OOPP3WluugYxlty5J3xyCMPfS6Vin8+kUgej8zXWAg//elNIw1yIwWEAlQObX6dSxYwicRjfvhNkboaTTxu64tnxTkcBw0TA9/6+zRZmz5cMmWHKPOD7RlK04A0dp8x2ueqkJC8Xt91n1hw7rj8Lj0qlPbgg/fNGQwPnY2Kfyp8lHnsGscKzIpMH45vaRPIzl+CHZqt+motGb1TpMubaFxX3XughYIwlRigsK/Bi1JTsWyoiWwzjiYd/NORe7xjzeD9uLAeYPslEn0t1TMB5KF2DIA0R87wSlNjiUypLxV3MQjtzZMGz5EFaeL9MWmNemTtQDknKml1udyPw39b7Hbri4455pSteCbrJmMEO0WadevWuZcvfz1hEcLqYpJEeuXlV+XJJ59WGWbZ11YkhImFNzw8PFKItJUbqg35wTegNXDNSRMNCSEr+jdm1TdpNqenS49xkLiDVUpSsh2DPhB9Gg1VySoqgksNTq3rWZfX962zTjvrNWv7+MaTTz5Y1dbW84lMNnNq1sydBLJ4mKc0yajFlX+oHPY8gZQv9FYg71VlZZDA0kDURIzAKTMur4Vss5mmnPKb3hJQ4HxyLS0tI5bDW4G7kB/WGpY2cVjOXFdLJC6DXl0OnOJS/gxJ4wr5rf5vOJemWTaZkRg0zZvNKfnros0QkA4V2q5vqJdGDqGurFyP530CmvN5w3A9ddRRR33kUwfvFGmI++//86ZMJjuJ6yRCPB6XoaGwPL/4RXn1FX4K0uo2Y+9nIICZxvAkC4zaotiflC8v6JdDjkemdWRlsMWUTR0lsj59tGj++hGyeH00y9yoJNv8IZXJuB6jSw6n+9YLz//slfkdex3YqNrR0XpSPDFMDXQ25E21bcYRJBDX7XFCKt9RktsK0zqOxzCpKbDyAo+/rd4Jli/Entr2UAnCOhYaC5ZEe3uHIg/HDfXCrLNhP4e6/ijiMLGM7MRr+V2mzGl0KtNsEpIKe3udIBXuhefJJDIS6Y/KPzcn5Zk3OkaEggpIYOlBPaivr5PGiY2csFFKS0tWYf/zECp/93iKnpk/f/4enzp4p0nzyCMPfjKTSX0Xptk8nKbOoySiXfzcc4tl9eq1MjAwIBMnTZQIJJYVx29UoVJbCxE1/iWy/5wWSff5pblnloSN2TDDYIqhINWUtB43KsK2x2LmJxJxJT39INRwPCkev+/uz3368+P6cw07C1RE7YEH7p03ODh0Nsy2BTB59oHpgiw1lDTf1qjK9jCr8r9dC1kVmlyiyaQ0C4kB4UbtNaKFKNyUFrIqrq2FSLj4cFw2qbB2s+qtzamBeQ913fySZcUlBZtFGjyXmZKZMMengjCNdSXiAmkc7P/Ga5M08bSEoWleA2lWbh7EO1hakIl1Ri35DzfjbwpWaqFJqGf1dXVmUVHRUhzzLB7hCV13vXzYYYd96FMHb5+3O4Fnn31y3tDQ0OUgz6eRqUFuY0aFwxE1DDgStkLN9ouzcEekx6iMoORkVIwahb2FqYnyvAJo3mVg3sWg0eAzwYwgmUqKQzII7eb0eP5x0ecvPiV/8McKDz/8cF1/f9eCtJk9K5fNHmk4HD7mHWGZz9v3jWNiKW9f0BaJVEVnMIEEysCMxroXgouCjmFjNwSZ0mZ5EvE4mnH0hXp7e5Upx5lNqZFswti+jGq0RT3gMwWcKWmq9cik+mLxBL3igqZRcyPwviBNX19MXlqfkGSajcE2aUa3F1lLQv3OL4lQKKSmDZ7QOEEmNDRkfT7fK9i3SNfNJ53O4KsfdG6FHWH7vNwF0ITo6mp9Go75oWxHscGMisWGUeGhHZBx6sXtTMDLqwxBgdLBpa3N7TZ4PO1qXoPdbij1HA6nRTwcHwz4oc2GxO33rfvy5y56X0ME9ia8+eab/pUrl52YSMYXQICdiHpU53JT+EBLIA+phZinIwSCJrIr3TYo24r/R2khyx+iYKNkpxaiNrJ8IUsIUgvRhKN/yzA2xwtZQYVmCLahbQRizwQ8C58n4NHEBx8nyE94A4lkFsn6ejfrxMhnUfisfE7WHTyseuZ8YpVVi/xbWKvWO/E8WjgN8IXq62rpG6VgwdDn/Ru08FOJRHbpzs6t8G6w7vw+cc+f/nBLJBK+kvmuNAb9ELy8DWYWNQYzWL00M4OCbxRRCBJk6dJlsn7dBjVr/9y5c6B5tg33tU0OhqD7eqF9dX3dFV+58mNPmtFAJdUW3r/wwOFIeEEmmz0VFXZ/l8ups6Jb/dAYMcuqclBCCGlHZpz6m6/wVu8Ei0D8/XZfiNexyocE4lwJ9HUH+gdAnlblDzEqx6CRxc28NlK3ydcJVS+4tMgysk1pF/Ih/xtncMmNXNhQ297yFvYvXq+qukr5QtRG1dXVCbfbxTkonsb1Fx96aBZa6dgdRzveBdvfbRdx//0Lrx4aCt+kpAkSM6u9o5O2ppok3HohC8rOpfc3ChwazPnF6As9eP/D8G28MnPmdJk3b46aF8DqPGhlGnOK2ond5zXDGP7G177pz1+mgB2Aw8Xb27d+Er4gSJQ5ChUcrhAsAtRYNWSBRMD6CIGQv6xkqnaPgBXcShR8tvbiuWxopg80WgvxOtQYJEUykZQETGtqoa6uLtna3CJt0EbWTD4kAe/DcrUqIe9vJ5b1yHp+33ZL9Xfb75ENCtv9ULC38Bn5GZX6+lqYc41SXl4ecRiOJ0GgZzXNeB7+0E59CeLtd9gFPPS3+88M9w8+RBOAhKCzyGgah/eecMJxqi8SpRMzU4VB2f6AYxmKjsViyu7lizDK8uc/3ctckH1mzpB5B8yFWeBTmWJlDJcwH5DRrZBgaRTek/94+rQXXnjh79aTFPBueOKJJ0JdXe3HJ1PJsyHgTkFmVrDthnlrEYH93GjG0Qe1fAor7/MXsImEBSikypBJ+SR5LURfiKYce2pbvpBFRloK9IMSJNEwhWREmXH0gzhuaBiaaVs5WxVyZJ1Ltbptv43Rv7fbs/1hwNs2jGxhpJaROX4VLwDyNzZMLj3yyCPf88PGb7/iLuCpp/4+vaure40tjWiKvfTyy7JmzTqZN3d/mTVrX1UYNLVouunQFH2QNDTbrC4xlkom7rlnofKFZu27j8yZt78Uw8Hj41l5Yy2pxe7/y4PKbjacjl+3bG25jHsL2Hlce+21+qxZsw4cCvfdnM1mDqfJ7IJPyjKi4GMggaYWt6t2IZrIikT5Cygo9igCWVqITr/Vo0FpIQhCCr2iohC0kNUuRAKRkAQDCTTlqI0YyiaJOG6oExqJ1xtNmu1uO6ou5H/sEG8/x8aOz+EzVlaU33nQQYd99bzz3vsTIO98550AJIVv8eJFMWaaTZx/vv6GLFu6XCZNnihHHHEYcpbbVR5LdW21dHd2qgxjhmyTaJr85b4H1HzKM2ZMl4MPPlBNUTQ684gnnnxannziaRSwMxYMBK9Yvnz5b9WOAnYZd/zmttucTuNSlh19HS5ZSPwuKbUQy5KdS9nzg+tWpd8m6EgYq1Ss8rWWVrIbZLf5Qm41kykjcrQ8VCCI10JS2koFFNLKnLMCCi0qKjc4ODQiVEfqgvoLjKwQ2/3YDm/b85bz6CeXlBZ3/u///LImv/E9YT3R+wTsw2FkZJtd8fmCVHmMijEEzc69lC70RZxMKBDOzcyI2Ij0yUsyDgVmhlPSpfJhUzvhj0q1tbVyzNFHm1d+7cobC4T5YDBRoTmRCL8yx0rNxMgb/UwO9uvv60dZ5Idpw+xi2ZEIdPTZdYomF7VLLscyovCzyMQyZflzaATb3ZhomnPMz4YNG2X1qjWyBeY7/ZwoTDXOv8DJRIJFkPbVFTJ7ziw56eQT5XOfvRDpAjn88EOVI8/6okiJZ1dpZOWtP7bH6D1q78iKwKcplbKyYgqNXfoK3QciTR5quh67gjPzaYrRb2EmWskiBl+OUsyKuFgZbUdO6ExSCFC9M2Izmiz29Wl/Tpo8KdfV01mpNhbw/oHiUGF/VEYmkoIEYj6z8fIF+KbLly1TBGFDJiOcPI7Ds9lKz1JJYVsCJOK+DAiklNV2JIJQxD3YFYr1ggRi2xyJx646q1atVpNA0jxjMCgeH8Y1siCcQ0IlQWmY2CCHHnqwfOITC+Tii74kZ515uszeb5aUlZZuTyC+z8gP/HkPEvHhy0pLZMrUiahPjZAg2a1q507iA5MGmsS6IXMRiZKJURq20xAWOayMpAnggP1s/x4Zw4ElnUiukzQsBPxQ51vHWut+f2BrRXll6Q3X/+e/qA0FvG/oukMJLJaP0g5MIAV/c+5sDmSjj+mBkGPjswOCjr2k2T2KzjusLuG3gFhuPDeTSo0QyG5msKosyi5PInUfkgjXpFlEq4RRVfq5a0Ge5ctXyMaNG5UWYsAgmUAdQg31BTxSWl4iM/edIcefcJx8+tPnyZe++Hk59pijVLCJhKc2s2mi7jvyY7ut6nGoYabPmCqhooCEgiHUWa+ax3pn8YFJg4xuVhWbT4PnohRiYubRzCLsik91bkszmzBMBCUYnU+ShoSzyTYCXBs/nV//+tfH9PiZ8YJgMFCnLACl9VEOikBstDQVWWgmswzo4ygtBEFIK8EDAvl8EIzYFkM5cWCgmucAwpIhaFoZ1BbUUPRR6KvQbyHJqIVUrWVtUXXA6hmivqkKLUTykZT8ZhD94jWr10iLGs7dr7YrU86lSxG0EEfzHnDgAXL6GacqLXTuOZ+UA+cfIFWVleraNk2Y7BU+c2NDnTQ1TYY5iGd1edVsqCDzLg1o/MCkQYavz6+qh2VbC7tCUH1SDXObnfjSVM82IUYnjgVRx0BKkXA8RmHkzXkvvYKz4Fi/CvggMDTNv03TW+YyfyufElqD/gt2Kc2gEvwU+qL0g0gQDtvgPNlOrPMziJs2bZHenl5FFvqxFIIkAq/B8uQcD9zHiQttX2jEksJBfA7WGxJUmfhIFKDd3T2yZs1aWQEtRJ+IEzOGh4aUKcdGCA8IXFpRIlObpsiRRx8h5577KUWik048QTVfFOE5eAvWr6lTGqWuvloNzXYaLqXNmhn+7ui84dprv3sI82Vn8IFJ4/P5t1NtlBq0Yem3DA4MWoIlD0ocqmgWjg3FB2QYJxlnxrEthwXGZJNlG3LO6dMnTs3/KOADIMmwMvLbEmAWaahtmO+srBR6VlnBrKJvkjet6KOwYtv71H6sb9ywQbXPkUSMq8VUW1xckYKBBJKI9SKTSSl/lyQimailSCLLH2L0jU8HAvG6uBe1m08JYkO17TVvbQGBVioiselhgFoIlT8F05ETsxcVB6SyulzmzJutAgoXXvgZOebYo6BhamHiFcOXKVPTrjHU/dzzL6lgR3l5WXb2YQfsdDDgA5OmqKh0M95zpHordQsVzSWHDozsAU9YICqjkckkChMLjmDGUD0zAxnHp8R7OzRZt25jIQiwG8AKqoiiiLNN49AXsQQWv17HwWu2FrKT5fuQaHZvDfYpDKPi2tdw0mcBUWrqqo7IZeVT8XjyD9ForIdahlNUsZMl/RneYxhE4JBsEokNoKzEqmNoXhuxzGm2s24oLeR1K3+IwaIeaDZG45a+uVTWrV0rnZ2dqu8izXs1Pa/XJdF4FMK7X8oryxRh+GkTapeHH3lMOjq6VB097Kgj//1TJ3+q28qZ98YHJs28efMGkVH86owCM40ZQukzFB411AEHMH5vZ+xbQZvZBbJRyrHQ6Ey+FcxCZGW99auA3QGWh10mXKq8z2sha5gAybE9caxeA9Z5JA8LhudYZLKEIJc+l7fnkksu/+ull3zl853tPdVOwzgE5XpDJBpbHY0NZ3ldaiA2hBL0Wzh6lBWffpXSRJxHAESmT6QIRK0IK4bmovKxQCKGAHq6umTl0mVy5+2/l3++tgRaqEVdawiptLREmWTJZFo2bt4s//jHU8oNABGzMDWv+cw5n/mpeoCdxAcmDTJnyOvxRCk1KL2wQUXQKBXYr2w06GQyysHMHQEzA4kkow1M0qj0Nk3DlmIlnEZm8yzg/QNlVIEqmP9lgRXdFlosFjUhPLZt7/uww+eoaoNLqOPzZa9IxoICSiZXdakVgN/Lueiiy1+57JKvXnPFV67cp7y0aiaqw7cjkdjzAwNDOTZ4j3TDcblBwqT6TAnHZlFz0M+y6g/rAK9vEUgl/PI4dQkV+eSAuTOVxmEEjkMXqJF43UQ8KSuhlZ5+6jn1fCBcprSi7DN/ufcvN6gH3AV8YNIQMKneyK+qWq0aypxQjZAcbwVfggSxyWKDL0K/hpnPDGLhWdj+QPg822ZqLOB9A4So5ZLEschjVXTmu+odAHDkLE0vmzD2kj4OS4S/eRZ9VZYbfRYbPG7+lHceVXnhhReuv+KrV944bcr0U4JFRY+EhyIwsTao9hu2CzGgVFZepjqEMhbGMDh9Gi5puvN7ruQpk0Ug6/md9GtAPAhyK6wNQcw6989/vikvv/Sacg3cHnekuq72wvvvu/9eddIuYreQxjQzS/OrCiQMoytRaBq7AGxQKtl9kN4KNnDyeDuCsx2r8gDhVGEX8MGgpo8aBavKKQGYX0M5wlxW5MhXSjvRPFI0y//msAMu6cva2/DvPcO4jz12f0M2l1yia9qZ/fA76MsO9g1Ke2u7bFy/WdrbOgSmnPKtysrK1PzStGJIUo7mZTRO1SdqRKdXfURXDJf6nhHPoUXD4MVrS96QpctWKA0JMoUrK0pP+tNdf1qYf4xdxm4hDbJvY35FgeFCmmdJqFhKLkohu/rzN19kR+CIQWY4SfNWstlAJpXmVwv4AGBDJcvETgSruhXNyqpBYOwGNRojhEDlVOfkf9OfsUw4Tq9lXc/Mme9JGs1wXOZ2O2c2TqyX4447Wg48cK4a91IE/8OFOhSLx6Wzq1s2b9oqvX39qmsW60VRKCjlIAZn2yExlKbDs+sgjtvrB3nZs57+FeuZLitWrFLa0evztUydOu2khQvvf9l6gveH3aNp9NxaO7MIqka+DB04th4rkDhIjIxs59OMIGfF9bHGY+gIskBs8NpMMM/Uh6MKeP/gB7hQFNtsKcDOX/qSHLJBQlC4qSJgyvsRBMtFCTWcwHNoFdDkZk9pdTwu/k7WxGiYWasseT32PZwwaYLMnb+/lFeWS3Fpsbp4BH5NqCTUm0okr92yyZoppw0aqH9gAPfl3HceKa8oU84+zTE2rLI90PazVIdT1EOf39dSXVVzzO233/6KuvkHwG4hjd/tttpq8pnI4c/WyEtdRUJGg4VC0mwjBM9gUt1kVGFR2sXoD+GQkb35FafhaOLPAt4/jj2WoxXNt8X0Wck497SN7YQbyiJPGVWuI7YDFox0qqHs9FXzyGbS7zmROYo6mF/FVVnYDINrMK0cEh7kt0pNaZretCpUWnIUSLieJn8imZDBwQFVr9jVZwi+0OBgOGP1IjFUlCykelOzf1wO+4c42vT1uXPmHXn33XfvUsfMd8JuIU04nOpCBqAQkIN4cWa2GnmJTGT37tFgqI8vZ3Emn/F5BAI+VTDskk5to4qJh4w6LJlMOZYsWbKdlCxg12EJLTtzrQy2zWiGggk10nME+X1cxbk8lpdgYsdNdrexwWtrowj0ztBq7Hsr5K/b09kj/Dxj46TGp8pKKo686l+uWg1WVjHETJORFgkjYn6fT3Xjcbld95WVVM3SDcf3hmPxF8IRa0KWBHwkWDuv1NXWH3/zzTfvUqfMd8NuIc35558fR0Z15n8qaUFVyVg6Y+WjskWpTWbqdmHLPNi+o8ZYsIGTIcZRTqkNnOrt7OwcF3P+jlVQ6MD/cOd/5mGZz/hvEQJbVJRzO+RLEgua3jZUnzAlKDkOxz5fe8/GQk3X3syvWsifW1peakVfB8P/fskll6gpmeLxeDF7m7BO0SRjpNXu5+YvCrSde+65K7/4uS//5OKLLj+ioW5ircPhvMjj9t1QU1V/1O9+9zt+c3e3YbeQJo+RPmgEpQAzUrXVqMywtlsOPtXw2yWR6suEcxgsYDCAEzJYBbl9AvFg8BbwftHa2uqB4LJaFLeDNfBMlREF244CNkq7WBqBRcpE8wyblIayygjlnMu857Dh5i2trVFoBfYBozAlUrgWrQyv3ytTZ84YsRWLAoFp1GY0DUkWRvZIIMLl9GzXlevUU0/t+MLnvvybCy/43DU7MxJzV7HbSIOM2sDMssGX4ssx7GxlrTpGZSobOEcXCPdyn+oMiHPstgK7K419HhPR39/dqFYKeF/o7V1r5aXK+HziAkvmPVeoadh1ZcdAWahWRvzHki33FJBsm1H74Is49J0IBJg5P+/Z0dml2masgWt+NSMRyVFbUTsSlYVZHiBZGZW1voTtUKYat0Hz7FIv5Q+K3UYaqMl1ihDIRJJC9ROCGo0NW9+CVDnMv1jQr6HqV1vzu3gMM0CN        sYDUoXnGRilu3zb1jzqQ8wNMVBcr4H2BE8LY+TmSoFwoqFQeEygL+qX5YtsO5Es2XyYEQ74kDCU/r6EEXibbpna+C2Ai1rHMLTJYg+G8Hq/aB1OPqmekdRxCto5Mto9jj2tqNtYjyN/3vNfuxG4jjeFydWwrALYO02kzrDEVDGPm9xE0AVSrMo4bvZ0LtuCOmGeQYHZB2oVBUg6Ew6M91AJ2EcXFOZ2CzU5W/uc7aqICW6VBc4v6Bshv4GFsi1Eb8udQoLGHMctF1+CPoozok2ZSyREf952A6wfZq50mudX50xqoyOeB+d5lRfksQAhP4HYey6T8LUU4kaDXvUc/ObjbSOPU9Q3WC1svrT4yBGefBOC4GgtWASlNgxe3wfy3C45RERYe+yLxXG5/K3G0XG6mdWYB7w8lEFhW5VZ5ms9blovK57x/Qb/TJhX+j4DCbjTh2LXFbqOh1lFlnki95wdncXgNr0WrhOYYNQ6fg0RyeVyx/GEKEKIl3E+y8HhqG94by0w67dyjAxN3G2mKijxbSRi+NF/GejFrwBnDzlbG50mDTGUm27/xRy15LqMijJpRy7CrONdVRqIgmRipCQ+Gv3r9DT+595Zbbpmbv30Bu4CsN+tW3e9RDna+UkOwOwxNYq5TgDEKqsqIJ7GcuIaazvKgZlHkwToDATxKlS0shO37Dr4zcF9nGvdkXVCMQ7LJDK01YnI98MADtbqmKSmr+r7lNQ3vARMyDo00YsbtCew20pxwwoIuZGrEylBrCABNNGobds8eIQgyl6aX3VajyKLIZu1nDJ6ShtP/sIMe97FQWTAkEickTCSTrlQyeU46k3r2Zz/72U5PvVOAhcHWwUaaVOxKwxZzlgfzl+s2kVgehCoflKddfrY2sJNqHkC5wFBS/dnY+MgBZgM9PcdDqL1r7w34QPuQpCOaBtt4X4aRsW9EU7W3twfpv/DeyncCYXi86ongMHZpfP/uwG4hzZIlS0J//vOfb00m0z5KMGY6wUAAfZeBgUGVwXYBsJCYARRbVuazQKxC4DlK0+R7tfJaiiww8RieHAABWUiqBVqTwauuuuo9becCtuGGG24IDg30XsPGPybmLSsfCUTisPzYl8wqQ8vPUeRg+ZFI+G+VWV7743h2nETRosySEosOq9b6SDjy/d6ezvaf/PiHj9x8839+duHChdv5oezKg3J3Kq2SJwTrAwUmr+l2uyPWkYycxWp4DKUshTC1DH/z2d3uPRs5Iz4wae68884rFy9evH7NmtVXDA2FDWscuKWe2VWcjZVDyEQ7o0kQ2s6EJbUsIjHzmBg942/6NNaIPpAFSw6d7untVcTh6D9kalsup5+Ja1gisYD3xLXXXjtnaLDvzXgy+UmOs0fFVoKJecyADQUTy46VkWVkmXAWgexE4WZpI+6HdgLZeDwFoT0vN+dMo4AEB0AM8/REKvmH5q7m7SKeGzdu9BqGHrC1l3LsAZY9txkOfbPaADidRp3VGG4dqwgE8N4et2uPRs6ID0yaSCQSgFquoPrk0FH6LywIkocqm6qUnS8twjBDaDtb0osRE1vDMLFQ2FWiqalJzfbOQuCHVXt7+tR3aRiXDxUXh/2BwLcNwznt6quv3m5IQgE7BicjufGG6692OvTXNE2fzHzu7uqWnp4eVcFpPjOvOf6JxIkn4ooQ9syX7I9GEqVBIiX0uI+EwXZO20STmaThBPhhlL8TVgBNLprg7H8cZbODlkvmH0cBvmuQS0UaLO2uO8qfwoasmVPz6RGoU9YXsXGs0kr5dd7TG/Dttu4xO4sPTBr4Lb8E+x9Vdikc/wjUc3dPr5pRkRlLMqiReHhBS1qBIFgy42liWYSxJJplJmSkpLREjZ/gNKYce07Hr7SkJIbfPwn4g5O+863v3AjC2CG5At4Da9as+mYqk74J9r+D2p8RSuZzd1eP6jXc1dmtPtJEgUetUVJcoionBR9/s2eGVTbweVB2JJIiTN6EpvSPkHBY97k5hp+zrDolg4o9GAmbw/H4V791xbe2q9yx2GDe5LJ+29qD9YObQIoR8wzkU5EzmoaKNKg3KghBy8TtHX/m2Ve/+tWBf736X88AAQ70eD1PcCCZ0+mWaAzSB5lbU1srpaVl+M0x35bZRvJQtTIjlIpXEssqAEo8RtBCRSF+T4TjJlIlxcW3OUPuad///v/7HsjyoX8ebm9DR0dbVWdXp3CgFyNk7BfIWSo5yTzbVkiWjvYO6enuUYKMn+bjuBaOX2GPDjV7DLQPp6xlmSptRLMZ+3julMmTZdKECezqosqOLfYplDGskLCZNE+75aZb3vbZepDWZ0fnyBKbFPRpCFcuN2Keob5UcD8tE4s0MOthoSjo+vgzz2x85zvfWfJv3/m3k1xO16EBv+/xUCiUKSkplbq6evUhoMGBoRH1T/KkGE7Gi1Na8RsmQyigPmUqDKkRnDg/GwwG73GHfNO++93vX/79b37/PeP+BewYEEqPIF+f7erqynXDJOOXyjImyOP3qXEoFeUVEFLFqPRBmVBfr4YYsx2Ec46xTFh2tv9jaZdh9ZuT+A3B17R7HZMw/DJEFGUcDg9tSCfSh9xyyy3/yD/GdnA49HqabyQKWUMycNXuXWCazhFzzjAcjawrIxN9KNJY/o2W08Zn9Gw0rrnmmpf/7d++d3LA75zt8Xnv9vv8WZKAKr2nt1+ZbSQPNQq3hcPwW7CNEosDnYphGkDL3Oct8h2E61xwzTeu2eOZsrfhzjt/98zvf3/XMU3TZs6Dc39Lb1/fZo6IpOZJphJiqAnIA2o4Mb/GzfEoNLE4+R+/I8OJKnrgW7LsLL91UPlCMZRhAMfxWPYZTENLDITVTDJvOjTnYb/85S9X5x/hbYA+UX3JWPltIkDtKE3I4NE555wzYs5hXxnNeBU1M3As/tkaqrSodKenXtpdwG0/XNx0000zYIL9v2w2cy5sYge1DKxRSLiQ6tTZ1tKufBaO9oRftAgO/nXQWvxabwEfIi666AvHDA/HP4e8/7Tb7fKx4qsJUdi2BhONvgXH7LPdhdpFSXqnQyoqq5RlQNOtCBYEmwiolTg0mf4n1h+d2TTzgveaPviOO351vT/gv2ZgaACarkzKK8pxX4ds2rIV5mCs518u+9rI/HbXX/+jtU63s4nzSoeKQ7BCSlTXLE7TNHf2Ac7R3W32BD500tgAeRrg8l8LvXueaea89GsoMCA9BgzdWO5waD+86qpv8XuIBexBXHvttYF161YvwOrFDqfjSJDHoM/DqWdd7BQJDcAJ9uh7Kn8UEp9mEsnFoAJNqv4hzlUWycI0/+Htt93+Q3Xh98Af//i7u50u4zN9AwNSWVmuZp4RU1PzkuE+6y6/+Ksj31S94T9/3Auzr8wLUtOcDAaLJRyN0Afr/foVV1XiGZWRt6ewx0hjAzZuEVRrMV7UhJTqb29vz1x33XW7fcxDAbuOyy77wsRwNHERVi9wOZ2T6aNQk1hTcrmtjpXQQiQSnfg4tFAnfKRoJDoMsn3hjtvuuM+60nvj9jt+dW8w6D9nMDzEr5CpGWRIznUbNsAM05+69MtfOSF/qPz0hh/n+A0bkobkCgSKVIQ2ncm0Xfrlyxr2etIUMD5A8y0eT3xJM7RPuV1uP3ufk0BYUQ4/zbG2jg6aapvdDvdpv/vd79bkT90p/P73v1miO/QDaPrx0xclpaWSSqRl7Yb1vP4jX/78xWfyuBtv/NEk0RybGDnzMeoHgvl9QfWlNPhCz1x60eXHqgvuQez2QEABewcYPLj77j9/obS4oiwYKPpJJp3t6OrsNvmJx3aQhfMhQ8M8E4/G5+0qYYg4ex3A6R+Z8Qag6UezXXc4Rrr6OxzuajuyZoecCbYduT3ujySiWiBNAe+KW2+9NXnLLbd+7/jjTmxoqG/cNxFPXheLDfdFo9FfdrV3nfjggw/u8vh79jvzejyz6CORNNYsNnY/RFNchmOk13IkEitTpGGImf/YsJkzVS8FaKQ93rBJFEhTwE7hvPPOy15//fVr/vCHu35w2aVfOei6/3fdN5599tn3FbVitCuZTBiM0DGMTB+JUA2bjCQb2kiDpcfjmqRIAzKpcDOOZW8A9kzQdGNL/rA9igJpCthlHHTQQZtmzZr1voM3S5YsKYfiMGyH2p6ZiN1icvin645tPZzTmaAiito+qmET+9wOR4911J5FgTQF7HG8+eZLLhBAY+UnaHZRw9hdaECeUb5KrpGEYcdfEsYijUWuaDL+gaaXfb8okKaAPY6ysvqJDFmzBwBBn4ZrdmdNp+Yc6Xdm6Ead3RtAmXL4Zw8n8Rm+d/wqwYeJAmkK2OPo7Gylphnl3FuGmuWn6JL0JEd6E8CXqVC+D7bb5hkDCFxfsICjhfc8CqQpYI+juLhkCis9GKASI2LUOhwegu3Dtf7aEZ9GM4xp1CrWcSSXJqlUEmSSFuuIPY8CaQrY4xgY6IPioJllTVFMLlDrcIyPw+HI2n3J/va3v7nh33hJGu63iMYpahNss/lIws1EgTQF7HH4fP4mpV0A5duANSSG+szHqOmNly171pPLmR42eJI0ijFY8vMtOTPbah2151EgTQF7HByXw/qvtAz9FPxTw6g5nZNj2ziadDowl2RRHUUzHDidU0t+hqW3t7/kxhtv9OcP3aMokKaAPQ7wwEGVYs0oZGkaNl6qQIAmIw2Wf/zjH7/X3d3NEaBqKIAarpAfEvDMomcP37Jly0fy/dUCaQrY44CGmcI2GU6Cr7QN/pEQ1CJOl3OkC006nT76r395UP5090J55OG/q1G9TK+9skQNzf75z3++3Zcq9hQKpClgz0MXJ7UKJ2NhJ0yCQQGqIE03RkgDXyZF8wz/pXlri/zXzf8jN9xwk5pJpzhU/DgOoaOzx1EgTQF7HKDJJDr3dtsLaz57ODMYABK1W0eJzJw5c9LMmTPa+Ylzy7fJqqmk3G73Q8uWLTstf9geR4E0BexxaJrhpmYhYdSgNrBGjeQFQKORVv6DDz54aMrkSaH5B8yT+QfOk5raGpkwoUHOPvus17HbOuEjQIE0BXwEyDWycyZBbUNNQ3ON2gTbRz7kpEb0anIlZ7uprqqS+fPmyuz9ZnGKsO0+wb+nUSBNAXsUCxcuDHHJ8DH/Wq38edLgn8Pp6FUb8rj99t/85oQTTj5/8uRJP6yorP5RbV3DgTfccMMf87s/ElhPXEABewg33XRTUyDoWcvoWXFxkRrz73J6pbW9XTo7OmT/WXMDJ5988nbfphlrKGiaAvYoDCNXQllt9VSmtuEcZtb3iNjQ6XK5tpvzeSyiQJoC9ijC4XClNQk+5/kmaawvBfAzHelMun1Pz2H2flAgTQF7FB6PbypJwvm77c+vM5TMuaKz6axceumlzvyhYxYF0hSwx3Duuee6Xn/jjUv59QFOqs5ezewJwEky2Alz2dJltYtfWnxO/vAxiwJpCthjgL9y8AuLX5zx6KOPyYuLX1JfKiCB6M+8+tKr8sLzL0hFaUXBPCugABu6U6+mL7Nq1WpZu2a9/PWvD8kTjz8lzz23WNasXsNWz1xJScmK/OFjFtY32wooYA9gzuw5Q52dndOz2WwT22To12zauFnWrVuvAgH7zdr32kcf/dtf8oePWRTaaQrYo7j44osnaZq5aeXK1dLX36/IQhx22KEdZ5/9iYnnnXfemJ/Xu2CeFbBHMWfOnFDOzJlz5+4vhx5ykKjloQdLbW3tqvFAGKJAmgL2KK644oo33R7XKalU+rni4mKZ0NAgZWXlLYlE8if5Q8Y4RP4/c86DeLAqmJYAAAAASUVORK5CYII=" style="top: 97px; height: 162px; width: 205px; position: absolute; left: 138px"></img>
        <label id="lbl3" style="text-align: right; width: 158px; height: 22px; left: 132px; position: absolute; top: 297px">Average cycle time :</label>
        <label id="lblAvCT" style="width: 50px; height: 22px; left: 300px; position: absolute; top: 297px">0</label>
        <select size="2" style="left: 8px; position: absolute; top: 357px; width: 464px; height: 276px; text-align: left; font-family: Roboto Mono;" id="Timer0">
          <option>Option1</option>
          <option style="background-color: #00FFDD">Option2</option>
          <option>Option3</option>
          <option style="background-color: #00FFDD">Option4</option>
          <option>Option5</option>
          <option style="background-color: #00FFDD">Option6</option>
          <option>Option7</option>
          <option style="background-color: #00FFDD">Option8</option>
          <option>Option9</option>
          <option style="background-color: #00FFDD">Option10</option>
          <option>Option11</option>
          <option style="background-color: #00FFDD">Option12</option>
          <option>Option13</option>
          <option style="background-color: #00FFDD">Option14</option>
          <option>Option15</option>
          <option style="background-color: #00FFDD">Option16</option>
          <option>Option17</option>
          <option style="background-color: #00FFDD">Option18</option>
          <option>Option19</option>
          <option style="background-color: #00FFDD">Option20</option>
          <option>Option21</option>
          <option style="background-color: #00FFDD">Option22</option>
          <option>Option23</option>
          <option style="background-color: #00FFDD">Option24</option>
          <option>Option25</option>
          <option style="background-color: #00FFDD">Option26</option>
          <option>Option27</option>
          <option style="background-color: #00FFDD">Option28</option>
          <option>Option29</option>
          <option style="background-color: #00FFDD">Option30</option>
          <option>Option31</option>
          <option style="background-color: #00FFDD">Option32</option>
          <option>Option33</option>
          <option style="background-color: #00FFDD">Option34</option>
          <option>Option35</option>
          <option style="background-color: #00FFDD">Option36</option>
          <option>Option37</option>
          <option style="background-color: #00FFDD">Option38</option>
          <option>Option39</option>
          <option style="background-color: #00FFDD">Option40</option>
          <option>Option41</option>
          <option style="background-color: #00FFDD">Option42</option>
          <option>Option43</option>
          <option style="background-color: #00FFDD">Option44</option>
          <option>Option45</option>
          <option style="background-color: #00FFDD">Option46</option>
          <option>Option47</option>
          <option style="background-color: #00FFDD">Option48</option>
          <option>Option49</option>
        </select>
        <label style="text-align: center; width: 464px; height: 22px; left: 8px; position: absolute; top: 326px" id="lbl3_Copy1">Timestamps from current cycle:</label>
      </body>
    </html>
    """
  hmi.write(message)
  hmi.close
  return

# Write Bindings JSON
def writeJSONBindingsInterface(bindings):
  global bTracking
  if bTracking==True:
    message = """{
    "version": "1.0",
    "bindings": [
      {
        "id": "btnStartStop",
        "attribute": "innerHTML",
        "data": "sBtnStartStop[0]",
        "size": 1,
        "direction": "r",
        "refresh": 1
      },
      {
        "id": "btnStartStop",
        "attribute": "disabled",
        "data": "bDisStartStop[0]",
        "size": 1,
        "direction": "r",
        "refresh": 1
      },
      {
        "id": "lblUserMessage",
        "attribute": "innerHTML",
        "data": "sUserMessage[0]",
        "size": 1,
        "direction": "r",
        "refresh": 1
      },
      {
        "id": "lblMissedPick",
        "attribute": "innerHTML",
        "data": "nMissedPick[0]",
        "size": 1,
        "direction": "r",
        "refresh": 1
      },
      {
        "id": "lblMissedPlace",
        "attribute": "innerHTML",
        "data": "nMissedPlace[0]",
        "size": 1,
        "direction": "r",
        "refresh": 1
      },
      {
        "id": "lblAvCT",
        "attribute": "innerHTML",
        "data": "sAverageCT[0]",
        "size": 1,
        "direction": "r",
        "refresh": 1
      },
      {
        "id": "nmbStepPick",
        "attribute": "value",
        "data": "nStepPick[0]",
        "size": 1,
        "direction": "r1w",
        "refresh": 1
      },
      {
        "id": "nmbStepPlace",
        "attribute": "value",
        "data": "nStepPlace[0]",
        "size": 1,
        "direction": "r1w",
        "refresh": 1
      },
      {
        "id": "nmbSpeedOUT",
        "attribute": "value",
        "data": "aEncoder[1]",
        "size": 1,
        "direction": "r1w",
        "refresh": 1
      },
      {
        "id": "nmbSpeedIN",
        "attribute": "value",
        "data": "aEncoder[0]",
        "size": 1,
        "direction": "r1w",
        "refresh": 1
      },
      {
        "id": "nmbDistOutIN",
        "attribute": "value",
        "data": "nDistOutConvIN[0]",
        "size": 1,
        "direction": "r1w",
        "refresh": 1
      },
      {
        "id": "nmbDistOUTOut",
        "attribute": "value",
        "data": "nDistOutConvOUT[0]",
        "size": 1,
        "direction": "r1w",
        "refresh": 1
      },
      {
        "id": "Timer0",
        "attribute": "options",
        "data": "sTimer0[0]",
        "size": 49,
        "direction": "r",
        "refresh": 1
      }
    ],
    "callbacks": [
      {
        "id": "btnStartStop",
        "event": "click",
        "data": "click_StartStop",
        "priority": 10
      }
    ],
    "events": []
  }"""
  else:
    message = """{
    "version": "1.0",
    "bindings": [
      {
        "id": "btnStartStop",
        "attribute": "innerHTML",
        "data": "sBtnStartStop[0]",
        "size": 1,
        "direction": "r",
        "refresh": 1
      },
      {
        "id": "btnStartStop",
        "attribute": "disabled",
        "data": "bDisStartStop[0]",
        "size": 1,
        "direction": "r",
        "refresh": 1
      },
      {
        "id": "lblUserMessage",
        "attribute": "innerHTML",
        "data": "sUserMessage[0]",
        "size": 1,
        "direction": "r",
        "refresh": 1
      },
      {
        "id": "lblAvCT",
        "attribute": "innerHTML",
        "data": "sAverageCT[0]",
        "size": 1,
        "direction": "r",
        "refresh": 1
      },
      {
        "id": "Timer0",
        "attribute": "options",
        "data": "sTimer0[0]",
        "size": 49,
        "direction": "r",
        "refresh": 1
      }
    ],
    "callbacks": [
      {
        "id": "btnStartStop",
        "event": "click",
        "data": "click_StartStop",
        "priority": 10
      }
    ],
    "events": []
  }"""
  bindings.write(message)
  bindings.close
  return

def writeTimerCall(code, routine, timerName):
  if timerName == "":
    timerName=routine.Name
    if timerName == "":
      timerName = "Timer"
  code.write(indent*depth + "call timer(\"%s\")\n" % timerName)

# RSL Call statement is equivalent to VAL3 instruction: call
def writeCall(code, routine, statement):
  targetRoutine = statement.getProperty("Routine").Value

  # Add timing of routine execution
  writeTimerCall(code, targetRoutine, "begin " + targetRoutine.Name )
  code.write(indent*depth + "call %s()\n" % targetRoutine.Name)
  writeTimerCall(code, targetRoutine, "end " + targetRoutine.Name )

# RSL Return statement is equivalent to VAL3 instruction: return
def writeReturn(code, routine, statement):
  code.write(indent*depth + "return\n")

# RSL Comment statement is equivalent to VAL3 instruction: //
def writeComment(code, routine, statement):
  global bTracking
  cmt = statement.Comment
  # Check for keywords:
  if cmt == "waitEndMove()":
    code.write(indent*depth + "waitEndMove()\n")
  elif cmt.startswith("timer "):
    writeTimerCall(code, routine, cmt[6:])
  elif cmt == "resetConv1" and bfMoving_1==True and CONVEYOR_TRACKING_ENABLED:
    code.write(indent*depth + "wait($initMobile(fMoving_1,trDetection[0])==true)\n")
  elif cmt == "resetConv2" and bfMoving_2==True  and CONVEYOR_TRACKING_ENABLED:
    code.write(indent*depth + "wait($initMobile(fMoving_2,trDetection[1])==true)\n")
  elif cmt == "lastMove":
    code.write(indent*depth + "bLastMove=true\n")
  else:
      code.write(indent*depth + "// %s\n" % statement.Comment)

# RSL Halt statenent can be used to write stopMove() instruction
def writeHalt(code, routine, statement):
  code.write(indent*depth + "stopMove()\n")

# RSL Delay statement is equivalent to VAL3 instruction: delay(...)
def writeDelay(code, routine, statement):
  code.write(indent*depth + "delay(%s)\n" % statement.Delay)

def writeDefineBase(code, routine, statement):
  if (statement.Base != None):
    name = statement.Base.Name
    name = parseVariableName(name)
    # Rename *NULL*
    if name == "":
      name = "fDefault"
    m = vcMatrix.new(statement.Position)
    # Find from bases
    for i in frames:
      if i.Name == name:
        # Transform position matrix orientation
        o = transformOrientation(m)
        # If relative checked
        if (statement.IsRelative == True):
          # Translate matrix
          code.write(indent*depth + "%s.trsf = %s.trsf * {%s, %s, %s, %s, %s, %s}\n" % (name, name, m.P.X, m.P.Y, m.P.Z, o[0], o[1], o[2]))
        else:
          code.write(indent*depth + "%s.trsf = {%s, %s, %s, %s, %s, %s}\n" % (name, i.x, i.y, i.z, i.Rx, i.Ry, i.Rz))

def writeDefineTool(code, routine, statement):
  if (statement.Tool != None):
    name = statement.Tool.Name
    name = parseVariableName(name)
    # Rename *NULL*
    if name == "":
      name = "tDefault"
    m = vcMatrix.new(statement.Position)
    # Find from tools
    for i in tools:
      if i.Name == name:
      # Transform position matrix orientation
        o = transformOrientation(m)
        # If relative checked
        if (statement.IsRelative == True):
          code.write(indent*depth + "%s.trsf = %s.trsf * {%s, %s, %s, %s, %s, %s}\n" % (name, name, m.P.X, m.P.Y, m.P.Z, o[0], o[1], o[2]))
        else:
          code.write(indent*depth + "%s.trsf = {%s, %s, %s, %s, %s, %s}\n" % (name, i.x, i.y, i.z, i.Rx, i.Ry, i.Rz))

# RSL Point to Point statement is equivalent to VAL3 instruction: moveJ(...)
def writePtpMotion(code, routine, statement):
  global bTrackingRSL
  statement.writeToTarget(motiontarget)
  tName = motiontarget.ToolName
  tName = parseVariableName(tName)
  if tName == "":
    tName = "tDefault"
  position = statement.Positions[0]

  # Find motion description variable name
  motionVariable = getMotionDescriptionVariableName(statement)

  for i in points:
    if i.Name == position.Name:
      if "fConveyor" in i.RefFrameName and CONVEYOR_TRACKING_ENABLED:
        code.write(indent*depth + "nMoveID=$trackOn(%s, %s, %s)\n" % ("j" + position.Name, tName, motionVariable))
        bTrackingRSL=True 
      else:
        if bTrackingRSL==False:
          code.write(indent*depth + "nMoveID=movej(%s, %s, %s)\n" % ("j" + position.Name, tName, motionVariable))
        else:
          code.write(indent*depth + "nMoveID=$trackOff(%s, %s, %s)\n" % ("j" + position.Name, tName, motionVariable))
          bTrackingRSL=False 

# RSL Linear motion statement is equivalent to VAL3 instruction: movel(...)
def writeLinMotion(code, routine, statement):
  global bTrackingRSL,bTracking
  statement.writeToTarget(motiontarget)
  tName = motiontarget.ToolName
  tName = parseVariableName(tName)
  if tName == "":
    tName = "tDefault"
  position = statement.Positions[0]

  # Find motion description variable name
  motionVariable = getMotionDescriptionVariableName(statement)

  for i in points :
    if i.Name == position.Name:
      if "fConveyor" in i.RefFrameName and CONVEYOR_TRACKING_ENABLED:
        code.write(indent*depth + "nMoveID=$movelt(%s, %s, %s)\n" % (position.Name, tName, motionVariable))
        bTrackingRSL=True 
      else:
        if bTrackingRSL==False:
          code.write(indent*depth + "nMoveID=movel(%s, %s, %s)\n" % (position.Name, tName, motionVariable))
        else:
          code.write(indent*depth + "nMoveID=$trackOff(%s, %s, %s)\n" % (position.Name, tName, motionVariable))
          bTrackingRSL=False 

def getMotionDescriptionVariableName(statement):
  for mDesc in motionDescriptions:
    if statement in mDesc.Statements:
      return "%s[%s]" % (MotionDescription.VariableName, mDesc.VariableIndex)

def writeSetBin(code, routine, statement):
  # Convert the integer presenting a boolean value to the string
  val = "false"
  if statement.OutputValue:
    val = "true"

  # Check that I/O exists in mappings
  found = False

  for i in outputMappings:
    if str(statement.OutputPort) == i.VCPort:
      code.write(indent*depth + "// %s\n" % (i.Comment))
      
      # Wait for movement to end even if asynchronous movement is used.
      if not USE_SYNCHRONOUS_MOVEMENT:
        code.write(indent*depth + "waitEndMove()\n")
      code.write(indent*depth + "%s = %s\n" % (i.VariableName, val))
      found = True
      break
      
  if found == False:
    # Warning: Unmapped robot component output port '%s'
    writeWarningMessage("StaubliPPWarningUnmappedOutputPort", [statement.OutputPort])
    if (writeUnmapped == True):
      code.write(indent*depth + "// dOut%s = %s Note: Unmapped signal\n" % (statement.OutputPort, val))

def writeWaitBin(code, routine, statement):
  # Convert the integer presenting a boolean value to string
  val = "false"
  if statement.InputValue == 1:
    val = "true"
  found = False
  # Check that I/O exists in mappings
  for i in inputMappings:
    if str(statement.InputPort) == i.VCPort:
      code.write(indent*depth + "// %s\n" % (i.Comment))
      code.write(indent*depth + "wait (%s == %s)\n" % (i.VariableName, val))
      found = True
      break
  if found == False:
    # Warning: Unmapped robot component input port '%s'
    writeWarningMessage("StaubliPPWarningUnmappedInputPort", [statement.InputPort])
    if (writeUnmapped == True):
      code.write(indent*depth + "// wait (dIn%s == %s) Note: Unmapped signal\n"  % (statement.InputPort, val))

# While block
def writeWhile(code, routine, statement):
  global depth
  _condition = replaceVariablesInExpression(statement.Condition, routine)
  _condition = replaceOperatorsInExpression(_condition)
  code.write(indent*depth + "\n")
  code.write(indent*depth + "while %s\n" % _condition)
  depth += 1
  
  if not statement.Scope.Statements:
    # Warning: Empty while loop in '%s'.
    writeWarningMessage("StaubliPPWarningEmptyWhileLoop", [routine.Name])
  
  # Process statements in sub scope
  writeStatementsInScope(code, routine, statement.Scope)
  
  depth -= 1
  code.write(indent*depth + "endWhile\n")

# If-else block
def writeIf(code, routine, statement):
  global depth
  _condition = replaceVariablesInExpression(statement.Condition, routine)
  _condition = replaceOperatorsInExpression(_condition)
  code.write(indent*depth + "\n")
  code.write(indent*depth + "if %s\n" % _condition)
  
  depth += 1
  writeStatementsInScope(code, routine, statement.ThenScope)
  depth -= 1

  if statement.ElseScope.Statements:
    code.write(indent*depth + "else\n")
    depth += 1
    writeStatementsInScope(code, routine, statement.ElseScope)
    depth -= 1
  code.write(indent*depth + "endIf\n")

# Variable assignment
def writeSetProperty(code, routine, statement):
  _target = replaceVariablesInExpression(statement.TargetProperty, routine)
  _value = replaceVariablesInExpression(statement.ValueExpression, routine)
  code.write(indent*depth + "%s = %s\n" % (_target, _value))

# Write text to the controller's screen
def writePrint(code, routine, statement):
  global isCS9
  if not isCS9:
    code.write(indent*depth + 'putln("%s")\n' % statement.Message)

# Called when a function for the statement type is not defined in statement_translators
def unknownStatement(code, routine, statement):
  # Unsupported statement of type '%s' skipped in sequence '%s'.
  writeWarningMessage("StaubliPPWarningUnsupportedStatement", [statement.Type, routine.Name])

statement_translators = {
  VC_STATEMENT_DEFINE_BASE:writeDefineBase,
  VC_STATEMENT_DEFINE_TOOL:writeDefineTool,
  VC_STATEMENT_HALT:writeHalt,
  VC_STATEMENT_WAITBIN:writeWaitBin,
  VC_STATEMENT_SETBIN:writeSetBin,
  VC_STATEMENT_DELAY:writeDelay,
  VC_STATEMENT_COMMENT:writeComment,
  VC_STATEMENT_CALL:writeCall,
  VC_STATEMENT_RETURN:writeReturn,
  VC_STATEMENT_LINMOTION:writeLinMotion,
  VC_STATEMENT_PTPMOTION:writePtpMotion,
  VC_STATEMENT_WHILE:writeWhile,
  VC_STATEMENT_IF:writeIf,
  VC_STATEMENT_SETPROPERTY:writeSetProperty,
  VC_STATEMENT_PRINT:writePrint
}

# Replaces known variable names in a VC robot program expression
def replaceVariablesInExpression(expression, routine):
  result = expression
  allVariables = variables.globals[:]
  allVariables.extend(variables.constants)
  allVariables.extend(variables.routines[routine.Name])

  for var in allVariables:

    # The parsing won't work for all variables with invalid names and those will cause syntax errors anyway
    if not isValidVariableName(var.Name): continue
    
    # Find instances of this variable by requiring that it is surrounded by 
    # non-legal characters for variable names, or it is at the end of the string.
    _pattern = "(?<=\W)%s(?=\W|$)" % var.Name
    result = re.sub(_pattern, var.Val3Name, result)

    # Separate search needed for start of string because look-behind requires fixed-width pattern
    _pattern = "^%s(?=\W|$)" % var.Name
    result = re.sub(_pattern, var.Val3Name, result)

  return result

# The first elements are evaluated as regex so they need to be escaped
operatorReplacements = [("&&", "and"), ("\|\|", "or")]

def replaceOperatorsInExpression(expression):
  result = expression
  for oper in operatorReplacements:
    # Match operator and zero or more space on each side
    _pattern = r"\s*" + oper[0] + r"\s*"
    # Add single space on each side
    result = re.sub(_pattern, " " + oper[1] + " ", result)
  
  return result

# Writes a program file (.pgx) for the given program
def writeProgramFile(program, routine, progName):
  global bTrackingRSL, depth, isCS9, bTracking
  # Create a new xml document
  doc = xml.dom.minidom.Document()
  Programs_el = doc.createElement("Programs")
  Programs_el.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
  Programs_el.setAttribute("xmlns", "http://www.staubli.com/robotics/VAL3/Program/2")
  doc.appendChild(Programs_el)
  Program_el = doc.createElement("Program")
  Program_el.setAttribute("name",  progName)
  Programs_el.appendChild(Program_el)

  # Write code to a memory stream instead of concatenating strings
  code = StringIO.StringIO()
  code.write("begin\n")
  
  # Write "stop" program
  if routine == None and progName == "stop":
    code.write("  resetMotion()\n")
  # Write "start" program
  elif routine == None and progName == "start":
    if bTracking==True and CONVEYOR_TRACKING_ENABLED:
      code.write("  // Init tracking parameters\n")
      if bTrackingPick==True:
        code.write("  call initTracking_1()\n")
      if bTrackingPlace==True:
        code.write("  call initTracking_2()\n")
    if not isCS9:
        code.write("  //Launch HMI\n")
        code.write("  taskCreate \"HMI\",10,HMI()\n")
    code.write("  // Init robot\n")
    code.write("  call initRobot()\n")
    code.write("  // Robot Cycle\n")
    code.write("  call robotCycle()\n")
  # Write "initRobot" program
  elif routine == None and progName == "initRobot":
    code.write("  //User interface\n")
    code.write("  bStart=false\n")
    code.write("  bDisStartStop=true\n")
    code.write("  sUserMessage=\"\"\n")
    if(isCS9):
      code.write("  userPage(\"HMI\")\n")
    else:
      code.write("  userPage()\n")
      
    code.write("  // Move to start position\n")
    code.write("  sUserMessage=\"Moving to jStart\"\n")
    code.write("  movej(jStart,flange,mNomSpeed)\n")
    code.write("  waitEndMove()\n")
    code.write("  bDisStartStop=false\n")
    code.write("  // Set working mode to auto/local\n")
    code.write("  nWorkingMode=workingMode(nWorkingStatus)\n")
    code.write("  if nWorkingMode!=3\n")
    code.write("    sUserMessage=\"Change working mode to Auto/Local\"\n")
    code.write("    wait(workingMode()==3)\n")
    code.write("  endIf\n")
    code.write("  //\n  // Enable arm power\n")
    code.write("  if !isPowered()\n")
    code.write("    sUserMessage=\"Enable Arm Power\"\n")
    code.write("    wait(isPowered())\n")
    code.write("  endIf\n")
    code.write("  //\n  // Set to Move (programmed movement)\n")
    code.write("  nWorkingMode=workingMode(nWorkingStatus)\n")
    code.write("  if nWorkingStatus!=0\n")
    code.write("    sUserMessage=\"Push the Move/Hold button\"\n")
    code.write("    while nWorkingStatus!=0\n")
    code.write("      nWorkingMode=workingMode(nWorkingStatus)\n")
    code.write("    endWhile\n")
    code.write("  endIf\n")
    code.write("  //\n  // Set monitor speed to 100%\n")
    code.write("  if getMonitorSpeed()<100\n")
    code.write("    sUserMessage=\"Set monitor speed to 100%\"\n")
    code.write("    wait(getMonitorSpeed()==100)\n")
    code.write("  endIf\n")

  # Write "HMI" program
  elif routine == None and progName == "HMI":
    Locals_el = doc.createElement("Locals")
    Program_el.appendChild(Locals_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_nKey")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    code.write("  cls()\n")
    code.write("  cls(sStepTime[0])\n")
    code.write("  cls(sStepTime[1])\n")
    code.write("  cls(sStepTime[2])\n")
    code.write("  cls(sStepTime[3])\n")
    code.write("  sUserMessage=\"Push the START button\"\n")
    code.write("  title(\"VC Post Processor v: %s\")\n"  % PPVersion)
    code.write("  title(sStepTime[0],\" Times1: F7 LastPage; F8 NextPage\")\n")
    code.write("  title(sStepTime[1],\" Times2: F7 LastPage; F8 NextPage\")\n")
    code.write("  title(sStepTime[2],\" Times3: F7 LastPage; F8 NextPage\")\n")
    code.write("  title(sStepTime[3],\" Times4: F7 LastPage; F8 FirstPage\")\n")
    code.write("  getKey()\n")
    code.write("  while true\n")
    code.write("    cls()\n")
    code.write("    gotoxy(0,1)\n")
    code.write("    putln(sUserMessage)\n")
    code.write("    if(!bDisStartStop)\n")
    code.write("      gotoxy(0,13)\n")
    code.write("      put(sBtnStartStop)\n")
    code.write("    endIf\n")
    code.write("    gotoxy(34,13)\n")
    code.write("    put(\"Times\")\n")
    code.write("    gotoxy(0,3)\n")
    if bTracking==True:
      code.write("    put(\"Missed Pick : \")\n")
      code.write("    putln(toString(\"\",nMissedPick))\n")
      code.write("    put(\"Missed Place : \")\n")
      code.write("    putln(toString(\"\",nMissedPlace))\n")
    code.write("    put(\"Average cycle time : \")\n")
    code.write("    putln(sAverageCT)\n")
    code.write("    putln(\"\")\n")
    if bTracking==True:
      code.write("    put(\" Step Pick: \")\n")
      code.write("    put(toString(\"\",nStepPick))\n")
      code.write("    put(\"    Step Place : \")\n")
      code.write("    putln(toString(\"\",nStepPlace))\n")
      code.write("    put(\"  Speed IN: \")\n")
      code.write("    put(toString(\".1\",aioGet(aEncoder[0])))\n")
      code.write("    put(\"   Speed OUT: \")\n")
      code.write("    putln(toString(\".1\",aioGet(aEncoder[1])))\n")
      code.write("    put(\"DistOut IN: \")\n")
      code.write("    put(toString(\"\",nDistOutConvIN))\n")
      code.write("    put(\"   DistOut OUT: \")\n")
      code.write("    putln(toString(\"\",nDistOutConvOUT))\n")
    code.write("    l_nKey= getKey()\n")
    code.write("    switch(l_nKey)\n")
    code.write("      case 271\n")
    code.write("        bStart=!bStart\n")
    code.write("        if sBtnStartStop==\"STOP\"\n")
    code.write("          bDisStartStop=true\n")
    code.write("          sBtnStartStop=\"\"\n")
    code.write("        endIf\n")
    code.write("      break\n")
    code.write("      case 278\n")
    code.write("        userPage(sStepTime[0])\n")
    code.write("      break\n")
    code.write("    endSwitch\n")
    code.write("    l_nKey= getKey(sStepTime[0])\n")
    code.write("    switch(l_nKey)\n")
    code.write("      case 277\n")
    code.write("        userPage()\n")
    code.write("      break\n")
    code.write("      case 278\n")
    code.write("        userPage(sStepTime[1])\n")
    code.write("      break\n")
    code.write("    endSwitch\n")
    code.write("    l_nKey= getKey(sStepTime[1])\n")
    code.write("    switch(l_nKey)\n")
    code.write("      case 277\n")
    code.write("        userPage(sStepTime[0])\n")
    code.write("      break\n")
    code.write("      case 278\n")
    code.write("        userPage(sStepTime[2])\n")
    code.write("      break\n")
    code.write("    endSwitch\n")
    code.write("    l_nKey= getKey(sStepTime[2])\n")
    code.write("    switch(l_nKey)\n")
    code.write("      case 277\n")
    code.write("        userPage(sStepTime[0])\n")
    code.write("      break\n")
    code.write("      case 278\n")
    code.write("        userPage(sStepTime[3])\n")
    code.write("      break\n")
    code.write("    endSwitch\n")
    code.write("    l_nKey= getKey(sStepTime[3])\n")
    code.write("    switch(l_nKey)\n")
    code.write("      case 277\n")
    code.write("        userPage(sStepTime[2])\n")
    code.write("      break\n")
    code.write("      case 278\n")
    code.write("        userPage()\n")
    code.write("      break\n")
    code.write("    endSwitch\n")
    code.write("    delay(0.1)\n")
    code.write("  endWhile\n")

   # Write "robotCycle" program
  elif routine == None and progName == "robotCycle":
    Locals_el = doc.createElement("Locals")
    Program_el.appendChild(Locals_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_nClock")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_Size")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_Index")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_i")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_nTime")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_nTotTime")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    code.write("  sUserMessage=\"Push the START button\"\n")
    code.write("  sBtnStartStop=\"START\"\n")
    code.write("  wait(bStart)\n")
    code.write("  sUserMessage=\"\"\n")
    code.write("  sBtnStartStop=\"STOP\"\n")
    code.write("  //\n  // Reset timer + loop\n")
    code.write("  l_nClock=clock()\n")
    code.write("  nLoop=0\n")
    code.write("  nIndex = 0\n")
    code.write("  taskCreate \"tTimer\",100,taskOfTimer()\n")
    code.write("  wait(taskStatus(\"tTimer\")==1)\n")
  
    if bTracking==True and CONVEYOR_TRACKING_ENABLED:
      if bTrackingPick:
        code.write("  //\n  //Initialize frame fMmoving_1 at trDetection\n")
        code.write("  wait($initMobile(fMoving_1,trDetection[0])==true)\n")
      if bTrackingPlace:
        code.write("  //Initialize frame fMmoving_2 at trDetection\n")
        code.write("  wait($initMobile(fMoving_2,trDetection[1])==true)\n")
      code.write("  //Initialize offsets\n")
      code.write("  nOffsetPick=0\n")
      code.write("  nOffsetPlace=0\n")

    code.write("\n")
    code.write("  // Main program cycle\n")
    code.write("  while bStart\n")

    code.write("\n")
    code.write("    // Clear collected timestamps\n")
    code.write("    for l_i = 0 to min(size(sTimer0), size(nTimer)) - 1\n")
    code.write("      sTimer0[l_i] = \"\"\n")
    code.write("      nTimer[l_i] = 0\n")
    code.write("    endFor\n")

    if isCS9 == False:
      code.write("    cls(sStepTime[0])\n")
      code.write("    cls(sStepTime[1])\n")
      code.write("    cls(sStepTime[2])\n")
      code.write("    cls(sStepTime[3])\n")
        
    code.write("\n")
    code.write("    // Store time at start of cycle for timestamps\n")
    code.write("    nCycleStartClk = clock()\n")

    if bTracking==True and CONVEYOR_TRACKING_ENABLED:
      if(SmartTrackBase.RslPick):
        #code.write("    call timer(\"" + SmartTrackBase.ProgramPick +"\")\n") 
        code.write("    call " + SmartTrackBase.ProgramPick +" ()\n") 
        #code.write("    call timer(\"" + SmartTrackBase.ProgramPick +"\")\n")
      else:
        #code.write("    call timer(\"Pick\")\n")
        code.write("    call trackingPick()\n")
        #code.write("    call timer(\"Pick\")\n")
      if(SmartTrackBase.RslBetween):
        #code.write("    call timer(\"" + SmartTrackBase.ProgramBetween +"\")\n")
        code.write("    call " + SmartTrackBase.ProgramBetween +" ()\n")
        #code.write("    call timer(\"" + SmartTrackBase.ProgramBetween +"\")\n")
      if(SmartTrackBase.RslPlace):
        #code.write("    call timer(\"" + SmartTrackBase.ProgramPlace +"\")\n")
        code.write("    call " + SmartTrackBase.ProgramPlace +" ()\n") 
        #code.write("    call timer(\"" + SmartTrackBase.ProgramPlace +"\")\n")
      else:
        #code.write("    call timer(\"Place\")\n")
        code.write("    call trackingPlace()\n")
        #code.write("    call timer(\"Place\")\n")
    else:
      code.write("    call main()\n")

    code.write("      waitEndMove()\n")
    code.write("      if nLoop == 0\n")
    code.write("        nTraceNum = nIndex\n")
    code.write("      endIf\n") 
    code.write("      nIndex=0\n")  
    
    if not isCS9:
      code.write("      gotoxy(sStepTime[0],0,0)\n")
      code.write("      gotoxy(sStepTime[1],0,0)\n")
      code.write("      gotoxy(sStepTime[2],0,0)\n")
      code.write("      gotoxy(sStepTime[3],0,0)\n")

    code.write("    // Timer + loop display\n")
    code.write("    l_nTime = clock()-l_nClock\n")
    code.write("    sUserMessage=\"Timer [\"+toString(\"\",nLoop)+\"] = \"+toString(\".3\",l_nTime)\n")
    code.write("    l_nTotTime = l_nTotTime + l_nTime\n")
    code.write("    nLoop=nLoop+1\n")
    code.write("    sAverageCT = toString(\".3\",round((l_nTotTime / nLoop)*100)/100) +\"s\"\n")
    code.write("    l_nClock=clock()\n")
    code.write("  endWhile\n")
    code.write("  waitEndMove()\n")
    code.write("  taskKill(\"tTimer\")\n")
  
  elif routine == None and progName == "click_StartStop":
    # Write "click_StartStop" program
    code.write("  bStart=!bStart\n")
    code.write("  if sBtnStartStop==\"STOP\"\n")
    code.write("    bDisStartStop=true\n")
    code.write("    sBtnStartStop=\"\"\n")
    code.write("  endIf\n")

  # Write "initTracking_1" program
  elif routine == None and progName == "initTracking_1" :
    # Create local variables
    Locals_el = doc.createElement("Locals")
    Program_el.appendChild(Locals_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_nComDelay")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_nFilterLength")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    code.write("  // Filter length (in seconds)\n")  
    code.write("  l_nFilterLength=0.08\n")
    code.write("  // Put here the encoder communication delay (in seconds)\n")
    code.write("  l_nComDelay=0\n")   
    code.write("  // aio=velocity in mm/s\n") 
    code.write("  aioSet(aEncoder[0],nConvSpeed[0])\n")  
    code.write("  // Simulated conveyor\n")
    code.write("  // The frame may be already conveyor (previous run)\n")
    if bTrackingPick==True :
      code.write("  $setMobile(fConveyor_1,false)\n")   
      code.write("  // Simulated = velocity mode\n")  
      code.write("  $setConv(fConveyor_1,aEncoder[0],"+ chr(34) +"vel"+ chr(34)+",{1,0,0,0,0,0},l_nFilterLength,l_nComDelay)\n")
      code.write("  // Mobile frame\n")  
      code.write("  $setMobile(fMoving_1,true)\n")  
  
  # Write "initTracking_2" program
  elif routine == None and progName == "initTracking_2" :
    # Create local variables
    Locals_el = doc.createElement("Locals")
    Program_el.appendChild(Locals_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_nComDelay")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_nFilterLength")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    code.write("  // Filter length (in seconds)\n")  
    code.write("  l_nFilterLength=0.08\n")
    code.write("  // Put here the encoder communication delay (in seconds)\n")
    code.write("  l_nComDelay=0\n")   
    code.write("  // aio=velocity in mm/s\n") 
    code.write("  aioSet(aEncoder[1],nConvSpeed[1])\n")  
    if bTrackingPlace==True :
      code.write("  // Simulated conveyor\n")
      code.write("  // The frame may be already conveyor (previous run)\n")
      code.write("  $setMobile(fConveyor_2,false)\n")   
      code.write("  // Simulated = velocity mode\n")  
      code.write("  $setConv(fConveyor_2,aEncoder[1],"+ chr(34) +"vel"+ chr(34)+",{1,0,0,0,0,0},l_nFilterLength,l_nComDelay)\n")  
      code.write("  // Mobile frame\n")  
      code.write("  $setMobile(fMoving_2,true)\n")

  # Write "trackingPick" program
  elif routine == None and progName == "trackingPick" :
    Locals_el = doc.createElement("Locals")
    Program_el.appendChild(Locals_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_pPick")
    Local_el.setAttribute("type", "point")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_pWaitingPos")
    Local_el.setAttribute("type", "point")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_bSentToWait")
    Local_el.setAttribute("type", "bool")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_nMoveID")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_mNomSpeedNB")
    Local_el.setAttribute("type", "mdesc")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_trPosX")
    Local_el.setAttribute("type", "trsf")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    code.write("  // Generates new part\n")
    code.write("  l_pPick=compose(pPick,fConveyor_1,{-nOffsetPick,0,0,0,0,0})\n")
    code.write("  l_trPosX = position(l_pPick,fConveyor_1)\n")
    code.write("  while(fMoving_1.trsf.x+l_pPick.trsf.x > nDistOutConvIN)\n")
    code.write("    nOffsetPick = nOffsetPick + nStepPick\n")
    code.write("    l_pPick=compose(pPick,fConveyor_1,{-nOffsetPick,0,0,0,0,0})\n")
    code.write("    l_trPosX = position(l_pPick,fConveyor_1)\n")
    code.write("    nMissedPick = nMissedPick+1\n")
    code.write("  endWhile\n")
    code.write("    // Wait until the part arrives at the origin of the frame fConveyor\n")
    code.write("    l_bSentToWait=false\n")
    code.write("    while (fMoving_1.trsf.x+l_pPick.trsf.x<0)\n")
    code.write("      if !l_bSentToWait\n")
    code.write("        link(l_pWaitingPos,fConveyor_1)\n")
    code.write("        l_pWaitingPos.trsf=position(compose(pPick,world,{0,0,nApproPick,0,0,0}),fConveyor_1)\n")
    code.write("        l_pWaitingPos.trsf.x=0\n")
    code.write("        l_pWaitingPos.config=pPick.config\n")
    code.write("        $trackOff(l_pWaitingPos,"+ SmartTrackBase.ToolName +",mNomSpeed)\n")
    code.write("      l_bSentToWait=true\n")
    code.write("    endIf\n")
    code.write("  endWhile\n")
    code.write("  // Robot moves on pPick\n")
    code.write("  l_mNomSpeedNB=mNomSpeed\n")
    code.write("  l_mNomSpeedNB.blend=off\n")
    code.write("  $trackOn(compose(l_pPick,world,{0,0,nApproPick,0,0,0})," + SmartTrackBase.ToolName + ",mNomSpeed)\n")
    if Scara :
      code.write("  $trackOn(compose(l_pPick,world,{0,0,0,0,0,0}),"+ SmartTrackBase.ToolName +",l_mNomSpeedNB)\n")
    else:
      code.write("  $movelt(compose(l_pPick,world,{0,0,0,0,0,0}),"+ SmartTrackBase.ToolName +",l_mNomSpeedNB)\n")
    code.write("    //waitEndMove()\n")
    if SmartTrackBase.RslBetween or SmartTrackBase.RslPlace:
      code.write("  l_nMoveID=$trackOff(compose(l_pPick,world,{0,0,nDepartPick,0,0,0}),"+ SmartTrackBase.ToolName +",mNomSpeed)\n")
    else:
      if Scara :
        code.write("  l_nMoveID=$trackOn(compose(l_pPick,world,{0,0,nDepartPick,0,0,0}),"+ SmartTrackBase.ToolName +",mNomSpeed)\n")
      else:
        code.write("  l_nMoveID=$movelt(compose(l_pPick,world,{0,0,nDepartPick,0,0,0}),"+ SmartTrackBase.ToolName +",mNomSpeed)\n")
    code.write("  wait(getMoveId()>l_nMoveID)\n")
    code.write("  nOffsetPick = nOffsetPick + nStepPick\n")

  # Write "trackingPlace" program
  elif routine == None and progName == "trackingPlace" :
    Locals_el = doc.createElement("Locals")
    Program_el.appendChild(Locals_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_pPlace")
    Local_el.setAttribute("type", "point")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_pWaitingPos")
    Local_el.setAttribute("type", "point")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_bSentToWait")
    Local_el.setAttribute("type", "bool")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_nMoveID")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_mNomSpeedNB")
    Local_el.setAttribute("type", "mdesc")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_trPosX")
    Local_el.setAttribute("type", "trsf")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    code.write("    // Generates new cavity\n")
    code.write("  l_pPlace=compose(pPlace,fConveyor_2,{-nOffsetPlace,0,0,0,0,0})\n")
    code.write("  l_trPosX = position(l_pPlace,fConveyor_2)\n")
    code.write("  while(fMoving_2.trsf.x+l_pPlace.trsf.x > nDistOutConvOUT)\n")
    code.write("    nOffsetPlace = nOffsetPlace + nStepPlace\n")
    code.write("    l_pPlace=compose(pPlace,fConveyor_2,{-nOffsetPlace,0,0,0,0,0})\n")
    code.write("    l_trPosX = position(l_pPlace,fConveyor_2)\n")
    code.write("    nMissedPlace = nMissedPlace+1\n")
    code.write("  endWhile\n")
    code.write("    // Wait until the part arrives at the origin of the frame fConveyor\n")
    code.write("    l_bSentToWait=false\n")
    code.write("    while (fMoving_2.trsf.x+l_pPlace.trsf.x<0)\n")
    code.write("      if !l_bSentToWait\n")
    code.write("        link(l_pWaitingPos,fConveyor_2)\n")
    code.write("        l_pWaitingPos.trsf=position(compose(pPlace,world,{0,0,nApproPlace,0,0,0}),fConveyor_2)\n")
    code.write("        l_pWaitingPos.trsf.x=0\n")
    code.write("        l_pWaitingPos.config=pPlace.config\n")
    code.write("        $trackOff(l_pWaitingPos,"+ SmartTrackBase.ToolName +",mNomSpeed)\n")
    code.write("        l_bSentToWait=true\n")
    code.write("      endIf\n")
    code.write("    endWhile\n")
    code.write("    // Robot moves on pPlace\n")
    code.write("    l_mNomSpeedNB=mNomSpeed\n")
    code.write("    l_mNomSpeedNB.blend=off\n")
    code.write("    $trackOn(compose(l_pPlace,world,{0,0,nApproPlace,0,0,0}),"+ SmartTrackBase.ToolName +",mNomSpeed)\n")
    if Scara :
      code.write("  $trackOn(compose(l_pPlace,world,{0,0,0,0,0,0}),"+ SmartTrackBase.ToolName +",l_mNomSpeedNB)\n")
    else:
      code.write("  $movelt(compose(l_pPlace,world,{0,0,0,0,0,0}),"+ SmartTrackBase.ToolName +",l_mNomSpeedNB)\n")
    code.write("    //waitEndMove()\n")
    if SmartTrackBase.RslPick:
      code.write("  l_nMoveID=$trackOff(compose(l_pPlace,world,{0,0,nDepartPlace,0,0,0}),"+ SmartTrackBase.ToolName +",mNomSpeed)\n")
    else:
      if Scara :
        code.write("  l_nMoveID=$trackOn(compose(l_pPlace,world,{0,0,nDepartPlace,0,0,0}),"+ SmartTrackBase.ToolName +",mNomSpeed)\n")
      else:
        code.write("  l_nMoveID=$movelt(compose(l_pPlace,world,{0,0,nDepartPick,0,0,0}),"+ SmartTrackBase.ToolName +",mNomSpeed)\n")
    code.write("    wait(getMoveId()>l_nMoveID)\n")
    code.write("  nOffsetPlace=nOffsetPlace + nStepPlace\n")
  
  # Write "timer" program
  elif routine == None and progName == "timer" :
    
    # Create Parameters variables
    Params_el = doc.createElement("Parameters")
    Params_el.setAttribute("xmlns", "http://www.staubli.com/robotics/VAL3/Param/1")
    Program_el.appendChild(Params_el)
    Param_el = doc.createElement("Parameter")
    Param_el.setAttribute("name", "x_sTimeName")
    Param_el.setAttribute("type", "string")
    Param_el.setAttribute("xsi:type ", "element")
    Params_el.appendChild(Param_el)

    if (isCS9) : 
      code.write("  // Store time since start of this main cycle.\n")
      code.write("  nTimer[nIndex] = clock() - nCycleStartClk\n")
      code.write("  \n")
      code.write("  if nLoop == 0 and nIndex >= size(sTimer0)\n")
      code.write("    bStepTimeShow = false\n")
      code.write("    sUserMessage=\"Warning: More than\" + toString(\"\", size(sTimer0)) + \" timestamps\"\n")
      code.write("  else\n")
      code.write("    bStepTimeShow = true\n")
      code.write("  endIf\n")
      code.write("  \n")
      code.write("  if bStepTimeShow\n")
      code.write("    // e.g. T13 abs: 10.21 dT: 0.32 move 12 done\n")
      code.write("    sTimer0[nIndex]= \"T\" + toString(\"\", nIndex) + \" abs:\" + toString(\".2\", nTimer[nIndex]) + \" dT:\" + toString(\".2\", clock() - nStartClock) + \" \" + x_sTimeName\n")
      code.write("  endIf\n")
      code.write("  \n")
      code.write("  // Measures time since previous timer call.\n")
      code.write("  nStartClock = clock()\n")
      code.write("  nIndex = nIndex + 1\n")
    else :
      Locals_el = doc.createElement("Locals")
      Program_el.appendChild(Locals_el)
      Local_el = doc.createElement("Local")
      Local_el.setAttribute("name", "l_nA")
      Local_el.setAttribute("type", "num")
      Local_el.setAttribute("xsi:type ", "array")
      Local_el.setAttribute("size", "1")
      Locals_el.appendChild(Local_el)

      code.write("  if nIndex >= min(size(nTimer), size(sTimer0))\n")
      code.write("    sUserMessage=\"Warning: More than \" + toString(\"\", min(size(nTimer), size(sTimer0))) + \" timestamps\"\n")
      code.write("  else\n")
      code.write("    nTimer[nIndex] = clock()-nStartClock\n")
      code.write("    // e.g. T13 abs: 10.21 dT: 0.32 move 12 done\n")
      code.write("    sTimer0[nIndex]= \"T\" + toString(\"\", nIndex) + \" abs:\" + toString(\".2\", nTimer[nIndex]) + \" dT:\" + toString(\".2\", clock() - nStartClock) + \" \" + x_sTimeName\n")
      code.write("    // calculate to which timestamp screen this line goes\n")
      code.write("    l_nA = roundDown(nIndex/13)\n")
      code.write("    putln(sStepTime[l_nA], sTimer0[nIndex])\n")
      code.write("    nStartClock=clock()\n")
      code.write("    nIndex=nIndex+1\n")
      code.write("  endIf\n")

  elif routine == None and progName == "taskOfTimer" :
    Locals_el = doc.createElement("Locals")
    Program_el.appendChild(Locals_el)
    Local_el = doc.createElement("Local")
    Local_el.setAttribute("name", "l_nMoveID")
    Local_el.setAttribute("type", "num")
    Local_el.setAttribute("xsi:type ", "array")
    Local_el.setAttribute("size", "1")
    Locals_el.appendChild(Local_el)
    code.write("  //init\n")
    code.write("  l_nMoveID=1\n")
    code.write("  // start timer\n")
    code.write("  wait(getMoveId()>0)\n")
    code.write("  nStartClock=clock()\n")
    code.write("  do\n")
    code.write("    wait(getMoveId()>=l_nMoveID+1)\n")
    code.write("    call timer(\"move \" + toString(\"\", l_nMoveID) + \" done\")\n")
    code.write("    //reset MoveID\n")
    code.write("    l_nMoveID=l_nMoveID+1\n")
    code.write("    delay(0)\n")
    code.write("  until false\n")
  
  # Write RSL routines
  else:
    
    # Indentation depth
    depth = 1
    
    # Convert all statements of the routine, including sub scopes
    writeStatementsInScope(code, routine, routine)

    # Finish movements in the routine before exiting
    if USE_SYNCHRONOUS_MOVEMENT:
      code.write(indent*depth + "waitEndMove()\n")

  if progName == "start" and executor.IsLooping == True:
    code.write("  \n")
  
  code.write("end")
  
  # Finish program 
  Code_el = doc.createElement("Code")
  Program_el.appendChild(Code_el)
  CodeBody = doc.createCDATASection(code.getvalue())
  code.close()
  Code_el.appendChild(CodeBody)
  # Write XML document to a file
  xml_document = doc.toprettyxml(indent='  ')
  xml_document = xml_document.replace("<?xml version=\"1.0\" ?>", "<?xml version=\"1.0\" encoding=\"utf-8\"?>")
  xml_document = xml_document.replace("<Code>\n", "<Code>")
  program.write(xml_document)
  program.close
  return
# end

# Writes all statements in the scope and sub scopes to the "code" stream
def writeStatementsInScope(code, routine, scope):

  for statement in scope.Statements:
    translator = statement_translators.get(statement.Type, unknownStatement)
    translator(code, routine, statement)

    # Write waitEndMove after previously identified statements that need it.
    if USE_SYNCHRONOUS_MOVEMENT and statement in wem_statements:
      code.write(indent*depth + "waitEndMove()\n")

# Creates an array "data" element 
def createDataElement(doc, type, name, size):
  Data_el = doc.createElement("Data")
  Data_el.setAttribute("name", name)
  Data_el.setAttribute("access", "private")
  Data_el.setAttribute("type", type)
  Data_el.setAttribute("xsi:type ", "array") 
  Data_el.setAttribute("size", size)
  return Data_el

# Creates a collection "data" element 
def createCollectionDataElement(doc, dataType, name):
  Data_el = doc.createElement("Data")
  Data_el.setAttribute("name", name)
  Data_el.setAttribute("access", "private")
  Data_el.setAttribute("type", dataType)
  Data_el.setAttribute("xsi:type ", "collection") 
  return Data_el

# Creates a value element for a tool
def createToolValueElement(doc, tool):
  Value_el = doc.createElement("Value")
  Value_el.setAttribute("key", "0")
  Value_el.setAttribute("x", "%s" % tool.x)
  Value_el.setAttribute("y", "%s" % tool.y)
  Value_el.setAttribute("z", "%s" % tool.z)
  Value_el.setAttribute("rx", "%s" % tool.Rx)
  Value_el.setAttribute("ry", "%s" % tool.Ry)
  Value_el.setAttribute("rz", "%s" % tool.Rz)
  Value_el.setAttribute("fatherId", "flange[0]")
  return Value_el
# end

# Creates a value element for a point
def createPointValueElement(doc, point):
  Value_el = doc.createElement("Value")
  Value_el.setAttribute("key", "0")
  Value_el.setAttribute("x", "%s" % point.x)
  Value_el.setAttribute("y", "%s" % point.y)
  Value_el.setAttribute("z", "%s" % point.z)
  Value_el.setAttribute("rx", "%s" % point.Rx)
  Value_el.setAttribute("ry", "%s" % point.Ry)
  Value_el.setAttribute("rz", "%s" % point.Rz)
  if point.RefFrameName == "fConveyor_1" and CONVEYOR_TRACKING_ENABLED:
    Value_el.setAttribute("fatherId", "fMoving_1" + "[0]")
  elif point.RefFrameName == "fConveyor_2" and CONVEYOR_TRACKING_ENABLED:
    Value_el.setAttribute("fatherId", "fMoving_2" + "[0]")
  else : 
    Value_el.setAttribute("fatherId", point.RefFrameName + "[0]")
  Value_el.setAttribute("shoulder", "ssame")
  
  # Scara configuration doesn't have elbow nor wrist parameters
  if Scara == True:
    return Value_el
  Value_el.setAttribute("elbow", "esame")
  Value_el.setAttribute("wrist", "wsame")
  return Value_el
# end

# Creates a value element for a joint
def createJointValueElement(doc, joint):
  Value_el = doc.createElement("Value")
  Value_el.setAttribute("key", "0")
  Value_el.setAttribute("j1", "%s" % joint.j1)
  Value_el.setAttribute("j2", "%s" % joint.j2)
  Value_el.setAttribute("j3", "%s" % joint.j3)
  Value_el.setAttribute("j4", "%s" % joint.j4)

  # Scara configuration doesn't have elbow nor wrist parameters
  if Scara == True:
    return Value_el
  Value_el.setAttribute("j5", "%s" % joint.j5)
  Value_el.setAttribute("j6", "%s" % joint.j6)
  return Value_el
# end

# Creates a value element for a frame
def createFrameValueElement(doc, frame):
  Value_el = doc.createElement("Value")
  Value_el.setAttribute("key", "0")
  Value_el.setAttribute("x", "%s" % frame.x)
  Value_el.setAttribute("y", "%s" % frame.y)
  Value_el.setAttribute("z", "%s" % frame.z)
  Value_el.setAttribute("rx", "%s" % frame.Rx)
  Value_el.setAttribute("ry", "%s" % frame.Ry)
  Value_el.setAttribute("rz", "%s" % frame.Rz)
  Value_el.setAttribute("fatherId", "world[0]")
  return Value_el
# end

# Creates a basic value element with key only
def createValueElement(doc, key):
  Value_el = doc.createElement("Value")
  Value_el.setAttribute("key", str(key))
  return Value_el
# end

# Creates a numerical value element
def createValueElementWithValue(doc, key, value):
  Value_el = doc.createElement("Value")
  Value_el.setAttribute("key", str(key))
  Value_el.setAttribute("value", str(value))
  return Value_el
# end

# Creates an IO value element
def createIOValueElement(doc, io):
  Value_el = doc.createElement("Value")
  Value_el.setAttribute("key", "0")
  Value_el.setAttribute("link", io.CS8Signal)
  return Value_el
# end

# Saves a tool data
def getToolData(statement):
  global motiontarget, tools
  
  if statement.Type == VC_STATEMENT_LINMOTION or statement.Type == VC_STATEMENT_PTPMOTION:
    statement.writeToTarget(motiontarget)
    tName = motiontarget.ToolName
    tName = parseVariableName(tName)
    
    if tName == "":
      tName = "tDefault"

    for t in tools:
      if t.Name == tName:
        return

    t = Tool()
    t.Name = tName
    
    # Check tool name validity in VAL 3
    if not isValidVariableName(tName):
      # Warning: Tool name '%s' is not valid for VAL 3 application.
      writeWarningMessage("StaubliPPWarningInvalidToolName", [tName])

    if tName == "tDefault":
      t.x = 0
      t.y = 0
      t.z = 0
      t.Rx = 0
      t.Ry = 0
      t.Rz = 0
      tools.append(t)
    else:
      # Get baseframe object
      for i in executor.Controller.Tools:
        if i.Name == motiontarget.ToolName:
          # If the frame position is relative to some other node but the robot
          if i.Node.Name != "mountplate" and i.Node.Name != "mountFrame":
            i.Node.update()
            mp = executor.Controller.Component.findNode("mountplate")
            nodechain = []
            node = i.Node
            fmatrix = vcMatrix.new(mp.PositionMatrix)   
            
            # Get the chain of nodes to perform matrix transformations        
            while node != mp:
              nodechain.append(node)
              node = node.Parent
            # endwhile
            nodechain.reverse()
            index = 0
            for j in nodechain:
              fmatrix = fmatrix * j.PositionMatrix
            # endfor
            fmatrix = fmatrix * motiontarget.ToolMatrix
            if Scara:
              fmatrix.rotateAbsX(180)
            t.x = fmatrix.P.X
            t.y = fmatrix.P.Y
            t.z = fmatrix.P.Z
            orientation = transformOrientation(fmatrix)
            t.Rx = orientation[0]
            t.Ry = orientation[1]
            t.Rz = orientation[2]
            tools.append(t) 
          else:
            t.x = motiontarget.ToolMatrix.P.X
            t.y = motiontarget.ToolMatrix.P.Y
            t.z = motiontarget.ToolMatrix.P.Z
            # Transform Rx, Ry, Rz values
            orientation = transformOrientation(motiontarget.ToolMatrix)
            t.Rx = orientation[0]
            t.Ry = orientation[1]
            t.Rz = orientation[2]
            tools.append(t)
          # endif
        # endif
      # endfor
    # endif
  return
# end

# Saves a point data
def createPointData(name, father, trsf, config):
  global  points, executor,Scara
  # Create the point
  p = Point()
  p.Name = name
  p.RefFrameName = father
  p.x = trsf[0]
  p.y = trsf[1]
  p.z = trsf[2]
  p.Rx = trsf[3]
  p.Ry = trsf[4]
  p.Rz = trsf[5]
  p.shoulder = "ssame"
  if not Scara:
    p.elbow = "esame"
    p.wrist = "wsame"
  points.append(p)

# Saves a point data from statement
def getPointData(statement):
  global motiontarget, points, executor
  configName=[]
  
  if statement.Type == VC_STATEMENT_LINMOTION or statement.Type == VC_STATEMENT_PTPMOTION:
    statement.writeToTarget(motiontarget)
     # Name the point according to the statement
    pName = statement.Positions[0].Name

    # Get base i.e. reference frame of the point
    bName = motiontarget.BaseName  
    bName = parseVariableName(bName)
    if bName == "":
      bName = "fDefault"
    
    # Check that point with same name doesn't exist already.
    for p in points:
      if p.Name == pName:
        return

    if not isValidVariableName(pName):
      # Warning: Point name '%s' is not valid for use in a VAL 3 program.
      writeWarningMessage("StaubliPPWarningInvalidPointName", [pName])

    # Create the point
    p = Point()
    p.Name = pName
    p.RefFrameName = bName
    p.x = motiontarget.Target.P.X
    p.y = motiontarget.Target.P.Y
    p.z = motiontarget.Target.P.Z 

    # Transform Rx, Ry, Rz values
    orientation = transformOrientation(motiontarget.Target)
    p.Rx = orientation[0]
    p.Ry = orientation[1]
    p.Rz = orientation[2]

    # Get the configuration
    config = motiontarget.RobotConfig
    configName = ConfigurationsList[config]
    defineConfig(p, config, configName)
    points.append(p)

# Saves a Joint data
def createJointData(name,jValues):
  global  joints, executor
  j = Joint()
  j.Name = jName
  #motiontarget.Joint1.Value
  j.j1 = jValues[0]
  j.j2 = jValues[1]
  j.j3 = jValues[2]
  j.j4 = jValues[3]
  if Scara == False:
    j.j5 = jValues[4]
    j.j6 = jValues[5]
  joints.append(j)

# Saves a Joint data from statement
def getJointData(statement):
  global motiontarget, joints, executor
  configName=[]
  if statement.Type == VC_STATEMENT_LINMOTION or statement.Type == VC_STATEMENT_PTPMOTION:
    statement.writeToTarget(motiontarget)
    position = statement.Positions[0]
    
    # Name the Joint according to the statement
    jName = "j" + position.Name
    
    for j in joints:
      if j.Name == jName:
        return

    if not isValidVariableName(jName):
      # Warning: Point name '%s' is not valid for use in a VAL 3 program.
      writeWarningMessage("StaubliPPWarningInvalidPointName", [jName])

    # Create the Joint
    j = Joint()
    j.Name = jName
    #motiontarget.Joint1.Value
    j.j1 = position.JointValues[0]
    j.j2 = position.JointValues[1]
    j.j3 = position.JointValues[2]
    j.j4 = position.JointValues[3]
    if Scara == False:
      j.j5 = position.JointValues[4]
      j.j6 = position.JointValues[5]
    joints.append(j)

# Defines a configuration
def defineConfig(p, config, configName):
  if Scara == True:
    if config == 0:
      p.shoulder = "lefty"
      return
    # endif
    if config == 1:
      p.shoulder = "righty"
      return
    # endif
  # endif    
  if "L++" in configName or "lefty epositive wpositive" in configName or "LEFTY ABOVE NOFLIP" in configName:
    p.shoulder = "lefty"
    p.elbow = "epositive"
    p.wrist =  "wpositive"
    return
  # endif

  if "L+-" in configName or "lefty epositive wnegative" in configName or "LEFTY ABOVE FLIPPED" in configName:
    p.shoulder = "lefty"
    p.elbow = "epositive"
    p.wrist =  "wnegative"
    return
  # endif

  if "L-+" in configName or "lefty enegative wpositive" in configName or "LEFTY BELOW NOFLIP" in configName:
    p.shoulder = "lefty"
    p.elbow = "enegative"
    p.wrist =  "wpositive"
    return
  # endif

  if "L--" in configName or "lefty enegative wnegative" in configName or "LEFTY BELOW FLIPPED" in configName:
    p.shoulder = "lefty"
    p.elbow = "enegative"
    p.wrist =  "wnegative"
    return
  # endif

  if "R-+" in configName or "righty epositive wpositive" in configName or "RIGHTY BELOW NOFLIP" in configName:
    p.shoulder = "righty"
    p.elbow = "enegative"
    p.wrist =  "wpositive"
    return
  # endif

  if "R--" in configName or "righty epositive wnegative" in configName or "RIGHTY BELOW FLIPPED" in configName:
    p.shoulder = "righty"
    p.elbow = "enegative"
    p.wrist =  "wnegative"
    return
  # endif

  if "R++" in configName or "righty enegative wpositive" in configName or "RIGHTY ABOVE NOFLIP" in configName:
    p.shoulder = "righty"
    p.elbow = "epositive"
    p.wrist =  "wpositive"
    return
  # endif

  if "R+-" in configName or "righty enegative wnegative" in configName or "RIGHTY ABOVE FLIPPED" in configName:
    p.shoulder = "righty"
    p.elbow = "epositive"
    p.wrist =  "wnegative"
    return
  # endif
# end

# Collects unique motion description parameter sets from motion statements
def getMotionData(statement):
  global motionDescriptions

  if statement.Type != VC_STATEMENT_LINMOTION and statement.Type != VC_STATEMENT_PTPMOTION:
    return

  mDesc = MotionDescription(statement)
  existingDesc = next(ifilter(lambda d: d == mDesc, motionDescriptions), None) 

  if existingDesc == None:
    mDesc.VariableIndex = len(motionDescriptions)
    motionDescriptions.append(mDesc)
    existingDesc = mDesc
  
  # Store which description should be used for this statement
  # Can't use a dictionary because vcStatement is not a hashable type
  existingDesc.Statements.append(statement)

# Create base data for tracking (frame)
def createBasesTrackingData():
  global motiontarget, bases

  # Get baseframe object
  for i in executor.Controller.Bases:
    # Create a new base for VAL3
    b = Base()
     
    b.Name = i.Name 
    if "fConveyor" in i.Name:
      
      # If the frame position is relative to some other node but the robot
      if i.Node != None:
        i.Node.update()
        executor.Controller.Component.update()
        fmatrix = vcMatrix.new()
        offset = motiontarget.getRootNodeToRobotRoot()
        # Transform to world coordinate system
        tmp = vcMatrix.new()
        tmp.WPR = vcVector.new(executor.Component.WorldPositionMatrix.WPR)
        tmp.P = vcVector.new(0,0,0)
        tmp.invert()
        tmp = tmp*offset
        offset.P = tmp.P
        # Calculate the robot origin in reference to world
        offset.invert()
        rworld = offset*executor.Component.WorldPositionMatrix
        # Calculate in reference to the node
        rworld.invert()
        fmatrix =  rworld*i.Node.WorldPositionMatrix 
        # Calculate base tranformation
        fmatrix = fmatrix * motiontarget.BaseMatrix
        b.x = fmatrix.P.X
        b.y = fmatrix.P.Y
        b.z = fmatrix.P.Z
        orientation = transformOrientation(fmatrix)
        b.Rx = orientation[0]
        b.Ry = orientation[1]
        b.Rz = orientation[2]
        frames.append(b) 
      else:
        b.x = i.PositionMatrix.P.X
        b.y = i.PositionMatrix.P.Y
        b.z = i.PositionMatrix.P.Z
        # Transform Rx, Ry, Rz values
        orientation = transformOrientation(motiontarget.BaseMatrix)
        b.Rx = i.PositionMatrix.WPR.X
        b.Ry = i.PositionMatrix.WPR.Y
        b.Rz = i.PositionMatrix.WPR.Z
        frames.append(b)

# Read base data (frame)  
def getBaseData(statement):
  global motiontarget, bases
  if statement.Type == VC_STATEMENT_LINMOTION or statement.Type == VC_STATEMENT_PTPMOTION:
    statement.writeToTarget(motiontarget)
    bName = parseVariableName(motiontarget.BaseName)
    
    if bName == "":
      bName = "fDefault"

    #  Check if the base has been read
    for b in frames:
      if b.Name == bName:
        return

    if not isValidVariableName(bName):
      # Warning: Base name '%s' is not valid for use in a VAL 3 program.
      writeWarningMessage("StaubliPPWarningInvalidBaseName", [bName])

    # Create a new base for VAL3
    b = Base()
    b.Name = bName  
    # Create a frame with default values
    if bName == "fDefault":
      b.x = 0
      b.y = 0
      b.z = 0
      b.Rx = 0
      b.Ry = 0
      b.Rz = 0
      frames.append(b)
    else:
      # Get baseframe object
      for i in executor.Controller.Bases:
        if i.Name == motiontarget.BaseName:
          # If the frame position is relative to some other node but the robot
          if i.Node != None:
            i.Node.update()
            executor.Controller.Component.update()
            fmatrix = vcMatrix.new()
            offset = motiontarget.getRootNodeToRobotRoot()
            # Transform to world coordinate system
            tmp = vcMatrix.new()
            tmp.WPR = vcVector.new(executor.Component.WorldPositionMatrix.WPR)
            tmp.P = vcVector.new(0,0,0)
            tmp.invert()
            tmp = tmp*offset
            offset.P = tmp.P
            # Calculate the robot origin in reference to world
            offset.invert()
            rworld = offset*executor.Component.WorldPositionMatrix
            # Calculate in reference to the node
            rworld.invert()
            fmatrix =  rworld*i.Node.WorldPositionMatrix 
            # Calculate base tranformation
            fmatrix = fmatrix * motiontarget.BaseMatrix
            b.x = fmatrix.P.X
            b.y = fmatrix.P.Y
            b.z = fmatrix.P.Z
            orientation = transformOrientation(fmatrix)
            b.Rx = orientation[0]
            b.Ry = orientation[1]
            b.Rz = orientation[2]
            frames.append(b) 
          else:
            b.x = motiontarget.BaseMatrix.P.X
            b.y = motiontarget.BaseMatrix.P.Y
            b.z = motiontarget.BaseMatrix.P.Z
            # Transform Rx, Ry, Rz values
            orientation = transformOrientation(motiontarget.BaseMatrix)
            b.Rx = orientation[0]
            b.Ry = orientation[1]
            b.Rz = orientation[2]
            frames.append(b)
  return

# Cleans up the given string 
def parseVariableName(Name):
  name = Name.replace('[', '')
  name = Name.replace(']', '')
  name = Name.replace(' ', '')
  return name

# Recursive method for finding statements that should be followed by waitEndMove instruction.
# Considers sub scopes but doesn't follow routine calls.
def findWaitEndMoveStatements(statementScope, resultList):

  movementTypes = [VC_STATEMENT_LINMOTION, VC_STATEMENT_PTPMOTION]
  isMoveStatement = lambda s: s.Type in movementTypes

  if len(statementScope.Statements) == 0:
    return

  # Add end of continuous block of move statements but allow comments in between
  # move statements
  previousMove = None
  for statement in statementScope.Statements:

    if (previousMove != None and (not statement.Type in movementTypes)
        and statement.Type != VC_STATEMENT_COMMENT):
      resultList.append(previousMove)
      previousMove = None
      
    if statement.Type in movementTypes:
      previousMove = statement

  # Handle statements with sub scopes and returning from routine calls
  for statement in statementScope.Statements:
    hasMotionStatements = False

    # Add if-else statement if it contains motion statements and handle sub scopes
    if statement.Type == VC_STATEMENT_IF:
      
      if (statement.ThenScope):
        findWaitEndMoveStatements(statement.ThenScope, resultList)
        hasMotionStatements = (hasMotionStatements or
                               any(isMoveStatement(s) for s in statement.ThenScope.Statements))
      
      if (statement.ElseScope):
        findWaitEndMoveStatements(statement.ElseScope, resultList)
        hasMotionStatements = (hasMotionStatements or
                               any(isMoveStatement(s) for s in statement.ElseScope.Statements))

    # All scope statements such as VC_STATEMENT_WHILE
    elif hasattr(statement, 'Scope') and statement.Scope != None:
      # Add scope statement if it contains motion statements and handle sub scopes
      findWaitEndMoveStatements(statement.Scope, resultList)
      hasMotionStatements = (hasMotionStatements or
                             any(isMoveStatement(s) for s in statement.Scope.Statements))

    if hasMotionStatements or statement.Type == VC_STATEMENT_CALL:
      resultList.append(statement)

def transformOrientation(vc_matrix):
  RAD_TO_DEG = 57.296779513082320876798154814105
  
  # Avoid precision errors
  if vc_matrix.A.X > 1.0:
    pitch = asin(1)
  else:
    pitch = asin( vc_matrix.A.X)
  # endif  
  cos_p = cos( pitch )
  TCP_P = pitch * RAD_TO_DEG
  if abs(cos_p) > 0.0001:
    TCP_W = atan2( -vc_matrix.A.Y/cos_p, vc_matrix.A.Z/cos_p ) * RAD_TO_DEG
    TCP_R = atan2( -vc_matrix.O.X/cos_p, vc_matrix.N.X/cos_p ) * RAD_TO_DEG
    if abs(TCP_R) > 90.0 and abs(TCP_W) > 90.:
      if TCP_P < 0.0:
        TCP_P = -180. - TCP_P
      else: 
        TCP_P = 180. - TCP_P
      cos_p = cos( TCP_P/RAD_TO_DEG )
      TCP_W = atan2( -vc_matrix.A.Y/cos_p, vc_matrix.A.Z/cos_p ) * RAD_TO_DEG
      TCP_R = atan2( -vc_matrix.O.X/cos_p, vc_matrix.N.X/cos_p ) * RAD_TO_DEG
  else:
    TCP_W = 0.0
    TCP_R = atan2( vc_matrix.N.Y, vc_matrix.O.Y ) * RAD_TO_DEG
  return [TCP_W, TCP_P, TCP_R]


def getConfigNames(executor):
  controller = executor.Controller
  robotconfigs = []
  routine = executor.Program.MainRoutine
  controller.clearTargets()
  motiontarget = controller.createTarget()
  robotconfig = motiontarget.RobotConfig
  motiontarget.TargetMode = VC_MOTIONTARGET_TM_NORMAL
  dummyStatement = routine.addStatement(VC_STATEMENT_PTPMOTION)
  for prop in dummyStatement.Positions[0].Properties:
    if prop.Name == 'Configuration':
      break
    else:
      prop = None
  if prop == None:
    robotconfigs = ['Config1', 'Config2', 'Config3', 'Config4', 'Config5', 'Config6', 'Config7', 'Config8']
  else:
    for config in prop.StepValues:
      robotconfigs.append( config )
  controller.clearTargets()
  routine.deleteStatement( dummyStatement )
  return robotconfigs

# Add all command states
addState( first_state )
