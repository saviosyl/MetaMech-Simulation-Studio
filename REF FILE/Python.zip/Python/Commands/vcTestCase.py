import unittest

class vcTestCase(unittest.TestCase):
    m_app = None

    @staticmethod
    def setApplication(app):
        global m_app
        m_app = app

    def getApplication(self):
        return m_app
